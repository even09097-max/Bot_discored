"""
قواعد اللعبة + محرك القتال بالأدوار.

هذا الملف لا يعتمد على discord ولا على قاعدة البيانات، لذلك يمكن اختباره
مباشرة (انظر simulate.py و test_core.py). كل أرقام الموازنة في الأعلى لتعديلها بسهولة.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field

import cards as cd
import hatsu as ht


class GameError(Exception):
    """خطأ متوقع برسالة عربية تُعرض للاعب كما هي."""


# ───────────────────────── ثوابت البرج ─────────────────────────
MAX_FLOOR = 100                # 100 طابق (كانت 251): كل طابق حلبة قتال وسيطرة
NEN_UNLOCK_FLOOR = 20
MASTER_FLOOR_START = 90        # طوابق الأسياد 90-99
MASTER_FLOOR_END = 99
BOSS_FLOOR = 100
ECHO_FLOOR_PCT = 0.85          # ظل المسيطر لا يقل عن 85% من خصم الطابق المعتاد
ECHO_CAP = 1.6                 # ولا يزيد عن 160% منه (حتى لا يستحيل تجاوز مسيطر تجاوز طابقه بكثير)
LIVE_CHALLENGE_SECONDS = 30    # مهلة قبول التحدي المباشر من المسيطر المتصل
ONLINE_WINDOW = 300            # يُعدّ اللاعب متصلاً إن تفاعل مع البوت خلال آخر 5 دقائق
REVENGE_HOURS = 48             # مدة صلاحية «سجل الانتقام»
REVENGE_BONUS_GOLD = 1.5       # مضاعف ذهب انتصار الانتقام

# ───────────────────────── التطوير ─────────────────────────
POINTS_PER_LEVEL = 3
LEVEL_HP_BONUS = 5
POINT_VALUE = {"atk": 2, "def": 1, "hp": 10, "speed": 1}
STAT_LABELS = {"atk": "⚔️ الهجوم", "def": "🛡️ الدفاع", "hp": "❤️ الصحة", "speed": "💨 السرعة"}

# ───────────────────────── الراحة والعقوبات ─────────────────────────
MIN_HP_PCT_TO_CLIMB = 0.40     # لا يمكن الصعود بأقل من 40% صحة
REGEN_PCT_PER_MIN = 0.10       # استعادة 10% من الصحة كل دقيقة
LOSS_GOLD_PCT = 0.10           # خسارة 10% من الذهب عند الهزيمة
LOSS_HP_PCT = 0.25             # بعد الهزيمة تبقى 25% من الصحة

# ───────────────────────── الاقتصاد ─────────────────────────
GACHA_GOLD_COST = 300
GACHA_GEM_COST = 10
PITY_LIMIT = 20                # ضمان عنصر ملحمي أو أعلى كل 20 سحبة
REROLL_GEM_COST = 100
DAILY_GOLD = 200
DAILY_GEMS = 5

# ───────────────────────── القتال ─────────────────────────
AURA_REGEN = 6
GUARD_AURA = 8
GUARD_REDUCTION = 0.5
SHIELD_ABSORB = 0.70
DEF_SCALE = 2.0                # تخفيض الضرر = 100 / (100 + DEF_SCALE * الدفاع)
AFFINITY_BONUS = 1.25
AFFINITY_PENALTY = 0.80
MAX_ROUNDS = 60

# منحنى قوة الخصوم حسب الطابق (يُضبط بواسطة simulate.py)
ENEMY_CURVE = {            # أُعيد ضبطها لـ100 طابق (= المنحنى القديم ×2.51 لنفس قوة القمة)
    "hp": (40.0, 8.0),
    "atk": (4.5, 1.75),
    "def": (3.0, 0.5),
    "speed": (8.0, 0.25),
}
MASTER_MULT = 1.05
BOSS_MULT = 1.2

# ───────────────────────── فئات النين ─────────────────────────
NEN = {
    "enhancer": {
        "name": "التعزيز", "emoji": "💪", "skill": "ضربة التعزيز", "cost": 20,
        "desc": "تضاعف هجوم ضربتك القادمة ×3.",
        "water": "ازداد منسوب الماء في الكأس!",
    },
    "transmuter": {
        "name": "التحويل", "emoji": "🧪", "skill": "سمّ الشلل", "cost": 20,
        "desc": "ضرر خفيف + تشلّ الخصم دوراً واحداً + سم لـ3 أدوار.",
        "water": "تغيّر طعم الماء!",
    },
    "conjurer": {
        "name": "التجسيد", "emoji": "🔮", "skill": "درع الهالة", "cost": 20,
        "desc": "درع يمتص 70% من الضرر القادم لهجومين.",
        "water": "ظهرت شوائب في الماء!",
    },
    "emitter": {
        "name": "الإرسال", "emoji": "🚀", "skill": "كرة الهالة", "cost": 20,
        "desc": "هجوم طاقة قوي يتجاهل دفاع الخصم.",
        "water": "تغيّر لون الماء!",
    },
    "manipulator": {
        "name": "التلاعب", "emoji": "🎭", "skill": "عكس الهجوم", "cost": 20,
        "desc": "تعكس الهجوم القادم على صاحبه وتسلبه جزءاً من طاقته.",
        "water": "تحركت الورقة من تلقاء نفسها!",
    },
    "specialist": {
        "name": "التخصص", "emoji": "🃏", "skill": "سرقة المهارة", "cost": 25,
        "desc": "تسرق مهارة خصمك وتستخدمها مرة واحدة في القتال.",
        "water": "حدث شيء غريب لم يُرَ من قبل!",
    },
}
NEN_WEIGHTS = {"enhancer": 20, "transmuter": 18, "conjurer": 18,
               "emitter": 18, "manipulator": 16, "specialist": 10}

# كل فئة تتفوق على التي بعدها وتضعف أمام التي قبلها (المتخصص محايد)
ADVANTAGE = {
    "enhancer": "transmuter", "transmuter": "conjurer", "conjurer": "manipulator",
    "manipulator": "emitter", "emitter": "enhancer",
}


def normalize_nen(value) -> str | None:
    """يحوّل القيمة المخزنة (قديمة أو جديدة) إلى مفتاح فئة أو None."""
    if not value or value == "None":
        return None
    v = str(value).lower()
    for key in NEN:
        if key in v:
            return key
    return None


def nen_label(key: str | None) -> str:
    if not key:
        return "لم تُفتح بعد"
    return f"{NEN[key]['emoji']} {NEN[key]['name']}"


def roll_nen(rng: random.Random) -> str:
    keys = list(NEN_WEIGHTS)
    return rng.choices(keys, [NEN_WEIGHTS[k] for k in keys])[0]


def affinity(att: str | None, dfn: str | None) -> float:
    if not att or not dfn:
        return 1.0
    if ADVANTAGE.get(att) == dfn:
        return AFFINITY_BONUS
    if ADVANTAGE.get(dfn) == att:
        return AFFINITY_PENALTY
    return 1.0


# ───────────────────────── المستوى والمكافآت ─────────────────────────
def xp_needed(level: int) -> int:
    return 100 + 40 * (level - 1)


def max_aura_for(level: int) -> int:
    return 50 + level // 2


def floor_rewards(floor: int, rng: random.Random) -> tuple[int, int]:
    gold = int((75 + 20 * floor) * rng.uniform(0.9, 1.1))
    xp = 50 + 25 * floor
    return gold, xp


def floor_tier(floor: int) -> str:
    if floor >= BOSS_FLOOR:
        return "👑 بطل البرج"
    if floor >= MASTER_FLOOR_START:
        return "🏯 سيد الطابق"
    if floor >= NEN_UNLOCK_FLOOR:
        return "🌀 مرحلة النين"
    return "🌱 المبتدئون"


# ───────────────────────── المقاتل ─────────────────────────
@dataclass
class Fighter:
    name: str
    hp: int
    max_hp: int
    atk: int
    defense: int
    speed: int
    nen: str | None = None
    aura: int = 0
    max_aura: int = 0
    is_player: bool = False
    # حالات مؤقتة
    atk_mult_next: float = 1.0
    shield_turns: int = 0
    reflect_turns: int = 0
    stun_turns: int = 0
    poison_turns: int = 0
    poison_dmg: int = 0
    guarding: bool = False
    stolen_used: bool = False
    no_guard: bool = False      # نذر: لا تحصّن
    no_skill: bool = False      # نذر: لا مهارات نين
    emoji: str = ""
    sig_name: str = ""          # ضربة مميزة كل 3 جولات (للأسياد والزعماء)
    sig_mult: float = 0.0
    rage_mult: float = 0.0      # غضب عند أقل من 50% صحة
    raged: bool = False
    look: str = ""              # مفتاح الشكل المرسوم (زعيم/نمط خصم)
    team: list = field(default_factory=list)   # بطاقات الفريق (cards.team_fighters) — للاعب فقط
    assist_cd: int = 0                          # جولات متبقية قبل «نداء الفريق» التالي
    # ── هاتسو وشجرة النين والعتاد ──
    hatsu: list = field(default_factory=list)   # [{move, power, owner}] من بطاقات الفريق
    hatsu_cd: dict = field(default_factory=dict)
    fx: dict = field(default_factory=dict)      # مؤثرات دائمة: crit/pierce/dodge/lifesteal/assist/aura/amp/reduce/reflect/double
    skill_lock: int = 0         # أدوار محظور فيها النين والهاتسو (سلسلة الحبس / الصاعقة)
    evade_turns: int = 0        # إعصار: مراوغة إضافية
    first_strike: int = 0       # إعصار: يضرب أولاً
    amp_turns: int = 0          # زمان الإمبراطور: مهارات مضاعفة
    forced_attack: int = 0      # علكة بونجي: هجوم أساسي فقط
    slowed: bool = False
    aura_shield: int = 0        # جدار الهالة: رصيد يمتص 60% من الضربات
    echo: bool = False          # ظل مسيطر (Shadow Echo)


def fighter_from_user(u: dict, name: str, full_hp: bool = False) -> Fighter:
    """u قادم من Database.get_user (يحوي المجاميع بعد العتاد). النذر يعدّل الأرقام هنا."""
    vow = VOWS.get(u.get("vow") or "")
    max_hp = u["t_hp"]
    atk, speed, defense = u["t_atk"], u["t_speed"], u["t_def"]
    if vow:
        max_hp = max(1, round(max_hp * vow.get("hp", 1.0)))
        atk = round(atk * vow.get("atk", 1.0))
        speed = round(speed * vow.get("speed", 1.0))
        defense = round(defense * vow.get("def", 1.0))
    aura = max_aura_for(u["level"])
    fx = dict(u.get("fx") or {})
    team = list(u.get("team_cards") or [])
    f = Fighter(
        name=name, hp=max_hp if full_hp else min(u["cur_hp"], max_hp), max_hp=max_hp,
        atk=atk, defense=defense, speed=speed,
        nen=normalize_nen(u["nen_type"]), aura=aura, max_aura=aura, is_player=True,
        no_guard=bool(vow and vow.get("no_guard")), no_skill=bool(vow and vow.get("no_skill")),
        team=team, fx=fx, hatsu=ht.hatsu_for_team(team),
    )
    f.hatsu = [{**h, "power": h["power"] * (1 + fx.get("assist", 0) * 0.5)} for h in f.hatsu]
    f.aura_shield = round(max_hp * fx.get("shield_pct", 0))
    return f


def shadow_fighter(u: dict, label: str | None = None) -> Fighter:
    """ظل لاعب حقيقي: نسخة من إحصائياته بصحة كاملة، يقاتل حتى وهو أوفلاين."""
    f = fighter_from_user(u, label or f"ظل {u.get('username') or 'لاعب'}", full_hp=True)
    f.is_player = False
    f.echo = True
    return f


_EARLY_NAMES = ["مقاتل متمرن", "ملاكم الأزقة", "حارس الطابق", "مبارز مجهول", "قناص مقنّع", "وحش الأنقاض"]
_NEN_NAMES = ["مستخدم نين", "هنتر منشق", "سيّاف الهالة", "وريث الظلام", "ساحر الأبراج"]
_LOOK_OF = {"مقاتل متمرن": "brawler", "ملاكم الأزقة": "boxer", "حارس الطابق": "guard", "مبارز مجهول": "swordsman",
            "قناص مقنّع": "sniper", "وحش الأنقاض": "beast", "مستخدم نين": "nen", "هنتر منشق": "hunter",
            "سيّاف الهالة": "swordsman", "وريث الظلام": "ninja", "ساحر الأبراج": "mage"}


def expected_level(floor: int) -> int:
    return 1 + int(floor * 0.75)


def enemy_for_floor(floor: int, rng: random.Random) -> Fighter:
    def stat(k: str) -> float:
        base, per = ENEMY_CURVE[k]
        return base + per * floor

    mult = 1.0
    if floor >= BOSS_FLOOR:
        mult, name = BOSS_MULT, "👑 بطل البرج الأعظم"
    elif floor >= MASTER_FLOOR_START:
        mult, name = MASTER_MULT, f"🏯 سيد الطابق {floor}"
    elif floor >= NEN_UNLOCK_FLOOR:
        name = rng.choice(_NEN_NAMES)
    else:
        name = rng.choice(_EARLY_NAMES)

    nen = roll_nen(rng) if floor >= NEN_UNLOCK_FLOOR else None
    aura = max_aura_for(expected_level(floor)) if nen else 0
    hp = max(1, round(stat("hp") * mult))
    look = _LOOK_OF.get(name, "nen" if floor >= NEN_UNLOCK_FLOOR else "brawler")
    if floor >= BOSS_FLOOR:
        look = "lord"
    elif floor >= MASTER_FLOOR_START:
        look = "master"
    f = Fighter(
        name=name, hp=hp, max_hp=hp, atk=max(1, round(stat("atk") * mult)),
        defense=max(0, round(stat("def") * mult)), speed=max(1, round(stat("speed") * mult)),
        nen=nen, aura=aura, max_aura=aura, look=look,
    )
    if floor >= MASTER_FLOOR_START:
        f.sig_name, f.sig_mult = ("ضربة السيد", 1.6) if floor < BOSS_FLOOR else ("غضب البرج", 1.8)
    return f


def blend_master_with_shadow(shadow: Fighter, generated: Fighter) -> Fighter:
    """يحصر ظل المسيطر بين 85% و160% من خصم الطابق المعتاد: لا أضعف من اللازم ولا مستحيل."""
    lo, hi = ECHO_FLOOR_PCT, ECHO_CAP
    for attr, gen in (("max_hp", generated.max_hp), ("atk", generated.atk), ("defense", generated.defense), ("speed", generated.speed)):
        setattr(shadow, attr, max(round(gen * lo), min(round(gen * hi), getattr(shadow, attr))) if gen else getattr(shadow, attr))
    shadow.hp = shadow.max_hp
    if generated.sig_name:           # طوابق الأسياد والبطل: يحتفظ الظل بالضربة المميزة
        shadow.sig_name, shadow.sig_mult = generated.sig_name, generated.sig_mult
    return shadow


def echo_of(holder_user: dict, generated: Fighter, label: str | None = None) -> Fighter:
    """«ظل المسيطر» (Shadow Echo): نسخة من أحدث إحصائيات وبطاقات ونين المسيطر يقاتلها المهاجم بالذكاء الاصطناعي."""
    sh = shadow_fighter(holder_user, label or f"👤 ظل {holder_user.get('username') or 'المسيطر'}")
    sh = blend_master_with_shadow(sh, generated)
    sh.look = "nen" if sh.nen else "brawler"
    return sh


# ───────────────────────── محرك القتال ─────────────────────────
class Battle:
    def __init__(self, player: Fighter, enemy: Fighter, rng: random.Random | None = None):
        self.p = player
        self.e = enemy
        self.rng = rng or random.Random()
        self.round = 0
        self.log: list[str] = []
        self.over = False
        self.winner: str | None = None   # player | enemy | fled | timeout
        self.max_rounds = MAX_ROUNDS
        self.ev: list[dict] = []        # أحداث الجولة الحالية (للرسم: ضربات، حرجة، تفادي...)
        self.last_ev: list[dict] = []
        self.combo = 0                  # ضربات متتالية للاعب بلا تلقي ضرر
        self.timeout_result = "enemy"    # في معارك الزعيم: "timeout" (انتهت الجولات وليست هزيمة)
        self.assist_casts = 0            # عدد مرات «نداء الفريق» في هذه المعركة
        self.hatsu_casts = 0             # عدد قدرات الهاتسو التي استخدمها اللاعب

    # ── معلومات للواجهة ──
    def assist_usable(self, actor: Fighter | None = None) -> bool:
        a = actor or self.p
        return bool(a.team) and a.assist_cd <= 0

    def hatsu_usable(self, actor: Fighter, move: str, opp: Fighter | None = None) -> bool:
        opp = opp or (self.e if actor is self.p else self.p)
        h = next((x for x in actor.hatsu if x["move"] == move), None)
        info = ht.HATSU.get(move)
        if h is None or info is None or actor.no_skill or actor.skill_lock > 0:
            return False
        if actor.aura < info["cost"] or actor.hatsu_cd.get(move, 0) > 0:
            return False
        if move == "killua_whirlwind" and actor.evade_turns > 0:
            return False
        if move == "kurapika_chain" and opp.skill_lock > 0:
            return False
        if move == "kurapika_emperor" and (actor.amp_turns > 0 or actor.hp <= round(actor.max_hp * 0.2) + 1):
            return False
        return True

    def player_hatsu_moves(self) -> list[tuple[str, bool]]:
        """قدرات هاتسو اللاعب مع صلاحية استخدامها الآن (للواجهة)."""
        return [(h["move"], self.hatsu_usable(self.p, h["move"], self.e)) for h in self.p.hatsu]

    def skill_usable(self, actor: Fighter, opp: Fighter) -> bool:
        if actor.no_skill or actor.skill_lock > 0 or not actor.nen or actor.aura < NEN[actor.nen]["cost"]:
            return False
        if actor.nen == "specialist":
            return (not actor.stolen_used) and opp.nen not in (None, "specialist")
        if actor.nen == "enhancer" and actor.atk_mult_next > 1:
            return False
        if actor.nen == "conjurer" and actor.shield_turns > 0:
            return False
        if actor.nen == "manipulator" and actor.reflect_turns > 0:
            return False
        return True

    def player_skill_usable(self) -> bool:
        return self.skill_usable(self.p, self.e)

    # ── الحساب ──
    def _damage(self, att: Fighter, dfn: Fighter, mult: float, ignore_def: bool, pierce: float = 0.0) -> tuple[int, float]:
        aff = affinity(att.nen, dfn.nen)
        raw = att.atk * mult * aff * self.rng.uniform(0.9, 1.1)
        if ignore_def:
            factor = 1.0
        else:
            eff_def = dfn.defense * (1 - min(0.9, pierce + att.fx.get("pierce", 0.0)))
            factor = 100 / (100 + DEF_SCALE * eff_def)
        dmg = raw * factor * (1 - min(0.5, dfn.fx.get("reduce", 0.0)))
        if dfn.guarding:
            dmg *= GUARD_REDUCTION
        return max(1, round(dmg)), aff

    def _side(self, f: Fighter) -> str:
        return "p" if f is self.p else "e"

    def _hit(self, att: Fighter, dfn: Fighter, label: str, mult: float = 1.0, ignore_def: bool = False, kind: str = "hit",
             nen: str | None = None, pierce: float = 0.0) -> None:
        a = self._side(att)
        # تفادي (لا يُتفادى الإطلاق ولا الضربات المميزة)
        if kind == "hit" and not ignore_def:
            dodge = min(0.18, max(0.0, 0.04 + (dfn.speed - att.speed) * 0.004))
            dodge = min(0.65, dodge + dfn.fx.get("dodge", 0.0) + (0.45 if dfn.evade_turns > 0 else 0.0))
            if self.rng.random() < dodge:
                self.ev.append({"a": a, "k": "miss", "d": 0})
                self.log.append(f"💨 {dfn.name} تفادى هجوم {att.name}!")
                if a == "e":
                    self.combo = self.combo
                return
        dmg, aff = self._damage(att, dfn, mult, ignore_def, pierce)
        crit = False
        if kind in ("hit", "skill"):
            cc = min(0.40, 0.08 + max(0, att.speed - dfn.speed) * 0.003 + att.fx.get("crit", 0.0))
            if self.rng.random() < cc:
                crit = True
                dmg = max(1, round(dmg * 1.6))
        if dfn.reflect_turns > 0:
            dfn.reflect_turns = 0
            back = max(1, round(dmg * 0.8))
            att.hp = max(0, att.hp - back)
            drained = min(att.aura, 15)
            att.aura -= drained
            dfn.aura = min(dfn.max_aura, dfn.aura + drained)
            self.ev.append({"a": self._side(dfn), "k": "reflect", "d": back})
            self.log.append(f"🔄 {dfn.name} عكس {label} على {att.name}: {back} ضرر وسلب {drained} طاقة")
            return
        note = ""
        if dfn.shield_turns > 0:
            dmg = max(1, round(dmg * (1 - SHIELD_ABSORB)))
            note += " 🔰"
        if dfn.aura_shield > 0:
            absorbed = min(dfn.aura_shield, round(dmg * 0.60))
            dfn.aura_shield -= absorbed
            dmg = max(1, dmg - absorbed)
            note += " 🔰هالة"
        if aff > 1:
            note += " ⚡تفوّق"
        elif aff < 1:
            note += " 💤ضعف"
        if crit:
            note += " 💥حرجة!"
        dfn.hp = max(0, dfn.hp - dmg)
        steal = att.fx.get("lifesteal", 0.0)
        if steal and att.hp > 0:
            att.hp = min(att.max_hp, att.hp + max(1, round(dmg * steal)))
        mirror = dfn.fx.get("reflect", 0.0)
        if mirror and dfn.hp > 0 and kind in ("hit", "skill") and self.rng.random() < mirror:
            back = max(1, round(dmg * 0.30))
            att.hp = max(0, att.hp - back)
            self.log.append(f"🪞 {dfn.name} عكس {back} من الضرر على {att.name}")
        if a == "p":
            self.combo += 1
        else:
            self.combo = 0
        self.ev.append({"a": a, "k": kind if not crit else "crit", "d": dmg, "nen": nen or att.nen, "aff": aff,
                        "guard": dfn.guarding})
        self.log.append(f"{label}: {att.name} ← {dfn.name} ({dmg}){note}")

    # ── الأفعال ──
    def _attack(self, actor: Fighter, opp: Fighter) -> None:
        mult, actor.atk_mult_next = actor.atk_mult_next, 1.0
        self._hit(actor, opp, "💥 ضربة معزَّزة" if mult > 1 else "⚔️ هجوم", mult)
        dbl = actor.fx.get("double", 0.0)
        if dbl and opp.hp > 0 and actor.hp > 0 and self.rng.random() < dbl:
            self._hit(actor, opp, "⚡ ضربة مزدوجة", 0.6)

    def _apply_skill(self, actor: Fighter, opp: Fighter, nen: str) -> None:
        name = NEN[nen]["skill"]
        amp = (2.0 if actor.amp_turns > 0 else 1.0) * (1 + actor.fx.get("amp", 0.0))
        if nen == "enhancer":
            actor.atk_mult_next = 1 + 2.0 * amp
            self.ev.append({"a": self._side(actor), "k": "buff", "d": 0, "nen": "enhancer"})
            self.log.append(f"💪 {actor.name} يستخدم {name}: ضربته القادمة ×{actor.atk_mult_next:g}!")
        elif nen == "transmuter":
            self._hit(actor, opp, f"🧪 {name}", 0.7 * amp, kind="skill", nen="transmuter")
            if opp.hp > 0:
                opp.stun_turns = 1
                opp.poison_turns = 3
                opp.poison_dmg = max(1, round(actor.atk * 0.25 * amp))
                self.log.append(f"💫 {opp.name} مشلول ومسموم!")
        elif nen == "conjurer":
            actor.shield_turns = min(6, round(3 * amp))
            self.ev.append({"a": self._side(actor), "k": "buff", "d": 0, "nen": "conjurer"})
            self.log.append(f"🔮 {actor.name} يستدعي {name}: يمتص 70% من هجومين قادمين")
        elif nen == "emitter":
            self._hit(actor, opp, f"🚀 {name}", 1.7 * amp, ignore_def=True, kind="skill", nen="emitter")
        elif nen == "manipulator":
            actor.reflect_turns = min(6, round(3 * amp))
            self.ev.append({"a": self._side(actor), "k": "buff", "d": 0, "nen": "manipulator"})
            self.log.append(f"🎭 {actor.name} يجهّز {name}...")

    def _cast(self, actor: Fighter, opp: Fighter) -> None:
        nen = actor.nen
        actor.aura -= NEN[nen]["cost"]
        if nen == "specialist":
            actor.stolen_used = True
            stolen = opp.nen
            self.log.append(f"🃏 {actor.name} يسرق مهارة «{NEN[stolen]['skill']}»!")
            self._apply_skill(actor, opp, stolen)
        else:
            self._apply_skill(actor, opp, nen)

    def _hatsu(self, actor: Fighter, opp: Fighter, move: str) -> None:
        """قدرة هاتسو خاصة ببطل أنمي (تأتي من بطاقته في الفريق)."""
        info = ht.HATSU[move]
        h = next(x for x in actor.hatsu if x["move"] == move)
        pw = h["power"]
        actor.aura -= info["cost"]
        actor.hatsu_cd[move] = info["cd"] + 1       # +1 لأن العدّاد ينقص في نهاية هذا الدور نفسه
        if actor is self.p:
            self.hatsu_casts += 1
        side = self._side(actor)
        label = f"{info['emoji']} {info['name']}"
        self.ev.append({"a": side, "k": "sigcall", "d": 0, "name": info["name"]})
        self.log.append(f"{info['emoji']} {actor.name} يطلق «{info['name']}»!")
        if move == "gon_rock":
            self._hit(actor, opp, label, 2.8 * pw, kind="skill")
        elif move == "gon_paper":
            self._hit(actor, opp, label, 1.5 * pw, kind="skill", pierce=0.5)
        elif move == "gon_scissors":
            self._hit(actor, opp, label, 1.1 * pw, kind="skill")
            if opp.hp > 0:
                opp.poison_turns = max(opp.poison_turns, 3)
                opp.poison_dmg = max(opp.poison_dmg, round(actor.atk * 0.30 * pw))
                if not opp.slowed:
                    opp.slowed = True
                    opp.speed = max(1, round(opp.speed * 0.8))
                self.log.append(f"🩸 {opp.name} ينزف وتتباطأ حركته!")
        elif move == "killua_whirlwind":
            actor.evade_turns = 4
            actor.first_strike = 4
            self.ev.append({"a": side, "k": "buff", "d": 0, "nen": "transmuter"})
            self.log.append(f"🌪️ {actor.name} يتحرك بسرعة الإله: يراوغ ويضرب أولاً 3 أدوار")
        elif move == "killua_thunder":
            self._hit(actor, opp, label, 0.9 * pw, kind="skill", nen="transmuter")
            if opp.hp > 0:
                opp.stun_turns = max(opp.stun_turns, 1)
                opp.skill_lock = max(opp.skill_lock, 2)
                opp.aura = 0
                self.ev.append({"a": side, "k": "stun", "d": 0})
                self.log.append(f"⚡ {opp.name} مشلول وانكسرت طاقته!")
        elif move == "kurapika_chain":
            opp.skill_lock = max(opp.skill_lock, 4)
            self.ev.append({"a": side, "k": "buff", "d": 0, "nen": "conjurer"})
            self.log.append(f"⛓️ سلسلة الحبس تقيّد {opp.name}: لا نين ولا هاتسو 4 أدوار!")
        elif move == "kurapika_emperor":
            cost_hp = round(actor.max_hp * 0.2)
            actor.hp = max(1, actor.hp - cost_hp)
            actor.amp_turns = 4
            self.ev.append({"a": side, "k": "buff", "d": 0, "nen": "specialist"})
            self.log.append(f"👁️ {actor.name} في زمان الإمبراطور: مهاراته مضاعفة 3 أدوار (−{cost_hp} صحة)")
        elif move == "hisoka_bungee":
            self._hit(actor, opp, label, 0.7 * pw, kind="skill")
            if opp.hp > 0:
                opp.forced_attack = 1
                actor.reflect_turns = max(actor.reflect_turns, 3)
                self.log.append(f"🎀 علكة بونجي تسحب {opp.name}: هجوم أساسي فقط وضربته القادمة تنعكس عليه!")

    def _assist(self, actor: Fighter, opp: Fighter) -> None:
        """نداء الفريق: كل بطاقة تنفّذ تأثير دورها (ضربة / درع / شفاء / شلل)."""
        actor.assist_cd = cd.ASSIST_COOLDOWN + 1     # +1 لأن العدّاد ينقص في نهاية هذا الدور نفسه
        if actor is self.p:
            self.assist_casts += 1
        side = self._side(actor)
        self.ev.append({"a": side, "k": "assist", "d": 0})
        for m in actor.team:
            if opp.hp <= 0 or actor.hp <= 0:
                break
            r, pw, role = m["r"], cd.assist_power(m) * (1 + actor.fx.get("assist", 0.0)), m["role"]
            label = f"🃏 {m['name']} · {m['skill']}"
            if role == "striker":
                self._hit(actor, opp, label, cd.ASSIST_STRIKE[r] * pw, kind="skill")
            elif role == "tank":
                actor.shield_turns = max(actor.shield_turns, cd.ASSIST_SHIELD_TURNS[r])
                self.ev.append({"a": side, "k": "buff", "d": 0, "nen": "conjurer"})
                self.log.append(f"🔮 {m['name']} · {m['skill']}: درع على {actor.name}")
            elif role == "healer":
                heal = max(1, round(actor.max_hp * cd.ASSIST_HEAL[r] * pw))
                before = actor.hp
                actor.hp = min(actor.max_hp, actor.hp + heal)
                if actor.hp > before:
                    self.ev.append({"a": side, "k": "heal", "d": actor.hp - before})
                    self.log.append(f"{label}: +{actor.hp - before} صحة لـ {actor.name}")
                else:
                    self.log.append(f"💚 {m['name']}: صحة {actor.name} كاملة أصلاً")
            else:   # controller
                chance = cd.ASSIST_STUN[r] * pw * (0.5 if opp.sig_name else 1.0)   # الأسياد والزعماء أصعب شللاً
                if self.rng.random() < chance and opp.stun_turns == 0:
                    opp.stun_turns = 1
                    self.ev.append({"a": side, "k": "stun", "d": 0})
                    self.log.append(f"💫 {m['name']} · {m['skill']}: {opp.name} مشلول دوراً!")
                else:
                    self._hit(actor, opp, label, 0.25 * pw, kind="skill")

    def _act(self, actor: Fighter, opp: Fighter, action: str) -> None:
        if actor.forced_attack > 0:
            action = "attack"
        if action == "guard" and actor.no_guard:
            action = "attack"
        if action.startswith("hatsu:"):
            move = action.split(":", 1)[1]
            if self.hatsu_usable(actor, move, opp):
                self._hatsu(actor, opp, move)
                return
            action = "attack"
        if action == "assist" and self.assist_usable(actor):
            self._assist(actor, opp)
        elif action == "guard":
            actor.guarding = True
            self.ev.append({"a": self._side(actor), "k": "guard", "d": 0})
            actor.aura = min(actor.max_aura, actor.aura + GUARD_AURA)
            self.log.append(f"🛡️ {actor.name} يتحصّن (-50% ضرر، +{GUARD_AURA} طاقة)")
        elif action == "sig" and actor.sig_name:
            self.ev.append({"a": self._side(actor), "k": "sigcall", "d": 0, "name": actor.sig_name})
            self.log.append(f"🌋 {actor.name} يطلق «{actor.sig_name}»!")
            self._hit(actor, opp, f"🌋 {actor.sig_name}", actor.sig_mult, kind="sig")
        elif action == "skill" and self.skill_usable(actor, opp):
            self._cast(actor, opp)
        else:
            self._attack(actor, opp)

    def _check_end(self) -> bool:
        if self.p.hp <= 0:
            self.over, self.winner = True, "enemy"
        elif self.e.hp <= 0:
            self.over, self.winner = True, "player"
        return self.over

    def _turn(self, actor: Fighter, opp: Fighter, action: str) -> None:
        actor.guarding = False
        if actor.rage_mult and not actor.raged and actor.hp < 0.5 * actor.max_hp:
            actor.raged = True
            actor.atk = round(actor.atk * actor.rage_mult)
            self.ev.append({"a": self._side(actor), "k": "rage", "d": 0})
            self.log.append(f"😡 {actor.name} يدخل وضع الغضب! هجومه يزداد")
        if actor.poison_turns > 0:
            actor.hp = max(0, actor.hp - actor.poison_dmg)
            actor.poison_turns -= 1
            self.log.append(f"☠️ السم يؤلم {actor.name} ({actor.poison_dmg})")
            if self._check_end():
                return
        if actor.stun_turns > 0:
            actor.stun_turns -= 1
            self.log.append(f"💫 {actor.name} مشلول ويفقد دوره")
        else:
            self._act(actor, opp, action)
        actor.shield_turns = max(0, actor.shield_turns - 1)
        actor.reflect_turns = max(0, actor.reflect_turns - 1)
        actor.assist_cd = max(0, actor.assist_cd - 1)
        for fld in ("skill_lock", "evade_turns", "first_strike", "amp_turns", "forced_attack"):
            setattr(actor, fld, max(0, getattr(actor, fld) - 1))
        for mv in list(actor.hatsu_cd):
            actor.hatsu_cd[mv] = max(0, actor.hatsu_cd[mv] - 1)
        actor.aura = min(actor.max_aura, actor.aura + AURA_REGEN + int(actor.fx.get("aura", 0)))
        self._check_end()

    def _policy(self, actor: Fighter, opp: Fighter, skill_chance: float) -> str:
        if actor.sig_name and actor is self.e and self.round % 3 == 0:
            return "sig"
        if actor.hatsu and self.rng.random() < 0.40:
            ready = [h["move"] for h in actor.hatsu if self.hatsu_usable(actor, h["move"], opp)]
            if ready:
                return "hatsu:" + self.rng.choice(ready)
        if self.skill_usable(actor, opp) and self.rng.random() < skill_chance:
            return "skill"
        if actor.hp < 0.3 * actor.max_hp and not actor.no_guard and self.rng.random() < 0.25:
            return "guard"
        return "attack"

    def suggest_action(self) -> str:
        """سياسة اللعب التلقائي للاعب (وتستخدم في simulate.py). يستدعي الفريق كلما جهز."""
        p = self.p
        ready = [mv for mv, ok in self.player_hatsu_moves() if ok and mv not in ("kurapika_emperor",)]
        if ready and self.rng.random() < 0.55:
            return "hatsu:" + self.rng.choice(ready)
        if self.assist_usable() and (p.hp < 0.9 * p.max_hp or any(m["role"] != "healer" for m in p.team)):
            return "assist"          # فريق معالجين فقط لا يُستدعى وصحتك كاملة (لا فائدة منه)
        return self._policy(self.p, self.e, 0.6)

    # ── واجهة الجولة ──
    def play_round(self, action: str, enemy_action: str | None = None) -> list[str]:
        """ينفذ جولة كاملة (الأسرع يبدأ، وعند التعادل اللاعب). يعيد سطور السجل الجديدة.
        enemy_action: في التحدي المباشر بين لاعبين يحدد اللاعب الثاني حركته، وإلا يقرر الذكاء الاصطناعي."""
        if self.over:
            return []
        self.round += 1
        start = len(self.log)
        self.ev = []
        p_first = self.p.speed >= self.e.speed
        if self.p.first_strike > 0 and self.e.first_strike <= 0:
            p_first = True
        elif self.e.first_strike > 0 and self.p.first_strike <= 0:
            p_first = False
        order = [self.p, self.e] if p_first else [self.e, self.p]
        for actor in order:
            if self.over:
                break
            if actor is self.p:
                self._turn(self.p, self.e, action)
            else:
                self._turn(self.e, self.p, enemy_action or self._policy(self.e, self.p, 0.35))
        if not self.over and self.round >= self.max_rounds:
            self.over, self.winner = True, self.timeout_result
            self.log.append("⏳ انتهت الجولات المسموحة" if self.timeout_result == "timeout"
                            else "⏳ طال القتال أكثر من اللازم... اعتُبرت هزيمة")
        self.last_ev = self.ev
        return self.log[start:]

    def flee(self) -> None:
        self.over, self.winner = True, "fled"


# ───────────────────────── العتاد والسحب ─────────────────────────
RARITIES = ["common", "rare", "epic", "legendary"]
RARITY_AR = ["عادي", "نادر", "ملحمي", "أسطوري"]
RARITY_EMOJI = ["⚪", "🔵", "🟣", "🟡"]
RARITY_WEIGHTS = [60, 28, 10, 2]
SELL_PRICE = [20, 60, 200, 800]

# نوع العنصر → (الإحصائية، الرمز، وزن السحب)
ITEM_TYPES = {
    "Weapon": ("atk", "⚔️", 25),
    "Armor": ("def", "🛡️", 25),
    "Helmet": ("hp", "⛑️", 20),
    "Companion": ("speed", "🐾", 15),
    "Spell": ("heal", "📜", 15),
}
ITEM_BONUS = {
    "atk": [3, 8, 18, 40],
    "def": [2, 5, 11, 24],
    "hp": [15, 40, 90, 200],
    "speed": [2, 4, 8, 15],
    "heal": [30, 50, 75, 100],     # نسبة مئوية من الصحة
}
STAT_SHORT = {"atk": "هجوم", "def": "دفاع", "hp": "صحة", "speed": "سرعة", "heal": "% شفاء"}
_BASE_NAMES = {
    "Weapon": ["سيف", "خنجر", "رمح", "قفازات"],
    "Armor": ["درع", "سترة", "عباءة"],
    "Helmet": ["خوذة", "قناع", "طوق"],
    "Companion": ["ذئب", "صقر", "قط الظلال", "ثعلب"],
    "Spell": ["بطاقة شفاء"],
}
_SUFFIX = ["التدريب", "الصيّاد", "الظلال", "الملوك"]


def roll_item(pity: int, rng: random.Random) -> tuple[dict, int]:
    """يسحب عنصراً. يعيد (العنصر، عداد الضمان الجديد)."""
    if pity + 1 >= PITY_LIMIT:
        r = rng.choices([2, 3], [83, 17])[0]
    else:
        r = rng.choices([0, 1, 2, 3], RARITY_WEIGHTS)[0]
    types = list(ITEM_TYPES)
    itype = rng.choices(types, [ITEM_TYPES[t][2] for t in types])[0]
    stat = ITEM_TYPES[itype][0]
    base = rng.choice(_BASE_NAMES[itype])
    name = f"{base} {RARITY_AR[r]}" if itype == "Spell" else f"{base} {_SUFFIX[r]}"
    item = {"name": name, "type": itype, "stat": stat, "bonus": ITEM_BONUS[stat][r], "rarity": RARITIES[r]}
    return item, (0 if r >= 2 else pity + 1)


# ───────── تحسين العتاد والدمج والأطقم ─────────
MAX_ENH = 5
ENH_STEP = 0.25                       # كل مستوى تحسين يضيف 25% من القيمة الأصلية
ENH_BASE_COST = [150, 400, 1100, 3000]    # حسب الندرة، يتضاعف مع المستوى
ENH_CHANCE = [1.0, 1.0, 0.80, 0.60, 0.40]  # فرصة النجاح للانتقال من المستوى i إلى i+1
FUSE_COUNT = 3
FUSE_COST = [100, 400, 1500]          # لدمج 3 عناصر من ندرة i إلى i+1
SET_NAMES = {"التدريب": "طقم المتدرب", "الصيّاد": "طقم الصيّاد", "الظلال": "طقم الظلال", "الملوك": "طقم الملوك"}
SET_BONUS = {2: 0.05, 3: 0.12, 4: 0.25}   # عدد القطع المجهّزة → زيادة نسبية في كل الإحصائيات


def enhanced_bonus(base: int, lvl: int) -> int:
    return max(base, int(round(base * (1 + ENH_STEP * lvl))))


def enhance_cost(rarity: str, lvl: int) -> int:
    r = RARITIES.index(rarity) if rarity in RARITIES else 0
    return ENH_BASE_COST[r] * (2 ** lvl)


def sell_value(rarity: str, lvl: int) -> int:
    r = RARITIES.index(rarity) if rarity in RARITIES else 0
    return int(SELL_PRICE[r] * (1 + 0.6 * lvl))


def item_set(name: str) -> str | None:
    for suf in SET_NAMES:
        if name.endswith(suf):
            return suf
    return None


def set_bonus_pct(equipped_names: list[str]) -> tuple[float, str | None, int]:
    """أعلى طقم مكتمل: (نسبة الزيادة، اسم الطقم، عدد القطع)."""
    counts: dict[str, int] = {}
    for n in equipped_names:
        k = item_set(n)
        if k:
            counts[k] = counts.get(k, 0) + 1
    best = max(counts.items(), key=lambda kv: kv[1], default=(None, 0))
    pct = SET_BONUS.get(best[1], 0.0) if best[1] >= 2 else 0.0
    return pct, (SET_NAMES.get(best[0]) if pct else None), best[1]


def power_of(atk: int, defense: int, hp: int, speed: int) -> int:
    """رقم واحد يلخّص قوتك القتالية (للعرض فقط)."""
    return int(atk * 4 + defense * 3 + hp * 0.5 + speed * 3)


def describe_item(name: str, rarity: str, stat: str, bonus: int) -> str:
    r = RARITIES.index(rarity) if rarity in RARITIES else 0
    return f"{RARITY_EMOJI[r]} {name} (+{bonus} {STAT_SHORT.get(stat, stat or '؟')})"


# ═════════════════════════ إضافات: النذور والرتب والزعماء والمهام ═════════════════════════
def fighter_view(f: Fighter) -> dict:
    """لقطة بسيطة للمقاتل تُمرَّر لمحرك الصور."""
    return {"name": f.name, "hp": f.hp, "max_hp": f.max_hp, "aura": f.aura, "max_aura": f.max_aura, "atk": f.atk,
            "defense": f.defense, "speed": f.speed, "nen": f.nen, "emoji": f.emoji or ("🧑" if f.is_player else "👹"),
            "shield": f.shield_turns > 0, "reflect": f.reflect_turns > 0, "stun": f.stun_turns > 0,
            "poison": f.poison_turns > 0, "boost": f.atk_mult_next > 1, "guard": f.guarding, "evade": f.evade_turns > 0,
            "locked": f.skill_lock > 0, "amp": f.amp_turns > 0, "aura_shield": f.aura_shield > 0, "echo": f.echo,
            "team": [{"key": m["key"], "name": m["name"], "r": m["r"], "role": m["role"], "stars": m["stars"]} for m in f.team]}


# ───────────────────────── النذور والقيود ─────────────────────────
VOW_SWITCH_GEMS = 20
VOWS = {
    "blood": {"name": "نذر الدم", "emoji": "🩸", "hp": 0.70, "atk": 1.35,
              "desc": "تقل صحتك القصوى 30% مقابل هجوم أقوى بـ 35%."},
    "silence": {"name": "نذر الصمت", "emoji": "🤐", "atk": 1.30, "speed": 1.20, "no_skill": True,
                "desc": "تتخلى عن مهارات النين كلياً مقابل +30% هجوم و+20% سرعة."},
    "wrath": {"name": "نذر الغضب", "emoji": "😡", "atk": 1.35, "def": 1.10, "no_guard": True,
              "desc": "لا تتحصّن أبداً مقابل +35% هجوم و+10% دفاع."},
    "greed": {"name": "نذر الجشع", "emoji": "🪙", "gold_mult": 1.30, "loss_mult": 2.0,
              "desc": "ذهب الطوابق +30%، لكن خسارتك للذهب عند الهزيمة تتضاعف."},
}


def vow_loss_pct(vow: str | None) -> float:
    v = VOWS.get(vow or "")
    return LOSS_GOLD_PCT * (v.get("loss_mult", 1.0) if v else 1.0)


def vow_gold_mult(vow: str | None) -> float:
    v = VOWS.get(vow or "")
    return v.get("gold_mult", 1.0) if v else 1.0


# ───────────────────────── رتبة الصيّاد ─────────────────────────
HUNTER_RANKS = [(0, 0, "متدرّب"), (5, 1, "صيّاد مبتدئ"), (20, 2, "صيّاد النين"), (40, 3, "صيّاد متمرّس"),
                (60, 4, "صيّاد النخبة"), (90, 5, "صيّاد أسطوري"), (100, 5, "ملك البرج")]


def hunter_rank(floor: int) -> tuple[str, int]:
    name, stars = HUNTER_RANKS[0][2], 0
    for need, st, nm in HUNTER_RANKS:
        if floor >= need:
            name, stars = nm, st
    return name, stars


# ───────────────────────── العتاد: أيقونات ونصوص ─────────────────────────
ITEM_EMOJI = {
    "سيف": "🗡️", "خنجر": "🔪", "رمح": "🔱", "قفازات": "🥊", "درع": "🛡️", "سترة": "🦺", "عباءة": "🧥",
    "خوذة": "⛑️", "قناع": "🎭", "طوق": "📿", "ذئب": "🐺", "صقر": "🦅", "قط الظلال": "🐈‍⬛", "ثعلب": "🦊",
    "بطاقة شفاء": "📜",
}
TYPE_EMOJI = {"Weapon": "⚔️", "Armor": "🛡️", "Helmet": "⛑️", "Companion": "🐾", "Spell": "📜", "Relic": "🔮"}


def item_emoji(name: str, item_type: str = "") -> str:
    if name in ht.GEAR_BY_NAME:
        return ht.GEAR_BY_NAME[name]["emoji"]
    for base in sorted(ITEM_EMOJI, key=len, reverse=True):
        if name.startswith(base):
            return ITEM_EMOJI[base]
    return TYPE_EMOJI.get(item_type, "🎁")


def item_bonus_text(stat: str, bonus: int) -> str:
    return f"+{bonus}% شفاء" if stat == "heal" else f"+{bonus} {STAT_SHORT.get(stat, stat or '؟')}"


_ITEM_SLOT = {"سيف": "item_sword", "خنجر": "item_dagger", "رمح": "item_spear", "قفازات": "item_gloves", "درع": "item_shield",
              "سترة": "item_vest", "عباءة": "item_cloak", "خوذة": "item_helmet", "قناع": "item_mask", "طوق": "item_collar",
              "ذئب": "item_wolf", "صقر": "item_falcon", "قط الظلال": "item_cat", "ثعلب": "item_fox", "بطاقة شفاء": "item_card"}


def item_slot(name: str) -> str | None:
    if name in ht.GEAR_BY_NAME:                      # عتاد هانتر: له خانة صورة خاصة (تُجلب من الويكي)
        return ht.GEAR_BY_NAME[name]["slot"]
    for base in sorted(_ITEM_SLOT, key=len, reverse=True):
        if name.startswith(base):
            return _ITEM_SLOT[base]
    return None


def item_view(row: dict, equipped: bool | None = None) -> dict:
    r = RARITIES.index(row["rarity"]) if row["rarity"] in RARITIES else 0
    nm = row.get("item_name") or row.get("name", "؟")
    lvl = row.get("lvl") or 0
    base = row.get("stat_bonus", row.get("bonus", 0))
    return {"item_id": row.get("item_id", 0), "name": nm, "rarity": r, "lvl": lvl, "slot": item_slot(nm),
            "fx_text": ht.fx_text(row.get("effect")), "is_gear": nm in ht.GEAR_BY_NAME,
            "emoji": item_emoji(nm, row.get("item_type") or row.get("type", "")),
            "bonus_text": item_bonus_text(row.get("stat"), enhanced_bonus(base, lvl) if row.get("stat") != "heal" else base),
            "equipped": bool(row.get("is_equipped")) if equipped is None else equipped}


def roll_item_rarity(r: int, rng: random.Random) -> dict:
    """عنصر بندرة محددة (للدمج)."""
    types = [t for t in ITEM_TYPES if t != "Spell"]
    itype = rng.choices(types, [ITEM_TYPES[t][2] for t in types])[0]
    stat = ITEM_TYPES[itype][0]
    base = rng.choice(_BASE_NAMES[itype])
    return {"name": f"{base} {_SUFFIX[r]}", "type": itype, "stat": stat, "bonus": ITEM_BONUS[stat][r], "rarity": RARITIES[r]}


def roll_item_min(pity: int, rng: random.Random, min_rarity: int) -> tuple[dict, int]:
    """عنصر بحد أدنى من الندرة (لغنائم الزعماء)."""
    for _ in range(50):
        item, np = roll_item(0, rng)
        if RARITIES.index(item["rarity"]) >= min_rarity:
            return item, pity
    item, _ = roll_item(PITY_LIMIT - 1, rng)
    return item, pity


# ───────────────────────── المتجر ─────────────────────────
SHOP = [
    ("small", "بطاقة شفاء صغيرة", 30, 150, 0),
    ("mid", "بطاقة شفاء", 60, 380, 1),
    ("big", "بطاقة شفاء كبرى", 100, 800, 2),
]
TRANSFER_TAX = 0.05
TRANSFER_MIN = 50


# ───────────────────────── الأحداث ─────────────────────────
EVENT_KINDS = {"gold": ("💰", "ذهب مضاعف"), "xp": ("✨", "خبرة مضاعفة")}


# ───────────────────────── الزعماء ─────────────────────────
BOSS_DURATION_H = 24 * 7
BOSS_RESPAWN_H = 12
BOSS_DAILY_ATTEMPTS = 3
BOSS_COOLDOWN = 300           # ثانية بين محاولتين
BOSS_ROUNDS = 10
BOSS_BASE_HP = 15000
BOSS_HP_PER_PLAYER = 2500
BOSS_MAX_PLAYERS_COUNTED = 40
BOSSES = [
    {"key": "hisoka", "name": "هيسوكا مورو", "title": "مهرج الأوهام", "emoji": "🤡", "floor": 48, "search": "Hisoka Morow", "sig": "مطر البطاقات"},
    {"key": "illumi", "name": "إيلومي زولديك", "title": "القاتل المتلاعب", "emoji": "🎭", "floor": 60, "search": "Illumi Zoldyck", "sig": "وابل الإبر"},
    {"key": "chrollo", "name": "كروللو لوسيلفر", "title": "زعيم فرقة العناكب", "emoji": "🕷️", "floor": 70, "search": "Chrollo Lucilfer", "sig": "سرقة المهارة"},
    {"key": "pitou", "name": "نفيربيتو", "title": "حارس ملك النمل", "emoji": "🐈‍⬛", "floor": 80, "search": "Neferpitou", "sig": "مخالب الحارس"},
    {"key": "netero", "name": "إيزاك نيتيرو", "title": "رئيس الجمعية", "emoji": "🧙", "floor": 90, "search": "Isaac Netero", "sig": "بوذا المئة"},
    {"key": "meruem", "name": "ميروم", "title": "ملك نمل الكيميرا", "emoji": "🐜", "floor": 100, "search": "Meruem", "sig": "شعاع الملك"},
]


def boss_max_hp(players: int) -> int:
    return BOSS_BASE_HP + BOSS_HP_PER_PLAYER * min(max(players, 1), BOSS_MAX_PLAYERS_COUNTED)


def boss_fighter(template: dict, hp: int, rng: random.Random, player_floor: int | None = None) -> Fighter:
    """قوة الزعيم تتكيّف مع المهاجم (طابقه + 25 كحد أقصى لطابق الزعيم) حتى يساهم الجميع بضرر مجدٍ."""
    eff = template["floor"] if player_floor is None else min(template["floor"], max(10, player_floor + 10))
    e = enemy_for_floor(eff, rng)
    e.name, e.emoji = f"{template['emoji']} {template['name']}", template["emoji"]
    e.atk = round(e.atk * 1.1)
    e.hp = e.max_hp = max(1, hp)
    e.look = template["key"]
    e.sig_name, e.sig_mult, e.rage_mult = template.get("sig", "ضربة قاضية"), 1.9, 1.25
    if not e.nen:
        e.nen = roll_nen(rng)
        e.aura = e.max_aura = max_aura_for(expected_level(eff))
    return e


def boss_rewards(share: float, rank: int, last_hit: bool, killed: bool) -> tuple[int, int, int]:
    """(ذهب، جواهر، أقل ندرة للغنيمة) لمشارك. rank يبدأ من 1."""
    gold = 300 + int(share * 20000)
    gems = 3 + int(share * 40)
    min_r = 1
    if rank == 1:
        gems, min_r = gems + 25, 2
    elif rank == 2:
        gems, min_r = gems + 15, 2
    elif rank == 3:
        gems, min_r = gems + 10, 2
    if last_hit:
        gems += 20
    if not killed:           # هرب الزعيم: مكافأة تعزية
        gold, gems = gold // 4, gems // 4
    return gold, gems, min_r


# ───────────────────────── حرب العصابات ─────────────────────────
WAR_DURATION_H = 24
WAR_MIN_MEMBERS = 2
WAR_COOLDOWN_H = 6
WAR_POINTS_WIN = 2
WAR_POINTS_BOSS = 1
WAR_REWARD = {"win": (1500, 20), "lose": (300, 3), "draw": (700, 8)}


# ───────────────────────── المهام ─────────────────────────
MISSION_BONUS_GEMS = 5
MISSION_POOL = [
    # key, emoji, عنوان ({n}), خيارات العدد, ذهب لكل وحدة, جواهر
    ("win", "⚔️", "اكسب {n} معارك في البرج", (2, 3, 5), 120, 0),
    ("gacha", "🃏", "اسحب {n} بطاقة", (1, 2), 150, 0),
    ("boss", "👹", "اضرب الزعيم {n} مرة", (1, 2), 200, 1),
    ("duel", "🥊", "اكسب مبارزة ظلال", (1,), 220, 0),
    ("daily", "🎁", "استلم مكافأتك اليومية", (1,), 100, 0),
    ("sell", "💰", "بِع عنصراً من حقيبتك", (1,), 90, 0),
    ("upgrade", "📈", "وزّع نقاط تطوير", (1,), 90, 0),
    ("tree", "🌳", "طوّر مهارة في شجرة النين", (1,), 130, 0),
    ("gear", "🎒", "اسحب عتاداً من سحب العتاد {n} مرة", (1, 2), 160, 0),
]


def roll_missions(seed: str) -> list[dict]:
    rnd = random.Random(seed)
    picks = rnd.sample(MISSION_POOL, 3)
    out = []
    for key, emoji, title, counts, gold_unit, gems in picks:
        n = rnd.choice(counts)
        out.append({"key": key, "emoji": emoji, "title": title.format(n=n), "target": n,
                    "gold": gold_unit * n, "gems": gems * (1 if n >= max(counts) else 0)})
    return out


# ───────────────────────── الصيد (قتال إضافي) ─────────────────────────
HUNT_CD = 600       # ثواني بين رحلتي صيد
# key, الاسم، رمز، أدنى طابق، شكل مرسوم، مضاعف القوة، مضاعف المكافأة، فرصة سقوط عتاد
HUNTS = [
    ("rats", "فئران الأنفاق", "🐀", 1, "rat", 0.70, 0.5, 0.10),
    ("wolves", "ذئاب الغابة", "🐺", 4, "wolf", 0.85, 0.7, 0.14),
    ("bandits", "قطّاع الطرق", "🗡️", 10, "bandit", 0.95, 0.9, 0.18),
    ("spiders", "عناكب الظلال", "🕷️", 20, "spider", 1.05, 1.1, 0.22),
    ("ants", "جنود النمل", "🐜", 40, "ant", 1.10, 1.3, 0.26),
    ("ghosts", "أشباح النين", "👻", 60, "ghost", 1.15, 1.5, 0.30),
    ("dragon", "تنين الطابق", "🐉", 80, "dragon", 1.20, 1.9, 0.38),
]


def hunt_enemy(hunt: tuple, floor: int, rng: random.Random) -> Fighter:
    key, name, emoji, _mf, look, pm, _rm, _dc = hunt
    f = enemy_for_floor(max(1, floor), rng)
    f.name, f.emoji, f.look = f"{emoji} {name}", emoji, look
    for attr in ("hp", "max_hp", "atk", "defense", "speed"):
        setattr(f, attr, max(1, round(getattr(f, attr) * pm)))
    f.sig_name, f.sig_mult = "", 0.0
    return f


def hunt_rewards(hunt: tuple, floor: int, rng: random.Random) -> tuple[int, int]:
    gold, xp = floor_rewards(max(1, floor), rng)
    return int(gold * hunt[6]), int(xp * hunt[6])


# ───────────────────────── أحداث الطوابق ─────────────────────────
FLOOR_EVENT_CHANCE = 0.30
FLOOR_EVENTS = [
    # key, الوزن، رمز، عنوان
    ("chest", 30, "🎁", "صندوق كنز مخبّأ"),
    ("gems", 12, "💎", "بلّورات متوهجة"),
    ("heal", 22, "💚", "ينبوع الشفاء"),
    ("item", 14, "🎴", "تاجر متجوّل أهداك عتاداً"),
    ("trap", 12, "🕸️", "فخ قديم"),
    ("blessing", 10, "✨", "بركة المعبد: خبرة إضافية"),
]


def roll_floor_event(rng: random.Random) -> dict | None:
    if rng.random() > FLOOR_EVENT_CHANCE:
        return None
    k = rng.choices(FLOOR_EVENTS, [e[1] for e in FLOOR_EVENTS])[0]
    return {"key": k[0], "emoji": k[2], "title": k[3]}


# ───────────────────────── الإنجازات ─────────────────────────
# key, رمز، عنوان، وصف، (حقل الإحصاء، الحد)، ذهب، جواهر
ACHIEVEMENTS = [
    ("f10", "🌱", "أول الغيث", "اصعد إلى الطابق 10", ("floor", 10), 200, 2),
    ("f20", "🌀", "باب النين", "اصعد إلى الطابق 20", ("floor", 20), 800, 6),
    ("f50", "🏯", "نصف الطريق", "اصعد إلى الطابق 50", ("floor", 50), 2000, 10),
    ("f90", "👑", "سيّد الأسياد", "اصعد إلى الطابق 90", ("floor", 90), 5000, 20),
    ("f100", "🌟", "بطل البرج", "اصعد إلى الطابق 100", ("floor", 100), 20000, 100),
    ("l10", "⭐", "صياد صاعد", "بلغ المستوى 10", ("level", 10), 300, 3),
    ("l30", "🌠", "محترف", "بلغ المستوى 30", ("level", 30), 1500, 8),
    ("l60", "💫", "أسطورة", "بلغ المستوى 60", ("level", 60), 6000, 30),
    ("w10", "⚔️", "مقاتل", "اربح 10 معارك", ("wins", 10), 250, 2),
    ("w100", "🗡️", "سفّاح الأبراج", "اربح 100 معركة", ("wins", 100), 2500, 15),
    ("w500", "🔥", "لا يُقهر", "اربح 500 معركة", ("wins", 500), 10000, 40),
    ("p10", "🎴", "مغامر الحظ", "اسحب 10 بطاقات", ("pulls", 10), 300, 2),
    ("p100", "🃏", "مدمن السحب", "اسحب 100 بطاقة", ("pulls", 100), 2500, 15),
    ("hu10", "🐺", "صياد", "أنهِ 10 رحلات صيد", ("hunts", 10), 400, 3),
    ("hu50", "🦁", "ملك الغابة", "أنهِ 50 رحلة صيد", ("hunts", 50), 2500, 12),
    ("en1", "🔨", "حدّاد", "حسّن عنصراً إلى +3", ("best_enh", 3), 500, 4),
    ("en5", "💎", "صائغ الأساطير", "حسّن عنصراً إلى +5", ("best_enh", 5), 3000, 20),
    ("lg1", "🟡", "ضربة حظ", "امتلك عنصراً أسطورياً", ("legend", 1), 1000, 10),
    ("bs5", "👹", "قاهر الزعماء", "اضرب الزعيم 5 مرات", ("boss_hits", 5), 1200, 8),
    ("gd1", "🏰", "ابن عصابة", "انضم إلى عصابة", ("guild", 1), 300, 2),
    ("rich", "💰", "ثري", "امتلك 20,000 ذهب", ("gold", 20000), 0, 25),
]


# ───────────────────────── أسباب العمليات المالية ─────────────────────────
REASON_AR = {
    "climb": "انتصار في البرج", "loss": "خسارة في البرج", "duel": "مبارزة", "gacha": "سحب بطاقات", "summon": "استدعاء الأبطال", "card_refund": "نسخ بطاقات زائدة", "sell": "بيع عتاد",
    "daily": "مكافأة يومية", "reroll": "إعادة اختبار النين", "boss": "غنائم الزعيم", "mission": "مهام", "mission_bonus": "مكافأة المهام",
    "transfer_out": "تحويل صادر", "transfer_in": "تحويل وارد", "tax": "ضريبة التحويل", "shop": "المتجر", "war": "حرب العصابات",
    "admin": "إدارة", "vow": "تغيير النذر", "hunt": "رحلة صيد", "enhance": "تحسين عتاد", "fuse": "دمج عتاد",
    "event": "حدث في البرج", "achieve": "إنجازات",
    "gear_gacha": "سحب العتاد", "black_market": "السوق الأسود", "gang_create": "تأسيس عصابة", "gang_deposit": "خزينة العصابة",
    "gang_war": "غنائم حرب العصابات", "season": "جوائز الموسم", "tree_respec": "إعادة توزيع النين", "weekly": "مهام أسبوعية",
    "gang_mission": "مهام العصابة", "revenge": "انتقام",
}
