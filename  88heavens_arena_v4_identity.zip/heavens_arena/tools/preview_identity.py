"""معاينة الهوية البصرية: يرسم عيّنة من كل بطاقة رئيسية بهوية أمرها ويجمعها في صورة واحدة (للفحص البصري).
تشغيل:  python tools/preview_identity.py [مخرج.jpg]"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from PIL import Image, ImageDraw

import cards as cd
import identity as idn
import render as R
import render2 as R2


class D(dict):
    """قاموس يعيد قيمة صالحة لأي مفتاح مفقود (للمعاينة فقط)."""
    def __missing__(self, k):
        return 5


def fighter(name="خصم"):
    return D(name=name, hp=50, max_hp=100, atk=10, df=5, speed=5, level=3, energy=5, status=[], team=[], emoji="👤", look="brawler", nen="enhancer", rage=False)


CARDS = [
    ("profile", lambda: R.profile_card(D(username="لاعب", floor=12, level=7, t_atk=30, t_def=20, t_speed=10, t_hp=200, xp=40, cur_hp=150, gold=500, gems=20, wins=5, nen_type="enhancer"), None, "صياد", 3, "مبتدئ", "العناكب", None, 100)),
    ("bag", lambda: R.inventory_card([], {}, 1, 1, 0, "لاعب", 500, 20)),
    ("vow", lambda: R.list_card("النذور والقيود", "أول نذر مجاني", [], "🩸", "boss", None, lines=["نذرك الحالي: دم", "القيود تمنحك قوة أكبر"])),
    ("shop", lambda: R.list_card("المتجر", "بطاقات شفاء", [("💚", "بطاقة", "100")], "🛒", "gold")),
    ("help", lambda: R.help_card("القتال", "⚔️", "القتال بالأدوار", [("هجوم", "ضرر عادي")] * 4, 3, 11, ["نصيحة"])),
    ("war", lambda: R.war_card(D(time_left="ساعة", name_a="الصقور", name_b="الذئاب", score_a=5, score_b=3, note="جارية"))),
    ("album", lambda: R.album_card({"gon": 2}, 0, "لاعب", None, ["gon"])),
    ("team", lambda: R.team_card([{"key": "gon", "stars": 2}], cd.team_bonus([("gon", 3)]), "لاعب", None)),
    ("summon", lambda: R.summon_result_card([{"key": "gon", "r": 1, "is_new": True, "stars": 1, "dup": False}], 5, "gems", 10, "لاعب", None)),
    ("boss", lambda: R.boss_card(D(name="هيسوكا", title="مهرج", emoji="🤡", hp=500, max_hp=1000), None, [D(name="أ", damage=100)], None, "ساعة", 3, "")),
    ("ledger", lambda: R.ledger_card("سجل", "آخر عمليات", [D(currency="gold", label="صعود", amount=10, balance=100, when="01/01 10:00")], 500, 20)),
    ("climb", lambda: R.tower_card(12, 100, "مبتدئ", fighter(), (10, 20), None, (50, 100))),
    ("nen_test", lambda: R.nen_card("enhancer", D(name="التعزيز", emoji="💪", desc="x", color=(255, 120, 60), affinity={}), None)),
    ("gacha", lambda: R.gacha_result_card([D(name="سيف", emoji="⚔️", r=1, item_type="weapon", bonus_text="+5")], 3, 20, "100 💰", 1)),
    ("card", lambda: R.card_detail_card(cd.CARDS["gon"], None, 2, "لاعب")),
    ("rank", lambda: R.leaderboard_card("الأبطال", "🏆", [D(username="أ", floor=5, level=3, gold=100, wins=2, user_id=1), D(username="ب", floor=4, level=2, gold=90, wins=1, user_id=2)], "")),
    ("gang", lambda: R2.gang_card(D(name="الصقور", leader_id=1, members=[D(user_id=1, username="أ", level=3, floor=5, war_points=2)], treasury_gold=100, treasury_gems=5, level=1, wins=0, missions=[], rank_list=[]), 1)),
    ("missions", lambda: R2.missions_full_card([D(name="م", progress=1, target=3, done=False, claimed=False, emoji="📋", reward="x")], [D(name="م", progress=1, target=3, done=False, claimed=False, emoji="📋", reward="x")], "n", "n", "ساعة", "يوم")),
    ("control", lambda: R.economy_card("الاقتصاد", "آخر 7 أيام", "gold", 1000, [("صعود", 500)], [("متجر", 300)])),
    ("market", lambda: R2.market_card(D(offers=[], open=True, left=100), "لاعب", None, None, "ساعتان", 100, 5)),
    ("season", lambda: R2.season_card(D(name="الموسم 1", left=100, number=1), "يوم", 0.5, [D(username="أ", floor=5, rank=1)], D(), "لاعب", 1)),
    ("tree", lambda: R2.tree_card({}, 3, 0, {}, "لاعب")),
    ("revenge", lambda: R2.floor_control_card(12, "خصم", "revenge", None, [("🔥", "x", "y")], "لاعب")),
]


def main(out="/tmp/identity_preview.jpg"):
    tiles = []
    for slug, fn in CARDS:
        if fn is None:
            continue
        idn.use(slug)
        try:
            data = fn()
        except Exception as e:      # عيّنة ناقصة البيانات: تُتخطى
            print("تخطي", slug, type(e).__name__, e)
            continue
        import io
        im = Image.open(io.BytesIO(data)).convert("RGB")
        im.thumbnail((700, 560))
        ImageDraw.Draw(im).text((6, im.height - 14), slug, fill=(255, 255, 0))
        tiles.append(im)
    cols = 3
    rows = (len(tiles) + cols - 1) // cols
    W = max(t.width for t in tiles) if tiles else 700
    H = max(t.height for t in tiles) if tiles else 560
    sheet = Image.new("RGB", (cols * W, rows * H))
    for i, t in enumerate(tiles):
        sheet.paste(t, ((i % cols) * W, (i // cols) * H))
    sheet.save(out, quality=88)
    print("حُفظت", out, len(tiles), "بطاقة")


if __name__ == "__main__":
    main(*sys.argv[1:2])
