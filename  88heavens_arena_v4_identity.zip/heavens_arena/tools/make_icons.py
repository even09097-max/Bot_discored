"""يولّد صور الأيقونات (assets/icons) من خط الإيموجي الملوّن. يُشغَّل مرة واحدة فقط؛
الصور الناتجة مرفقة مع المشروع فلا يحتاج البوت لأي خط إيموجي أثناء التشغيل."""
import sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

FONT = "/usr/share/fonts/truetype/noto/NotoColorEmoji.ttf"
EMOJI = ("⚔️ 🛡️ ❤️ 💎 💰 🏰 ⭐ ⚡ 🔷 💨 💪 🧪 🔮 🚀 🎭 🃏 🗡️ 🔱 🥊 🦺 🧥 ⛑️ 🪖 📿 🐺 🦅 🐈‍⬛ 🦊 📜 💚 👑 🏯 🌀 🌱 💀 🏆 🏳️ "
         "🔥 🎁 👹 🔰 🔄 💫 ☠️ 💥 🎒 🐾 🔭 🥇 🥈 🥉 📊 🌊 ✨ 🎯 🔒 📢 🧑 🎴 🏹 🪙 👤 👥 ⏳ 🎉 🤝 📈 🛒 🧿 🩸 🔋 "
         "🐱 🔪 🥋 🧤 🎩 🪽 🌟 🔔 ❓ ✅ ❌ 📋 🗺️ 🕐 ⚙️ 🏅 🎖️ 💼 🧭 🌙 ☀️ 🕸️ 🎪 🃏 🐲 👾 🤡 🦂 🐜 🕷️ 🧙 🥷 🪄 💡 🤐 😡 ⌛ 🧾 👋 🛠️ 💬 🛑 🔓 💤 ⚠️ ⚪ 🔵 🟣 🟡 🧬 📖 🔑 💳 🏦 🔻 🔺 ➕ ➖ 🎲 🧧 🌆 🌋 🌠 🎬 🐀 🐉 👻 🔢 🔨 🖼️ 🗑️ 🦁 🐈 🔪 🐍 🦇 🦖 🐗 🦉 🐻 🐅 🏵️ 🎗️ \
         🪀 ⛓️ 🎣 ☂️ 🪲 🧢 🪆 📕 👁️ 🥛 🧱 🪞 💠 📦 🏴 ✊ 🖐️ ✌️ 🌪️ 🎀 🌳 🔁 ⚖️ 🎰 🏪 ⏰ 🗝️ 🔥").split()


def key(e: str) -> str:
    return "-".join(f"{ord(c):x}" for c in e if ord(c) != 0xFE0F)


def main(out: str) -> None:
    out_dir = Path(out)
    out_dir.mkdir(parents=True, exist_ok=True)
    font = ImageFont.truetype(FONT, 109)
    for e in dict.fromkeys(EMOJI):
        im = Image.new("RGBA", (136, 128), (0, 0, 0, 0))
        ImageDraw.Draw(im).text((0, 0), e, font=font, embedded_color=True)
        bb = im.getbbox()
        if not bb:
            print("فارغ:", e)
            continue
        im = im.crop(bb)
        side = max(im.size)
        sq = Image.new("RGBA", (side, side), (0, 0, 0, 0))
        sq.paste(im, ((side - im.width) // 2, (side - im.height) // 2))
        sq.resize((128, 128), Image.LANCZOS).save(out_dir / f"{key(e)}.png", optimize=True)


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "assets/icons")
