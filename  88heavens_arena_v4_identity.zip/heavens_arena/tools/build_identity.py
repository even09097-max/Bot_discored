"""يبني ويفحص مكتبة الهوية البصرية (assets/identity): خلفية لكل أمر وقائمة فرعية وفئة طوابق وساحة وزعيم وحدث، وشارة لكل أمر،
وصورة لكل قدرة هاتسو. صورك المرفوعة بأمر «صور» (assets/art/) لا تُمسّ أبداً وتتقدم دائماً على هذه.

    python tools/build_identity.py            # يبني الناقص فقط ثم يفحص
    python tools/build_identity.py --force    # يعيد بناء كل شيء
    python tools/build_identity.py --check    # فحص فقط (رمز خروج 1 إن وُجد نقص أو تكرار) — للاختبار الآلي
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import identity as idn  # noqa: E402


def main(argv: list[str]) -> int:
    force, check = "--force" in argv, "--check" in argv
    if not check:
        n = idn.build_library(force=force)
        print(f"كُتب {n} ملفاً في {idn.LIB}")
    rep = idn.audit([c.ar for c in idn.CMDS], help_pages=len(idn.HELP_SUBS), build=not check)
    print(f"أوامر: {rep['commands']} · خلفيات في المكتبة: {rep['art_total']} · صور مكررة: {len(rep['duplicates'])} · "
          f"بلا هوية: {len(rep['no_identity'])} · بلا خلفية: {len(rep['missing_art'])} · بلا شارة: {len(rep['missing_emblem'])}")
    for a, b in rep["duplicates"]:
        print("  ♻️ مكرر:", a, "=", b)
    up = [(a.slot, len(idn.uploaded_files(a.slot))) for a in idn.REG.values() if idn.uploaded_files(a.slot)]
    print(f"أماكن فيها صورك المرفوعة: {len(up)}")
    print("✅ كل أمر رئيسي له هوية بصرية كاملة" if rep["ok"] else "❌ يوجد نقص — راجع القائمة أعلاه")
    return 0 if rep["ok"] else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
