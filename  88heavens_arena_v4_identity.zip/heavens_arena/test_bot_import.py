"""يفحص bot.py + commands_ext.py بدون مكتبة discord (محاكي خفيف): أخطاء الاستيراد، أسماء الأوامر (صالحة وفريدة)، الأوصاف.
شغّله:  python test_bot_import.py"""
import re
import sys
import types

COMMANDS = []


class _Meta(type):
    def __getattr__(cls, n):
        return _Base()


class _Base(metaclass=_Meta):
    def __init__(self, *a, **k):
        pass

    def __call__(self, *a, **k):
        return a[0] if len(a) == 1 and callable(a[0]) and not k else _Base()

    def __getattr__(self, n):
        return _Deco()

    def __class_getitem__(cls, item):
        return cls

    def __or__(self, o):
        return self

    __ror__ = __or__


class _Deco:
    def __call__(self, *a, **k):
        return a[0] if len(a) == 1 and callable(a[0]) and not k else _Deco()

    def __getattr__(self, n):
        return _Deco()


class _Mod(types.ModuleType):
    def __getattr__(self, n):
        if n.startswith("__"):
            raise AttributeError(n)
        c = type(n, (_Base,), {})
        setattr(self, n, c)
        return c


class _Loop:
    def __init__(self, fn):
        self.fn = fn

    def __getattr__(self, n):
        return lambda *a, **k: (a[0] if a and callable(a[0]) else None)

    def is_running(self):
        return False


class Tree(_Base):
    def __init__(self, *a, **k):
        pass

    def command(self, name=None, description=None, **k):
        def deco(fn):
            COMMANDS.append((name, description, fn))
            return fn
        return deco

    def error(self, fn):
        return fn


def install():
    d = _Mod("discord")
    d.ui, d.app_commands, d.ext = _Mod("discord.ui"), _Mod("discord.app_commands"), _Mod("discord.ext")
    d.app_commands.CommandTree = Tree
    d.app_commands.guild_only = lambda: (lambda f: f)
    tasks = _Mod("discord.ext.tasks")
    tasks.loop = lambda *a, **k: (lambda fn: _Loop(fn))
    d.ext.tasks = tasks
    for n, m in (("discord", d), ("discord.ui", d.ui), ("discord.app_commands", d.app_commands), ("discord.ext", d.ext), ("discord.ext.tasks", tasks)):
        sys.modules[n] = m


if __name__ == "__main__":
    install()
    sys.path.insert(0, ".")
    import bot  # noqa: F401
    import commands_ext  # noqa: F401
    names = [c[0] for c in COMMANDS]
    assert len(names) == len(set(names)), [n for n in names if names.count(n) > 1]
    bad = [n for n in names if not re.fullmatch(r"[\w\-]{1,32}", n)]
    assert not bad, bad
    assert all(c[1] and len(c[1]) <= 100 for c in COMMANDS), [c[0] for c in COMMANDS if not c[1] or len(c[1]) > 100]
    assert len(names) <= 100
    need = {"صعود", "عصابة", "شجرة", "هاتسو", "سحب_عتاد", "صندوق", "سوق_اسود", "موسم", "انتقام", "arena_setfloor", "arena_giveitem", "arena_reset", "مهام", "حرب"}
    assert need <= set(names), need - set(names)
    print(f"✓ {len(names)} أمراً صالحاً، بلا تكرار")

    # ── الهوية البصرية: لكل أمر رئيسي صورة وخلفية وثيم، ولا نقص ولا صور مكررة ──
    import identity as idn
    rep = idn.audit(names, len(bot.HELP_PAGES), build=False)
    assert not rep["no_identity"], f"أوامر بلا هوية بصرية: {rep['no_identity']}"
    assert not rep["unused_specs"], f"هويات لأوامر غير موجودة: {rep['unused_specs']}"
    assert rep["ok"], rep
    # الاستدعاءات الثابتة idn.use("أمر", "قائمة") في الكود تشير إلى هويات حقيقية
    src = open("bot.py", encoding="utf-8").read() + open("commands_ext.py", encoding="utf-8").read()
    for m in re.finditer(r'idn\.use\("([^"]+)"(?:, "([^"]+)")?\)', src):
        spec = idn.resolve(m.group(1))
        assert spec, f"idn.use لأمر مجهول: {m.group(1)}"
        if m.group(2):
            assert m.group(2) in {k for k, _ in spec.subs}, f"قائمة فرعية مجهولة: {m.group(1)}/{m.group(2)}"
    gang = set(re.findall(r'\("[^"]+", "(\w+)"\)', src[src.index("GANG_ACTIONS"):src.index("GANG_ACTIONS") + 520]))
    assert gang == {k for k, _ in idn.resolve("gang").subs}, gang
    assert set(bot.PERIODS) == {k for k, _ in idn.resolve("control").subs}
    # خلفيات القتال: كل نمط/طابق يعطي خانة معروفة في المكتبة
    for floor in (1, 9, 10, 55, 99, 100):
        assert idn.slot_to_key(bot.bg_slot(floor)), floor
    for mode in ("boss", "hunt", "duel", "live", "revenge"):
        assert bot.bg_slot(5, mode) in ("bg_boss", "bg_hunt") or idn.slot_to_key(bot.bg_slot(5, mode)), mode
    print(f"✓ هوية بصرية كاملة: {len(names)} أمراً · {rep['art_total']} خلفية في المكتبة · بلا تكرار")
