"""
جالب صور الأنمي (هنتر × هنتر) لتزيين بطاقات اللعبة.

الترتيب (أول مصدر ينجح يُستخدم):
  1) مجلد محلي  assets/art/<السياق>/        ← ضع فيه أي صور تريدها وستُستخدم أولاً.
  2) ملف روابط  art_urls.json                ← {"سياق": ["رابط", ...]} روابط تضيفها بنفسك.
  3) ويكي ميديا (Fandom وأي ويكي أنمي آخر)   ← صفحات مثل Water Divination فيها لقطات من الحلقات.
  4) AniList ثم Jikan (MyAnimeList)          ← صور الشخصيات والأغلفة.
إذا فشل كل شيء يرجع None والبوت يرسم بطاقة بديلة جميلة، فلا يتعطل أي أمر بسبب الصور.

لا يحتاج أي مكتبة خارجية (urllib فقط) ويعمل داخل threads حتى لا يبلوك البوت.
تُحفظ الصور في cache/art لتُحمَّل مرة واحدة.
"""
from __future__ import annotations

import asyncio
import hashlib
import io
import json
import logging
import os
import random
import re
import time
import urllib.parse
import urllib.request
from pathlib import Path

from PIL import Image

import hatsu as ht
import identity as idn

log = logging.getLogger("arena.images")
BASE = Path(__file__).resolve().parent
UA = "HeavensArenaBot/2.0 (fan Discord game; contact: bot owner)"
URL_TTL = 3 * 86400
FAIL_TTL = 600
MAX_BYTES = 8_000_000
BAD_NAME = re.compile(r"(icon|logo|symbol|flag|wiki|favicon|button|stub|placeholder|ambox|commons|\.svg|\.gif|\.ogg|\.mp3)", re.I)

DEFAULT_WIKIS = ["https://hunterxhunter.fandom.com/api.php"]
ANILIST_URL = "https://graphql.anilist.co"
JIKAN_URL = "https://api.jikan.moe/v4"
ANILIST_HXH_ID = 11061    # Hunter x Hunter (2011)

# السياق → صفحات الويكي + أسماء شخصيات للبحث
CONTEXTS: dict[str, dict] = {
    "nen_test": {"wiki": ["Water Divination", "Nen"], "chars": ["Wing"]},
    "enhancer": {"wiki": ["Enhancement", "Nen"], "chars": ["Gon Freecss"]},
    "transmuter": {"wiki": ["Transmutation", "Nen"], "chars": ["Killua Zoldyck"]},
    "conjurer": {"wiki": ["Conjuration", "Nen"], "chars": ["Kurapika"]},
    "emitter": {"wiki": ["Emission", "Nen"], "chars": ["Razor"]},
    "manipulator": {"wiki": ["Manipulation", "Nen"], "chars": ["Shalnark"]},
    "specialist": {"wiki": ["Specialization", "Nen"], "chars": ["Chrollo Lucilfer"]},
    "tower": {"wiki": ["Heavens Arena", "Heavens Arena Arc"], "chars": ["Gon Freecss"]},
    "floor_master": {"wiki": ["Hisoka Morow"], "chars": ["Hisoka Morow"]},
    "victory": {"wiki": ["Gon Freecss"], "chars": ["Gon Freecss"]},
    "defeat": {"wiki": ["Killua Zoldyck"], "chars": ["Killua Zoldyck"]},
    "gacha": {"wiki": ["Greed Island", "Greed Island (Game)"], "chars": ["Biscuit Krueger"]},
    "guild": {"wiki": ["Phantom Troupe"], "chars": ["Chrollo Lucilfer"]},
    "war": {"wiki": ["Phantom Troupe", "Zoldyck Family"], "chars": ["Illumi Zoldyck"]},
    "help": {"wiki": ["Hunter Exam", "Hunter Association"], "chars": ["Gon Freecss"]},
    "vow": {"wiki": ["Nen", "Kurapika"], "chars": ["Kurapika"]},
    "missions": {"wiki": ["Hunter Exam"], "chars": ["Leorio Paradinight"]},
    "shop": {"wiki": ["Yorknew City"], "chars": ["Biscuit Krueger"]},
    "profile": {"wiki": ["Hunter License"], "chars": ["Gon Freecss"]},
    # ── تحديث 3 ──
    "gang": {"wiki": ["Phantom Troupe", "Zoldyck Family"], "chars": ["Chrollo Lucilfer"]},
    "market": {"wiki": ["Yorknew City", "Auction"], "chars": ["Biscuit Krueger"]},
    "season": {"wiki": ["Hunter Exam", "Heavens Arena Arc"], "chars": ["Isaac Netero"]},
    "tree": {"wiki": ["Nen", "Hatsu"], "chars": ["Wing"]},
    "gear_gacha": {"wiki": ["Greed Island", "Greed Island (Game)"], "chars": ["Biscuit Krueger"]},
    "revenge": {"wiki": ["Kurapika"], "chars": ["Kurapika"]},
    "echo": {"wiki": ["Heavens Arena"], "chars": ["Hisoka Morow"]},
    "hatsu": {"wiki": ["Hatsu", "Nen"], "chars": ["Gon Freecss", "Killua Zoldyck"]},
    "season_hall": {"wiki": ["Hunter Association"], "chars": ["Isaac Netero"]},
}


# ───────────────────────── خانات الصور (كل مكان في اللعبة يقبل صورك أو GIF) ─────────────────────────
# المفتاح: (الكلمة العربية التي تكتبها، الوصف، المجموعة)
SLOTS: dict[str, tuple[str, str, str]] = {
    # مشاهد
    "nen_test": ("اختبار", "اختبار كأس الماء", "مشاهد"), "tower": ("برج", "صورة البرج والطوابق", "مشاهد"),
    "victory": ("فوز", "شاشة الانتصار", "مشاهد"), "defeat": ("هزيمة", "شاشة الهزيمة", "مشاهد"),
    "levelup": ("ارتقاء", "رفع المستوى", "مشاهد"), "gacha": ("سحب", "شاشة السحب", "مشاهد"),
    "jackpot": ("اسطوري", "سحبة أسطورية", "مشاهد"), "daily": ("يومي", "المكافأة اليومية", "مشاهد"),
    "missions": ("مهام", "المهام", "مشاهد"), "shop": ("متجر", "المتجر", "مشاهد"), "profile": ("ملف", "رخصة الصياد", "مشاهد"),
    "guild": ("نقابة", "العصابات (قديم)", "مشاهد"), "war": ("حرب", "حرب العصابات", "مشاهد"), "help": ("شرح", "الشرح", "مشاهد"),
    "gang": ("عصابة", "العصابات (غلاف بطاقة العصابة)", "مشاهد"), "market": ("سوق", "السوق الأسود", "مشاهد"),
    "season": ("موسم", "المواسم", "مشاهد"), "tree": ("شجرة", "شجرة النين", "مشاهد"), "gear_gacha": ("سحب_عتاد", "سحب العتاد", "مشاهد"),
    "revenge": ("انتقام", "سجل الانتقام", "مشاهد"), "echo": ("ظل", "ظل المسيطر", "مشاهد"), "hatsu": ("هاتسو", "قدرات هاتسو", "مشاهد"),
    "vow": ("نذر", "النذور", "مشاهد"), "hunt": ("صيد", "رحلات الصيد", "مشاهد"), "enhance": ("تحسين", "تحسين العتاد", "مشاهد"),
    "fuse": ("دمج", "دمج العتاد", "مشاهد"), "achieve": ("انجازات", "الإنجازات", "مشاهد"),
    "event": ("حدث", "أحداث الطوابق (كنز، فخ...)", "مشاهد"), "boss_win": ("سقوط", "سقوط الزعيم", "مشاهد"),
    # خلفيات القتال حسب الطوابق
    "bg_street": ("شارع", "خلفية الطوابق 1-19", "خلفيات"), "bg_arena": ("ساحة", "خلفية الطوابق 20-59", "خلفيات"),
    "bg_nen": ("هالة", "خلفية الطوابق 60-89", "خلفيات"), "bg_temple": ("معبد", "خلفية الطوابق 90-99", "خلفيات"),
    "bg_summit": ("قمة", "خلفية الطابق 100", "خلفيات"), "bg_boss": ("ساحة_زعيم", "خلفية معارك الزعيم", "خلفيات"),
    "bg_hunt": ("غابة", "خلفية الصيد", "خلفيات"),
    # فئات النين
    "enhancer": ("تعزيز", "فئة التعزيز", "النين"), "transmuter": ("تحويل", "فئة التحويل", "النين"),
    "conjurer": ("تجسيد", "فئة التجسيد", "النين"), "emitter": ("ارسال", "فئة الإرسال", "النين"),
    "manipulator": ("تلاعب", "فئة التلاعب", "النين"), "specialist": ("تخصص", "فئة التخصص", "النين"),
    # الزعماء
    "hisoka_morow": ("هيسوكا", "زعيم هيسوكا", "زعماء"), "illumi_zoldyck": ("ايلومي", "زعيم إيلومي", "زعماء"),
    "chrollo_lucilfer": ("كروللو", "زعيم كروللو", "زعماء"), "neferpitou": ("بيتو", "زعيم نفيربيتو", "زعماء"),
    "isaac_netero": ("نيتيرو", "زعيم نيتيرو", "زعماء"), "meruem": ("ميروم", "زعيم ميروم", "زعماء"),
    # الخصوم
    "enemy_brawler": ("متمرن", "مقاتل متمرن", "خصوم"), "enemy_boxer": ("ملاكم", "ملاكم الأزقة", "خصوم"),
    "enemy_guard": ("حارس", "حارس الطابق", "خصوم"), "enemy_swordsman": ("سياف", "مبارز / سيّاف", "خصوم"),
    "enemy_sniper": ("قناص", "قناص مقنّع", "خصوم"), "enemy_beast": ("وحش", "وحش الأنقاض", "خصوم"),
    "enemy_nen": ("منين", "مستخدم نين", "خصوم"), "enemy_hunter": ("منشق", "هنتر منشق", "خصوم"),
    "enemy_ninja": ("ظلام", "وريث الظلام", "خصوم"), "enemy_mage": ("ساحر", "ساحر الأبراج", "خصوم"),
    "enemy_master": ("سيد", "سيد الطابق", "خصوم"), "enemy_lord": ("بطل", "بطل البرج الأعظم", "خصوم"),
    "enemy_rat": ("فار", "فئران الأنفاق", "خصوم"), "enemy_wolf": ("ذئب_صيد", "ذئاب الغابة", "خصوم"),
    "enemy_bandit": ("قاطع", "قطّاع الطرق", "خصوم"), "enemy_spider": ("عنكبوت", "عناكب الظلال", "خصوم"),
    "enemy_ant": ("نملة", "جنود النمل", "خصوم"), "enemy_ghost": ("شبح", "أشباح النين", "خصوم"),
    "enemy_dragon": ("تنين", "تنين الطابق", "خصوم"),
    # العتاد (صورة لكل نوع عتاد)
    "item_sword": ("سيف", "سيف", "عتاد"), "item_dagger": ("خنجر", "خنجر", "عتاد"), "item_spear": ("رمح", "رمح", "عتاد"),
    "item_gloves": ("قفازات", "قفازات", "عتاد"), "item_shield": ("درع", "درع", "عتاد"), "item_vest": ("سترة", "سترة", "عتاد"),
    "item_cloak": ("عباءة", "عباءة", "عتاد"), "item_helmet": ("خوذة", "خوذة", "عتاد"), "item_mask": ("قناع", "قناع", "عتاد"),
    "item_collar": ("طوق", "طوق", "عتاد"), "item_wolf": ("ذئب", "مرافق ذئب", "عتاد"), "item_falcon": ("صقر", "مرافق صقر", "عتاد"),
    "item_cat": ("قط", "قط الظلال", "عتاد"), "item_fox": ("ثعلب", "مرافق ثعلب", "عتاد"), "item_card": ("بطاقة", "بطاقة شفاء", "عتاد"),
    "rarity_common": ("عادي", "إطار العناصر العادية", "عتاد"), "rarity_rare": ("نادر", "إطار العناصر النادرة", "عتاد"),
    "rarity_epic": ("ملحمي", "إطار العناصر الملحمية", "عتاد"), "rarity_legendary": ("اسطوري_عتاد", "إطار الأسطورية", "عتاد"),
}
for _g in ht.GEAR.values():          # عتاد هانتر: كل قطعة لها خانة صورة (تُجلب تلقائياً من الويكي أو ترفع صورتك)
    SLOTS[_g["slot"]] = (_g["name"], f"{_g['name']} (عتاد هانتر)", "عتاد هانتر")
import cards as _cd
_seen_words: set[str] = set()
for _k, _c in _cd.CARDS.items():     # رفع صورة لكل بطاقة بطل: «صور اضافة بطاقة_<الاسم> + صورة»
    _w = "بطاقة_" + _c["name"].split()[0]
    if _w in _seen_words:
        _w = "بطاقة_" + _c["name"].replace(" ", "_")
    _seen_words.add(_w)
    SLOTS[f"card_{_k}"] = (_w, f"صورة بطاقة {_c['name']}", "صور البطاقات")
SLOTS.update(idn.slot_entries())   # صورة لكل أمر + خلفية لكل قسم/قائمة فرعية + خلفيات الطوابق والساحات والزعماء والأحداث
GROUPS = ["مشاهد", "خلفيات", "النين", "زعماء", "خصوم", "عتاد", "عتاد هانتر"] + list(idn.groups())
ITEM_SLOT = {"سيف": "item_sword", "خنجر": "item_dagger", "رمح": "item_spear", "قفازات": "item_gloves", "درع": "item_shield",
             "سترة": "item_vest", "عباءة": "item_cloak", "خوذة": "item_helmet", "قناع": "item_mask", "طوق": "item_collar",
             "ذئب": "item_wolf", "صقر": "item_falcon", "قط الظلال": "item_cat", "ثعلب": "item_fox", "بطاقة شفاء": "item_card"}
EXTS = (".png", ".jpg", ".jpeg", ".webp", ".gif")
MAX_PER_SLOT = 12
MAX_UPLOAD = 8_000_000


def _norm_word(w: str) -> str:
    w = re.sub(r"[\u064b-\u065f\u0640]", "", w).strip().lower().replace("_", "")
    w = w.translate(str.maketrans("أإآٱىة", "اااايه"))
    return w[2:] if w.startswith("ال") and len(w) > 3 else w


def resolve_slot(word: str) -> str | None:
    """يحوّل كلمة عربية أو مفتاحاً إنجليزياً إلى مفتاح خانة."""
    w = _norm_word(word)
    if not w:
        return None
    for key, (ar, desc, _g) in SLOTS.items():
        if w in (_norm_word(key), _norm_word(ar), _norm_word(desc)):
            return key
    for key, (ar, desc, _g) in SLOTS.items():   # مطابقة بداية الكلمة
        if len(w) >= 3 and (_norm_word(ar).startswith(w) or _norm_word(key).startswith(w)):
            return key
    return None


def item_slot_for(name: str) -> str | None:
    for base in sorted(ITEM_SLOT, key=len, reverse=True):
        if name.startswith(base):
            return ITEM_SLOT[base]
    return None


def _slug(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", s.lower()).strip("_") or "x"


def _http(url: str, data: bytes | None = None, headers: dict | None = None, timeout: float = 7.0) -> bytes:
    h = {"User-Agent": UA, "Accept": "*/*"}
    h.update(headers or {})
    req = urllib.request.Request(url, data=data, headers=h)
    with urllib.request.urlopen(req, timeout=timeout) as r:   # noqa: S310 (روابط https فقط)
        return r.read(MAX_BYTES + 1)


def _http_json(url: str, data: dict | None = None, timeout: float = 7.0) -> dict:
    body = json.dumps(data).encode() if data is not None else None
    hdr = {"Content-Type": "application/json", "Accept": "application/json"} if data is not None else {"Accept": "application/json"}
    return json.loads(_http(url, body, hdr, timeout).decode("utf-8", "replace"))


def _scale_wikia(url: str, width: int = 900) -> str:
    if "static.wikia.nocookie.net" in url and "/revision/" in url:
        return url.split("/revision/")[0] + f"/revision/latest/scale-to-width-down/{width}"
    return url


# ───────────────────────── المزوّدون (دوال متزامنة تُشغَّل في thread) ─────────────────────────
def wiki_page_images(api: str, title: str, limit: int = 40) -> list[str]:
    """صور صفحة في ويكي ميديا: صورة الصفحة الرئيسية + باقي صورها الكبيرة."""
    q = urllib.parse.urlencode({"action": "query", "format": "json", "redirects": 1, "titles": title,
                                "prop": "pageimages|images", "piprop": "original", "imlimit": limit})
    data = _http_json(f"{api}?{q}")
    pages = (data.get("query") or {}).get("pages") or {}
    urls: list[str] = []
    names: list[str] = []
    for p in pages.values():
        orig = (p.get("original") or {}).get("source")
        if orig and not BAD_NAME.search(orig):
            urls.append(orig)
        for im in p.get("images") or []:
            t = im.get("title", "")
            if t and not BAD_NAME.search(t) and re.search(r"\.(jpe?g|png|webp)$", t, re.I):
                names.append(t)
    if names:
        q2 = urllib.parse.urlencode({"action": "query", "format": "json", "titles": "|".join(names[:limit]),
                                     "prop": "imageinfo", "iiprop": "url|size|mime"})
        info = ((_http_json(f"{api}?{q2}").get("query") or {}).get("pages") or {})
        for p in info.values():
            for ii in p.get("imageinfo") or []:
                if ii.get("width", 0) >= 480 and ii.get("height", 0) >= 270 and str(ii.get("mime", "")).startswith("image/") \
                        and ii.get("url") and ii["url"] not in urls:
                    urls.append(ii["url"])
    return urls


def wiki_lead_image(api: str, title: str, width: int = 700) -> list[str]:
    """صورة صفحة الشخصية الرئيسية (صندوق المعلومات) في الويكي بحجم مصغّر. هي الأنسب لوجه البطاقة."""
    q = urllib.parse.urlencode({"action": "query", "format": "json", "redirects": 1, "titles": title,
                                "prop": "pageimages", "pithumbsize": width})
    pages = ((_http_json(f"{api}?{q}").get("query") or {}).get("pages")) or {}
    return [u for p in pages.values() for u in [(p.get("thumbnail") or {}).get("source")] if u]


def wiki_search_title(api: str, text: str) -> str | None:
    q = urllib.parse.urlencode({"action": "query", "format": "json", "list": "search", "srsearch": text, "srlimit": 1})
    hits = ((_http_json(f"{api}?{q}").get("query") or {}).get("search")) or []
    return hits[0]["title"] if hits else None


def anilist_character(name: str) -> list[str]:
    q = "query($s:String){Character(search:$s){image{large}}}"
    d = _http_json(ANILIST_URL, {"query": q, "variables": {"s": name}})
    img = (((d.get("data") or {}).get("Character") or {}).get("image") or {}).get("large")
    return [img] if img else []


def anilist_banner() -> list[str]:
    q = "query($id:Int){Media(id:$id,type:ANIME){bannerImage coverImage{extraLarge}}}"
    d = _http_json(ANILIST_URL, {"query": q, "variables": {"id": ANILIST_HXH_ID}})
    m = (d.get("data") or {}).get("Media") or {}
    return [u for u in (m.get("bannerImage"), (m.get("coverImage") or {}).get("extraLarge")) if u]


def jikan_character(name: str) -> list[str]:
    d = _http_json(f"{JIKAN_URL}/characters?q={urllib.parse.quote(name)}&limit=3")
    out = []
    for c in d.get("data") or []:
        jpg = ((c.get("images") or {}).get("jpg") or {}).get("image_url")
        if jpg and "questionmark" not in jpg:
            out.append(jpg)
    return out[:1]


def jikan_character_exact(name: str) -> list[str]:
    """صورة شخصية من MyAnimeList بشرط أن يحوي اسمها الاسم الأول المطلوب (حتى لا تأتي شخصية أخرى مكانها)."""
    d = _http_json(f"{JIKAN_URL}/characters?q={urllib.parse.quote(name)}&limit=3&order_by=favorites&sort=desc")
    first = name.split()[0].lower()
    out = []
    for c in d.get("data") or []:
        jpg = ((c.get("images") or {}).get("jpg") or {}).get("image_url")
        if jpg and "questionmark" not in jpg and first in (c.get("name") or "").lower():
            out.append(jpg)
    return out


class ImageHub:
    def __init__(self, cache_dir: str | os.PathLike = BASE / "cache", wikis: list[str] | None = None, enabled: bool = True) -> None:
        self.cache = Path(cache_dir)
        (self.cache / "art").mkdir(parents=True, exist_ok=True)
        env = [w.strip() for w in os.environ.get("WIKI_APIS", "").split(",") if w.strip()]
        self.wikis = wikis or (env + DEFAULT_WIKIS)
        self.enabled = enabled and os.environ.get("ANIME_IMAGES", "1") != "0"
        self.local_dir = BASE / "assets" / "art"
        self._urls: dict[str, tuple[float, list[str]]] = {}
        self._lock = asyncio.Semaphore(3)
        self._pending: dict[tuple, asyncio.Future] = {}
        self._medals: dict[str, bytes] = {}
        self._card_fail: dict[str, float] = {}      # بطاقة → وقت آخر فشل جلب (لا نعيد المحاولة فوراً)
        self._url_file = self.cache / "urls.json"
        self._load_disk()

    # ── تخزين مؤقت لقوائم الروابط ──
    def _load_disk(self) -> None:
        try:
            raw = json.loads(self._url_file.read_text(encoding="utf-8"))
            self._urls = {k: (float(v[0]), list(v[1])) for k, v in raw.items()}
        except Exception:
            self._urls = {}

    def _save_disk(self) -> None:
        try:
            self._url_file.write_text(json.dumps({k: [t, u] for k, (t, u) in self._urls.items() if u}, ensure_ascii=False), encoding="utf-8")
        except OSError:
            pass

    # ── المصادر المحلية واليدوية ──
    def local_files(self, key: str, gifs: bool = True) -> list[Path]:
        d = self.local_dir / key
        if not d.is_dir():
            return []
        exts = EXTS if gifs else EXTS[:-1]
        return sorted(p for p in d.iterdir() if p.suffix.lower() in exts)

    def local_gif(self, key: str) -> bytes | None:
        """GIF مرفوع لهذه الخانة (يُرسل متحركاً)."""
        files = [p for p in self.local_files(key) if p.suffix.lower() == ".gif"]
        if not files:
            return None
        try:
            data = idn.pick(f"gif:{key}", files).read_bytes()
            return data if len(data) <= MAX_UPLOAD else None
        except OSError:
            return None

    def counts(self) -> dict[str, int]:
        return {k: len(self.local_files(k)) for k in SLOTS}

    def add_local(self, slot: str, data: bytes, ext_hint: str = "") -> str:
        """يحفظ صورة/GIF في الخانة بعد التحقق منها. يعيد اسم الملف. يرفع ValueError برسالة عربية."""
        if slot not in SLOTS:
            raise ValueError("مكان غير معروف.")
        if len(data) > MAX_UPLOAD:
            raise ValueError("الملف أكبر من 8 ميغابايت.")
        try:
            im = Image.open(io.BytesIO(data))
            im.load()
            fmt = (im.format or "").upper()
        except Exception:
            raise ValueError("هذا الملف ليس صورة صالحة.")
        d = self.local_dir / slot
        d.mkdir(parents=True, exist_ok=True)
        if len(self.local_files(slot)) >= MAX_PER_SLOT:
            raise ValueError(f"هذا المكان وصل الحد ({MAX_PER_SLOT} ملفاً). احذف بعضها أولاً.")
        stamp = f"{int(time.time() * 1000)}"
        if fmt == "GIF":
            path = d / f"{stamp}.gif"
            path.write_bytes(data)
        else:
            im = im.convert("RGBA") if im.mode in ("P", "LA", "RGBA") else im.convert("RGB")
            im.thumbnail((1400, 1400))
            path = d / f"{stamp}.png" if im.mode == "RGBA" else d / f"{stamp}.jpg"
            if path.suffix == ".png":
                im.save(path, "PNG", optimize=True)
            else:
                im.save(path, "JPEG", quality=90)
        return path.name

    def remove_local(self, slot: str, index: int | None = None) -> int:
        files = self.local_files(slot)
        targets = files if index is None else files[index - 1:index]
        for p in targets:
            try:
                p.unlink()
            except OSError:
                pass
        return len(targets)

    def curated(self, key: str) -> list[str]:
        try:
            data = json.loads((BASE / "art_urls.json").read_text(encoding="utf-8"))
            return [u for u in data.get(key, []) if isinstance(u, str) and u.startswith("http")]
        except Exception:
            return []

    # ── البحث الحي ──
    def _discover(self, key: str, wiki_titles: list[str], chars: list[str]) -> list[str]:
        found: list[str] = []
        for title in wiki_titles:
            for api in self.wikis:
                try:
                    imgs = wiki_page_images(api, title)
                    if not imgs:
                        alt = wiki_search_title(api, title)
                        imgs = wiki_page_images(api, alt) if alt else []
                    found += [_scale_wikia(u) for u in imgs]
                except Exception as e:
                    log.debug("wiki %s %s: %s", api, title, e)
            if len(found) >= 3:
                break
        if len(found) < 2:
            for name in chars:
                for fn in (anilist_character, jikan_character):
                    try:
                        found += fn(name)
                    except Exception as e:
                        log.debug("%s %s: %s", fn.__name__, name, e)
                    if found:
                        break
        if not found and key in ("tower", "help", "victory"):
            try:
                found += anilist_banner()
            except Exception as e:
                log.debug("anilist banner: %s", e)
        return list(dict.fromkeys(found))

    async def urls(self, key: str, wiki_titles: list[str], chars: list[str]) -> list[str]:
        now = time.time()
        hit = self._urls.get(key)
        if hit and now - hit[0] < (URL_TTL if hit[1] else FAIL_TTL):
            return hit[1]
        async with self._lock:
            found = await asyncio.to_thread(self._discover, key, wiki_titles, chars)
        self._urls[key] = (now, found)
        await asyncio.to_thread(self._save_disk)
        return found

    # ── تنزيل وتجهيز الصورة ──
    def _download(self, url: str) -> bytes | None:
        f = self.cache / "art" / (hashlib.sha1(url.encode()).hexdigest() + ".jpg")
        if f.exists():
            return f.read_bytes()
        try:
            raw = _http(url, timeout=9.0)
            if len(raw) > MAX_BYTES:
                return None
            im = Image.open(io.BytesIO(raw))
            im.load()
            im = im.convert("RGB")
            im.thumbnail((900, 900))
            buf = io.BytesIO()
            im.save(buf, "JPEG", quality=88)
            f.write_bytes(buf.getvalue())
            return buf.getvalue()
        except Exception as e:
            log.debug("download %s: %s", url, e)
            return None

    # ── الواجهة العامة ──
    async def art(self, context: str, name: str | None = None, timeout: float = 2.0) -> bytes | None:
        """صورة مناسبة للسياق (أو لشخصية باسم معيّن). لا يرفع استثناءات؛ يعيد None عند الفشل.
        إن تأخر الجلب عن المهلة يكمل في الخلفية ويُحفظ في الكاش فتجهز الصورة في المرة القادمة."""
        key = (context, name or "")
        task = self._pending.get(key)
        if task is None or task.done() and task.cancelled():
            task = asyncio.ensure_future(self._art_safe(context, name))
            self._pending[key] = task
            task.add_done_callback(lambda t, k=key: self._pending.pop(k, None))
        data = None
        try:
            done, _ = await asyncio.wait({task}, timeout=timeout)
            data = task.result() if done else None
        except Exception as e:
            log.debug("art %s/%s: %s", context, name, e)
        # لا واجهة بلا صورة: إن لم تُرفع صورة ولم تُجلب بعد، تُستخدم صورة الهوية المولَّدة لهذا السياق
        return data or idn.hero_for_context(context, name)

    async def _art_safe(self, context: str, name: str | None) -> bytes | None:
        try:
            return await asyncio.wait_for(self._art(context, name), 25)
        except Exception as e:
            log.debug("art %s/%s: %s", context, name, e)
            return None

    LEGACY_BG = {"bg_hunt": "arena:hunt", "bg_boss": "arena:boss"}

    def local_art(self, key: str) -> bytes | None:
        """صورة المكان بلا إنترنت (فورية): صورتك المرفوعة (بالتناوب بلا تكرار) ← الصورة المولَّدة لهوية المكان إن كان
        من الخلفيات (طوابق/ساحات/زعماء/أحداث/أقسام). أماكن العتاد والخصوم لا تُولَّد فتعيد None إن لم ترفع صورة."""
        files = self.local_files(key)
        if files:
            try:
                return idn.pick(f"art:{key}", files).read_bytes()
            except OSError:
                pass
        ak = self.LEGACY_BG.get(key) or idn.slot_to_key(key)
        if ak is None:
            return None
        if ak.startswith("floor:"):          # خلفية فئة طوابق: رُفعت على الخانة القديمة (V3) ← المولَّدة
            lo = idn.FLOOR_BANDS[int(ak.rsplit("_", 1)[1]) - 1][0]
            return idn.floor_art(lo, idn.legacy_floor_slot(lo))
        return idn.art_bytes(ak)

    async def warm(self, items: list[tuple[str, str | None]], pause: float = 4.0) -> None:
        """تسخين الكاش في الخلفية بعد التشغيل (لا يؤخر أي أمر)."""
        for ctx, name in items:
            try:
                await self.art(ctx, name, timeout=20.0)
            except Exception:
                pass
            await asyncio.sleep(pause)

    # ── صور بطاقات الشخصيات ──
    # الأولوية: صورة ترفعها أنت في assets/art/card_<مفتاح>/ ← الكاش cache/cards/<مفتاح>.jpg ← الجلب من الإنترنت
    # (صورة صفحة الشخصية في ويكي Hunterpedia ← Jikan/MyAnimeList ← صور الصفحة). يُحفظ أول نجاح فلا يُعاد الجلب.
    def _card_path(self, key: str) -> Path:
        return self.cache / "cards" / f"{key}.jpg"

    def card_art_cached(self, key: str) -> bytes | None:
        """صورة البطاقة بلا أي شبكة (آمنة أثناء الرسم). يعيد None إن لم تُجلب بعد."""
        files = self.local_files(f"card_{key}", gifs=False)
        for f in ([idn.pick(f"card:{key}", files)] if files else []) + [self._card_path(key)]:
            try:
                if f.exists():
                    return f.read_bytes()
            except OSError:
                pass
        return None

    @staticmethod
    def _urls_safe(fn, *args) -> list[str]:
        try:
            return fn(*args) or []
        except Exception as e:
            log.debug("%s%s: %s", getattr(fn, "__name__", fn), args, e)
            return []

    def _fetch_card_art(self, card: dict) -> bytes | None:
        """متزامن (يُشغَّل في thread): يجرّب المصادر بالترتيب ويعيد أول صورة صالحة."""
        name = card["en"]
        sources = (
            lambda: [u for api in self.wikis for u in self._urls_safe(wiki_lead_image, api, name)],
            lambda: self._urls_safe(jikan_character_exact, name),
            lambda: [u for api in self.wikis for u in self._urls_safe(wiki_page_images, api, name)[:3]],
        )
        for src in sources:
            for url in src()[:3]:
                data = self._download(_scale_wikia(url))
                if data:
                    return data
        return None

    async def _card_safe(self, card: dict) -> bytes | None:
        key = card["key"]
        data = None
        try:
            async with self._lock:
                data = await asyncio.wait_for(asyncio.to_thread(self._fetch_card_art, card), 45)
        except Exception as e:
            log.debug("card art %s: %s", key, e)
        if data:
            try:
                path = self._card_path(key)
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(data)
            except OSError:
                pass
        else:
            self._card_fail[key] = time.time()
        return data

    async def card_art(self, card: dict, budget: float = 8.0) -> bytes | None:
        """صورة بطاقة شخصية (JPEG) أو None. إن تأخر الجلب عن الميزانية يكمل في الخلفية ويُحفظ للمرة القادمة."""
        key = card["key"]
        cached = self.card_art_cached(key)
        if cached or not self.enabled:
            return cached
        if time.time() - self._card_fail.get(key, 0) < FAIL_TTL:
            return None
        pk = ("card", key)
        task = self._pending.get(pk)
        if task is None:
            task = asyncio.ensure_future(self._card_safe(card))
            self._pending[pk] = task
            task.add_done_callback(lambda t, k=pk: self._pending.pop(k, None))
        try:
            done, _ = await asyncio.wait({task}, timeout=budget)
            return task.result() if done else None
        except Exception as e:
            log.debug("card_art %s: %s", key, e)
            return None

    async def card_arts(self, cards: list[dict], budget: float = 7.0) -> dict[str, bytes]:
        """يجلب صور عدة بطاقات بالتوازي ضمن ميزانية زمنية، ويعيد ما نجح فقط."""
        uniq = {c["key"]: c for c in cards}
        res = await asyncio.gather(*(self.card_art(c, budget) for c in uniq.values()), return_exceptions=True)
        return {k: r for k, r in zip(uniq, res) if isinstance(r, (bytes, bytearray))}

    async def warm_cards(self, cards: list[dict], delay: float = 2.0) -> int:
        """تسخين في الخلفية: ينزّل صور البطاقات الناقصة ببطء كي يكون الاستدعاء لحظياً. يعيد عدد ما نجح."""
        done = 0
        for c in cards:
            if not self.enabled:
                break
            if self.card_art_cached(c["key"]):
                continue
            if await self.card_art(c, 30.0):
                done += 1
            await asyncio.sleep(delay)
        return done

    # ── صور عتاد هانتر (سحب العتاد): تُجلب من الويكي وتُحفظ في cache/gear ولا تُرسم ──
    def _gear_path(self, key: str) -> Path:
        return self.cache / "gear" / f"{key}.jpg"

    def gear_art_cached(self, gear: dict) -> bytes | None:
        files = self.local_files(gear["slot"], gifs=False)          # صورتك المرفوعة بأمر «صور» تتقدم
        for f in ([idn.pick(f"gear:{gear['key']}", files)] if files else []) + [self._gear_path(gear["key"])]:
            try:
                if f.exists():
                    return f.read_bytes()
            except OSError:
                pass
        return None

    def gear_art_map(self) -> dict[str, bytes]:
        """{خانة العتاد: bytes} لكل ما جُلب أو رُفع — يُمرَّر لمحرك الرسم."""
        out = {}
        for gr in ht.GEAR.values():
            d = self.gear_art_cached(gr)
            if not d:      # لم تُجلب صورة بعد: ميدالية مولَّدة خاصة بهذه القطعة (لا تبقى قطعة بلا هوية)
                d = self._medals.get(gr["slot"])
                if d is None:
                    try:
                        d = self._medals[gr["slot"]] = idn.gear_medal(gr["slot"], gr["emoji"], gr["r"])
                    except Exception as e:
                        log.debug("medal %s: %s", gr["slot"], e)
            if d:
                out[gr["slot"]] = d
        return out

    def _fetch_gear_art(self, gear: dict) -> bytes | None:
        sources = (
            lambda: [u for api in self.wikis for t in gear["wiki"] for u in self._urls_safe(wiki_lead_image, api, t)],
            lambda: [u for api in self.wikis for t in gear["wiki"] for u in self._urls_safe(wiki_page_images, api, t)[:3]],
            lambda: [u for c in gear["chars"] for u in self._urls_safe(jikan_character_exact, c)],
        )
        for src in sources:
            for url in src()[:3]:
                data = self._download(_scale_wikia(url))
                if data:
                    return data
        return None

    async def gear_art(self, gear: dict, budget: float = 8.0) -> bytes | None:
        key = gear["key"]
        cached = self.gear_art_cached(gear)
        if cached or not self.enabled:
            return cached
        if time.time() - self._card_fail.get("g:" + key, 0) < FAIL_TTL:
            return None
        pk = ("gear", key)
        task = self._pending.get(pk)
        if task is None:
            task = asyncio.ensure_future(self._gear_safe(gear))
            self._pending[pk] = task
            task.add_done_callback(lambda t, k=pk: self._pending.pop(k, None))
        try:
            done, _ = await asyncio.wait({task}, timeout=budget)
            return task.result() if done else None
        except Exception as e:
            log.debug("gear_art %s: %s", key, e)
            return None

    async def _gear_safe(self, gear: dict) -> bytes | None:
        data = None
        try:
            async with self._lock:
                data = await asyncio.wait_for(asyncio.to_thread(self._fetch_gear_art, gear), 45)
        except Exception as e:
            log.debug("gear art %s: %s", gear["key"], e)
        if data:
            try:
                path = self._gear_path(gear["key"])
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(data)
            except OSError:
                pass
        else:
            self._card_fail["g:" + gear["key"]] = time.time()
        return data

    async def gear_arts(self, gears: list[dict], budget: float = 7.0) -> dict[str, bytes]:
        uniq = {x["slot"]: x for x in gears}
        res = await asyncio.gather(*(self.gear_art(x, budget) for x in uniq.values()), return_exceptions=True)
        return {k: r for k, r in zip(uniq, res) if isinstance(r, (bytes, bytearray))}

    async def warm_gear(self, delay: float = 2.5) -> int:
        """يحمّل صور العتاد الناقصة ببطء في الخلفية بعد التشغيل."""
        done = 0
        for gr in ht.GEAR.values():
            if not self.enabled:
                break
            if self.gear_art_cached(gr):
                continue
            if await self.gear_art(gr, 30.0):
                done += 1
            await asyncio.sleep(delay)
        return done

    async def _art(self, context: str, name: str | None) -> bytes | None:
        key = _slug(name) if name else context
        local = self.local_files(key) or (self.local_files(context) if name else [])
        if local:
            try:
                return idn.pick(f"art:{key}", local).read_bytes()
            except OSError:
                pass
        if not self.enabled:
            return None
        urls = self.curated(key) or self.curated(context)
        if not urls:
            if name:
                wiki, chars = [name], [name]
            else:
                spec = CONTEXTS.get(context, {"wiki": [], "chars": []})
                wiki, chars = spec["wiki"], spec["chars"]
            urls = await self.urls(key, wiki, chars)
        start = idn._rotate(f"url:{key}", len(urls))      # تناوب بدل العشوائية: لا تتكرر الصورة نفسها مرتين متتاليتين
        for url in (urls[start:] + urls[:start])[:3]:
            data = await asyncio.to_thread(self._download, url)
            if data:
                return data
        return None


async def fetch_bytes(url: str, timeout: float = 5.0) -> bytes | None:
    """تنزيل بسيط (للصور الرمزية مثلاً)."""
    try:
        return await asyncio.wait_for(asyncio.to_thread(_http, url, None, None, timeout), timeout + 1)
    except Exception:
        return None
