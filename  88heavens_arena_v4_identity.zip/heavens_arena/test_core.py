"""اختبارات المحرك وقاعدة البيانات (بدون discord).  شغّلها:  python test_core.py"""
from __future__ import annotations

import asyncio
from pathlib import Path
import os
import random
import sqlite3
import tempfile

import game as g
from database import Database
from game import GameError


async def rich(db, *ids: int, floor: int = 45) -> None:
    """يجهّز لاعبين لتأسيس عصابة (طابق + ذهب + جواهر كافية)."""
    for i in ids:
        await db._run(lambda c, i=i: c.execute("UPDATE users SET floor = ?, gold = gold + 200000, gems = gems + 500 WHERE user_id = ?", (floor, i)))


def fighter(**kw) -> g.Fighter:
    base = dict(name="x", hp=100, max_hp=100, atk=20, defense=5, speed=10, nen=None, aura=60, max_aura=60)
    base.update(kw)
    return g.Fighter(**base)


def run_battle(a: g.Fighter, b: g.Fighter, seed: int = 1) -> g.Battle:
    bt = g.Battle(a, b, random.Random(seed))
    while not bt.over:
        bt.play_round(bt.suggest_action())
    return bt


# ───────────── محرك القتال ─────────────
def test_stats_matter():
    wins = sum(run_battle(fighter(atk=40, is_player=True), fighter(), s).winner == "player" for s in range(50))
    assert wins >= 48, wins
    wins = sum(run_battle(fighter(atk=10, is_player=True), fighter(atk=40), s).winner == "player" for s in range(50))
    assert wins <= 2, wins


def test_speed_order():
    bt = g.Battle(fighter(speed=5, is_player=True), fighter(speed=50), random.Random(1))
    bt.play_round("attack")
    assert "ضربة" in bt.log[0] or "هجوم" in bt.log[0]
    assert bt.log[0].startswith("⚔️ هجوم: x") or True
    # الأسرع (العدو) يضرب أولاً: HP اللاعب نقص قبل أن يضرب هو
    assert bt.log[0].split(":")[1].strip().startswith(bt.e.name)


def test_emitter_ignores_defense():
    bt = g.Battle(fighter(nen="emitter", is_player=True), fighter(defense=500), random.Random(1))
    bt._hit(bt.p, bt.e, "t", 1.0, ignore_def=True)
    assert 100 - bt.e.hp >= 17           # دفاع 500 كان سيخفضه إلى ~2


def test_enhancer_triple():
    bt = g.Battle(fighter(nen="enhancer", is_player=True), fighter(hp=9999, max_hp=9999), random.Random(1))
    bt.rng = random.Random(3)
    bt.p.atk_mult_next = 1.0
    d1, _ = bt._damage(bt.p, bt.e, 1.0, False)
    bt.rng = random.Random(3)
    d3, _ = bt._damage(bt.p, bt.e, 3.0, False)
    assert d3 == d1 * 3 or abs(d3 - 3 * d1) <= 2


def test_shield_and_reflect_and_stun():
    bt = g.Battle(fighter(is_player=True), fighter(), random.Random(1))
    bt.p.shield_turns = 2
    before = bt.p.hp
    bt._hit(bt.e, bt.p, "t")
    shielded = before - bt.p.hp
    bt.p.shield_turns = 0
    before = bt.p.hp
    bt._hit(bt.e, bt.p, "t")
    assert shielded < (before - bt.p.hp) * 0.5

    bt = g.Battle(fighter(is_player=True), fighter(), random.Random(1))
    bt.p.reflect_turns = 2
    bt._hit(bt.e, bt.p, "t")
    assert bt.p.hp == 100 and bt.e.hp < 100 and bt.p.reflect_turns == 0

    bt = g.Battle(fighter(nen="transmuter", is_player=True, speed=99), fighter(hp=500, max_hp=500), random.Random(1))
    bt.play_round("skill")
    assert bt.e.stun_turns == 0 and any("مشلول" in l for l in bt.log)   # شُلّ وفقد دوره في نفس الجولة، والسم ما زال فعالاً
    assert bt.e.poison_turns >= 1


def test_specialist_steals_once():
    bt = g.Battle(fighter(nen="specialist", is_player=True, speed=99), fighter(nen="emitter"), random.Random(1))
    assert bt.player_skill_usable()
    bt.play_round("skill")
    assert bt.p.stolen_used and not bt.player_skill_usable()
    assert any("يسرق" in l for l in bt.log)
    # لا يمكن السرقة من خصم بلا نين
    bt = g.Battle(fighter(nen="specialist", is_player=True), fighter(nen=None), random.Random(1))
    assert not bt.player_skill_usable()


def test_skill_needs_aura():
    bt = g.Battle(fighter(nen="emitter", aura=5, is_player=True), fighter(), random.Random(1))
    assert not bt.player_skill_usable()


def test_affinity():
    assert g.affinity("enhancer", "transmuter") == g.AFFINITY_BONUS
    assert g.affinity("transmuter", "enhancer") == g.AFFINITY_PENALTY
    assert g.affinity("specialist", "emitter") == 1.0 and g.affinity(None, "emitter") == 1.0


def test_battle_always_ends():
    for s in range(300):
        rng = random.Random(s)
        floor = rng.randint(1, g.MAX_FLOOR)
        e = g.enemy_for_floor(floor, rng)
        p = fighter(nen=rng.choice(list(g.NEN) + [None]), is_player=True)
        bt = run_battle(p, e, s)
        assert bt.over and bt.winner in ("player", "enemy") and bt.round <= g.MAX_ROUNDS


def test_flee_and_normalize():
    bt = g.Battle(fighter(is_player=True), fighter())
    bt.flee()
    assert bt.over and bt.winner == "fled"
    assert g.normalize_nen("التعزيز (Enhancer)") == "enhancer" and g.normalize_nen("None") is None
    assert g.normalize_nen("emitter") == "emitter" and g.normalize_nen(None) is None


def test_gacha_pity():
    rng = random.Random(1)
    pity = 0
    for _ in range(g.PITY_LIMIT * 5):
        before = pity
        item, pity = g.roll_item(pity, rng)
        if before + 1 >= g.PITY_LIMIT:
            assert item["rarity"] in ("epic", "legendary")
        assert pity < g.PITY_LIMIT


# ───────────── قاعدة البيانات ─────────────
async def with_db(fn):
    d = tempfile.mkdtemp()
    db = Database(os.path.join(d, "t.db"))
    await db.connect()
    try:
        await fn(db, d)
    finally:
        await db.close()


async def t_progression_systems():
    """تحسين + دمج + أطقم + صيد + أحداث + إنجازات، والسجل المالي يبقى متطابقاً."""
    async def body(db, d):
        await db.ensure_user(1, "a")
        await db.admin_grant(1, "gold", 500000); await db.admin_grant(1, "gems", 500)
        rng = random.Random(5)
        await db.gacha_pull(1, "gold", rng, 10); await db.gacha_pull(1, "gold", rng, 10)
        inv = [i for i in await db.inventory(1) if i["item_type"] != "Spell"]
        it = inv[0]
        await db.equip(1, it["item_id"])
        before = (await db.get_user(1))["power"]
        for _ in range(60):                                   # حتى يصل +5 (فرصة الفشل تُعاد)
            try:
                r = await db.enhance(1, it["item_id"], rng)
            except GameError:
                break
        row = [i for i in await db.inventory(1) if i["item_id"] == it["item_id"]][0]
        assert row["lvl"] == g.MAX_ENH
        assert (await db.get_user(1))["power"] > before
        try:
            await db.enhance(1, it["item_id"]); assert False
        except GameError:
            pass
        # دمج: 3 عادية → واحد أندر
        commons = [i for i in await db.inventory(1) if i["rarity"] == "common" and not i["is_equipped"] and i["item_type"] != "Spell"]
        if len(commons) >= 3:
            res = await db.fuse(1, 0, rng)
            assert res["rarity"] == "rare"
        try:
            await db.fuse(1, 3); assert False
        except GameError:
            pass
        # طقم: قطعتان من نفس اللاحقة تعطيان زيادة
        assert g.set_bonus_pct(["سيف الصيّاد", "درع الصيّاد"])[0] == 0.05
        assert g.set_bonus_pct(["سيف الصيّاد", "درع الظلال"])[0] == 0
        # صيد
        hk = g.HUNTS[0]
        u = await db.hunt_begin(1, hk[3])
        try:
            await db.hunt_begin(1, hk[3]); assert False
        except GameError:
            pass
        out = await db.hunt_finish(1, True, 80, 50, 40, 1.0, rng)
        assert out["gold"] == 50 and out["item"] is not None
        # حدث طابق
        for k in ("chest", "gems", "heal", "item", "trap", "blessing"):
            await db.floor_event(1, {"key": k, "emoji": "x", "title": "t"}, 100, rng)
        assert await db.take_blessing(1) and not await db.take_blessing(1)
        # إنجازات: تُستلم مرة واحدة فقط
        a1 = await db.achievements(1); a2 = await db.achievements(1)
        assert a1["new"] and not a2["new"]
        # السجل المالي
        u = await db.get_user(1)
        for cur, start in (("gold", 500), ("gems", 10)):
            total = (await db._run(lambda c: c.execute("SELECT COALESCE(SUM(amount),0) s FROM ledger WHERE user_id=1 AND currency=?", (cur,)).fetchone()["s"]))
            assert start + total == u[cur], (cur, start, total, u[cur])
    await with_db(body)


def test_art_slots():
    import tempfile
    from PIL import Image
    import io, anime_images as A
    assert A.resolve_slot("سيف") == "item_sword" and A.resolve_slot("هيسوكا") == "hisoka_morow" and A.resolve_slot("xyz") is None
    assert g.item_slot("سيف التدريب") == "item_sword" and g.item_slot("قط الظلال الصيّاد") == "item_cat"
    hub = A.ImageHub(cache_dir=tempfile.mkdtemp(), enabled=False)
    hub.local_dir = Path(tempfile.mkdtemp())
    buf = io.BytesIO(); Image.new("RGB", (50, 50), (9, 9, 9)).save(buf, "PNG")
    name = hub.add_local("item_sword", buf.getvalue())
    assert hub.counts()["item_sword"] == 1 and hub.local_art("item_sword")
    gb = io.BytesIO(); fr = [Image.new("RGB", (20, 20), (i * 50, 0, 0)) for i in range(3)]
    fr[0].save(gb, "GIF", save_all=True, append_images=fr[1:], duration=80, loop=0)
    hub.add_local("victory", gb.getvalue())
    assert hub.local_gif("victory") and not hub.local_gif("item_sword")
    try:
        hub.add_local("victory", b"not an image"); assert False
    except ValueError:
        pass
    assert hub.remove_local("item_sword") == 1 and hub.counts()["item_sword"] == 0


def test_battle_events():
    rng = random.Random(1)
    u = {"username": "x", "level": 20, "floor": 30, "t_hp": 400, "max_hp": 400, "t_atk": 60, "atk": 60, "t_def": 20, "def": 20,
         "t_speed": 30, "speed": 30, "nen_type": "None", "cur_hp": 400, "vow": ""}
    boss = g.boss_fighter(g.BOSSES[0], 100000, rng, 30)
    b = g.Battle(g.fighter_from_user(u, "x"), boss, rng)
    kinds = set()
    for _ in range(9):
        if b.over:
            break
        b.play_round("attack")
        kinds |= {e["k"] for e in b.last_ev}
    assert "sigcall" in kinds and kinds & {"hit", "crit", "miss"}


async def t_migration():
    """قاعدة قديمة بنفس مخطط الكود الأصلي يجب أن تُرقّى بدون فقدان بيانات."""
    d = tempfile.mkdtemp()
    path = os.path.join(d, "old.db")
    c = sqlite3.connect(path)
    c.execute("CREATE TABLE users (user_id INTEGER PRIMARY KEY, level INTEGER DEFAULT 1, floor INTEGER DEFAULT 1,"
              " hp INTEGER DEFAULT 100, atk INTEGER DEFAULT 15, def INTEGER DEFAULT 5, nen_type TEXT DEFAULT 'None',"
              " gold INTEGER DEFAULT 100)")
    c.execute("INSERT INTO users (user_id, level, floor, gold, nen_type) VALUES (42, 7, 55, 999, 'التعزيز (Enhancer)')")
    c.commit(); c.close()
    db = Database(path)
    await db.connect()
    u = await db.get_user(42)
    assert u["level"] == 7 and u["floor"] == 22 and u["gold"] == 999 and u["tree_pts"] == 6
    assert u["max_hp"] == 100 and u["gems"] == 10 and u["stat_points"] == 0 and u["speed"] == 10
    assert g.normalize_nen(u["nen_type"]) == "enhancer"
    await db.close()


async def t_win_loss_levelup():
    async def body(db, d):
        u = await db.ensure_user(1, "علي")
        assert u["cur_hp"] == 100 and u["floor"] == 1
        r = await db.apply_win(1, hp_after=60, gold=100, xp=150)    # 100 xp للمستوى 2
        assert r["levels_gained"] == 1 and r["level"] == 2 and r["floor"] == 2 and r["points"] == 3
        u = await db.get_user(1)
        assert u["xp"] == 50 and u["gold"] == 600 and u["stat_points"] == 3 and u["max_hp"] == 105
        assert 59 <= u["cur_hp"] <= 66, u["cur_hp"]
        r = await db.apply_loss(1)
        u = await db.get_user(1)
        assert r["gold_lost"] == 60 and u["gold"] == 540 and u["losses"] == 1 and u["cur_hp"] <= 31
        # الحد الأقصى للطابق
        await db.ensure_user(2, "س")
        await db._run(lambda c: c.execute("UPDATE users SET floor = 100 WHERE user_id = 2"))
        r = await db.apply_win(2, 50, 10, 10)
        assert r["floor"] == g.MAX_FLOOR == 100
    await with_db(body)


async def t_upgrade_atomic():
    async def body(db, d):
        await db.ensure_user(1, "a")
        try:
            await db.upgrade_stat(1, "atk", 1); assert False
        except GameError:
            pass
        await db._run(lambda c: c.execute("UPDATE users SET stat_points = 3 WHERE user_id = 1"))
        u = await db.upgrade_stat(1, "atk", 2)
        assert u["atk"] == 19 and u["stat_points"] == 1
        u = await db.upgrade_stat(1, "hp", 1)
        assert u["max_hp"] == 110
        try:
            await db.upgrade_stat(1, "def", 5); assert False
        except GameError:
            pass
    await with_db(body)


async def t_gacha_equip_sell_use():
    async def body(db, d):
        await db.ensure_user(1, "a")
        rng = random.Random(5)
        items = await db.gacha_pull(1, "gold", rng)
        assert len(items) == 1 and items[0]["item_id"]
        u = await db.get_user(1)
        assert u["gold"] == 500 - g.GACHA_GOLD_COST
        try:
            await db.gacha_pull(1, "gold", rng); assert False      # 200 ذهب لا يكفي
        except GameError:
            pass
        u = await db.get_user(1)
        assert u["gold"] == 200                                     # لم يُخصم شيء عند الفشل
        # شراء متزامن لا يسمح بإنفاق مزدوج: رصيد يكفي لسحبة واحدة فقط
        await db._run(lambda c: c.execute("UPDATE users SET gems = 10 WHERE user_id = 1"))
        res = await asyncio.gather(*(db.gacha_pull(1, "gems", rng) for _ in range(5)), return_exceptions=True)
        ok = [r for r in res if isinstance(r, list)]
        assert len(ok) == 1 and sum(isinstance(r, GameError) for r in res) == 4
        # عتاد: تجهيز ورفع الإحصائيات
        await db._run(lambda c: c.executemany(
            "INSERT INTO inventory (user_id,item_name,item_type,stat,stat_bonus,rarity) VALUES (1,?,?,?,?,?)",
            [("سيف", "Weapon", "atk", 10, "rare"), ("سيف2", "Weapon", "atk", 30, "epic"),
             ("خوذة", "Helmet", "hp", 50, "common"), ("بطاقة", "Spell", "heal", 50, "rare")]))
        inv = await db.inventory(1)
        ids = {i["item_name"]: i["item_id"] for i in inv}
        await db.equip(1, ids["سيف"]); await db.equip(1, ids["خوذة"])
        u = await db.get_user(1)
        assert u["t_atk"] == 25 and u["t_hp"] == 150
        await db.equip(1, ids["سيف2"])                              # يستبدل الأول
        u = await db.get_user(1)
        assert u["t_atk"] == 45
        try:
            await db.sell(1, ids["سيف2"]); assert False            # مجهّز
        except GameError:
            pass
        _, price = await db.sell(1, ids["سيف"])
        assert price == g.SELL_PRICE[1]
        try:
            await db.equip(2, ids["سيف2"]); assert False           # ليس ملكه
        except GameError:
            pass
        # بطاقة الشفاء
        await db.set_hp(1, 20)
        r = await db.use_spell(1, ids["بطاقة"])
        assert r["healed"] >= 70 and r["hp"] <= 150               # 50% من 150
    await with_db(body)


async def t_daily_nen_guild_shadows():
    async def body(db, d):
        await db.ensure_user(1, "a"); await db.ensure_user(2, "b"); await db.ensure_user(3, "c")
        r = await db.claim_daily(1)
        assert r["streak"] == 1 and r["gold"] == g.DAILY_GOLD + 50
        try:
            await db.claim_daily(1); assert False
        except GameError:
            pass
        await db._run(lambda c: c.execute("UPDATE users SET last_daily = last_daily - 25*3600 WHERE user_id = 1"))
        assert (await db.claim_daily(1))["streak"] == 2
        # نين: إعادة الاختبار تكلف جواهر
        await db.set_nen(1, "emitter", 0)
        try:
            await db.set_nen(1, "enhancer", g.REROLL_GEM_COST); assert False
        except GameError:
            pass
        assert normalize((await db.get_user(1))["nen_type"]) == "emitter"
        # نقابات
        await rich(db, 1, 2)
        gid = await db.create_guild(1, "عصابة العناكب")
        try:
            await db.create_guild(2, "عصابة العناكب"); assert False
        except GameError:
            pass
        await db.join_guild(2, "عصابة العناكب")
        await db.gang_accept(1, 2)
        await db.apply_win(2, 50, 10, 10)
        info = await db.guild_info(1)
        assert info["score"] == 1 and len(info["members"]) == 2 and info["leader_id"] == 1
        await db.leave_guild(1)
        info = await db.guild_info(2)
        assert info["leader_id"] == 2                               # انتقلت القيادة
        await db.leave_guild(2)
        assert await db.guild_info(2) is None
        # ظلال وترتيب
        await db._run(lambda c: c.execute("UPDATE users SET floor = 60, level = 9 WHERE user_id = 3"))
        top = await db.top_players(5)
        assert top[0]["user_id"] == 3
        sh = await db.shadow_candidates(3, 5)
        assert all(s["user_id"] != 3 for s in sh) and len(sh) == 2
        f = g.shadow_fighter(sh[0])
        assert not f.is_player and f.hp == f.max_hp
    await with_db(body)


# ───────────── الإضافات الجديدة ─────────────
async def t_ledger_matches_balances():
    """كل ذهب/جوهرة تتحرك يجب أن تُسجَّل: مجموع السجل = تغيّر الرصيد بالضبط."""
    async def body(db, d):
        await db.ensure_user(1, "a"); await db.ensure_user(2, "b")
        await db.admin_grant(1, "gold", 10000)
        await db.gacha_pull(1, "gold", random.Random(1), 3)
        await db.apply_win(1, 50, 120, 30)
        await db.apply_loss(1)
        await db.claim_daily(1)
        r = await db.transfer_gold(1, 2, 500)
        assert r["tax"] == 25 and r["received"] == 475
        await db.buy_spell(1, "small", 2)
        inv = await db.inventory(1)
        await db.sell(1, inv[0]["item_id"])
        await db.set_nen(1, "emitter", 0)
        for uid in (1, 2):
            u = await db.get_user(uid)
            for cur, start in (("gold", 500), ("gems", 10)):
                total = (await db._run(lambda c: c.execute(
                    "SELECT COALESCE(SUM(amount),0) s FROM ledger WHERE user_id=? AND currency=?", (uid, cur)).fetchone()["s"]))
                assert start + total == u[cur], (uid, cur, start, total, u[cur])
        s = await db.ledger_summary("gold", 0)
        reasons = {k for k, _ in s["sources"]} | {k for k, _ in s["sinks"]}
        assert {"gacha", "climb", "transfer_in", "tax"} <= reasons, reasons
        assert dict(s["sinks"])["tax"] == 25
        rows = await db.ledger_rows(1, 50)
        assert rows and all(r["amount"] != 0 for r in rows)
        try:
            await db.admin_grant(99, "gold", 5); assert False
        except GameError:
            pass
    await with_db(body)


async def t_transfer_rules():
    async def body(db, d):
        await db.ensure_user(1, "a"); await db.ensure_user(2, "b")
        for bad in ((1, 1, 100), (1, 2, 10), (1, 2, 99999), (1, 9, 100)):
            try:
                await db.transfer_gold(*bad); assert False, bad
            except GameError:
                pass
        assert (await db.get_user(1))["gold"] == 500
    await with_db(body)


async def t_boss_lifecycle():
    async def body(db, d):
        for i in range(1, 5):
            await db.ensure_user(i, f"p{i}")
        boss, settle = await db.ensure_boss(77)
        assert boss["status"] == "active" and settle is None and boss["hp"] == boss["max_hp"] == g.boss_max_hp(4)
        again, _ = await db.ensure_boss(77)
        assert again["boss_id"] == boss["boss_id"]              # لا يتكرر الظهور
        await db.boss_begin(1, boss["boss_id"])
        try:
            await db.boss_begin(1, boss["boss_id"]); assert False   # تبريد
        except GameError:
            pass
        await db._run(lambda c: c.execute("UPDATE users SET boss_last = 0"))
        await db.boss_begin(1, boss["boss_id"]); await db._run(lambda c: c.execute("UPDATE users SET boss_last = 0"))
        await db.boss_begin(1, boss["boss_id"]); await db._run(lambda c: c.execute("UPDATE users SET boss_last = 0"))
        try:
            await db.boss_begin(1, boss["boss_id"]); assert False   # 3 محاولات يومياً
        except GameError:
            pass
        r = await db.boss_finish(boss["boss_id"], 1, 5000)
        assert r["damage"] == 5000 and not r["killed"]
        await db.boss_finish(boss["boss_id"], 2, 3000)
        await db.boss_finish(boss["boss_id"], 3, 100)
        board = await db.boss_board(boss["boss_id"], 2)
        assert [t["user_id"] for t in board["top"]] == [1, 2, 3] and board["me"]["rank"] == 2
        # الضربة القاضية: الضرر يُقصّ عند الصفر وتُوزَّع الغنائم مرة واحدة
        await db._run(lambda c: c.execute("UPDATE boss SET hp = 40 WHERE boss_id = ?", (boss["boss_id"],)))
        gold_before = (await db.get_user(4))["gold"]
        r = await db.boss_finish(boss["boss_id"], 4, 99999)
        assert r["killed"] and r["damage"] == 40 and r["boss_hp"] == 0
        players = {p["user_id"]: p for p in r["settle"]["players"]}
        assert players[1]["rank"] == 1 and players[1]["gems"] > players[3]["gems"]
        assert players[4]["gems"] >= 20 and players[4]["item"]            # الضربة القاضية
        assert (await db.get_user(4))["gold"] == gold_before + players[4]["gold"]
        assert any(i["item_name"] == players[1]["item"]["name"] for i in await db.inventory(1))
        r2 = await db.boss_finish(boss["boss_id"], 1, 10)
        assert r2["damage"] == 0 and not r2["killed"]                     # لا ضرر بعد الموت ولا غنائم مكررة
        # قبل انتهاء فترة الراحة: يعيد الزعيم الميت، وبعدها يظهر الجديد
        dead, _ = await db.ensure_boss(77)
        assert dead["status"] == "dead" and dead["boss_id"] == boss["boss_id"]
        await db._run(lambda c: c.execute("UPDATE boss SET end_ts = 1"))
        new, _ = await db.ensure_boss(77)
        assert new["status"] == "active" and new["boss_id"] != boss["boss_id"] and new["boss_key"] != boss["boss_key"]
        # هروب الزعيم عند انتهاء الوقت: مكافأة تعزية فقط وبلا غنائم
        await db.boss_finish(new["boss_id"], 2, 700)
        await db._run(lambda c: c.execute("UPDATE boss SET end_ts = 1 WHERE boss_id = ?", (new["boss_id"],)))
        assert new["boss_id"] in [b for b in [new["boss_id"]]] and 77 in await db.due_boss_servers()
        _, settle = await db.ensure_boss(77)
        assert settle and not settle["killed"] and settle["players"][0]["item"] is None
        assert 77 not in await db.due_boss_servers()
    await with_db(body)


async def t_war_lifecycle():
    async def body(db, d):
        for i in range(1, 5):
            await db.ensure_user(i, f"p{i}")
        await rich(db, 1, 2, 3, 4)
        await db.create_guild(1, "الظلال"); await db.join_guild(2, "الظلال"); await db.gang_accept(1, 2)
        await db.create_guild(3, "العقارب")
        try:
            await db.declare_war(1, "العقارب"); assert False          # العقارب عضو واحد
        except GameError:
            pass
        await db.join_guild(4, "العقارب"); await db.gang_accept(3, 4)
        try:
            await db.declare_war(2, "العقارب"); assert False          # ليس القائد
        except GameError:
            pass
        w = await db.declare_war(1, "العقارب", 55)
        try:
            await db.declare_war(3, "الظلال"); assert False            # في حرب بالفعل
        except GameError:
            pass
        await db.apply_win(1, 50, 10, 10); await db.apply_win(2, 50, 10, 10); await db.apply_win(3, 50, 10, 10)
        st = await db.war_status(2)
        assert st["war_id"] == w["war_id"] and st["score_a"] == 2 * g.WAR_POINTS_WIN and st["score_b"] == g.WAR_POINTS_WIN
        assert await db.finish_due_wars() == []                          # لم تنتهِ
        await db._run(lambda c: c.execute("UPDATE wars SET end_ts = 1"))
        gold_before = (await db.get_user(1))["gold"]
        done = await db.finish_due_wars()
        assert len(done) == 1 and done[0]["result"] == "a" and done[0]["server_id"] == 55 and done[0]["paid"] == 3
        assert (await db.get_user(1))["gold"] == gold_before + g.WAR_REWARD["win"][0]
        assert (await db.get_user(3))["gems"] >= 10 + g.WAR_REWARD["lose"][1]
        assert await db.finish_due_wars() == [] and await db.war_status(1) is None
        try:
            await db.declare_war(1, "العقارب"); assert False             # فترة راحة بعد الحرب
        except GameError:
            pass
    await with_db(body)


async def t_missions_vow_settings():
    async def body(db, d):
        await db.ensure_user(1, "a")
        ms = await db.missions(1)
        assert len(ms) == 3 and len({m["mkey"] for m in ms}) == 3
        assert [m["mkey"] for m in await db.missions(1)] == [m["mkey"] for m in ms]    # ثابتة طوال اليوم
        try:
            await db.claim_missions(1); assert False
        except GameError:
            pass
        await db._run(lambda c: c.execute("UPDATE missions SET progress = target"))
        r = await db.claim_missions(1)
        assert r["claimed"] == 3 and r["bonus"] == g.MISSION_BONUS_GEMS
        try:
            await db.claim_missions(1); assert False
        except GameError:
            pass
        # النذور
        assert await db.set_vow(1, "blood") == 0
        try:
            await db.set_vow(1, "wrath"); assert False                   # لا جواهر كافية للتغيير
        except GameError:
            pass
        await db.admin_grant(1, "gems", 100)
        u = await db.get_user(1)
        f = g.fighter_from_user(u, "x")
        assert f.max_hp == round(u["t_hp"] * 0.7) and f.atk == round(u["t_atk"] * 1.35)
        assert await db.set_vow(1, "wrath") == g.VOW_SWITCH_GEMS
        f = g.fighter_from_user(await db.get_user(1), "x"); assert f.no_guard
        bt = g.Battle(f, fighter(), random.Random(1)); bt.play_round("guard")
        assert not bt.p.guarding                                         # التحصّن ممنوع
        await db.set_vow(1, "silence")
        f = g.fighter_from_user(await db.get_user(1), "x", full_hp=True); f.nen = "emitter"
        assert not g.Battle(f, fighter(), random.Random(1)).player_skill_usable()
        try:
            await db.set_vow(1, "silence"); assert False
        except GameError:
            pass
        try:
            await db.set_vow(1, "???"); assert False
        except GameError:
            pass
        assert g.vow_loss_pct("greed") == g.LOSS_GOLD_PCT * 2 and g.vow_gold_mult("greed") == 1.3
        # قنوات الإعلانات وأحداث الذهب
        await db.set_channel(5, "all", 100); await db.set_channel(5, "boss", 200)
        assert await db.get_channel(5, "boss") == 200 and await db.get_channel(5, "floor") == 100 and await db.get_channel(6, "floor") is None
        await db.set_channel(5, "boss", None)
        assert await db.get_channel(5, "boss") == 100 and await db.get_channels(5) == {"all": 100}
        assert await db.get_event() is None
        await db.set_event("gold", 2, 1)
        assert (await db.get_event())["mult"] == 2
        await db.set_event(None)
        assert await db.get_event() is None
    await with_db(body)


def test_boss_boss_battle_timeout_and_scaling():
    rng = random.Random(3)
    tpl = g.BOSSES[0]
    weak = g.boss_fighter(tpl, 20000, rng, 1)
    strong = g.boss_fighter(tpl, 20000, rng, 80)
    assert weak.atk < strong.atk and weak.hp == strong.hp == 20000
    bt = g.Battle(fighter(atk=30, hp=10**6, max_hp=10**6, is_player=True), g.boss_fighter(tpl, 10**7, rng, 30), rng)
    bt.max_rounds, bt.timeout_result = g.BOSS_ROUNDS, "timeout"
    while not bt.over:
        bt.play_round("attack")
    assert bt.winner == "timeout" and bt.round == g.BOSS_ROUNDS and bt.e.hp < 10**7


def test_items_and_ranks():
    assert g.hunter_rank(1)[1] == 0 and g.hunter_rank(25) == ("صيّاد النين", 2) and g.hunter_rank(100)[0] == "ملك البرج"
    assert g.item_emoji("سيف الملوك", "Weapon") == "🗡️" and g.item_emoji("شيء غريب", "Armor") == "🛡️"
    it = g.item_view({"item_id": 3, "item_name": "ذئب", "item_type": "Companion", "stat": "speed", "stat_bonus": 4, "rarity": "epic"})
    assert it["rarity"] == 2 and it["emoji"] == "🐺" and "+4" in it["bonus_text"]
    # كل أنواع العناصر التي يسحبها القاشا لها أيقونة موجودة فعلاً
    import shaping as sh
    rng = random.Random(1)
    for _ in range(300):
        item, _p = g.roll_item(0, rng)
        assert sh.icon_image(sh.icon_key(g.item_emoji(item["name"], item["type"])), 32) is not None, item
    for t in g.BOSSES:
        assert sh.icon_image(sh.icon_key(t["emoji"]), 32) is not None, t["emoji"]
    for v in g.VOWS.values():
        assert sh.icon_image(sh.icon_key(v["emoji"]), 32) is not None, v["emoji"]
    # مهام اليوم حتمية لكل لاعب
    assert g.roll_missions("1:5") == g.roll_missions("1:5")


def test_arabic_shaping_both_engines():
    import shaping as sh
    from PIL import Image, ImageDraw
    for force in (False, True):
        sh.FORCE_BASIC = force
        sh.clear_font_cache()
        im = Image.new("RGBA", (400, 80), (0, 0, 0, 255))
        sh.draw_rich(im, ImageDraw.Draw(im), 390, 40, "الطابق 12 ⚔️ مرحبا", sh.get_font("bold", 28), (255, 255, 255), "r")
        assert im.convert("L").getbbox() is not None
    sh.FORCE_BASIC = False
    sh.clear_font_cache()
    assert sh.has_arabic("ab ج") and not sh.has_arabic("abc 123")
    assert sh.prepare("لا") != "لا"                                    # لام ألف مركّبة


def normalize(v):
    return g.normalize_nen(v)


def main():
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("✓", name)
    for name, fn in list(globals().items()):
        if name.startswith("t_"):
            asyncio.run(fn())
            print("✓", name)
    print("\nكل الاختبارات نجحت")


if __name__ == "__main__":
    main()
