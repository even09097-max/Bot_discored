"""اختبارات الهوية البصرية (V4): صورة لكل أمر، خلفية لكل قسم وقائمة فرعية، ثيمات، خلفيات القتال والطوابق والأحداث،
مكتبة منظمة، منع التكرار العشوائي، وسلسلة الاحتياط. لا تحتاج discord ولا إنترنت.
شغّلها:  python test_identity.py"""
from __future__ import annotations

import asyncio
import hashlib
import io
import shutil
import tempfile
from pathlib import Path

from PIL import Image

import anime_images as A
import game as g
import hatsu as ht
import identity as idn
import render as R
import shaping as sh


def _png(color, size=(320, 200)) -> bytes:
    b = io.BytesIO()
    Image.new("RGB", size, color).save(b, "PNG")
    return b.getvalue()


def _phash(data: bytes) -> str:
    return hashlib.sha1(Image.open(io.BytesIO(data)).convert("RGB").resize((48, 30)).tobytes()).hexdigest()


class Sandbox:
    """مجلدات مؤقتة للمكتبة وللصور المرفوعة كي لا نلمس ملفات المشروع."""
    def __enter__(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.old = (idn.LIB, idn.UPLOADS, dict(idn._rot_state))
        idn.LIB, idn.UPLOADS = self.tmp / "identity", self.tmp / "art"
        idn._dec.clear()
        return self

    def __exit__(self, *a):
        idn.LIB, idn.UPLOADS = self.old[0], self.old[1]
        idn._rot_state.clear()
        idn._rot_state.update(self.old[2])
        idn._dec.clear()
        shutil.rmtree(self.tmp, ignore_errors=True)

    def upload(self, slot: str, name: str, data: bytes) -> None:
        d = idn.UPLOADS / slot
        d.mkdir(parents=True, exist_ok=True)
        (d / name).write_bytes(data)


# ───────────────────────── الجداول والمكتبة ─────────────────────────
def test_manifest_is_complete():
    assert len({c.slug for c in idn.CMDS}) == len(idn.CMDS) and len({c.ar for c in idn.CMDS}) == len(idn.CMDS)
    for c in idn.CMDS:
        assert c.theme in idn.THEMES, c.slug
        assert c.motif in idn.MOTIFS, (c.slug, c.motif)
        assert c.family in idn.FAMILIES, c.slug
        assert sh.icon_key(c.emoji) and sh.icon_image(sh.icon_key(c.emoji), 32) is not None, f"لا أيقونة لـ {c.emoji} ({c.slug})"
        assert idn.resolve(c.ar) is c and idn.resolve(c.slug) is c
    for a in idn.REG.values():
        assert a.theme in idn.THEMES and a.motif in idn.MOTIFS, a.key
    # الشرح: صفحة فرعية لكل صفحة شرح، والطوابق كلها مغطاة بفئات متتالية بلا ثغرات
    assert len(idn.HELP_SUBS) == 11
    assert idn.FLOOR_BANDS[0][0] == 1 and idn.FLOOR_BANDS[-1][1] == g.MAX_FLOOR
    for (lo, hi, *_), (lo2, *_r) in zip(idn.FLOOR_BANDS, idn.FLOOR_BANDS[1:]):
        assert lo2 == hi + 1
    assert set(idn.BOSS_BG) == {b["key"] for b in g.BOSSES}, "خلفية لكل زعيم"
    assert set(idn.EVENT_BG) == {e[0] for e in g.FLOOR_EVENTS}, "خلفية لكل حدث طابق"


def test_every_main_command_has_image_background_theme():
    with Sandbox():
        for c in idn.CMDS:
            bg = idn.section_backdrop(idn.Ident(c.slug), (500, 320))
            assert bg is not None and bg.size == (500, 320), f"لا خلفية لـ {c.ar}"
            em = idn.emblem(c, 64)
            assert em is not None and em.size == (64, 64) and em.getchannel("A").getbbox(), f"لا شارة لـ {c.ar}"
            for sk, _l in c.subs:
                assert idn.section_backdrop(idn.Ident(c.slug, sk), (200, 120)) is not None, (c.slug, sk)


def test_library_is_organized_on_disk_and_unique():
    with Sandbox():
        n = idn.build_library()
        assert n >= len(idn.REG) + len(idn.CMDS)
        folders = {p.name for p in idn.LIB.iterdir() if p.is_dir()}
        assert {"backgrounds", "floors", "arenas", "bosses", "events", "nen", "emblems", "hatsu"} <= folders, folders
        for a in idn.REG.values():
            assert idn.lib_path(a).is_file(), a.key
        rep = idn.audit([c.ar for c in idn.CMDS], help_pages=11, build=False)
        assert rep["ok"], rep
        assert not rep["duplicates"]
        # الشارات فريدة أيضاً
        hs = {_phash(_png_of(idn.emblem(c, 96))) for c in idn.CMDS}
        assert len(hs) == len(idn.CMDS)
        assert idn.build_library() == 0       # مكتبة مكتملة: لا إعادة بناء


def _png_of(im: Image.Image) -> bytes:
    b = io.BytesIO()
    im.convert("RGB").save(b, "PNG")
    return b.getvalue()


def test_audit_detects_missing_identity_and_duplicates():
    with Sandbox():
        rep = idn.audit(["صعود", "أمر_جديد_بلا_هوية"], build=True)
        assert rep["no_identity"] == ["أمر_جديد_بلا_هوية"] and not rep["ok"]
        # نسخ ملف مكتبة فوق آخر = صورة مكررة تُكشف
        a, b = idn.REG["bg:climb"], idn.REG["bg:floor"]
        shutil.copy(idn.lib_path(a), idn.lib_path(b))
        idn._dec.clear()
        rep = idn.audit([], build=False)
        assert ("bg:climb", "bg:floor") in rep["duplicates"], rep["duplicates"]


# ───────────────────────── خلفيات القتال والطوابق والأحداث ─────────────────────────
def test_floor_bands_each_have_distinct_background():
    with Sandbox():
        seen = {}
        for f in range(1, g.MAX_FLOOR + 1):
            k = idn.floor_key(f)
            seen.setdefault(k, idn.floor_art(f))
        assert len(seen) == len(idn.FLOOR_BANDS) == 11
        assert len({_phash(d) for d in seen.values()}) == 11, "فئتا طوابق بنفس الصورة"
        assert idn.floor_key(9) != idn.floor_key(10) and idn.floor_key(99) != idn.floor_key(100)
        assert idn.band_index(g.BOSS_FLOOR) == len(idn.FLOOR_BANDS) - 1


def test_battle_arenas_bosses_and_events_have_backgrounds():
    with Sandbox():
        hub = A.ImageHub(cache_dir=tempfile.mkdtemp(), enabled=False)
        slots = [f"bg_floor_{i:02d}" for i in range(1, 12)] + ["bg_arena_duel", "bg_arena_live", "bg_arena_revenge", "bg_hunt", "bg_boss"]
        slots += [f"bgb_{k}" for k in idn.BOSS_BG] + [f"ev_{k}" for k in idn.EVENT_BG]
        imgs = {}
        for s in slots:
            d = hub.local_art(s)
            assert d and len(d) > 2000, f"لا خلفية للخانة {s}"
            imgs[s] = _phash(d)
        assert len(set(imgs.values())) == len(slots), "خلفيتان متطابقتان"
        # أماكن غير الخلفيات لا تُولَّد (عتاد/خصوم): تبقى بلا صورة حتى تُرفع أو تُجلب
        assert hub.local_art("item_sword") is None and hub.local_art("hisoka_morow") is None


def test_uploaded_legacy_floor_background_still_works():
    with Sandbox() as sb:
        hub = A.ImageHub(cache_dir=tempfile.mkdtemp(), enabled=False)
        hub.local_dir = idn.UPLOADS
        red = _png((200, 0, 0))
        sb.upload("bg_street", "mine.png", red)         # صورتك على خانة V3 القديمة
        assert hub.local_art("bg_floor_01") == red       # الفئة الجديدة 1-9 تأخذها لأنها ضمن bg_street
        green = _png((0, 200, 0))
        sb.upload("bg_floor_01", "new.png", green)      # رفعتَ للفئة الجديدة: تتقدم على القديمة
        assert hub.local_art("bg_floor_01") == green
        assert hub.local_art("bg_floor_11") != red       # قمة البرج لها خلفيتها المولَّدة


# ───────────────────────── ألوان صورك تتقدم + سلسلة الاحتياط ─────────────────────────
def test_uploaded_images_take_priority_and_fallback_chain():
    with Sandbox() as sb:
        sb.upload("bgs_climb", "a.png", _png((250, 10, 10)))
        px = idn.section_backdrop(idn.Ident("climb"), (50, 30)).getpixel((25, 15))
        assert px[0] > 200 and px[1] < 60                      # صورتك المرفوعة
        sb.upload("bgs_help_p3", "b.png", _png((10, 10, 250)))
        assert idn.section_backdrop(idn.Ident("help", "p3"), (50, 30)).getpixel((25, 15))[2] > 200      # قائمة فرعية مستقلة
        px = idn.section_backdrop(idn.Ident("help", "p4"), (50, 30)).getpixel((25, 15))
        assert not (px[2] > 200 and px[0] < 40)                 # صفحة أخرى لا ترث خلفية p3
        # ملف مرفوع تالف ← تسقط بسلام إلى المولَّدة
        sb.upload("bgs_daily", "bad.png", b"not an image")
        assert idn.section_backdrop(idn.Ident("daily"), (50, 30)) is not None
        # ملف المكتبة المولَّدة تالف ← يُعاد توليده
        a = idn.REG["bg:rank"]
        idn.lib_path(a).parent.mkdir(parents=True, exist_ok=True)
        idn.lib_path(a).write_bytes(b"garbage")
        idn._dec.clear()
        assert idn.generated("bg:rank") is not None
        # أمر مجهول: لا هوية ولا استثناء
        assert idn.section_backdrop(None, (10, 10)) is None and idn.resolve("لا_يوجد") is None
        assert idn.use("لا_يوجد") is None and idn.current() is None


def test_uploaded_command_image_becomes_emblem():
    with Sandbox() as sb:
        sb.upload("cmd_climb", "pic.png", _png((10, 200, 10), (400, 400)))
        em = idn.emblem("صعود", 80)
        c = em.getpixel((40, 40))
        assert c[1] > 150 and c[0] < 60 and c[3] == 255        # صورتك داخل الدائرة
        assert em.getpixel((1, 1))[3] == 0                      # الزاوية شفافة (قصّ دائري)


# ───────────────────────── منع التكرار العشوائي ─────────────────────────
def test_rotation_never_repeats_consecutively():
    with Sandbox():
        for n in (2, 3, 5):
            idn._rot_state.clear()
            seq = [idn._rotate(f"slot{n}", n) for _ in range(n * 6)]
            assert all(a != b for a, b in zip(seq, seq[1:])), seq
            assert set(seq) == set(range(n)), "كل الصور تظهر بالتناوب"
        assert idn._rotate("one", 1) == 0
        # البداية حتمية (من اسم المكان) لا عشوائية
        idn._rot_state.clear()
        first = idn._rotate("same-slot", 7)
        idn._rot_state.clear()
        assert idn._rotate("same-slot", 7) == first


def test_pick_distinct_avoids_duplicates_in_one_screen():
    with Sandbox():
        files = ["a", "b", "c"]
        used: set = set()
        got = [idn.pick_distinct("scr", files, used) for _ in range(3)]
        assert sorted(got) == files
        assert idn.pick("empty", []) is None


def test_hub_rotates_uploads_without_immediate_repeat():
    with Sandbox() as sb:
        hub = A.ImageHub(cache_dir=tempfile.mkdtemp(), enabled=False)
        hub.local_dir = idn.UPLOADS
        cols = [(255, 0, 0), (0, 255, 0), (0, 0, 255)]
        for i, c in enumerate(cols):
            sb.upload("bg_hunt", f"{i}.png", _png(c))
        seq = [hub.local_art("bg_hunt") for _ in range(9)]
        assert all(a != b for a, b in zip(seq, seq[1:])) and len(set(seq)) == 3


def test_no_random_choice_left_in_image_selection():
    src = (Path(__file__).parent / "anime_images.py").read_text(encoding="utf-8")
    assert "random.choice" not in src and "random.sample" not in src, "اختيار الصور يجب أن يكون بالتناوب"


# ───────────────────────── الرسم والسياق ─────────────────────────
def _decode(b: bytes) -> Image.Image:
    return Image.open(io.BytesIO(b)).convert("RGB")


def test_canvas_applies_section_backdrop_theme_and_emblem():
    with Sandbox():
        idn.clear()
        plain = _decode(R.list_card("عنوان", "فرعي", [("🏆", "س", "ص")], "🏆"))
        seen = {_phash(_png_of(plain))}
        for slug in ("vow", "shop", "gang", "help", "boss", "daily"):
            idn.use(slug)
            card = _decode(R.list_card("عنوان", "فرعي", [("🏆", "س", "ص")], "🏆"))
            h = _phash(_png_of(card))
            assert h not in seen, f"بطاقة {slug} تشبه غيرها (لا هوية)"
            seen.add(h)
            # الشارة في الزاوية العلوية اليسرى: تختلف عن البطاقة بلا هوية
            box = (14, 8, 56, 50)
            assert list(card.crop(box).getdata()) != list(plain.crop(box).getdata())
        idn.clear()


def test_win_lose_themes_and_battle_cards_keep_their_own_look():
    with Sandbox():
        idn.clear()
        base_win = R.list_card("t", "s", [], "🏆", "win")
        idn.use("shop")
        # فوز/خسارة يحتفظان بلون النتيجة؛ لكن الخلفية والشارة تُضافان
        from PIL import ImageStat
        win = ImageStat.Stat(_decode(R.list_card("t", "s", [("🏆", "a", "b")], "🏆", "win"))).mean
        gold = ImageStat.Stat(_decode(R.list_card("t", "s", [("🏆", "a", "b")], "🏆", "gold"))).mean
        assert max(abs(a - b) for a, b in zip(win, gold)) > 3, "ثيم الفوز يجب أن يبقى مختلفاً عن ثيم القسم"
        # بطاقة القتال لها خلفيتها: الهوية لا تغيّرها إطلاقاً
        p = g.fighter_view(_fighter(True))
        e = g.fighter_view(_fighter(False))
        idn.clear()
        b0 = R.battle_card("t", 1, p, e, ["x"])
        idn.use("climb")
        b1 = R.battle_card("t", 1, p, e, ["x"])
        assert b0 == b1, "بطاقة القتال يجب ألا تتأثر بهوية الأمر"
        assert base_win
        idn.clear()


def _fighter(is_player: bool):
    from test_core import fighter
    return fighter(is_player=is_player)


def test_identity_context_reaches_render_thread():
    async def run():
        idn.clear()
        idn.use("market")
        got = await asyncio.to_thread(idn.current)
        assert got is not None and got.cmd == "market"
        # كل مهمة (أمر) لها سياقها: لا تسريب بين أمرين متزامنين
        async def one(slug):
            idn.use(slug)
            await asyncio.sleep(0.01)
            return (await asyncio.to_thread(idn.current)).cmd
        res = await asyncio.gather(*[asyncio.create_task(one(s)) for s in ("climb", "vow", "shop", "gang")])
        assert res == ["climb", "vow", "shop", "gang"]
    asyncio.run(run())
    idn.clear()


def test_generated_medals_and_hero_fallbacks():
    sb = Sandbox().__enter__()
    try:
        arts = {gr["slot"]: idn.gear_medal(gr["slot"], gr["emoji"], gr["r"]) for gr in ht.GEAR.values()}
        assert len(arts) == len(ht.GEAR) and len({_phash(d) for d in arts.values()}) == len(arts), "كل قطعة عتاد لها ميدالية مختلفة"
        hub = A.ImageHub(cache_dir=tempfile.mkdtemp(), enabled=False)
        assert set(hub.gear_art_map()) >= {gr["slot"] for gr in ht.GEAR.values()}
        ab = {k: idn.ability_art(k, v["emoji"]) for k, v in ht.HATSU.items()}
        assert len({_phash(d) for d in ab.values()}) == len(ab), "كل قدرة هاتسو لها صورة"
        for ctx in ("tower", "gacha", "vow", "hatsu", "enhancer", "specialist"):
            assert idn.hero_for_context(ctx), ctx
        assert idn.hero_for_context("لا_سياق") is None
        assert set(idn.NEN_TYPES) == set(g.NEN_TYPES) if hasattr(g, "NEN_TYPES") else True
    finally:
        sb.__exit__()


def test_upload_slots_registered_for_every_identity_place():
    ent = idn.slot_entries()
    for c in idn.CMDS:
        assert f"cmd_{c.slug}" in ent and f"bgs_{c.slug}" in ent
    for k in list(idn.BOSS_BG) + list(idn.EVENT_BG):
        assert f"bgb_{k}" in ent or f"ev_{k}" in ent
    for key, (word, desc, group) in ent.items():
        assert key in A.SLOTS and group in A.GROUPS, (key, group)
    words = [v[0] for v in A.SLOTS.values()]
    assert len(words) == len(set(words)), "كلمتا رفع متطابقتان: " + str({w for w in words if words.count(w) > 1})
    assert any(k.startswith("card_") for k in A.SLOTS)


def main() -> None:
    import test_identity as me
    tests = [v for k, v in sorted(vars(me).items()) if k.startswith("test_")]
    for fn in tests:
        fn()
        print("✓", fn.__name__)
    print("\nكل اختبارات الهوية البصرية نجحت")


if __name__ == "__main__":
    main()
