"""
بطاقات التحديث الكبير (شجرة النين، هاتسو، العصابة، السوق الأسود، المواسم، المهام الشاملة).
كل الصور الحقيقية (شخصيات، عتاد، خلفيات) تُجلب من مواقع الأنمي وتُمرَّر هنا كـ bytes؛ هذا الملف يرتّب البطاقات فقط ولا يرسم شخصيات.
"""
from __future__ import annotations

import math

import hatsu as ht
import identity as idn
import render as R
from render import (BLUE, CYAN, GOLD, GREEN, MUTED, ORANGE, PURPLE, RARITY_COL, RED, WHITE, Canvas, _a, _darken, _lighten, chip,
                    load_image)

GRAY = (110, 112, 140)


def _fmt(n) -> str:
    return f"{int(n):,}"


def _backdrop(cv: Canvas, art: bytes | None, dark: float = 0.72) -> None:
    im = load_image(art)
    if im is not None:
        cv.backdrop(im, dark)


# ═════════════════════════ شجرة النين ═════════════════════════
BRANCH_X = {"power": 880, "defense": 550, "speed": 220}
LEAVES = {"power": ["finisher", "nenboost"], "defense": ["absorb", "aurawall"], "speed": ["swift", "mirror"]}


def _node_state(levels: dict, key: str, points: int) -> str:
    lv = levels.get(key, 0)
    if lv >= ht.TREE_MAX_LEVEL:
        return "maxed"
    ok, _ = ht.can_upgrade(levels, key, points)
    if ok:
        return "ready"
    node = ht.TREE_NODES[key]
    parent = node["parent"]
    locked = bool(parent and parent != "core" and levels.get(parent, 0) < node["req"])
    return "locked" if locked and lv == 0 else "have" if lv else "poor"


def _tree_node(cv: Canvas, cx: float, cy: float, r: float, key: str, levels: dict, points: int, art=None, lw: float = 190) -> None:
    node = ht.TREE_NODES[key]
    col = ht.TREE_BRANCH_COLOR[node["branch"]]
    lv = levels.get(key, 0) if key != "core" else 1
    state = "have" if key == "core" else _node_state(levels, key, points)
    ring = {"maxed": GOLD, "ready": GREEN, "locked": GRAY, "have": _lighten(col, 0.2), "poor": _darken(col, 0.2)}[state]
    if lv > 0 or state == "ready":
        cv.glow(cx, cy, r * 2.1, ring if state != "have" else col, 170 if state in ("ready", "maxed") else 110)
    if art is not None:
        cv.circle_image(art, cx, cy, r, ring, fallback=node["emoji"], ring_w=5)
        cv.ellipse(cx + r * 0.72, cy + r * 0.72, r * 0.3, fill=(8, 6, 22, 235), outline=_a(ring, 230), width=2)
        cv.icon(node["emoji"], cx + r * 0.72, cy + r * 0.72, r * 0.36)
    else:
        cv.ellipse(cx, cy, r, fill=_a(_darken(col, 0.62 if state != "locked" else 0.85), 250), outline=ring, width=5 if state != "locked" else 2.5)
        cv.ellipse(cx, cy, r - 7, outline=_a(ring, 80), width=1.5)
        cv.icon(node["emoji"], cx, cy, r * 1.05)
    cv.fit_text(cx, cy + r + 24, node["name"], lw, 22 if lw > 150 else 18, fill=WHITE if state != "locked" else MUTED, align="m", weight="black")
    if key == "core":
        return
    for i in range(ht.TREE_MAX_LEVEL):
        px = cx + (i - (ht.TREE_MAX_LEVEL - 1) / 2) * 22
        on = i < lv
        cv.ellipse(px, cy + r + 52, 7, fill=_a(ring, 255) if on else (255, 255, 255, 28), outline=_a(ring, 190), width=1.5)
    if state == "maxed":
        cv.text(cx, cy + r + 82, "أقصى مستوى", 17, GOLD, "m", "bold", shadow=False)
    else:
        cost = ht.node_cost(key, lv)
        txt = f"ترقية: {cost} نقطة" if state in ("ready", "poor", "have") else f"🔒 يحتاج المسار {node['req']}"
        cv.fit_text(cx, cy + r + 82, txt, lw, 16, fill=GREEN if state == "ready" else MUTED, align="m", weight="bold", shadow=False)


def _effects_lines(e: dict) -> list[str]:
    parts = []
    for k, label in (("atk_pct", "هجوم"), ("hp_pct", "صحة"), ("def_pct", "دفاع"), ("speed_pct", "سرعة"), ("crit", "حرجة"),
                     ("pierce", "تحطيم دروع"), ("amp", "قوة المهارات"), ("reduce", "امتصاص"), ("dodge", "مراوغة"),
                     ("double", "ضربة مزدوجة"), ("reflect", "عكس"), ("assist", "قدرات البطاقات")):
        if e.get(k):
            parts.append(f"+{round(e[k] * 100)}% {label}")
    if e.get("aura_regen"):
        parts.append(f"+{int(e['aura_regen'])} طاقة/جولة")
    if e.get("shield_pct"):
        parts.append(f"درع هالة {round(e['shield_pct'] * 100)}% من الصحة")
    lines, cur = [], ""
    for p in parts:
        if len(cur) + len(p) > 52:
            lines.append(cur)
            cur = p
        else:
            cur = f"{cur}  ·  {p}" if cur else p
    if cur:
        lines.append(cur)
    return lines or ["لم تفتح أي ترقية بعد — اختر مساراً من الأسفل"]


def tree_card(levels: dict, points: int, spent: int, effects: dict, owner: str, art: bytes | None = None,
              portraits: dict[str, bytes] | None = None, nen_label: str = "") -> bytes:
    """شجرة النين البصرية: مركز ← 3 مسارات ← تفرّعين لكل مسار. الأخضر = جاهز للترقية، الذهبي = أقصى مستوى."""
    lines = _effects_lines(effects)
    cv = Canvas(1100, 1090 + 28 * len(lines), "default")
    _backdrop(cv, art)
    cv.header("شجرة النين", f"{owner}" + (f"  ·  {nen_label}" if nen_label else ""), emoji="🌳")
    chip(cv, 1060, 135, "🌳", f"نقاط النين: {points}", GREEN if points else MUTED, 21, "r")
    chip(cv, 760, 135, "📈", f"المصروف: {spent}", GOLD, 18, "r")
    root = (550, 300)
    pts = portraits or {}
    # الخطوط أولاً
    for br, bx in BRANCH_X.items():
        col = ht.TREE_BRANCH_COLOR[br]
        lit = levels.get(br, 0) > 0
        cv.line((root[0], root[1] + 56), (bx, 520 - 60), _a(col, 230 if lit else 90), 5 if lit else 3)
        for i, leaf in enumerate(LEAVES[br]):
            lx = bx + (100 if i == 0 else -100)
            on = levels.get(leaf, 0) > 0
            cv.line((bx, 520 + 60), (lx, 790 - 46), _a(col, 230 if on else 90), 5 if on else 3)
    _tree_node(cv, root[0], root[1], 56, "core", levels, points)
    for br, bx in BRANCH_X.items():
        _tree_node(cv, bx, 520, 58, br, levels, points, load_image(pts.get(br)))
        for i, leaf in enumerate(LEAVES[br]):
            _tree_node(cv, bx + (100 if i == 0 else -100), 790, 46, leaf, levels, points, lw=128)
    cv.panel((40, 975, 1060, 1050 + 28 * len(lines)), 18, fill=(255, 255, 255, 16), outline=_a(GOLD, 110))
    cv.text(1030, 1006, "تأثير شجرتك الحالي", 20, GOLD, "r", "black")
    for i, ln in enumerate(lines):
        cv.fit_text(1030, 1042 + i * 28, ln, 960, 19, fill=WHITE, align="r", weight="bold", shadow=False)
    cv.footer(f"اختر عقدة من القائمة للترقية · إعادة التوزيع {ht.TREE_RESPEC_GEMS} 💎 · تكسب نقطة مع كل مستوى وكل {ht.TREE_POINT_PER_FLOORS} طوابق")
    return cv.finish()


# ═════════════════════════ هاتسو ═════════════════════════
def hatsu_card(blocks: list[dict], art: bytes | None = None, portraits: dict[str, bytes] | None = None) -> bytes:
    """blocks: [{owner, name, status: team|owned|locked, moves:[{emoji,name,en,cost,cd,desc}], stars}]"""
    pts = portraits or {}
    h = 190 + sum(110 + 74 * len(b["moves"]) for b in blocks) + 30
    cv = Canvas(1100, h, "boss")
    _backdrop(cv, art, 0.78)
    cv.header("قدرات النين الخاصة (هاتسو)", "تأتي من بطاقات الأبطال في فريقك — قوتها تزيد مع النجوم", emoji="🌀")
    y = 140
    for b in blocks:
        n = len(b["moves"])
        bh = 100 + 74 * n
        st = b["status"]
        col = GREEN if st == "team" else GOLD if st == "owned" else GRAY
        cv.panel((40, y, 1060, y + bh), 22, fill=_a(_darken(col, 0.82), 205), outline=_a(col, 200 if st != "locked" else 90), width=2.2)
        cv.circle_image(load_image(pts.get(b["owner"])), 985, y + 52, 38, col, fallback="🎴", ring_w=3.5)
        cv.text(930, y + 36, b["name"], 28, WHITE if st != "locked" else MUTED, "r", "black")
        label = {"team": "في فريقك — جاهزة في القتال", "owned": "تملك البطاقة — ضعها في الفريق", "locked": "لا تملك البطاقة — استدعها"}[st]
        cv.text(930, y + 70, label + (f"  ·  {'⭐' * b['stars']}" if b.get("stars") else ""), 17, _lighten(col, 0.3), "r", "bold", shadow=False)
        for i, m in enumerate(b["moves"]):
            my = y + 100 + i * 74
            cv.panel((60, my - 6, 1040, my + 62), 14, fill=(255, 255, 255, 14), outline=(255, 255, 255, 36), shadow=False)
            ab = load_image(idn.ability_art(m["key"], m["emoji"])) if m.get("key") else None     # صورة خاصة لكل قدرة
            if ab is not None:
                cv.circle_image(ab, 1000, my + 28, 29, col, fallback=m["emoji"], ring_w=3)
            else:
                cv.icon(m["emoji"], 1000, my + 28, 42)
            cv.text(960, my + 14, f"{m['name']}  ({m['en']})", 21, WHITE if st != "locked" else MUTED, "r", "black")
            cv.fit_text(960, my + 44, m["desc"], 640, 16, fill=MUTED, align="r", weight="regular", shadow=False)
            chip(cv, 300, my + 16, "🔋", f"{m['cost']} طاقة", CYAN, 14, "r")
            chip(cv, 300, my + 46, "⏳", f"تبريد {m['cd']}", ORANGE, 14, "r")
        y += bh + 14
    cv.footer("في القتال: اختر القدرة من القائمة تحت الأزرار · القتال التلقائي يستخدمها تلقائياً")
    return cv.finish()


# ═════════════════════════ العصابة ═════════════════════════
ROLE_ICON = {"leader": "👑", "deputy": "🛡️", "member": "🧑"}


def _bar_row(cv: Canvas, y: float, emoji: str, title: str, prog: int, target: int, right_txt: str = "", done: bool = False) -> None:
    col = GREEN if done else BLUE
    cv.panel((40, y, 1060, y + 84), 16, fill=_a(_darken(col, 0.74), 190), outline=_a(col, 190), width=2)
    cv.icon(emoji, 1018, y + 42, 44)
    cv.fit_text(972, y + 26, title, 700, 22, fill=WHITE, align="r", weight="black")
    cv.bar((300, y + 48, 972, y + 68), prog / max(1, target), _lighten(col, 0.2), col)
    cv.text(636, y + 58, f"{_fmt(min(prog, target))} / {_fmt(target)}", 13, WHITE, "m", "bold", shadow=False)
    if right_txt:
        cv.fit_text(270, y + 42, right_txt, 200, 17, fill=GOLD, align="r", weight="bold", shadow=False)
    if done:
        cv.icon("✅", 78, y + 42, 36)


def gang_card(info: dict, my_id: int, art: bytes | None = None, war_text: str = "") -> bytes:
    members = info["members"]
    ms = info.get("missions") or []
    reqs = info.get("requests") or []
    h = 330 + len(members) * 50 + 70 + len(ms) * 96 + (80 + min(5, len(reqs)) * 34 if reqs and info.get("my_role") in ("leader", "deputy") else 0) + 60
    cv = Canvas(1100, h, "gold" if info.get("war") else "default")
    _backdrop(cv, art, 0.76)
    cv.header(info["guild_name"], f"نقاط العصابة {_fmt(info['score'])}  ·  {len(members)} / {info['max_members']} عضو", emoji="🏴")
    if info.get("war"):
        cv.badge(170, 62, war_text or info["war"], RED, 16)
    # الخزينة
    cv.panel((40, 130, 1060, 226), 20, fill=_a(_darken(GOLD, 0.8), 210), outline=_a(GOLD, 180), width=2)
    cv.text(1030, 158, "الخزينة المشتركة", 22, GOLD, "r", "black")
    chip(cv, 1030, 198, "💰", _fmt(info.get("gold", 0)), GOLD, 20, "r")
    chip(cv, 740, 198, "💎", _fmt(info.get("gems", 0)), CYAN, 20, "r")
    role = ht.GANG_ROLES.get(info.get("my_role", "member"), "عضو")
    cv.text(70, 176, f"رتبتك: {role}", 20, WHITE, "l", "bold", shadow=False)
    cv.text(70, 204, "ساهم بـ «عصابة ايداع ذهب 1000»", 14, MUTED, "l", "regular", shadow=False)
    # الأعضاء
    cv.text(1030, 262, "الأعضاء", 24, GOLD, "r", "black")
    for i, m in enumerate(members):
        y = 308 + i * 50
        me = m["user_id"] == my_id
        cv.panel((40, y - 22, 1060, y + 22), 12, fill=_a(BLUE if me else (255, 255, 255), 42 if me else 14), outline=_a(GOLD, 150) if me else None, shadow=False)
        cv.icon(ROLE_ICON.get(m.get("gang_role", "member"), "🧑"), 1030, y, 28)
        cv.fit_text(990, y, m["username"] or str(m["user_id"]), 330, 21, fill=WHITE, align="r", weight="bold", shadow=False)
        cv.text(640, y, f"المستوى {m['level']}", 18, MUTED, "r", "regular", shadow=False)
        cv.text(480, y, f"الطابق {m['floor']}", 18, WHITE, "r", "bold", shadow=False)
        cv.text(320, y, f"{_fmt(m.get('points', 0))} نقطة أسبوعية", 16, _lighten(GREEN, 0.2), "r", "bold", shadow=False)
        if m.get("war_points") is not None:
            cv.text(80, y, f"{m['war_points']} ⚔️", 18, GOLD, "l", "black", shadow=False)
    y = 308 + len(members) * 50 + 20
    cv.text(1030, y + 14, "مهام العصابة الأسبوعية", 24, GOLD, "r", "black")
    y += 50
    for m in ms:
        _bar_row(cv, y, m["emoji"], m["title"], m["progress"], m["target"], f"+{_fmt(m['gold'])} 💰 للخزينة", bool(m["done"]))
        y += 96
    if reqs and info.get("my_role") in ("leader", "deputy"):
        cv.text(1030, y + 14, f"طلبات الانضمام ({len(reqs)})", 22, GOLD, "r", "black")
        for i, r in enumerate(reqs[:5]):
            cv.fit_text(1010, y + 52 + i * 34, f"{r['username']} · مستوى {r['level']} · طابق {r['floor']}  — «عصابة قبول @…»", 900, 18, fill=WHITE, align="r", weight="bold", shadow=False)
    cv.footer("أكملوا المهام الثلاث لتحصلوا على صناديق عتاد حصرية · «صندوق» لفتحها")
    return cv.finish()


# ═════════════════════════ السوق الأسود ═════════════════════════
def _offer_card(cv: Canvas, x: float, y: float, w: float, h: float, o: dict, art, closed: bool) -> None:
    col = RARITY_COL[min(3, o["r"])]
    gone = o["left"] <= 0 or o.get("mine", 0) >= ht.MARKET_MAX_BUY
    dim = closed or gone
    cv.glow(x + w / 2, y + h / 2, w * 0.75, col, 60 if dim else 130)
    cv.panel((x, y, x + w, y + h), 22, fill=_a(_darken(col, 0.8), 245), outline=_a(_lighten(col, 0.25) if not dim else GRAY, 255), width=3 if o["r"] >= 3 else 2)
    top = y + h * 0.56
    if art is not None:
        cv.cover(art, (x + 9, y + 9, x + w - 9, top), 16, dark=0.45 if dim else 0.0)
        cv.fade_bottom((x + 9, top - h * 0.1, x + w - 9, top), _darken(col, 0.8), 200)
    else:
        cv.glow(x + w / 2, y + h * 0.28, w * 0.3, col, 150)
        cv.icon(o["emoji"], x + w / 2, y + h * 0.28, w * 0.46)
    cv.fit_text(x + w / 2, y + h * 0.625, o["name"], w - 30, 27, fill=WHITE if not dim else MUTED, align="m", weight="black")
    sub = o.get("bonus_text") or ("نقاط في شجرة النين" if o["kind"] == "stone" else "صندوق: ملحمي أو أعلى مضمون")
    cv.fit_text(x + w / 2, y + h * 0.70, sub, w - 30, 21, fill=_lighten(col, 0.5), align="m", weight="bold")
    if o.get("fx_text"):
        cv.fit_text(x + w / 2, y + h * 0.765, o["fx_text"], w - 30, 16, fill=_lighten(CYAN, 0.25), align="m", weight="regular", shadow=False)
    py = y + h * 0.855
    if o["gold"]:
        chip(cv, x + w / 2 + 70, py, "💰", _fmt(o["gold"]), GOLD, 19, "r")
    if o["gems"]:
        chip(cv, x + w / 2 + 70, py, "💎", _fmt(o["gems"]), CYAN, 19, "r")
    left_txt = "اشتريته" if o.get("mine", 0) >= ht.MARKET_MAX_BUY else "نفدت الكمية" if o["left"] <= 0 else f"المتبقي {o['left']}"
    cv.text(x + w / 2, y + h * 0.95, left_txt, 16, GOLD if not dim else MUTED, "m", "bold", shadow=False)
    cv.badge(x + 42, y + 26, f"#{o['slot'] + 1}", col, 14)


def market_card(state: dict, owner: str, art: bytes | None = None, offer_arts: dict[int, bytes] | None = None,
                left_text: str = "", gold: int = 0, gems: int = 0) -> bytes:
    stock = state["stock"]
    closed = not state["open"]
    cw, ch, gap = 380, 500, 22
    rows = math.ceil(len(stock) / 3)
    cv = Canvas(1300, 260 + rows * (ch + gap) + 80, "boss" if not closed else "default")
    _backdrop(cv, art, 0.78)
    cv.header("السوق الأسود", f"{owner}", emoji="🏴")
    badge_col, badge_txt = (GREEN, f"مفتوح — {left_text}") if not closed else (RED, f"مغلق — يفتح بعد {left_text}")
    cv.badge(1130, 130, badge_txt, badge_col, 19, min_w=300)
    chip(cv, 560, 130, "💰", _fmt(gold), GOLD, 17, "r")
    chip(cv, 330, 130, "💎", _fmt(gems), CYAN, 17, "r")
    for i, o in enumerate(stock):
        row, k = divmod(i, 3)
        x = 1300 / 2 + (3 * cw + 2 * gap) / 2 - (k + 1) * cw - k * gap
        _offer_card(cv, x, 200 + row * (ch + gap), cw, ch, o, load_image((offer_arts or {}).get(o["slot"])), closed)
    cv.footer("أسعار وعروض تتغير كل فترة · لكل لاعب شراء واحد من كل عرض · اختر العرض من القائمة تحت الصورة")
    return cv.finish()


# ═════════════════════════ المواسم ═════════════════════════
def season_card(cur: dict, left_text: str, frac: float, top_now: list[dict], hall: dict, owner: str, my_rank: int | None,
                art: bytes | None = None) -> bytes:
    pl = hall.get("players") or []
    gang = hall.get("gang")
    h = 330 + len(top_now[:5]) * 52 + 40 + 3 * 64 + 60 + ((120 + len(pl[:3]) * 52 + (60 if gang else 0)) if pl else 0)
    cv = Canvas(1100, h, "gold")
    _backdrop(cv, art, 0.78)
    cv.header(cur["name"], f"{owner}", emoji="🏆")
    cv.panel((40, 130, 1060, 230), 20, fill=_a(_darken(GOLD, 0.8), 210), outline=_a(GOLD, 170), width=2)
    cv.text(1030, 160, f"ينتهي الموسم بعد {left_text}", 24, WHITE, "r", "black")
    cv.bar((70, 192, 1030, 214), frac, (255, 214, 90), (255, 140, 40))
    y = 270
    cv.text(1030, y, "الترتيب الحالي (حسب الطابق)", 24, GOLD, "r", "black")
    y += 36
    for i, p in enumerate(top_now[:5]):
        medal = ["🥇", "🥈", "🥉", "🔹", "🔹"][i]
        me = my_rank == i + 1
        cv.panel((40, y, 1060, y + 44), 12, fill=_a(BLUE if me else (255, 255, 255), 40 if me else 14), outline=_a(GOLD, 150) if me else None, shadow=False)
        cv.icon(medal, 1025, y + 22, 28)
        cv.fit_text(985, y + 22, p["username"] or "؟", 400, 21, fill=WHITE, align="r", weight="bold", shadow=False)
        cv.text(480, y + 22, f"الطابق {p['floor']}", 19, WHITE, "r", "bold", shadow=False)
        cv.text(300, y + 22, f"المستوى {p['level']}", 18, MUTED, "r", "regular", shadow=False)
        y += 52
    if my_rank and my_rank > 5:
        cv.text(1030, y + 6, f"ترتيبك الحالي: {my_rank}", 20, _lighten(GREEN, 0.2), "r", "bold")
    y += 40
    cv.text(1030, y, "جوائز نهاية الموسم", 24, GOLD, "r", "black")
    y += 36
    for i, (gold, gems, title) in enumerate(ht.SEASON_PLAYER_REWARDS):
        cv.panel((40, y, 1060, y + 54), 12, fill=(255, 255, 255, 16), outline=(255, 255, 255, 40), shadow=False)
        cv.text(1030, y + 27, title, 22, WHITE, "r", "black")
        chip(cv, 420, y + 27, "💰", _fmt(gold), GOLD, 15, "r")
        chip(cv, 220, y + 27, "💎", _fmt(gems), CYAN, 15, "r")
        y += 62
    cv.text(1030, y + 8, f"المراكز 4-{ht.SEASON_TOP_N}: {_fmt(ht.SEASON_TOP_REWARD[0])} 💰 + {ht.SEASON_TOP_REWARD[1]} 💎 · العصابة الأولى: لقب {ht.SEASON_GANG_REWARD[2]} + خزينة {_fmt(ht.SEASON_GANG_REWARD[0])} 💰", 16, MUTED, "r", "regular", shadow=False)
    y += 56
    if pl:
        cv.text(1030, y, f"قاعة الأبطال — {hall.get('name', '')}", 24, GOLD, "r", "black")
        y += 36
        for p in pl[:3]:
            cv.panel((40, y, 1060, y + 44), 12, fill=(255, 255, 255, 14), shadow=False)
            cv.fit_text(1030, y + 22, f"{p['title']}  {p['name']}", 600, 21, fill=WHITE, align="r", weight="bold", shadow=False)
            cv.text(300, y + 22, f"الطابق {p['floor']} · مستوى {p['level']}", 17, MUTED, "r", "regular", shadow=False)
            y += 52
        if gang:
            cv.text(1030, y + 14, f"{gang['title']}  {gang['name']}", 21, _lighten(PURPLE, 0.3), "r", "black")
    return cv.finish()


# ═════════════════════════ المهام الشاملة (يومية + أسبوعية + عصابة) ═════════════════════════
def _mission_row(cv: Canvas, y: float, m: dict) -> None:
    done = m["progress"] >= m["target"]
    col = GREEN if m["claimed"] else GOLD if done else BLUE
    cv.panel((40, y, 1060, y + 96), 18, fill=_a(_darken(col, 0.72), 190), outline=_a(col, 200), width=2)
    cv.icon(m["emoji"], 1015, y + 48, 50)
    cv.fit_text(962, y + 28, m["title"], 700, 23, fill=WHITE, align="r", weight="black")
    cv.bar((390, y + 54, 962, y + 76), m["progress"] / max(1, m["target"]), _lighten(col, 0.2), col)
    cv.text(676, y + 65, f"{_fmt(min(m['progress'], m['target']))} / {_fmt(m['target'])}", 14, WHITE, "m", "bold", shadow=False)
    chip(cv, 360, y + 48, "💰", _fmt(m["gold"]), GOLD, 16, "r")
    if m["gems"]:
        chip(cv, 200, y + 48, "💎", str(m["gems"]), CYAN, 16, "r")
    if m["claimed"]:
        cv.icon("✅", 74, y + 48, 40)
    elif done:
        cv.icon("🎁", 74, y + 48, 40)


def missions_full_card(daily: list[dict], weekly: list[dict], daily_note: str, weekly_note: str, daily_reset: str, weekly_reset: str,
                       gang: list[dict] | None = None, gang_name: str = "", art: bytes | None = None) -> bytes:
    gang = gang or []
    h = 190 + (60 + len(daily) * 106 + 36) + (60 + len(weekly) * 106 + 36) + ((60 + len(gang) * 96 + 20) if gang else 0) + 30
    cv = Canvas(1100, h, "blue")
    _backdrop(cv, art, 0.80)
    cv.header("مهام الصيّاد", "يومية · أسبوعية · العصابة", emoji="📋")
    y = 130
    for title, rows, note, reset, emoji in (("المهام اليومية", daily, daily_note, daily_reset, "☀️"), ("المهام الأسبوعية", weekly, weekly_note, weekly_reset, "🗓️")):
        cv.icon(emoji, 1030, y + 24, 34)
        cv.text(996, y + 14, title, 26, GOLD, "r", "black")
        cv.text(70, y + 18, f"تتجدد بعد {reset}", 17, MUTED, "l", "regular", shadow=False)
        y += 60
        for m in rows:
            _mission_row(cv, y, m)
            y += 106
        cv.text(550, y + 4, note, 17, GOLD if "🎉" in note else MUTED, "m", "bold", shadow=False)
        y += 36
    if gang:
        cv.icon("🏴", 1030, y + 24, 34)
        cv.text(996, y + 14, f"مهام عصابة «{gang_name}» (أسبوعية)", 26, GOLD, "r", "black")
        y += 60
        for m in gang:
            _bar_row(cv, y, m["emoji"], m["title"], m["progress"], m["target"], f"+{_fmt(m['gold'])} 💰", bool(m["done"]))
            y += 96
    return cv.finish()


# ═════════════════════════ لقطات سريعة: ظل المسيطر والانتقام ═════════════════════════
def floor_control_card(floor: int, holder_name: str, mode: str, art: bytes | None, rows: list[tuple[str, str, str]], owner: str) -> bytes:
    """mode: echo (ظل المسيطر) / live (تحدٍّ مباشر) / revenge. صورة الخلفية حقيقية (تُجلب)."""
    title = {"echo": "ظل المسيطر", "live": "تحدٍّ مباشر", "revenge": "الانتقام"}.get(mode, "المسيطر")
    emoji = {"echo": "👤", "live": "⚔️", "revenge": "🔥"}.get(mode, "🏯")
    h = 330 + len(rows) * 62 + 40
    cv = Canvas(1000, h, "boss" if mode != "echo" else "default")
    _backdrop(cv, art, 0.6)
    cv.header(f"{title} · الطابق {floor}", owner, emoji=emoji)
    cv.text(950, 200, holder_name, 40, WHITE, "r", "black")
    y = 270
    for e, label, val in rows:
        cv.panel((40, y, 960, y + 52), 14, fill=(0, 0, 0, 110), outline=(255, 255, 255, 45), shadow=False)
        cv.icon(e, 925, y + 26, 30)
        cv.text(885, y + 26, label, 21, MUTED, "r", "bold", shadow=False)
        cv.fit_text(70, y + 26, val, 520, 22, fill=WHITE, align="l", weight="black", shadow=False)
        y += 62
    return cv.finish()
