الخطوط المرفقة: DejaVu Sans (عادي + عريض) — رخصة حرة تسمح بإعادة التوزيع، وتدعم العربية.
لشكل أجمل ضع هنا Tajawal-Regular.ttf و Tajawal-ExtraBold.ttf و Tajawal-Black.ttf (مجاني من fonts.google.com/specimen/Tajawal)
وسيُفضَّل تلقائياً على DejaVu.
