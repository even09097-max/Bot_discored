"""
محرك نصوص عربية للصور (Pillow).

- إن وُجد raqm + fribidi في Pillow نستخدمهما (أفضل جودة).
- وإلا نستخدم مشكِّلاً داخلياً (بدون أي مكتبة خارجية) يبني أشكال الحروف من جدول يونيكود
  ويرتّب الاتجاه (RTL) مع بقاء الأرقام والإنجليزي من اليسار لليمين.
- الإيموجي داخل النص يُرسم كصور جاهزة من assets/icons (لا يحتاج خط إيموجي).
"""
from __future__ import annotations

import re
import unicodedata
from functools import lru_cache
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, features

BASE = Path(__file__).resolve().parent
ICON_DIR = BASE / "assets" / "icons"
FONT_DIR = BASE / "assets" / "fonts"

try:
    HAS_RAQM = bool(features.check("raqm") and features.check("fribidi"))
except Exception:   # pragma: no cover
    HAS_RAQM = False
import os
# المشكِّل الداخلي هو الافتراضي (يعمل بنفس الشكل على كل الاستضافات). ARABIC_RAQM=1 لتجربة raqm.
FORCE_BASIC = os.getenv("ARABIC_RAQM", "0") != "1"


def use_raqm() -> bool:
    return HAS_RAQM and not FORCE_BASIC


# ───────────────────────── المشكِّل الداخلي ─────────────────────────
_FORMS: dict[str, dict[str, str]] = {}
_LIGS: dict[tuple[str, str], dict[str, str]] = {}


def _build_tables() -> None:
    for cp in range(0xFE70, 0xFF00):
        ch = chr(cp)
        d = unicodedata.decomposition(ch)
        if not d.startswith("<"):
            continue
        tag, *rest = d.split()
        tag = tag.strip("<>")
        if tag not in ("isolated", "initial", "medial", "final"):
            continue
        bases = [chr(int(x, 16)) for x in rest]
        if len(bases) == 1:
            if "\u0621" <= bases[0] <= "\u064a" or bases[0] in "\u0671\u067e\u0686\u0698\u06a9\u06af\u06cc":
                _FORMS.setdefault(bases[0], {})[tag] = ch
        elif len(bases) == 2 and bases[0] == "\u0644":
            _LIGS.setdefault((bases[0], bases[1]), {})[tag] = ch


_build_tables()
# حروف فارسية/إضافية شائعة تُعامل كأقرب حرف عربي إن لم تتوفر لها أشكال
_MARKS = re.compile("[\u064b-\u065f\u0670\u0640\u200c\u200d]")   # تشكيل + تطويل


def _joins_next(c: str) -> bool:
    f = _FORMS.get(c)
    return bool(f and "initial" in f)


def _joins_prev(c: str) -> bool:
    f = _FORMS.get(c)
    return bool(f and "final" in f)


def _is_ar(c: str) -> bool:
    return "\u0600" <= c <= "\u06ff" or "\ufb50" <= c <= "\ufeff"


def has_arabic(text: str) -> bool:
    return any(_is_ar(c) for c in text)


def _shape(text: str) -> str:
    text = _MARKS.sub("", text)
    out: list[str] = []
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if c not in _FORMS:
            out.append(c)
            i += 1
            continue
        prev = text[i - 1] if i > 0 else ""
        joins_prev = bool(prev) and prev in _FORMS and _joins_next(prev) and _joins_prev(c)
        nxt = text[i + 1] if i + 1 < n else ""
        if c == "\u0644" and nxt in ("\u0622", "\u0623", "\u0625", "\u0627") and ("\u0644", nxt) in _LIGS:
            forms = _LIGS[("\u0644", nxt)]
            out.append(forms.get("final" if joins_prev else "isolated", forms["isolated"]))
            i += 2
            continue
        joins_next = bool(nxt) and nxt in _FORMS and _joins_next(c) and _joins_prev(nxt)
        key = ("medial" if joins_prev else "initial") if joins_next else ("final" if joins_prev else "isolated")
        forms = _FORMS[c]
        out.append(forms.get(key) or forms.get("isolated") or c)
        i += 1
    return "".join(out)


_MIRROR = str.maketrans("()[]{}<>«»", ")(][}{><»«")


def _bidi_visual(text: str) -> str:
    """ترتيب مرئي مبسّط لفقرة أساسها RTL."""
    runs: list[list] = []   # [kind, chars]
    for c in text:
        if _is_ar(c):
            k = "R"
        elif c.isalnum():
            k = "L"
        else:
            k = "N"
        if runs and runs[-1][0] == k:
            runs[-1][1] += c
        else:
            runs.append([k, c])
    for idx, (k, s) in enumerate(runs):   # الحياد بين رقمين/إنجليزيين يبقى LTR
        if k == "N":
            before = runs[idx - 1][0] if idx > 0 else "R"
            after = runs[idx + 1][0] if idx + 1 < len(runs) else "R"
            if before == "L" and after == "L" and s.strip(" ") in ("", ".", ",", ":", "/", "-", "+", "%", "'"):
                runs[idx][0] = "L"
            else:
                runs[idx][0] = "R"
    merged: list[list] = []
    for k, s in runs:
        if merged and merged[-1][0] == k:
            merged[-1][1] += s
        else:
            merged.append([k, s])
    out = []
    for k, s in reversed(merged):
        out.append(s[::-1].translate(_MIRROR) if k == "R" else s)
    return "".join(out)


_CTRL = re.compile("[\u200b-\u200f\u202a-\u202e\u2060-\u2069\ufeff\u00ad\ufe00-\ufe0f]")


def _allowed(o: int) -> bool:
    return (o < 0x250 or 0x600 <= o <= 0x6FF or 0xFB50 <= o <= 0xFDFF or 0xFE70 <= o <= 0xFEFF
            or 0x2010 <= o <= 0x2027 or 0x2030 <= o <= 0x205E or 0x2190 <= o <= 0x21FF or 0x2212 <= o <= 0x2212
            or 0x25A0 <= o <= 0x25FF or o in (0x2022, 0x2605, 0x2606))


@lru_cache(maxsize=4096)
def clean(text: str) -> str:
    """يحذف الرموز التي لا يملك الخط شكلاً لها (تظهر مربعات) ويحوّل الخطوط الزخرفية إلى عادية."""
    text = _CTRL.sub("", text)
    out = []
    for ch in text:
        o = ord(ch)
        if _allowed(o):
            out.append(ch)
            continue
        norm = unicodedata.normalize("NFKC", ch)
        out.extend(c for c in norm if _allowed(ord(c)))
    return "".join(out)


@lru_cache(maxsize=4096)
def prepare(text: str) -> str:
    """نص جاهز للرسم بالمحرك الأساسي (يسار→يمين)."""
    text = clean(text)
    if not has_arabic(text):
        return text
    return _bidi_visual(_shape(text))


# ───────────────────────── الخطوط ─────────────────────────
_CANDIDATES = {
    "regular": ["Tajawal-Regular.ttf", "Cairo-Regular.ttf", "NotoSansArabic-Regular.ttf", "segoeui.ttf", "tahoma.ttf",
                "arial.ttf", "DejaVuSans.ttf", "Arial.ttf", "Tahoma.ttf", "LiberationSans-Regular.ttf"],
    "bold": ["Tajawal-ExtraBold.ttf", "Tajawal-Bold.ttf", "Cairo-Bold.ttf", "NotoSansArabic-Bold.ttf", "segoeuib.ttf",
             "tahomabd.ttf", "arialbd.ttf", "DejaVuSans-Bold.ttf", "Arial Bold.ttf", "LiberationSans-Bold.ttf"],
    "black": ["Tajawal-Black.ttf", "Tajawal-ExtraBold.ttf", "Cairo-Black.ttf", "Cairo-Bold.ttf", "NotoSansArabic-Bold.ttf",
              "segoeuib.ttf", "tahomabd.ttf", "arialbd.ttf", "DejaVuSans-Bold.ttf", "LiberationSans-Bold.ttf"],
}
_SEARCH_DIRS = [
    FONT_DIR, BASE, BASE / "fonts", Path("C:/Windows/Fonts"), Path("/usr/share/fonts"), Path("/usr/local/share/fonts"),
    Path("/Library/Fonts"), Path("/System/Library/Fonts"), Path.home() / ".fonts", Path.home() / ".local/share/fonts",
    Path("/system/fonts"),   # أندرويد/Termux
]
_font_paths: dict[str, str] = {}


def _find(weight: str) -> str:
    if weight in _font_paths:
        return _font_paths[weight]
    found = ""
    for name in _CANDIDATES[weight]:
        for d in _SEARCH_DIRS:
            if not d.exists():
                continue
            if (d / name).exists():
                found = str(d / name)
                break
            hit = next(iter(d.rglob(name)), None) if d not in (FONT_DIR, BASE, BASE / "fonts") else None
            if hit:
                found = str(hit)
                break
        if found:
            break
    if not found:   # آخر حل: أي خط في assets/fonts
        for p in FONT_DIR.glob("*.ttf") if FONT_DIR.exists() else []:
            found = str(p)
            break
    _font_paths[weight] = found
    return found


@lru_cache(maxsize=128)
def get_font(weight: str, px: int) -> ImageFont.FreeTypeFont:
    path = _find(weight if weight in _CANDIDATES else "regular")
    if not path:
        raise RuntimeError("لم أجد خطاً يدعم العربية. ضع ملف خط (مثل Tajawal-Bold.ttf) داخل assets/fonts")
    engine = ImageFont.Layout.RAQM if use_raqm() else ImageFont.Layout.BASIC
    return ImageFont.truetype(path, px, layout_engine=engine)


def clear_font_cache() -> None:
    get_font.cache_clear()


# ───────────────────────── قياس ورسم النص ─────────────────────────
def text_len(font: ImageFont.FreeTypeFont, text: str) -> float:
    if not text:
        return 0.0
    if use_raqm():
        text = clean(text)
        return font.getlength(text, direction="rtl" if has_arabic(text) else "ltr", language="ar" if has_arabic(text) else None)
    return font.getlength(prepare(text))


def draw_plain(draw: ImageDraw.ImageDraw, xy: tuple[float, float], text: str, font, fill, anchor: str = "ls") -> None:
    """يرسم قطعة نص واحدة (بدون إيموجي). anchor: l/m/r + s (خط الأساس)."""
    if not text:
        return
    if use_raqm():
        text = clean(text)
        ar = has_arabic(text)
        draw.text(xy, text, font=font, fill=fill, anchor=anchor, direction="rtl" if ar else "ltr",
                  language="ar" if ar else None)
    else:
        draw.text(xy, prepare(text), font=font, fill=fill, anchor=anchor)


# ───────────────────────── الإيموجي ─────────────────────────
def _is_emoji_char(c: str) -> bool:
    o = ord(c)
    return o >= 0x1F000 or 0x2600 <= o <= 0x27BF or o in (0x2B50, 0x2B1B, 0x2B1C, 0x2B06, 0x2194, 0x2195, 0x23F3, 0x231B, 0x23F0, 0x2764)


def tokenize(text: str) -> list[tuple[str, str]]:
    """يقسم النص إلى ('t', نص) و ('e', مفتاح أيقونة)."""
    out: list[tuple[str, str]] = []
    buf = ""
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if _is_emoji_char(c):
            seq = [c]
            i += 1
            while i < n and (text[i] in "\ufe0f\u200d" or (seq[-1] == "\u200d" and _is_emoji_char(text[i]))):
                seq.append(text[i])
                i += 1
            if buf:
                out.append(("t", buf))
                buf = ""
            out.append(("e", _emoji_key(seq)))
        else:
            buf += c
            i += 1
    if buf:
        out.append(("t", buf))
    return out


def _emoji_key(seq: list[str]) -> str:
    return "-".join(f"{ord(x):x}" for x in seq if ord(x) != 0xFE0F)


@lru_cache(maxsize=256)
def _icon_raw(key: str) -> Image.Image | None:
    for k in (key, key.split("-")[0]):
        p = ICON_DIR / f"{k}.png"
        if p.exists():
            return Image.open(p).convert("RGBA")
    return None


@lru_cache(maxsize=512)
def icon_image(key: str, px: int) -> Image.Image | None:
    raw = _icon_raw(key)
    if raw is None:
        return None
    return raw.resize((px, px), Image.LANCZOS)


def icon_key(emoji: str) -> str:
    return _emoji_key(list(emoji))


def rich_width(font, text: str, gap: float = 1.15) -> float:
    w = 0.0
    for kind, val in tokenize(text):
        w += text_len(font, val) if kind == "t" else font.size * gap
    return w


def draw_rich(img: Image.Image, draw: ImageDraw.ImageDraw, x: float, y: float, text: str, font, fill,
              align: str = "r", gap: float = 1.15) -> float:
    """يرسم نصاً فيه إيموجي. (x,y) = حافة المحاذاة وخط المنتصف العمودي تقريباً. يعيد العرض."""
    toks = tokenize(text)
    rtl = has_arabic(text)
    total = rich_width(font, text, gap)
    if align == "r":
        left = x - total
    elif align == "m":
        left = x - total / 2
    else:
        left = x
    order = list(reversed(toks)) if rtl else toks   # الترتيب المرئي يسار→يمين
    cx = left
    asc = font.size * 0.5
    for kind, val in order:
        if kind == "t":
            draw_plain(draw, (cx, y + asc * 0.62), val, font, fill, "ls")
            cx += text_len(font, val)
        else:
            px = int(font.size * gap * 0.92)
            ic = icon_image(val, px)
            if ic is not None:
                img.alpha_composite(ic, (int(cx + (font.size * gap - px) / 2), int(y - px / 2)))
            cx += font.size * gap
    return total


def wrap(font, text: str, max_w: float) -> list[str]:
    """التفاف بالكلمات (بالترتيب المنطقي)."""
    lines: list[str] = []
    for para in text.split("\n"):
        cur = ""
        for word in para.split(" "):
            trial = f"{cur} {word}".strip()
            if cur and rich_width(font, trial) > max_w:
                lines.append(cur)
                cur = word
            else:
                cur = trial
        lines.append(cur)
    return lines
