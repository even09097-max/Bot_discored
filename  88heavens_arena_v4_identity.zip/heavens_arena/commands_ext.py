"""
أوامر التحديث الكبير: شجرة النين · هاتسو · سحب العتاد والصناديق · السوق الأسود · المواسم · الانتقام · أوامر الإدارة.
تُسجَّل تلقائياً عند الاستيراد من نهاية bot.py (تستخدم نفس bot/tree/أدوات الإرسال).
"""
from __future__ import annotations

import re
import time

import discord
from discord import app_commands

import bot as B
import cards as cd
import game as g
import hatsu as ht
import render as R
import render2 as R2
from game import GameError

slash, draw, send_card, to_file, dname = B.slash, B.draw, B.send_card, B.to_file, B.dname
bot = B.bot
OwnedView = B.OwnedView


async def _ensure(ix) -> dict:
    return await bot.db.ensure_user(ix.user.id, dname(ix.user))


# ═════════════════════════ شجرة النين ═════════════════════════
TREE_PORTRAITS = {"power": "gon", "defense": "kurapika", "speed": "killua"}


async def tree_image(user) -> bytes:
    info = await bot.db.tree_info(user.id)
    u = await bot.db.get_user(user.id)
    art = await bot.hub.art("tree", timeout=2.0)
    portraits = {}
    for br, key in TREE_PORTRAITS.items():          # صور الأبطال من الكاش فقط (لا انتظار شبكة أثناء الرسم)
        d = bot.hub.card_art_cached(key)
        if d:
            portraits[br] = d
    nen = g.normalize_nen(u["nen_type"]) if u else None
    return await draw(R2.tree_card, info["levels"], info["points"], info["spent"], info["effects"], dname(user), art, portraits,
                      g.nen_label(nen) if nen else "")


class TreeSelect(discord.ui.Select):
    def __init__(self, levels: dict, points: int) -> None:
        opts = []
        for key in ht.TREE_ORDER:
            if key == "core":
                continue
            node, lv = ht.TREE_NODES[key], levels.get(key, 0)
            ok, why = ht.can_upgrade(levels, key, points)
            desc = f"ترقية بـ {ht.node_cost(key, lv)} نقطة · {node['desc']}" if ok else why
            opts.append(discord.SelectOption(label=f"{node['name']} — {lv}/{ht.TREE_MAX_LEVEL}", value=key, emoji=node["emoji"], description=desc[:100]))
        super().__init__(placeholder="🌳 اختر عقدة لترقيتها", min_values=1, max_values=1, options=opts)

    async def callback(self, interaction: discord.Interaction) -> None:
        view: TreeView = self.view  # type: ignore[assignment]
        await interaction.response.defer()
        try:
            u = await bot.db.get_user(view.user.id)
            if u["floor"] < g.NEN_UNLOCK_FLOOR or not g.normalize_nen(u["nen_type"]):
                raise GameError(f"ترقية شجرة النين تُفتح بعد الطابق {g.NEN_UNLOCK_FLOOR} واختبار الكأس («اختبار»).")
            r = await bot.db.tree_upgrade(view.user.id, self.values[0])
            node = ht.TREE_NODES[r["node"]]
            await interaction.followup.send(f"{node['emoji']} **{node['name']}** صار مستوى {r['level']}/{ht.TREE_MAX_LEVEL} (−{r['cost']} نقطة، باقي {r['points']})", ephemeral=True)
        except GameError as e:
            await interaction.followup.send(f"❌ {e}", ephemeral=True)
        await view.refresh(interaction)


class TreeView(OwnedView):
    def __init__(self, user, levels: dict, points: int) -> None:
        super().__init__(user.id, timeout=300)
        self.user = user
        self.sel = TreeSelect(levels, points)
        self.add_item(self.sel)

    async def refresh(self, interaction: discord.Interaction) -> None:
        info = await bot.db.tree_info(self.user.id)
        nv = TreeView(self.user, info["levels"], info["points"])
        nv.message = self.message
        self.stop()
        await interaction.edit_original_response(attachments=[to_file(await tree_image(self.user))], view=nv)

    @discord.ui.button(label=f"إعادة توزيع ({ht.TREE_RESPEC_GEMS} 💎)", emoji="🔄", style=discord.ButtonStyle.secondary, row=1)
    async def respec_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.defer()
        try:
            r = await bot.db.tree_respec(self.user.id)
            await interaction.followup.send(f"🔄 أُعيدت {r['refunded']} نقطة نين إليك (−{r['cost']} 💎).", ephemeral=True)
        except GameError as e:
            await interaction.followup.send(f"❌ {e}", ephemeral=True)
        await self.refresh(interaction)


@slash("شجرة", "🌳 شجرة مهارات النين: ارتقِ بالقوة والدفاع والسرعة")
async def tree_cmd(ix: discord.Interaction) -> None:
    await ix.response.defer()
    await _ensure(ix)
    info = await bot.db.tree_info(ix.user.id)
    await send_card(ix, await tree_image(ix.user), TreeView(ix.user, info["levels"], info["points"]))


# ═════════════════════════ هاتسو ═════════════════════════
@slash("هاتسو", "🌀 قدرات النين الخاصة بأبطال الأنمي (من بطاقات فريقك)")
async def hatsu_cmd(ix: discord.Interaction) -> None:
    await ix.response.defer()
    u = await _ensure(ix)
    owned = {c["key"]: c for c in await bot.db.cards_of(ix.user.id)}
    team = [k for k in (u.get("team") or "").split(",") if k]
    cards = [cd.CARDS[k] for k in ht.CARD_HATSU]
    arts = await bot.hub.card_arts(cards, budget=4.0)
    blocks = []
    for key, moves in ht.CARD_HATSU.items():
        c = cd.CARDS[key]
        st = "team" if key in team else "owned" if key in owned else "locked"
        blocks.append({"owner": key, "name": c["name"], "status": st, "stars": owned.get(key, {}).get("stars", 0),
                       "moves": [{**ht.HATSU[m], "key": m} for m in moves]})
    art = await bot.hub.art("hatsu", timeout=2.0)
    await send_card(ix, await draw(R2.hatsu_card, blocks, art, arts))


# ═════════════════════════ سحب العتاد والصناديق ═════════════════════════
GEAR_CURRENCIES = [app_commands.Choice(name=f"💰 ذهب ({ht.GEAR_GOLD_COST})", value="gold"),
                   app_commands.Choice(name=f"💎 جواهر ({ht.GEAR_GEM_COST})", value="gems")]


async def _gear_card(items: list[dict], title: str, spent: str, pity: int | None) -> bytes:
    gears = [ht.GEAR[i["gear_key"]] for i in items if i.get("gear_key") in ht.GEAR]
    await bot.hub.gear_arts(gears, budget=5.0)          # صور هانتر الحقيقية: تُجلب مرة وتُحفظ في الكاش
    B.refresh_item_art()
    views = [g.item_view({"item_id": i["item_id"], "item_name": i["name"], "item_type": i["type"], "stat": i["stat"], "stat_bonus": i["bonus"],
                          "rarity": i["rarity"], "effect": i.get("effect", "")}) for i in items]
    best = max(v["rarity"] for v in views)
    return await draw(R.gacha_result_card, views, pity if pity is not None else 0, ht.GEAR_PITY, spent, best, title, "🎒",
                      "ملحمي أو أعلى مضمون" if pity is not None else "ملحمي أو أعلى مضمون في كل صندوق")


async def _announce_legend(user, items: list[dict], guild_id: int) -> None:
    for it in items:
        if it["rarity"] == "legendary":
            await B.announce(guild_id, "gacha", f"🌟 **{dname(user)}** حصل على عتاد **أسطوري**: {g.item_emoji(it['name'], it['type'])} {it['name']}!")


async def _do_gear(user, currency: str, count: int, guild_id: int) -> tuple[bytes, str | None]:
    items = await bot.db.gear_pull(user.id, currency, count, bot.rng)
    cost = items[0]["cost"]
    data = await _gear_card(items, "سحب العتاد", f"{cost} {'ذهب' if currency == 'gold' else 'جوهرة'}", items[-1]["pity"])
    await _announce_legend(user, items, guild_id)
    return data, "🎒 جهّز القطعة بـ «تجهيز» — لكل قطعة تأثير خاص يظهر في القتال."


@slash("سحب_عتاد", "🎒 اسحب عتاد وأسلحة وآثار من عالم هانتر (سيوف، يو يو، سلاسل...) — فوري")
@app_commands.describe(currency="طريقة الدفع", count="عدد السحبات (1 إلى 10)")
@app_commands.rename(currency="العملة", count="العدد")
@app_commands.choices(currency=GEAR_CURRENCIES)
async def gear_gacha_cmd(ix: discord.Interaction, currency: str = "gold", count: app_commands.Range[int, 1, 10] = 1) -> None:
    await ix.response.defer()
    await _ensure(ix)
    gid = ix.guild_id or 0

    async def pull(user, cur, n):
        return await _do_gear(user, cur, n, gid)

    data, tip = await pull(ix.user, currency, count)
    await send_card(ix, data, B.PullAgainView(ix.user.id, pull, currency), content=tip)


@slash("صندوق", "📦 افتح صناديق العتاد الحصرية (من مهام العصابة والسوق الأسود)")
@app_commands.describe(count="كم صندوقاً تفتح (1 إلى 10)")
@app_commands.rename(count="العدد")
async def crate_cmd(ix: discord.Interaction, count: app_commands.Range[int, 1, 10] = 1) -> None:
    await ix.response.defer()
    await _ensure(ix)
    items = await bot.db.open_crates(ix.user.id, count, bot.rng)
    u = await bot.db.get_user(ix.user.id)
    data = await _gear_card(items, "صندوق عتاد حصري", f"باقي {u['crates']} صندوق", None)
    await send_card(ix, data, content="📦 كل صندوق يضمن عتاداً ملحمياً أو أعلى!")
    await _announce_legend(ix.user, items, ix.guild_id or 0)


# ═════════════════════════ السوق الأسود ═════════════════════════
async def market_image(user, state: dict | None = None) -> tuple[bytes, dict]:
    st = state or await bot.db.market_state(user.id)
    u = await bot.db.get_user(user.id)
    gears = []
    for o in st["stock"]:
        if o["kind"] == "gear":
            gr = ht.GEAR[o["key"]]
            it = g.item_view({"item_id": 0, "item_name": gr["name"], "item_type": gr["type"], "stat": gr["stat"],
                              "stat_bonus": ht.GEAR_BONUS[gr["stat"]][gr["r"]], "rarity": ["common", "rare", "epic", "legendary"][gr["r"]], "effect": gr["fx"]})
            o["bonus_text"], o["fx_text"] = it["bonus_text"], it["fx_text"]
            gears.append(gr)
    await bot.hub.gear_arts(gears, budget=4.0)
    B.refresh_item_art()
    offer_arts = {}
    for o in st["stock"]:
        if o["kind"] == "gear":
            offer_arts[o["slot"]] = bot.hub.gear_art_cached(ht.GEAR[o["key"]])
    art = await bot.hub.art("market", timeout=2.0)
    now = time.time()
    left = B.fmt_dur((st["end"] - now) if st["open"] else (st["next_open"] - now))
    data = await draw(R2.market_card, st, dname(user), art, offer_arts, left, u["gold"] if u else 0, u["gems"] if u else 0)
    return data, st


class MarketSelect(discord.ui.Select):
    def __init__(self, st: dict) -> None:
        opts = []
        for o in st["stock"]:
            gone = o["left"] <= 0 or o.get("mine", 0) >= ht.MARKET_MAX_BUY
            price = f"{o['gold']:,} ذهب" if o["gold"] else f"{o['gems']} جوهرة"
            opts.append(discord.SelectOption(label=f"#{o['slot'] + 1} {o['name']}"[:100], value=str(o["slot"]), emoji=o["emoji"],
                                             description=("غير متاح — " if gone else "") + price))
        super().__init__(placeholder="🛒 اختر عرضاً للشراء", min_values=1, max_values=1, options=opts, disabled=not st["open"])

    async def callback(self, interaction: discord.Interaction) -> None:
        view: MarketView = self.view  # type: ignore[assignment]
        await interaction.response.defer()
        try:
            r = await bot.db.market_buy(view.user.id, int(self.values[0]))
            o = r["offer"]
            await interaction.followup.send(f"🏴 اشتريت **{o['emoji']} {o['name']}** من السوق الأسود!" + ("\n🎒 جهّزها بـ «تجهيز»." if r["item"] else
                                            "\n🌳 أُضيفت نقاط النين لشجرتك." if o["kind"] == "stone" else "\n📦 افتحه بـ «صندوق»."), ephemeral=True)
        except GameError as e:
            await interaction.followup.send(f"❌ {e}", ephemeral=True)
        await view.refresh(interaction)


class MarketView(OwnedView):
    def __init__(self, user, st: dict) -> None:
        super().__init__(user.id, timeout=300)
        self.user = user
        self.add_item(MarketSelect(st))

    async def refresh(self, interaction: discord.Interaction) -> None:
        data, st = await market_image(self.user)
        nv = MarketView(self.user, st)
        nv.message = self.message
        self.stop()
        await interaction.edit_original_response(attachments=[to_file(data)], view=nv)


@slash("سوق_اسود", "🏴 السوق الأسود: عتاد نادر ومواد نين — يفتح لفترات محدودة بأسعار متغيرة")
@app_commands.describe(open_hours="للإدارة: افتح السوق لعدد ساعات (0 لإغلاقه)")
@app_commands.rename(open_hours="فتح_ساعات")
async def market_cmd(ix: discord.Interaction, open_hours: app_commands.Range[float, 0, 48] | None = None) -> None:
    await ix.response.defer()
    await _ensure(ix)
    if open_hours is not None:
        B.need_admin(ix)
        await bot.db.market_force(open_hours)
        if open_hours > 0:
            await B.announce(ix.guild_id or 0, "floor", f"🏴 **السوق الأسود فتح أبوابه** لمدة {open_hours:g} ساعة! اكتبوا «سوق_اسود».")
    data, st = await market_image(ix.user)
    await send_card(ix, data, MarketView(ix.user, st))


# ═════════════════════════ المواسم ═════════════════════════
async def season_image(user) -> bytes:
    cur = await bot.db.season_current()
    total = cur["end_ts"] - cur["start_ts"]
    frac = 1 - cur["left"] / total if total > 0 else 1
    top = await bot.db.top_players(100)
    my_rank = next((i + 1 for i, p in enumerate(top) if p["user_id"] == user.id), None)
    hall = await bot.db.season_hall()
    art = await bot.hub.art("season", timeout=2.0)
    return await draw(R2.season_card, cur, B.fmt_dur(cur["left"]), frac, top[:5], hall, dname(user), my_rank, art)


async def season_tick(force: bool = False) -> dict | None:
    """يُستدعى من مهمة الخلفية: ينهي الموسم المنتهي ويعلن النتائج في كل السيرفرات."""
    out = await bot.db.finish_due_season(force)
    if not out:
        return None
    rows = [(["🥇", "🥈", "🥉"][p["rank"] - 1] if p["rank"] <= 3 else "🌟", p["username"] or "؟", f"{p['title'] or 'نخبة الموسم'} · طابق {p['floor']} · +{p['gold']:,} 💰 +{p['gems']} 💎")
            for p in out["players"][:6]]
    lines = [f"تبدأ الآن {out['new']['name']}: صُفّرت الطوابق والسيطرة وبقيت مستوياتك وعتادك وبطاقاتك."]
    if out["gang"]:
        lines.insert(0, f"{out['gang']['title']}: عصابة «{out['gang']['name']}» (+{out['gang']['gold']:,} 💰 للخزينة و+{out['gang']['gems']} 💎 لكل عضو)")
    B.idn.use("season", "end")
    data = await draw(R.list_card, f"انتهى {out['season']['name']}!", "قاعة الأبطال", rows or [("🏆", "لا مشاركين", "—")], "🏆", "gold", lines=lines)
    for guild in bot.guilds:
        await B.announce(guild.id, "floor", f"🏆 **انتهى {out['season']['name']}!** اكتبوا «موسم» لتروا قاعة الأبطال.", data)
    return out


SEASON_ACTIONS = [app_commands.Choice(name="معلومات", value="info"), app_commands.Choice(name="إنهاء (للإدارة)", value="end")]


@slash("موسم", "🏆 الموسم الحالي: الترتيب والجوائز وقاعة الأبطال")
@app_commands.describe(action="اتركه فارغاً للمعلومات")
@app_commands.rename(action="الإجراء")
@app_commands.choices(action=SEASON_ACTIONS)
async def season_cmd(ix: discord.Interaction, action: str = "info") -> None:
    B.idn.use("season", action if action in ("info", "end") else "info")
    await ix.response.defer()
    await _ensure(ix)
    if action == "end":
        B.need_admin(ix)
        out = await season_tick(True)
        await ix.followup.send(f"🏆 أُنهي {out['season']['name']} وبدأ {out['new']['name']}." if out else "تعذّر إنهاء الموسم.")
        return
    await send_card(ix, await season_image(ix.user))


# ═════════════════════════ الانتقام ═════════════════════════
class RevengeView(OwnedView):
    def __init__(self, user, rows: list[dict]) -> None:
        super().__init__(user.id, timeout=240)
        self.user, self.rows = user, rows

    @discord.ui.button(label="ابدأ الانتقام", emoji="🔥", style=discord.ButtonStyle.danger)
    async def go_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        uid = interaction.user.id
        if uid in bot.active:
            await interaction.response.send_message("❌ عندك معركة مفتوحة بالفعل!", ephemeral=True)
            return
        bot.active.add(uid)
        try:
            await interaction.response.defer()
            rv = self.rows[0]
            u = await bot.db.get_user(uid)
            if u["cur_hp"] < g.MIN_HP_PCT_TO_CLIMB * u["t_hp"]:
                raise GameError(f"صحتك منخفضة ({u['cur_hp']}/{u['t_hp']}). ارتح قليلاً أو استخدم بطاقة شفاء.")
            holder = await bot.db.floor_holder(rv["floor"], exclude_id=uid)
            if holder is None:
                raise GameError("الطابق بلا مسيطر الآن.")
            gen = g.enemy_for_floor(rv["floor"], bot.rng)
            enemy = g.echo_of(holder, gen, f"👤 ظل {holder['username']} · الطابق {rv['floor']}")
            battle = g.Battle(g.fighter_from_user(u, dname(interaction.user)), enemy, bot.rng)
            self.stop()
            await B.start_battle(interaction, battle, "revenge", rv["floor"], f"🔥 الانتقام · الطابق {rv['floor']}", theme="boss",
                                 art_ctx=B.floor_art_ctx(rv["floor"]), holder=holder, revenge_id=rv["id"])
        except BaseException:
            bot.active.discard(uid)
            raise


@slash("انتقام", "🔥 سجل الانتقام: استعد الطابق الذي خسرته أثناء غيابك")
async def revenge_cmd(ix: discord.Interaction) -> None:
    await ix.response.defer()
    await _ensure(ix)
    rows = await bot.db.revenge_open(ix.user.id)
    art = await bot.hub.art("revenge", timeout=2.0)
    if not rows:
        floors = await bot.db.floors_held(ix.user.id)
        data = await draw(R.list_card, "سجل الانتقام", dname(ix.user), [("✅", "لا شيء للانتقام", "لم يسرق أحد طابقك")] +
                          ([("🏯", "طوابقك تحت السيطرة", "، ".join(str(f) for f in floors[:10]))] if floors else []), "🔥", "default", art,
                          lines=[f"عندما يهزم لاعب ظلّك في طابق تسيطر عليه يُسجَّل هنا لـ{g.REVENGE_HOURS} ساعة وتصلك رسالة خاصة."])
        await send_card(ix, data, ephemeral=True)
        return
    rv = rows[0]
    rr = [("⚔️", f"الطابق {r['floor']}", f"{r['taker_name'] or '؟'} · باقي {B.fmt_dur(r['left'])}") for r in rows[:6]]
    data = await draw(R2.floor_control_card, rv["floor"], f"{rv['taker_name'] or '؟'} أخذ طابقك", "revenge", art, rr, dname(ix.user))
    await send_card(ix, data, RevengeView(ix.user, rows))


async def revenge_notify() -> None:
    """رسالة خاصة لكل من خسر طابقه (مرة واحدة)."""
    for r in await bot.db.revenge_unnotified():
        try:
            user = bot.get_user(r["victim_id"]) or await bot.fetch_user(r["victim_id"])
            await user.send(f"🏯 **{r['taker_name'] or 'لاعب'}** هزم ظلّك وأخذ **الطابق {r['floor']}**!\n"
                            f"🔥 اكتب «انتقام» في السيرفر خلال {g.REVENGE_HOURS} ساعة لتستعيده بمكافأة ×{g.REVENGE_BONUS_GOLD:g}.")
        except Exception as e:
            B.log.debug("revenge dm: %s", e)


# ═════════════════════════ أوامر الإدارة ═════════════════════════
def _split_count(text: str | None, count: int) -> tuple[str, int]:
    """«سيف نوبوناغا 3» ← ('سيف نوبوناغا', 3)."""
    t = (text or "").strip()
    m = re.match(r"^(.*?)[\s]+([0-9٠-٩]+)$", t)
    if m and m.group(1):
        return m.group(1).strip(), int(m.group(2).translate(str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")))
    return t, count


@slash("arena_setfloor", "🛠️ [إدارة] اضبط طابق لاعب")
@app_commands.describe(member="اللاعب", floor=f"رقم الطابق (1 إلى {g.MAX_FLOOR})")
@app_commands.rename(member="اللاعب", floor="الطابق")
async def admin_setfloor(ix: discord.Interaction, member: discord.Member, floor: app_commands.Range[int, 1, 100]) -> None:
    B.need_admin(ix)
    await ix.response.defer(ephemeral=True)
    r = await bot.db.admin_set_floor(member.id, floor)
    await ix.followup.send(f"🛠️ طابق **{dname(member)}**: {r['old']} ← {r['new']}", ephemeral=True)


@slash("arena_giveitem", "🛠️ [إدارة] أعطِ لاعباً عتاداً أو موارد (ذهب/جواهر/صندوق/نقاط_نين)")
@app_commands.describe(member="اللاعب", count="الكمية (1 إلى 99999)", item="اسم القطعة أو: ذهب / جواهر / صندوق / نقاط_نين")
@app_commands.rename(member="اللاعب", count="الكمية", item="العنصر")
async def admin_giveitem(ix: discord.Interaction, member: discord.Member, count: app_commands.Range[int, 1, 99999] = 1, item: str | None = None) -> None:
    B.need_admin(ix)
    await ix.response.defer(ephemeral=True)
    name, count = _split_count(item, count)
    if not name:
        raise GameError("الصيغة: arena_giveitem @لاعب 2 سيف نوبوناغا   (أو: ذهب 5000)")
    await bot.db.ensure_user(member.id, dname(member))
    key = B.strip_al(B.norm(name)).replace(" ", "_")
    if key in ("ذهب", "gold", "دهب"):
        await bot.db.admin_grant(member.id, "gold", count, f"من {dname(ix.user)}")
        msg = f"💰 +{count:,} ذهب"
    elif key in ("جواهر", "جوهره", "gems"):
        await bot.db.admin_grant(member.id, "gems", count, f"من {dname(ix.user)}")
        msg = f"💎 +{count:,} جوهرة"
    elif key in ("صندوق", "صناديق", "crate", "crates"):
        await bot.db._run(lambda c: c.execute("UPDATE users SET crates = crates + ? WHERE user_id = ?", (count, member.id)))
        msg = f"📦 +{count} صندوق عتاد"
    elif key in ("نقاط_نين", "نقاط_النين", "نين", "tree"):
        await bot.db.grant_tree_points(member.id, count)
        msg = f"🌳 +{count} نقطة نين"
    else:
        gear = ht.find_gear(name)
        if gear is None:
            raise GameError(f"ما لقيت عتاداً باسم «{name[:30]}». الأسماء: " + "، ".join(x["name"] for x in list(ht.GEAR.values())[:8]) + " ...")
        count = min(count, 20)
        await bot.db.give_gear(member.id, gear, count)
        msg = f"{gear['emoji']} {gear['name']} ×{count}"
    await ix.followup.send(f"🛠️ أُعطي **{dname(member)}**: {msg}", ephemeral=True)


@slash("arena_reset", "🛠️ [إدارة] أعد ضبط تقدم لاعب (الطابق والمستوى والنين والإحصائيات) مع إبقاء ممتلكاته")
@app_commands.describe(member="اللاعب")
@app_commands.rename(member="اللاعب")
async def admin_reset(ix: discord.Interaction, member: discord.Member) -> None:
    B.need_admin(ix)
    await ix.response.defer(ephemeral=True)
    await bot.db.admin_reset(member.id)
    await ix.followup.send(f"🛠️ أُعيد ضبط تقدم **{dname(member)}** (الطابق 1، المستوى 1). ذهبه وجواهره وعتاده وبطاقاته باقية.", ephemeral=True)
