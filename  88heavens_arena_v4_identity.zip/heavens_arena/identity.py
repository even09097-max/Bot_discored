"""
الهوية البصرية لكل واجهة في اللعبة (تحديث V4).

ما يحققه هذا الملف:
  • لكل أمر رئيسي «شارة/صورة» خاصة به + خلفية مستقلة + ثيم لوني (جدول CMDS).
  • لكل قائمة فرعية (صفحات الشرح، إجراءات العصابة، مهام، تحكم، موسم...) خلفية خاصة (SUBS).
  • خلفيات متعددة للقتال (11 فئة طوابق) والساحات (صيد/مبارزة/مباشر/زعيم/انتقام) والزعماء الستة وأحداث الطوابق.
  • مكتبة صور منظمة على القرص:  assets/identity/{backgrounds,floors,arenas,bosses,events,nen,emblems}/
    تُبنى بـ  python tools/build_identity.py  وتُولَّد تلقائياً عند الحاجة إن نقص أي ملف.
  • صورك المرفوعة بأمر «صور» (assets/art/<مكان>/) تتقدم دائماً على المولَّد.
  • لا تكرار عشوائي: اختيار حتمي بالتناوب (rotation) لا يعيد الصورة نفسها مرتين متتاليتين،
    وسلسلة احتياط ثابتة: صورتك ← الصورة المولَّدة للمكان ← خلفية الثيم. لا تتعطل أي واجهة لنقص صورة.
  • فحص تغطية (coverage/audit) يكشف أي أمر بلا هوية وأي صور مكررة.

الاستخدام داخل البوت: يضبط البوت «الهوية الحالية» عند بدء كل أمر (use) فيطبّقها محرك الرسم تلقائياً
على كل بطاقة تُرسم أثناء ذلك الأمر (خلفية القسم + شارة الأمر + ثيم القسم).
"""
from __future__ import annotations

import colorsys
import contextvars
import hashlib
import io
import logging
import math
import random
import re
import threading
import unicodedata
from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from PIL import Image, ImageDraw, ImageFilter

log = logging.getLogger("arena.identity")
BASE = Path(__file__).resolve().parent
LIB = BASE / "assets" / "identity"          # المكتبة المنظمة (مولَّدة)
UPLOADS = BASE / "assets" / "art"           # صور المالك (أمر «صور») — تتقدم دائماً
BG_W, BG_H = 1000, 640
STATIC_EXTS = (".png", ".jpg", ".jpeg", ".webp", ".gif")
Color = tuple


# ═════════════════════════════════ الثيمات ═════════════════════════════════
# اسم: (أعلى التدرج، أسفل التدرج، لون التمييز) — تُضاف إلى render.THEMES عند الاستيراد.
THEMES: dict[str, tuple[Color, Color, Color]] = {
    "tower": ((12, 10, 40), (40, 18, 78), (140, 100, 255)),
    "city": ((8, 16, 38), (22, 30, 74), (90, 180, 255)),
    "duel": ((10, 16, 44), (32, 20, 66), (100, 170, 255)),
    "license": ((34, 22, 8), (40, 14, 40), (255, 190, 60)),
    "water": ((6, 26, 40), (8, 52, 74), (70, 215, 235)),
    "aura": ((24, 8, 46), (10, 20, 62), (176, 104, 255)),
    "ascend": ((8, 30, 28), (14, 42, 64), (70, 225, 145)),
    "crates": ((32, 20, 12), (18, 16, 38), (255, 170, 70)),
    "portal": ((32, 8, 52), (8, 18, 54), (255, 100, 200)),
    "cards": ((10, 20, 50), (32, 10, 54), (255, 200, 90)),
    "book": ((10, 18, 42), (24, 28, 68), (120, 190, 255)),
    "team": ((8, 28, 46), (22, 14, 52), (90, 224, 204)),
    "forge": ((14, 22, 42), (32, 22, 56), (150, 192, 255)),
    "heal": ((8, 34, 30), (10, 22, 46), (90, 240, 170)),
    "coins": ((36, 24, 8), (38, 14, 34), (255, 204, 74)),
    "gift": ((42, 16, 32), (20, 12, 52), (255, 140, 182)),
    "crown": ((38, 28, 8), (26, 12, 46), (255, 216, 92)),
    "vow": ((42, 6, 16), (16, 6, 32), (238, 62, 84)),
    "gang": ((24, 10, 32), (12, 12, 38), (192, 94, 255)),
    "war": ((46, 10, 14), (18, 8, 38), (255, 112, 62)),
    "boss": ((40, 8, 24), (14, 8, 38), (255, 72, 92)),
    "missions": ((10, 28, 42), (22, 14, 56), (124, 204, 255)),
    "ledger": ((8, 26, 38), (12, 20, 58), (84, 224, 204)),
    "admin": ((16, 18, 30), (26, 20, 46), (164, 174, 204)),
    "hunt": ((6, 32, 22), (8, 18, 42), (92, 224, 124)),
    "stars": ((26, 16, 52), (10, 14, 42), (255, 212, 104)),
    "party": ((46, 16, 42), (14, 12, 48), (255, 122, 224)),
    "market": ((14, 10, 24), (32, 10, 32), (212, 72, 255)),
    "season": ((14, 22, 58), (42, 14, 62), (255, 192, 82)),
    "revenge": ((46, 8, 12), (22, 6, 24), (255, 84, 52)),
    "echo": ((10, 10, 28), (26, 10, 44), (150, 120, 230)),
    "tree": ((8, 28, 30), (16, 12, 48), (110, 236, 170)),
    "signal": ((8, 20, 44), (14, 12, 54), (96, 196, 255)),
    # الطوابق
    "dusk": ((38, 20, 44), (14, 14, 42), (255, 150, 100)),
    "neon": ((8, 12, 40), (30, 10, 60), (80, 220, 255)),
    "colosseum": ((34, 24, 18), (18, 18, 46), (240, 192, 112)),
    "ember": ((46, 14, 10), (22, 8, 32), (255, 112, 52)),
    "aura_b": ((8, 18, 48), (12, 30, 72), (80, 170, 255)),
    "aura_v": ((26, 8, 52), (14, 14, 60), (190, 110, 255)),
    "abyss": ((10, 6, 18), (34, 8, 30), (210, 60, 90)),
    "temple": ((20, 18, 36), (40, 24, 56), (232, 200, 140)),
    "gold_temple": ((40, 28, 10), (28, 14, 44), (255, 214, 98)),
    "summit": ((16, 20, 54), (60, 30, 80), (255, 232, 160)),
    # الزعماء والأحداث
    "hisoka": ((44, 8, 40), (18, 8, 46), (255, 70, 190)),
    "illumi": ((12, 8, 22), (30, 12, 40), (170, 130, 230)),
    "chrollo": ((10, 10, 18), (28, 14, 36), (210, 190, 140)),
    "pitou": ((10, 24, 34), (24, 12, 40), (120, 230, 210)),
    "netero": ((36, 28, 12), (22, 14, 46), (255, 224, 120)),
    "meruem": ((30, 8, 40), (12, 8, 30), (255, 90, 150)),
    "trap": ((38, 20, 10), (20, 10, 28), (240, 150, 70)),
}


# ═════════════════════════════════ الجداول ═════════════════════════════════
@dataclass(frozen=True)
class Spec:
    slug: str                    # اسم ملف/مفتاح إنجليزي ثابت
    ar: str                      # اسم الأمر كما يُسجَّل في ديسكورد
    family: str                  # مفتاح العائلة (للمجموعات في أمر «صور»)
    theme: str
    motif: str
    emoji: str
    subs: tuple = ()             # ((مفتاح فرعي، اسم عربي), ...)


FAMILIES: dict[str, tuple[str, str]] = {      # مفتاح: (اسم المجموعة، رمز)
    "tower": ("البرج والقتال", "🏰"), "nen": ("النين والقوة", "🌀"), "gear": ("العتاد والسحب", "🎒"),
    "cards": ("البطاقات والفريق", "🎴"), "shop": ("المتاجر والسوق", "🛒"), "gang": ("العصابات", "🏴"),
    "boss": ("الزعيم والمهام", "👹"), "admin": ("الإدارة والأدوات", "🛠️"), "help": ("الشرح", "📖"),
}
EXTRA_GROUPS = {"صور البطاقات": "🎴", "خلفيات الطوابق": "🏙️", "ساحات القتال": "🏟️", "خلفيات الزعماء": "👹", "أحداث الطوابق": "🎉", "صور النين": "🌀"}

# الشرح: 11 صفحة (تطابق HELP_PAGES في bot.py — يتحقق منها الاختبار)
HELP_SUBS = (("p0", "البداية والبرج"), ("p1", "السيطرة والانتقام"), ("p2", "القتال"), ("p3", "النين وهاتسو"), ("p4", "الحقيبة والسحب"),
             ("p5", "البطاقات والفريق"), ("p6", "التطوير والصيد"), ("p7", "الزعيم والمهام"), ("p8", "العصابات والحروب"),
             ("p9", "السوق الأسود والمواسم"), ("p10", "الاقتصاد والإدارة"))
GANG_SUBS = (("info", "معلومات"), ("create", "تأسيس"), ("join", "انضمام"), ("leave", "مغادرة"), ("accept", "قبول"), ("kick", "طرد"),
             ("setrole", "تعيين"), ("deposit", "إيداع"), ("war", "حرب"), ("requests", "طلبات"))

CMDS: tuple[Spec, ...] = (
    # ── البرج والقتال ──
    Spec("climb", "صعود", "tower", "tower", "tower", "🏰"),
    Spec("floor", "طابق", "tower", "city", "city", "🔭"),
    Spec("duel", "مبارزة", "tower", "duel", "swords", "🥊"),
    Spec("profile", "ملف", "tower", "license", "license", "📊"),
    Spec("daily", "يومي", "tower", "gift", "gift", "🎁"),
    Spec("rank", "ترتيب", "tower", "crown", "crown", "🏆"),
    Spec("revenge", "انتقام", "tower", "revenge", "flames", "🔥"),
    Spec("season", "موسم", "tower", "season", "stars", "🌠", (("info", "الموسم"), ("end", "نهاية الموسم"))),
    Spec("hunt", "صيد", "tower", "hunt", "forest", "🏹"),
    Spec("achieve", "انجازات", "tower", "stars", "medal", "🏅"),
    # ── النين والقوة ──
    Spec("nen_test", "اختبار", "nen", "water", "ripples", "🌊"),
    Spec("skills", "مهارات", "nen", "aura", "nen", "🌀"),
    Spec("upgrade", "تطوير", "nen", "ascend", "ascend", "📈"),
    Spec("tree", "شجرة", "nen", "tree", "tree", "🌳"),
    Spec("hatsu", "هاتسو", "nen", "aura", "echo", "🔮"),
    Spec("vow", "نذر", "nen", "vow", "chains", "🩸"),
    # ── العتاد والسحب ──
    Spec("bag", "حقيبة", "gear", "crates", "bag", "🎒"),
    Spec("gacha", "سحب", "gear", "portal", "portal", "🎰", (("result", "النتيجة"),)),
    Spec("gear_gacha", "سحب_عتاد", "gear", "forge", "gear", "🎲"),
    Spec("crate", "صندوق", "gear", "crates", "crates", "📦"),
    Spec("equip", "تجهيز", "gear", "forge", "shield", "🛡️"),
    Spec("use", "استخدام", "gear", "heal", "heal", "📜"),
    Spec("sell", "بيع", "gear", "coins", "coins", "💰"),
    Spec("enhance", "تحسين", "gear", "forge", "anvil", "🔨"),
    Spec("fuse", "دمج", "gear", "portal", "fusion", "🧪"),
    # ── البطاقات والفريق ──
    Spec("summon", "استدعاء", "cards", "cards", "cards", "🎴", (("result", "النتيجة"),)),
    Spec("card", "بطاقة", "cards", "cards", "bigcard", "🃏"),
    Spec("album", "ألبوم", "cards", "book", "book", "📕"),
    Spec("team", "فريق", "cards", "team", "team", "👥"),
    # ── المتاجر والسوق ──
    Spec("shop", "متجر", "shop", "coins", "stall", "🛒"),
    Spec("transfer", "تحويل", "shop", "ledger", "exchange", "🤝"),
    Spec("market", "سوق_اسود", "shop", "market", "lanterns", "🕸️"),
    # ── العصابات ──
    Spec("gang", "عصابة", "gang", "gang", "banner", "🏴", GANG_SUBS),
    Spec("found", "تأسيس", "gang", "gang", "temple", "🧱"),
    Spec("join", "انضمام", "gang", "gang", "team", "✅"),
    Spec("leave", "مغادرة", "gang", "gang", "echo", "👋"),
    Spec("war", "حرب", "gang", "war", "swords", "⚔️"),
    # ── الزعيم والمهام ──
    Spec("boss", "زعيم", "boss", "boss", "demon", "👹", (("fight", "المواجهة"), ("win", "سقوط الزعيم"))),
    Spec("missions", "مهام", "boss", "missions", "scroll", "📋", ()),
    # ── الإدارة والأدوات ──
    Spec("ledger", "سجل", "admin", "ledger", "ledger", "🧾"),
    Spec("control", "تحكم", "admin", "admin", "grid", "🔢", (("day", "آخر 24 ساعة"), ("week", "آخر 7 أيام"), ("all", "كل الوقت"))),
    Spec("grant", "منح", "admin", "gift", "gift", "💳"),
    Spec("channel", "قناة", "admin", "signal", "signal", "📢"),
    Spec("ping", "بينغ", "admin", "signal", "pulse", "⚡"),
    Spec("say", "قول", "admin", "signal", "bubble", "💬"),
    Spec("event", "حدث", "admin", "party", "stars", "🎉"),
    Spec("art", "صور", "admin", "admin", "frame", "🖼️"),
    Spec("identity", "هوية", "admin", "admin", "palette", "🎭"),
    Spec("admin_setfloor", "arena_setfloor", "admin", "admin", "tower", "🗺️"),
    Spec("admin_giveitem", "arena_giveitem", "admin", "admin", "crates", "🧧"),
    Spec("admin_reset", "arena_reset", "admin", "admin", "cycle", "🔄"),
    # ── الشرح ──
    Spec("help", "شرح", "help", "book", "book", "📖", HELP_SUBS),
)

# فئات الطوابق: (من، إلى، نمط، ثيم، إزاحة لون) — كل فئة خلفية قتال مستقلة
FLOOR_BANDS: tuple[tuple[int, int, str, str, int], ...] = (
    (1, 9, "city", "dusk", 0), (10, 19, "city", "neon", 0), (20, 29, "arena", "colosseum", 0), (30, 39, "arena", "ember", 0),
    (40, 49, "tower", "tower", 10), (50, 59, "nen", "aura_b", 0), (60, 69, "nen", "aura_v", 0), (70, 79, "flames", "abyss", 0),
    (80, 89, "temple", "temple", 0), (90, 99, "temple", "gold_temple", 0), (100, 100, "summit", "summit", 0),
)
ARENAS = {   # ساحات الأنماط: مفتاح: (اسم عربي، نمط، ثيم)
    "hunt": ("ساحة الصيد", "forest", "hunt"), "duel": ("ساحة المبارزة", "swords", "duel"), "live": ("ساحة التحدي المباشر", "arena", "war"),
    "boss": ("ساحة الزعيم", "flames", "boss"), "revenge": ("ساحة الانتقام", "chains", "revenge"),
}
BOSS_BG = {   # مفتاح الزعيم (game.BOSSES): (اسم، نمط، ثيم)
    "hisoka": ("هيسوكا", "cards", "hisoka"), "illumi": ("إيلومي", "spikes", "illumi"), "chrollo": ("كروللو", "banner", "chrollo"),
    "pitou": ("نفيربيتو", "echo", "pitou"), "netero": ("نيتيرو", "stars", "netero"), "meruem": ("ميروم", "halo", "meruem"),
}
EVENT_BG = {   # أحداث الطوابق (game.FLOOR_EVENTS)
    "chest": ("صندوق كنز", "coins", "coins"), "gems": ("بلّورات", "stars", "signal"), "heal": ("ينبوع الشفاء", "heal", "heal"),
    "item": ("تاجر متجوّل", "cards", "cards"), "trap": ("فخ قديم", "spikes", "trap"), "blessing": ("بركة المعبد", "halo", "gold_temple"),
}
NEN_TYPES = {   # فئات النين الست: (اسم، لون)
    "enhancer": ("التعزيز", "ascend"), "transmuter": ("التحويل", "aura"), "conjurer": ("التجسيد", "tree"),
    "emitter": ("الإرسال", "coins"), "manipulator": ("التلاعب", "signal"), "specialist": ("التخصص", "portal"),
}
# سياقات anime_images ← مفتاح الأمر الذي يرثها (للصورة البطولية الاحتياطية)
CONTEXT_CMD = {
    "tower": "climb", "floor_master": "floor", "victory": "climb", "defeat": "revenge", "nen_test": "nen_test", "gacha": "gacha",
    "gear_gacha": "gear_gacha", "guild": "gang", "gang": "gang", "war": "war", "help": "help", "vow": "vow", "missions": "missions",
    "shop": "shop", "profile": "profile", "market": "market", "season": "season", "tree": "tree", "revenge": "revenge", "echo": "hatsu",
    "hatsu": "hatsu", "season_hall": "season", "hunt": "hunt", "achieve": "achieve", "boss": "boss",
}


def _norm(s: str) -> str:
    s = unicodedata.normalize("NFKC", s or "")
    s = re.sub(r"[\u064b-\u065f\u0640]", "", s).strip().lower().lstrip("/!")
    return s.translate(str.maketrans("أإآٱىة", "اااايه"))


_BY_SLUG = {c.slug: c for c in CMDS}
_BY_NORM = {_norm(c.ar): c for c in CMDS}
assert len(_BY_SLUG) == len(CMDS) and len(_BY_NORM) == len(CMDS), "تكرار في جدول الهوية"


def resolve(command: str | None) -> Spec | None:
    """يحوّل اسم أمر عربي (أو مفتاحه الإنجليزي) إلى مواصفاته. None إن لم يكن معروفاً."""
    if not command:
        return None
    return _BY_SLUG.get(command) or _BY_NORM.get(_norm(command))


def band_index(floor: int) -> int:
    f = max(1, int(floor))
    for i, (lo, hi, *_r) in enumerate(FLOOR_BANDS):
        if lo <= f <= hi:
            return i
    return len(FLOOR_BANDS) - 1


def floor_key(floor: int) -> str:
    return f"floor_{band_index(floor) + 1:02d}"


def legacy_floor_slot(floor: int, nen_unlock: int = 20, master_start: int = 90, boss_floor: int = 100) -> str:
    """خانات الخلفيات القديمة (V3) كي لا تضيع صورك المرفوعة عليها."""
    if floor >= boss_floor:
        return "bg_summit"
    if floor >= master_start:
        return "bg_temple"
    if floor >= 60:
        return "bg_nen"
    if floor >= nen_unlock:
        return "bg_arena"
    return "bg_street"


# ═════════════════════════════ الهوية الحالية (سياق) ═════════════════════════════
@dataclass(frozen=True)
class Ident:
    cmd: str                    # slug الأمر
    sub: str | None = None
    variant: int = 0            # أي صورة مرفوعة تُستخدم (ثابتة طوال تنفيذ الأمر)


_CUR: contextvars.ContextVar[Ident | None] = contextvars.ContextVar("arena_identity", default=None)


def use(command: str | None, sub: str | None = None, ident: Ident | None = None) -> Ident | None:
    """يضبط هوية الأمر الجاري (تنتقل تلقائياً إلى asyncio.to_thread). يعيدها أو None لأمر غير معروف."""
    if ident is not None:
        _CUR.set(ident)
        return ident
    spec = resolve(command)
    if spec is None:
        _CUR.set(None)
        return None
    if sub is not None and sub not in {k for k, _ in spec.subs}:
        sub = None
    ident = Ident(spec.slug, sub, _rotate(f"cmd:{spec.slug}", 64))
    _CUR.set(ident)
    return ident


def current() -> Ident | None:
    return _CUR.get()


def clear() -> None:
    _CUR.set(None)


def theme_of(ident: Ident | None) -> str:
    return _BY_SLUG[ident.cmd].theme if ident and ident.cmd in _BY_SLUG else "default"


# ═════════════════════════════ التناوب بلا تكرار ═════════════════════════════
_rot_lock = threading.Lock()
_rot_state: dict[str, int] = {}


def _rotate(slot: str, n: int) -> int:
    """رقم الصورة التالية لهذا المكان: تناوب دائري، لا تتكرر الصورة نفسها مرتين متتاليتين إن وُجد أكثر من واحدة.
    البداية تُحدَّد من اسم المكان (ثابتة) فلا يكون أول ظهور عشوائياً."""
    if n <= 1:
        return 0
    with _rot_lock:
        if slot not in _rot_state:
            _rot_state[slot] = int(hashlib.sha1(slot.encode()).hexdigest(), 16) % n
        else:
            _rot_state[slot] = (_rot_state[slot] + 1) % n
        return _rot_state[slot] % n


def pick(slot: str, files: list) -> object | None:
    """يختار من قائمة ملفات بالتناوب (انظر _rotate). يعيد None إن كانت القائمة فارغة."""
    return files[_rotate(slot, len(files))] if files else None


def pick_distinct(slot: str, files: list, used: set) -> object | None:
    """مثل pick لكن يتخطى ما استُخدم في الشاشة نفسها (used) إن أمكن — لعناصر متعددة في بطاقة واحدة."""
    if not files:
        return None
    for _ in range(len(files)):
        f = pick(slot, files)
        if f not in used:
            used.add(f)
            return f
    f = pick(slot, files)
    used.add(f)
    return f


def uploaded_files(slot: str) -> list[Path]:
    d = UPLOADS / slot
    if not d.is_dir():
        return []
    try:
        return sorted(p for p in d.iterdir() if p.suffix.lower() in STATIC_EXTS)
    except OSError:
        return []


# ═════════════════════════════ مفاتيح الفن (المكتبة) ═════════════════════════════
@dataclass(frozen=True)
class Art:
    key: str                   # مفتاح فريد: bg:climb / sub:help:p3 / floor:floor_05 ...
    folder: str                # مجلد داخل assets/identity
    fname: str                 # اسم الملف بلا امتداد
    motif: str
    theme: str
    label: str
    slot: str                  # خانة الرفع (assets/art/<slot>) في أمر «صور»
    word: str                  # الكلمة العربية لأمر «صور»
    group: str                 # مجموعة أمر «صور»
    hue: int = 0


def _hue_for(key: str) -> int:
    return int(hashlib.sha1(key.encode()).hexdigest()[:4], 16) % 41 - 20    # ±20°: يفرّق الأقسام المتشابهة بصرياً


def _build_registry() -> dict[str, Art]:
    reg: dict[str, Art] = {}

    def add(a: Art) -> None:
        assert a.key not in reg, a.key
        reg[a.key] = a

    for c in CMDS:
        grp = FAMILIES[c.family][0]
        add(Art(f"bg:{c.slug}", "backgrounds", f"cmd_{c.slug}", c.motif, c.theme, f"خلفية {c.ar}", f"bgs_{c.slug}", f"خلفية_{c.ar}", grp, _hue_for(c.slug)))
        for sk, sl in c.subs:
            k = f"sub:{c.slug}:{sk}"
            add(Art(k, "backgrounds", f"sub_{c.slug}_{sk}", _sub_motif(c, sk), c.theme, f"{c.ar} · {sl}", f"bgs_{c.slug}_{sk}", f"خلفية_{c.ar}_{sl}", grp, _hue_for(k)))
    for i, (lo, hi, motif, theme, hue) in enumerate(FLOOR_BANDS, 1):
        rng = f"{lo}" if lo == hi else f"{lo}-{hi}"
        add(Art(f"floor:floor_{i:02d}", "floors", f"floor_{i:02d}", motif, theme, f"طوابق {rng}", f"bg_floor_{i:02d}", f"خلفية_طوابق_{lo}_{hi}", "خلفيات الطوابق", hue))
    for k, (name, motif, theme) in ARENAS.items():
        add(Art(f"arena:{k}", "arenas", f"arena_{k}", motif, theme, name, f"bg_arena_{k}", f"خلفية_{name.replace(' ', '_')}", "ساحات القتال", _hue_for(k)))
    for k, (name, motif, theme) in BOSS_BG.items():
        add(Art(f"boss:{k}", "bosses", f"boss_{k}", motif, theme, f"خلفية زعيم {name}", f"bgb_{k}", f"خلفية_زعيم_{name}", "خلفيات الزعماء"))
    for k, (name, motif, theme) in EVENT_BG.items():
        add(Art(f"event:{k}", "events", f"event_{k}", motif, theme, f"حدث: {name}", f"ev_{k}", f"خلفية_حدث_{name.replace(' ', '_')}", "أحداث الطوابق", _hue_for(k)))
    for k, (name, theme) in NEN_TYPES.items():
        add(Art(f"nen:{k}", "nen", f"nen_{k}", "nen", theme, f"صورة النين: {name}", f"nenart_{k}", f"صورة_نين_{name}", "صور النين", _hue_for(k)))
    return reg


def _sub_motif(c: Spec, sk: str) -> str:
    """القوائم الفرعية تغيّر الزخرفة قليلاً عن الأمر الأم كي تكون لها خلفية مستقلة فعلاً."""
    if c.slug == "gang":
        return {"war": "swords", "deposit": "coins", "requests": "scroll", "kick": "spikes", "leave": "echo"}.get(sk, "banner")
    if c.slug == "help":
        return ("book", "tower", "swords", "nen", "crates", "cards", "gear", "flames", "banner", "spikes", "grid")[int(sk[1:]) % 11]
    if c.slug == "control":
        return {"week": "ledger", "all": "signal"}.get(sk, "grid")
    if c.slug == "boss":
        return "crown" if sk == "win" else "flames"
    if c.slug == "season":
        return "crown" if sk == "end" else "stars"
    return {"result": "stars"}.get(sk, c.motif)


REG: dict[str, Art] = _build_registry()


def groups() -> dict[str, str]:
    g = {name: icon for name, icon in FAMILIES.values()}
    g.update(EXTRA_GROUPS)
    return g


def slot_entries() -> dict[str, tuple[str, str, str]]:
    """خانات الرفع الجديدة لأمر «صور»: مفتاح: (الكلمة، الوصف، المجموعة). تُضاف إلى anime_images.SLOTS."""
    out: dict[str, tuple[str, str, str]] = {}
    for c in CMDS:
        grp = FAMILIES[c.family][0]
        out[f"cmd_{c.slug}"] = (f"صورة_{c.ar}", f"شارة/صورة أمر «{c.ar}»", grp)
    for a in REG.values():
        out[a.slot] = (a.word, a.label, a.group)
    return out


# ═════════════════════════════ الرسم الإجرائي ═════════════════════════════
def _hue(c: Color, deg: float) -> Color:
    h, s, v = colorsys.rgb_to_hsv(*(x / 255 for x in c))
    r, g, b = colorsys.hsv_to_rgb((h + deg / 360) % 1, s, v)
    return int(r * 255), int(g * 255), int(b * 255)


def _mix(a: Color, b: Color, t: float) -> Color:
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def _lt(c: Color, t: float = 0.4) -> Color:
    return _mix(c, (255, 255, 255), t)


def _dk(c: Color, t: float = 0.5) -> Color:
    return _mix(c, (0, 0, 0), t)


def _rgba(c: Color, a: int = 255) -> Color:
    return (c[0], c[1], c[2], a)


class _Paint:
    def __init__(self, theme: str, seed: int, hue: int = 0, w: int = BG_W, h: int = BG_H) -> None:
        top, bot, acc = (_hue(c, hue) for c in THEMES.get(theme, THEMES["tower"]))
        self.w, self.h = w, h
        self.rnd = random.Random(seed)
        g = Image.linear_gradient("L").resize((w, h))
        self.img = Image.composite(Image.new("RGB", (w, h), bot), Image.new("RGB", (w, h), top), g).convert("RGBA")
        self.top, self.bot, self.acc = top, bot, acc
        self.acc2 = _hue(acc, 38)
        self.lite = _lt(acc, 0.55)

    def layer(self):
        L = Image.new("RGBA", (self.w, self.h), (0, 0, 0, 0))
        return L, ImageDraw.Draw(L)

    def put(self, L: Image.Image, blur: float = 0) -> None:
        self.img.alpha_composite(L.filter(ImageFilter.GaussianBlur(blur)) if blur else L)

    def glow(self, x: float, y: float, r: float, col: Color | None = None, a: int = 110) -> None:
        col = col or self.acc
        size = max(8, int(r * 2))
        g = Image.radial_gradient("L").resize((size, size))
        g = g.point(lambda v: int(((255 - v) / 255) ** 2 * a))
        lay = Image.merge("RGBA", (Image.new("L", g.size, col[0]), Image.new("L", g.size, col[1]), Image.new("L", g.size, col[2]), g))
        X, Y = int(x - size / 2), int(y - size / 2)
        cx0, cy0, cx1, cy1 = max(0, X), max(0, Y), min(self.w, X + size), min(self.h, Y + size)
        if cx1 > cx0 and cy1 > cy0:
            self.img.alpha_composite(lay.crop((cx0 - X, cy0 - Y, cx1 - X, cy1 - Y)), (cx0, cy0))

    def finish(self, dim: float = 0.0) -> Image.Image:
        vig = Image.radial_gradient("L").resize((self.w, self.h)).point(lambda v: int(max(0, v - 105) * 1.25))
        self.img.alpha_composite(Image.merge("RGBA", (Image.new("L", (self.w, self.h), 0),) * 3 + (vig,)))
        if dim:
            self.img.alpha_composite(Image.new("RGBA", (self.w, self.h), (0, 0, 0, int(255 * dim))))
        return self.img.convert("RGB")


def _poly_glow(p: _Paint, pts, col: Color, a: int = 120, blur: float = 14) -> None:
    L, d = p.layer()
    d.polygon(pts, fill=_rgba(col, a))
    p.put(L, blur)


def _cog(d: ImageDraw.ImageDraw, cx: float, cy: float, r: float, teeth: int, fill, hole: float = 0.45, rot: float = 0.0) -> None:
    pts = []
    for i in range(teeth):
        a = rot + 2 * math.pi * i / teeth
        w1, w2 = math.pi / teeth * 0.58, math.pi / teeth * 0.34
        for da, rr in ((-w1, r * 0.8), (-w2, r), (w2, r), (w1, r * 0.8)):
            pts.append((cx + math.cos(a + da) * rr, cy + math.sin(a + da) * rr))
    d.polygon(pts, fill=fill)
    d.ellipse([cx - r * hole, cy - r * hole, cx + r * hole, cy + r * hole], fill=(0, 0, 0, 0))


def _silhouette(d: ImageDraw.ImageDraw, cx: float, base_y: float, h: float, fill) -> None:
    hr = h * 0.13
    d.ellipse([cx - hr, base_y - h, cx + hr, base_y - h + hr * 2], fill=fill)
    d.rounded_rectangle([cx - h * 0.2, base_y - h + hr * 2.1, cx + h * 0.2, base_y], radius=int(h * 0.12), fill=fill)


def _star(cx: float, cy: float, r1: float, r2: float, n: int = 5, rot: float = -math.pi / 2):
    return [(cx + math.cos(rot + math.pi * i / n) * (r1 if i % 2 == 0 else r2), cy + math.sin(rot + math.pi * i / n) * (r1 if i % 2 == 0 else r2)) for i in range(n * 2)]


def _windows(d, x0, y0, x1, y1, rnd, col, step=22, density=0.45) -> None:
    for yy in range(int(y0) + 10, int(y1) - 10, step):
        for xx in range(int(x0) + 8, int(x1) - 10, step):
            if rnd.random() < density:
                d.rectangle([xx, yy, xx + 8, yy + 11], fill=_rgba(col, rnd.randint(110, 230)))


# ── الأنماط (motifs): كل دالة ترسم على اللوحة p ──
def m_tower(p: _Paint) -> None:
    cx = p.w * 0.5 + p.rnd.uniform(-50, 50)
    p.glow(cx, p.h * 0.4, 360, p.acc, 95)
    L, d = p.layer()
    for i in range(3):   # أشعة من القمة
        a = p.rnd.uniform(-0.5, 0.5)
        d.polygon([(cx, 40), (cx + math.tan(a - 0.08) * 600, p.h), (cx + math.tan(a + 0.08) * 600, p.h)], fill=_rgba(p.lite, 26))
    p.put(L, 6)
    L, d = p.layer()
    y = p.h - 20
    for i in range(9):
        w = 230 - i * 17
        hh = 60
        d.rectangle([cx - w / 2, y - hh, cx + w / 2, y], fill=(12, 10, 32, 240), outline=_rgba(p.acc, 150), width=2)
        _windows(d, cx - w / 2, y - hh, cx + w / 2, y, p.rnd, p.lite, 24, 0.5)
        y -= hh - 4
    d.polygon([(cx - 30, y + 4), (cx + 30, y + 4), (cx, y - 90)], fill=(12, 10, 32, 240), outline=_rgba(p.lite, 200))
    d.rectangle([0, p.h - 26, p.w, p.h], fill=(6, 6, 18, 255))
    p.put(L)
    p.glow(cx, y - 90, 70, p.lite, 200)


def m_city(p: _Paint) -> None:
    p.glow(p.w * p.rnd.uniform(0.25, 0.75), p.h * 0.22, 260, p.acc, 100)
    for layer_i, (dark, hmin, hmax) in enumerate(((0.55, 150, 330), (0.72, 120, 280), (0.86, 90, 230))):
        L, d = p.layer()
        x = -20
        while x < p.w:
            w = p.rnd.randint(60, 120)
            hh = p.rnd.randint(hmin, hmax)
            col = _dk(_mix(p.top, p.acc, 0.25), dark)
            d.rectangle([x, p.h - hh, x + w, p.h], fill=_rgba(col, 255), outline=_rgba(p.acc, 40))
            _windows(d, x, p.h - hh, x + w, p.h, p.rnd, p.lite if layer_i == 2 else p.acc2, 20, 0.3 + 0.1 * layer_i)
            if p.rnd.random() < 0.3:
                d.rectangle([x + 10, p.h - hh - 18, x + w - 10, p.h - hh - 8], fill=_rgba(p.acc2, 200))   # لافتة نيون
            x += w + p.rnd.randint(-8, 14)
        p.put(L)


def m_arena(p: _Paint) -> None:
    p.glow(p.w / 2, p.h * 0.2, 300, p.lite, 70)
    L, d = p.layer()
    for sx in (0.2, 0.5, 0.8):
        sx += p.rnd.uniform(-0.06, 0.06)
        d.polygon([(p.w * sx, -10), (p.w * sx - 110, p.h * 0.8), (p.w * sx + 110, p.h * 0.8)], fill=_rgba(p.lite, 58))
    p.put(L, 8)
    L, d = p.layer()
    for i in range(7):   # مدرجات الجمهور
        y = 90 + i * 34
        for x in range(-10, p.w + 10, 17 - i):
            d.ellipse([x, y, x + 7, y + 7], fill=_rgba(_mix(p.acc, (255, 255, 255), p.rnd.random() * 0.5), p.rnd.randint(40, 120)))
    d.ellipse([-120, p.h * 0.55, p.w + 120, p.h + 160], fill=(30, 24, 40, 255), outline=_rgba(p.acc, 190), width=3)
    for k in range(1, 4):
        d.ellipse([-120 + k * 120, p.h * 0.55 + k * 30, p.w + 120 - k * 120, p.h + 160 - k * 30], outline=_rgba(p.acc, 90), width=2)
    p.put(L)


def m_nen(p: _Paint) -> None:
    cx, cy = p.w * 0.5, p.h * 0.5
    p.glow(cx, cy, 380, p.acc, 130)
    L, d = p.layer()
    for r in (95, 160, 230, 310):
        pts = [(cx + math.cos(math.pi / 3 * i + math.pi / 6) * r, cy + math.sin(math.pi / 3 * i + math.pi / 6) * r) for i in range(6)]
        d.polygon(pts, outline=_rgba(_lt(p.acc, 0.2), 170 - r // 3), width=3)
    for i in range(6):   # ألسنة هالة
        a = math.pi / 3 * i + p.rnd.uniform(-0.1, 0.1)
        d.polygon([(cx + math.cos(a - 0.14) * 100, cy + math.sin(a - 0.14) * 100), (cx + math.cos(a) * 420, cy + math.sin(a) * 420),
                   (cx + math.cos(a + 0.14) * 100, cy + math.sin(a + 0.14) * 100)], fill=_rgba(p.acc, 46))
    cols = [(255, 120, 60), (180, 90, 255), (70, 200, 130), (255, 210, 60), (70, 170, 255), (240, 70, 140)]
    for i, c in enumerate(cols):
        a = math.pi / 3 * i - math.pi / 2
        x, y = cx + math.cos(a) * 230, cy + math.sin(a) * 230
        d.ellipse([x - 16, y - 16, x + 16, y + 16], fill=_rgba(c, 235), outline=(255, 255, 255, 200), width=2)
    p.put(L)
    p.glow(cx, cy, 90, p.lite, 210)


def m_chains(p: _Paint) -> None:
    p.glow(p.w * 0.5, p.h * 0.55, 330, p.acc, 100)
    link = Image.new("RGBA", (74, 40), (0, 0, 0, 0))
    ImageDraw.Draw(link).rounded_rectangle([3, 3, 71, 37], radius=18, outline=_rgba(_lt(p.acc, 0.3), 235), width=7)
    link2 = Image.new("RGBA", (74, 40), (0, 0, 0, 0))
    ImageDraw.Draw(link2).rounded_rectangle([14, 6, 60, 34], radius=14, outline=_rgba(_dk(p.acc, 0.2), 235), width=6)
    for (x0, y0, x1, y1) in ((-40, 60, p.w + 40, p.h - 40), (p.w + 40, 90, -40, p.h - 90)):
        n = 22
        ang = math.degrees(math.atan2(y1 - y0, x1 - x0))
        for i in range(n):
            t = i / (n - 1)
            x, y = x0 + (x1 - x0) * t, y0 + (y1 - y0) * t + math.sin(t * math.pi * 2) * 14
            lk = (link if i % 2 == 0 else link2).rotate(-ang, expand=True, resample=Image.BICUBIC)
            p.img.alpha_composite(lk, (int(x - lk.width / 2), int(y - lk.height / 2)))
    L, d = p.layer()
    cx, cy = p.w / 2, p.h / 2
    d.ellipse([cx - 62, cy - 62, cx + 62, cy + 62], fill=(10, 4, 14, 240), outline=_rgba(p.lite, 240), width=4)
    d.ellipse([cx - 16, cy - 28, cx + 16, cy + 4], fill=_rgba(p.acc, 255))
    d.polygon([(cx - 10, cy), (cx + 10, cy), (cx + 18, cy + 36), (cx - 18, cy + 36)], fill=_rgba(p.acc, 255))
    p.put(L)


def m_cards(p: _Paint) -> None:
    p.glow(p.w / 2, p.h * 0.6, 330, p.acc, 80)
    cw, ch = 190, 280
    n = 5
    for i in range(n):
        card = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
        cd = ImageDraw.Draw(card)
        col = _hue(p.acc, (i - 2) * 24)
        cd.rounded_rectangle([0, 0, cw - 1, ch - 1], radius=18, fill=(14, 12, 38, 245), outline=_rgba(col, 255), width=4)
        cd.rounded_rectangle([14, 14, cw - 15, ch - 15], radius=12, outline=_rgba(col, 120), width=2)
        cd.polygon(_star(cw / 2, ch / 2, 56, 24), fill=_rgba(col, 235))
        rot = (i - 2) * 17
        r = card.rotate(-rot, expand=True, resample=Image.BICUBIC)
        px = p.w / 2 + (i - 2) * 118 - r.width / 2
        py = p.h * 0.62 - r.height / 2 + abs(i - 2) * 22
        p.img.alpha_composite(r, (int(px), int(py)))


def m_gear(p: _Paint) -> None:
    p.glow(p.w * 0.72, p.h * 0.7, 300, p.acc, 90)
    L, d = p.layer()
    _cog(d, p.w * 0.76, p.h * 0.72, 290, 14, _rgba(_dk(p.acc, 0.62), 245), 0.42, p.rnd.random())
    _cog(d, p.w * 0.2, p.h * 0.28, 170, 11, _rgba(_dk(p.acc, 0.7), 245), 0.4, p.rnd.random())
    _cog(d, p.w * 0.46, p.h * 0.12, 90, 9, _rgba(_dk(p.acc, 0.55), 245), 0.4, p.rnd.random())
    p.put(L)
    L, d = p.layer()
    for _ in range(46):   # شرر
        x, y = p.rnd.uniform(p.w * 0.3, p.w), p.rnd.uniform(p.h * 0.3, p.h)
        l = p.rnd.uniform(6, 26)
        a = p.rnd.uniform(-2.6, -0.5)
        d.line([(x, y), (x + math.cos(a) * l, y + math.sin(a) * l)], fill=_rgba(p.lite, p.rnd.randint(120, 240)), width=2)
    p.put(L)


def m_coins(p: _Paint) -> None:
    p.glow(p.w / 2, p.h * 0.7, 340, p.acc, 100)
    L, d = p.layer()
    for i in range(0, p.w + 80, 80):   # مظلة السوق
        d.polygon([(i, 0), (i + 80, 0), (i + 70, 70), (i - 10, 70)], fill=_rgba(p.acc if (i // 80) % 2 == 0 else _dk(p.acc, 0.6), 190))
    for _ in range(34):
        x, y, r = p.rnd.uniform(0, p.w), p.rnd.uniform(p.h * 0.35, p.h), p.rnd.uniform(22, 46)
        d.ellipse([x - r, y - r, x + r, y + r], fill=_rgba(_mix(p.acc, (255, 240, 170), 0.3), 240), outline=_rgba(_dk(p.acc, 0.3), 255), width=3)
        d.ellipse([x - r * 0.62, y - r * 0.62, x + r * 0.62, y + r * 0.62], outline=_rgba(_dk(p.acc, 0.35), 220), width=3)
    p.put(L)


def m_banner(p: _Paint) -> None:
    p.glow(p.w / 2, p.h * 0.45, 320, p.acc, 90)
    L, d = p.layer()
    xs = (0.16, 0.36, 0.64, 0.84)
    for i, sx in enumerate(xs):
        x, top, bw, bh = p.w * sx, -10, 96, 360 - (i % 2) * 70
        d.polygon([(x - bw / 2, top), (x + bw / 2, top), (x + bw / 2, top + bh), (x, top + bh - 50), (x - bw / 2, top + bh)], fill=_rgba(_dk(p.acc, 0.5), 240), outline=_rgba(p.lite, 200))
        d.polygon(_star(x, top + 120, 26, 11, 4), fill=_rgba(p.lite, 230))
    cx, cy = p.w / 2, p.h * 0.64
    d.ellipse([cx - 90, cy - 90, cx + 90, cy + 90], fill=(10, 8, 24, 240), outline=_rgba(p.lite, 230), width=5)
    for i in range(8):   # أرجل العنكبوت/الشعار
        a = math.pi / 4 * i + 0.2
        d.arc([cx - 150, cy - 150, cx + 150, cy + 150], math.degrees(a) - 8, math.degrees(a) + 8, fill=_rgba(p.lite, 220), width=5)
        d.line([(cx + math.cos(a) * 90, cy + math.sin(a) * 90), (cx + math.cos(a) * 150, cy + math.sin(a) * 150)], fill=_rgba(p.lite, 200), width=4)
    d.polygon([(cx, cy - 46), (cx + 34, cy), (cx, cy + 46), (cx - 34, cy)], fill=_rgba(p.acc, 255))
    p.put(L)


def m_scroll(p: _Paint) -> None:
    p.glow(p.w * 0.5, p.h * 0.5, 330, p.acc, 80)
    L, d = p.layer()
    x0, y0, x1, y1 = p.w * 0.22, 70, p.w * 0.78, p.h - 70
    d.rounded_rectangle([x0, y0, x1, y1], radius=22, fill=(24, 24, 50, 235), outline=_rgba(p.lite, 200), width=4)
    d.ellipse([x0 - 30, y0 - 20, x1 + 30, y0 + 24], fill=_rgba(_dk(p.acc, 0.45), 255), outline=_rgba(p.lite, 200), width=3)
    d.ellipse([x0 - 30, y1 - 24, x1 + 30, y1 + 20], fill=_rgba(_dk(p.acc, 0.45), 255), outline=_rgba(p.lite, 200), width=3)
    for i in range(6):
        y = y0 + 70 + i * 74
        d.rounded_rectangle([x0 + 90, y, x1 - 50 - p.rnd.randint(0, 120), y + 16], radius=8, fill=_rgba(p.lite, 150))
        d.rounded_rectangle([x0 + 40, y - 6, x0 + 72, y + 26], radius=6, outline=_rgba(p.acc, 230), width=3)
        if i % 2 == 0:
            d.line([(x0 + 46, y + 10), (x0 + 54, y + 20), (x0 + 68, y - 2)], fill=(110, 240, 150, 255), width=4)
    p.put(L)


def m_flames(p: _Paint) -> None:
    p.glow(p.w / 2, p.h * 0.85, 420, p.acc, 130)
    L, d = p.layer()
    for k, (a, dark) in enumerate(((120, 0.5), (170, 0.2), (220, -0.1))):
        x = -30
        while x < p.w + 30:
            w = p.rnd.randint(70, 150)
            hh = p.rnd.randint(150, 380) - k * 30
            col = _mix(p.acc, (255, 230, 150), max(0, -dark)) if dark < 0 else _dk(p.acc, dark)
            d.polygon([(x, p.h), (x + w * 0.2, p.h - hh * 0.55), (x + w * 0.5, p.h - hh), (x + w * 0.75, p.h - hh * 0.5), (x + w, p.h)], fill=_rgba(col, a))
            x += w * 0.6
    for _ in range(60):
        x, y = p.rnd.uniform(0, p.w), p.rnd.uniform(0, p.h)
        d.ellipse([x, y, x + 4, y + 4], fill=_rgba(p.lite, p.rnd.randint(80, 220)))
    p.put(L, 2)
    L, d = p.layer()
    for sx in (0, 1):   # قرنان
        bx = 40 if sx == 0 else p.w - 40
        s = 1 if sx == 0 else -1
        d.polygon([(bx, 20), (bx + s * 150, 120), (bx + s * 60, 90), (bx + s * 40, 260), (bx, 120)], fill=_rgba(_dk(p.acc, 0.7), 235), outline=_rgba(p.lite, 160))
    p.put(L)


def m_stars(p: _Paint) -> None:
    cx, cy = p.w / 2, p.h * 0.48
    p.glow(cx, cy, 380, p.acc, 120)
    L, d = p.layer()
    for i in range(20):
        a = math.pi * 2 * i / 20
        d.polygon([(cx, cy), (cx + math.cos(a) * 700, cy + math.sin(a) * 700), (cx + math.cos(a + 0.09) * 700, cy + math.sin(a + 0.09) * 700)], fill=_rgba(p.lite, 30))
    p.put(L, 2)
    L, d = p.layer()
    for _ in range(26):
        x, y, r = p.rnd.uniform(0, p.w), p.rnd.uniform(0, p.h), p.rnd.uniform(8, 34)
        d.polygon(_star(x, y, r, r * 0.42), fill=_rgba(_mix(p.acc, (255, 255, 255), p.rnd.random() * 0.6), p.rnd.randint(140, 245)))
    d.ellipse([cx - 110, cy - 110, cx + 110, cy + 110], fill=(20, 16, 44, 235), outline=_rgba(p.lite, 240), width=6)
    d.polygon(_star(cx, cy, 76, 32), fill=_rgba(p.acc, 255))
    p.put(L)


def m_grid(p: _Paint) -> None:
    p.glow(p.w * 0.7, p.h * 0.3, 300, p.acc, 70)
    L, d = p.layer()
    for i in range(-p.h * 2 // 60, p.w // 60 + 12):
        d.line([(i * 60, 0), (i * 60 + p.h * 0.58, p.h)], fill=_rgba(p.acc, 52), width=2)
        d.line([(i * 60 + p.h, 0), (i * 60 + p.h - p.h * 0.58, p.h)], fill=_rgba(p.acc, 52), width=2)
    for _ in range(9):
        x, y, r = p.rnd.uniform(60, p.w - 60), p.rnd.uniform(60, p.h - 60), p.rnd.uniform(34, 80)
        d.polygon([(x + math.cos(math.pi / 3 * k) * r, y + math.sin(math.pi / 3 * k) * r) for k in range(6)], outline=_rgba(p.lite, 120), width=3)
    y = p.rnd.uniform(120, p.h - 160)
    d.rectangle([0, y, p.w, y + 26], fill=_rgba(p.acc, 70))
    for i in range(7):
        d.rounded_rectangle([60, 90 + i * 70, 60 + p.rnd.randint(120, 420), 108 + i * 70], radius=8, fill=_rgba(p.lite, 80))
    p.put(L)


def m_forest(p: _Paint) -> None:
    p.glow(p.w * 0.72, p.h * 0.2, 150, p.lite, 200)
    L, d = p.layer()
    d.ellipse([p.w * 0.72 - 62, p.h * 0.2 - 62, p.w * 0.72 + 62, p.h * 0.2 + 62], fill=_rgba(_lt(p.acc, 0.7), 235))
    p.put(L)
    for dark, hmin, hmax, a in ((0.45, 200, 380, 230), (0.62, 160, 320, 240), (0.78, 120, 260, 250)):
        L, d = p.layer()
        x = -40
        while x < p.w + 40:
            w, hh = p.rnd.randint(70, 120), p.rnd.randint(hmin, hmax)
            col = _dk(_mix(p.top, p.acc, 0.3), dark)
            for k in range(4):
                yy = p.h - hh + k * hh * 0.22
                ww = w * (0.45 + 0.2 * k)
                d.polygon([(x + w / 2, yy), (x + w / 2 - ww / 2, yy + hh * 0.34), (x + w / 2 + ww / 2, yy + hh * 0.34)], fill=_rgba(col, a))
            d.rectangle([x + w / 2 - 6, p.h - hh * 0.2, x + w / 2 + 6, p.h], fill=_rgba(col, a))
            x += w * 0.7
        p.put(L)
    L, d = p.layer()
    d.rectangle([0, p.h * 0.7, p.w, p.h], fill=_rgba(p.acc, 28))
    p.put(L, 22)


def _blade(d, x0, y0, x1, y1, w, col, edge) -> None:
    a = math.atan2(y1 - y0, x1 - x0)
    nx, ny = -math.sin(a) * w, math.cos(a) * w
    d.polygon([(x0 + nx, y0 + ny), (x1, y1), (x0 - nx, y0 - ny)], fill=col, outline=edge)
    gx, gy = x0 + (x1 - x0) * 0.04, y0 + (y1 - y0) * 0.04
    d.line([(gx + nx * 2.4, gy + ny * 2.4), (gx - nx * 2.4, gy - ny * 2.4)], fill=edge, width=9)
    d.line([(x0, y0), (x0 - (x1 - x0) * 0.1, y0 - (y1 - y0) * 0.1)], fill=_dk(edge[:3], 0.4), width=10)


def m_swords(p: _Paint) -> None:
    cx, cy = p.w / 2, p.h / 2
    p.glow(cx, cy, 360, p.acc, 130)
    L, d = p.layer()
    _blade(d, cx - 360, p.h - 70, cx + 330, 70, 22, (210, 220, 245, 245), _rgba(p.lite, 255))
    _blade(d, cx + 360, p.h - 70, cx - 330, 70, 22, (190, 200, 235, 245), _rgba(p.lite, 255))
    for _ in range(14):
        a = p.rnd.uniform(0, math.tau)
        r1, r2 = p.rnd.uniform(40, 90), p.rnd.uniform(120, 260)
        d.line([(cx + math.cos(a) * r1, cy + math.sin(a) * r1), (cx + math.cos(a) * r2, cy + math.sin(a) * r2)], fill=_rgba(p.lite, 160), width=3)
    p.put(L)
    p.glow(cx, cy, 80, (255, 255, 255), 220)


def m_book(p: _Paint) -> None:
    cx, cy = p.w / 2, p.h * 0.58
    p.glow(cx, cy - 80, 360, p.acc, 110)
    L, d = p.layer()
    d.polygon([(cx - 10, cy - 130), (cx - 340, cy - 100), (cx - 340, cy + 150), (cx - 10, cy + 190)], fill=(238, 232, 214, 235), outline=_rgba(p.lite, 255))
    d.polygon([(cx + 10, cy - 130), (cx + 340, cy - 100), (cx + 340, cy + 150), (cx + 10, cy + 190)], fill=(230, 224, 206, 235), outline=_rgba(p.lite, 255))
    for i in range(8):
        for sgn in (-1, 1):
            y = cy - 80 + i * 29
            d.line([(cx + sgn * 40, y + 6), (cx + sgn * (300 - p.rnd.randint(0, 90)), y - 6 + (6 if sgn > 0 else 0))], fill=(60, 60, 90, 150), width=4)
    p.put(L)
    L, d = p.layer()
    for _ in range(30):
        x, y = cx + p.rnd.uniform(-300, 300), p.rnd.uniform(40, cy - 120)
        d.ellipse([x, y, x + 6, y + 6], fill=_rgba(p.lite, p.rnd.randint(100, 240)))
    p.put(L, 1)


def m_ledger(p: _Paint) -> None:
    p.glow(p.w * 0.6, p.h * 0.5, 320, p.acc, 80)
    L, d = p.layer()
    base = p.h - 70
    for i in range(10):
        h = 60 + i * 32 + p.rnd.randint(-30, 40)
        x = 110 + i * 82
        d.rounded_rectangle([x, base - h, x + 54, base], radius=8, fill=_rgba(_mix(p.acc, p.acc2, i / 10), 215), outline=_rgba(p.lite, 200), width=2)
    pts = [(110 + i * 82 + 27, base - (60 + i * 32) - 40 + p.rnd.randint(-26, 26)) for i in range(10)]
    d.line(pts, fill=(255, 255, 255, 235), width=5)
    for (x, y) in pts:
        d.ellipse([x - 9, y - 9, x + 9, y + 9], fill=_rgba(p.lite, 255))
    d.line([(80, base + 4), (p.w - 70, base + 4)], fill=_rgba(p.lite, 200), width=3)
    p.put(L)


def m_gift(p: _Paint) -> None:
    cx, cy = p.w / 2, p.h * 0.58
    p.glow(cx, cy, 340, p.acc, 120)
    L, d = p.layer()
    d.rounded_rectangle([cx - 150, cy - 40, cx + 150, cy + 210], radius=14, fill=_rgba(_dk(p.acc, 0.35), 245), outline=_rgba(p.lite, 255), width=4)
    d.rounded_rectangle([cx - 170, cy - 90, cx + 170, cy - 30], radius=12, fill=_rgba(_dk(p.acc, 0.15), 250), outline=_rgba(p.lite, 255), width=4)
    d.rectangle([cx - 22, cy - 90, cx + 22, cy + 210], fill=_rgba(p.lite, 240))
    d.ellipse([cx - 100, cy - 170, cx - 6, cy - 80], outline=_rgba(p.lite, 255), width=12)
    d.ellipse([cx + 6, cy - 170, cx + 100, cy - 80], outline=_rgba(p.lite, 255), width=12)
    for _ in range(70):
        x, y = p.rnd.uniform(0, p.w), p.rnd.uniform(0, p.h)
        d.rectangle([x, y, x + p.rnd.randint(5, 12), y + p.rnd.randint(5, 12)], fill=_rgba(_hue(p.acc, p.rnd.randint(-80, 80)), p.rnd.randint(120, 230)))
    p.put(L)


def m_portal(p: _Paint) -> None:
    cx, cy = p.w / 2, p.h / 2
    p.glow(cx, cy, 400, p.acc, 140)
    L, d = p.layer()
    for i in range(14):
        r = 330 - i * 21
        col = _hue(p.acc, i * 9)
        d.ellipse([cx - r, cy - r * 0.62, cx + r, cy + r * 0.62], outline=_rgba(col, 235 - i * 10), width=5)
    p.put(L)
    L, d = p.layer()
    d.ellipse([cx - 90, cy - 56, cx + 90, cy + 56], fill=(255, 255, 255, 235))
    p.put(L, 6)
    for i in range(5):
        card = Image.new("RGBA", (70, 100), (0, 0, 0, 0))
        ImageDraw.Draw(card).rounded_rectangle([0, 0, 69, 99], radius=9, fill=(14, 12, 38, 240), outline=_rgba(_hue(p.acc, i * 30), 255), width=3)
        r = card.rotate(p.rnd.randint(-40, 40), expand=True, resample=Image.BICUBIC)
        p.img.alpha_composite(r, (int(cx + (i - 2) * 150 - r.width / 2), int(cy - 150 - abs(i - 2) * 24 - r.height / 2)))


def m_crown(p: _Paint) -> None:
    cx = p.w / 2
    p.glow(cx, p.h * 0.36, 360, p.acc, 130)
    L, d = p.layer()
    base = p.h * 0.52
    d.polygon([(cx - 190, base), (cx - 190, base - 150), (cx - 110, base - 70), (cx - 60, base - 190), (cx, base - 90), (cx + 60, base - 190),
               (cx + 110, base - 70), (cx + 190, base - 150), (cx + 190, base)], fill=_rgba(_mix(p.acc, (255, 240, 160), 0.2), 250), outline=_rgba(p.lite, 255))
    for x, y in ((cx - 190, base - 150), (cx - 60, base - 190), (cx + 60, base - 190), (cx + 190, base - 150)):
        d.ellipse([x - 14, y - 14, x + 14, y + 14], fill=(235, 70, 90, 255), outline=(255, 255, 255, 220), width=2)
    for i, (dx, hh) in enumerate(((-220, 150), (0, 210), (220, 110))):
        d.rectangle([cx + dx - 100, p.h - hh, cx + dx + 100, p.h], fill=_rgba(_dk(p.acc, 0.55), 245), outline=_rgba(p.lite, 200), width=2)
    p.put(L)


def m_echo(p: _Paint) -> None:
    p.glow(p.w / 2, p.h * 0.55, 340, p.acc, 100)
    for i, (dx, a) in enumerate(((-250, 90), (-120, 130), (0, 250), (120, 130), (250, 90))):
        L, d = p.layer()
        _silhouette(d, p.w / 2 + dx, p.h - 40, 360 + (40 if i == 2 else 0), _rgba(_mix(p.acc, p.top, 0.7), a))
        p.put(L, 3 if i != 2 else 0)
    L, d = p.layer()
    d.ellipse([p.w / 2 - 36, p.h - 410, p.w / 2 + 36, p.h - 338], outline=_rgba(p.lite, 220), width=3)
    p.put(L)


def m_license(p: _Paint) -> None:
    p.glow(p.w / 2, p.h / 2, 340, p.acc, 90)
    L, d = p.layer()
    x0, y0, x1, y1 = 150, 130, p.w - 150, p.h - 130
    d.rounded_rectangle([x0, y0, x1, y1], radius=30, fill=(26, 20, 40, 238), outline=_rgba(p.lite, 255), width=5)
    d.rounded_rectangle([x0 + 40, y0 + 60, x0 + 260, y0 + 300], radius=18, fill=_rgba(_dk(p.acc, 0.6), 255), outline=_rgba(p.lite, 220), width=3)
    _silhouette(d, x0 + 150, y0 + 300, 190, _rgba(p.acc, 200))
    for i in range(5):
        d.rounded_rectangle([x0 + 300, y0 + 70 + i * 46, x1 - 70 - p.rnd.randint(0, 150), y0 + 90 + i * 46], radius=9, fill=_rgba(p.lite, 150))
    d.polygon(_star(x1 - 110, y1 - 80, 40, 17), fill=_rgba(p.acc, 255))
    d.rectangle([x0 + 20, y1 - 56, x1 - 180, y1 - 36], fill=_rgba(p.acc2, 120))
    p.put(L)


def m_ascend(p: _Paint) -> None:
    cx = p.w / 2
    p.glow(cx, p.h * 0.7, 360, p.acc, 120)
    L, d = p.layer()
    for i in range(6):
        y = p.h - 90 - i * 90
        w = 330 - i * 28
        d.polygon([(cx - w, y), (cx, y - 70), (cx + w, y), (cx + w - 56, y), (cx, y - 70 + 52), (cx - w + 56, y)], fill=_rgba(_mix(p.acc, p.lite, i / 7), 235 - i * 25))
    for _ in range(40):
        x, y = p.rnd.uniform(0, p.w), p.rnd.uniform(0, p.h)
        d.line([(x, y), (x, y - p.rnd.randint(12, 40))], fill=_rgba(p.lite, p.rnd.randint(60, 180)), width=3)
    p.put(L)


def m_crates(p: _Paint) -> None:
    p.glow(p.w / 2, p.h * 0.7, 340, p.acc, 90)
    L, d = p.layer()
    boxes = [(120, 440, 230), (380, 470, 190), (600, 420, 250), (300, 260, 170), (520, 240, 180), (700, 250, 140)]
    for (x, y, s) in boxes:
        d.rectangle([x, y, x + s, y + s * 0.8], fill=_rgba(_dk(p.acc, 0.55), 255), outline=_rgba(p.lite, 230), width=4)
        d.line([(x, y), (x + s, y + s * 0.8)], fill=_rgba(p.lite, 160), width=5)
        d.line([(x + s, y), (x, y + s * 0.8)], fill=_rgba(p.lite, 160), width=5)
        d.rectangle([x - 6, y + s * 0.34, x + s + 6, y + s * 0.46], fill=_rgba(_dk(p.acc, 0.3), 255))
    p.put(L)


def m_heal(p: _Paint) -> None:
    cx, cy = p.w / 2, p.h / 2
    p.glow(cx, cy, 380, p.acc, 130)
    L, d = p.layer()
    d.rounded_rectangle([cx - 52, cy - 170, cx + 52, cy + 170], radius=24, fill=_rgba(p.acc, 240), outline=(255, 255, 255, 230), width=4)
    d.rounded_rectangle([cx - 170, cy - 52, cx + 170, cy + 52], radius=24, fill=_rgba(p.acc, 240), outline=(255, 255, 255, 230), width=4)
    for _ in range(60):
        x, y, r = p.rnd.uniform(0, p.w), p.rnd.uniform(0, p.h), p.rnd.uniform(3, 10)
        d.ellipse([x - r, y - r, x + r, y + r], fill=_rgba(p.lite, p.rnd.randint(70, 200)))
    p.put(L)


def m_team(p: _Paint) -> None:
    p.glow(p.w / 2, p.h * 0.55, 340, p.acc, 100)
    L, d = p.layer()
    for i, (dx, hh) in enumerate(((-300, 330), (-105, 400), (105, 380), (300, 320))):
        _silhouette(d, p.w / 2 + dx, p.h - 30, hh, _rgba(_mix(p.acc, p.top, 0.25 + 0.1 * i), 235))
        d.ellipse([p.w / 2 + dx - 20, p.h - 30 - hh - 52, p.w / 2 + dx + 20, p.h - 30 - hh - 12], outline=_rgba(p.lite, 220), width=3)
    p.put(L)


def m_temple(p: _Paint) -> None:
    p.glow(p.w / 2, p.h * 0.42, 330, p.acc, 110)
    L, d = p.layer()
    d.polygon([(p.w / 2 - 70, p.h * 0.28), (p.w / 2 + 70, p.h * 0.28), (p.w / 2 + 90, p.h * 0.72), (p.w / 2 - 90, p.h * 0.72)], fill=_rgba(p.lite, 120))
    npil = p.rnd.choice((5, 6, 7, 8))
    step = (p.w - 140) / (npil - 1)
    for i in range(npil):
        x = 70 + i * step - 28
        d.rectangle([x, 150, x + 56, p.h - 90], fill=_rgba(_dk(p.acc, 0.55), 245), outline=_rgba(p.lite, 150), width=2)
        d.rectangle([x - 12, 126, x + 68, 156], fill=_rgba(_dk(p.acc, 0.4), 255), outline=_rgba(p.lite, 180), width=2)
        d.rectangle([x - 10, p.h - 96, x + 66, p.h - 76], fill=_rgba(_dk(p.acc, 0.4), 255))
    d.rectangle([40, 96, p.w - 40, 130], fill=_rgba(_dk(p.acc, 0.35), 255), outline=_rgba(p.lite, 200), width=3)
    for i in range(5):
        d.rectangle([60 - i * 14, p.h - 80 + i * 16, p.w - 60 + i * 14, p.h - 64 + i * 16], fill=_rgba(_dk(p.acc, 0.5 + i * 0.06), 255))
    p.put(L)


def m_summit(p: _Paint) -> None:
    p.glow(p.w / 2, p.h * 0.2, 400, p.lite, 150)
    L, d = p.layer()
    pts = [(-20, p.h), (120, 380), (240, 430), (380, 230), (470, 300), (p.w / 2, 120), (590, 300), (680, 220), (790, 400), (900, 340), (p.w + 20, p.h)]
    d.polygon(pts, fill=_rgba(_dk(_mix(p.top, p.acc, 0.2), 0.45), 255), outline=_rgba(p.lite, 160))
    d.polygon([(p.w / 2 - 70, 190), (p.w / 2, 120), (p.w / 2 + 70, 190), (p.w / 2 + 20, 176), (p.w / 2, 200), (p.w / 2 - 22, 176)], fill=_rgba(_lt(p.acc, 0.7), 245))
    p.put(L)
    L, d = p.layer()
    for _ in range(14):
        x, y = p.rnd.uniform(0, p.w), p.rnd.uniform(p.h * 0.5, p.h * 0.9)
        d.ellipse([x - 160, y - 28, x + 160, y + 28], fill=_rgba((255, 255, 255), 24))
    p.put(L, 18)
    p.glow(p.w / 2, 120, 70, (255, 255, 255), 230)


def m_ripples(p: _Paint) -> None:
    cx, cy = p.w / 2, p.h * 0.62
    p.glow(cx, cy, 380, p.acc, 100)
    L, d = p.layer()
    for i in range(9):
        r = 90 + i * 52
        d.ellipse([cx - r, cy - r * 0.34, cx + r, cy + r * 0.34], outline=_rgba(p.lite, max(20, 210 - i * 22)), width=3)
    d.polygon([(cx - 100, cy - 190), (cx + 100, cy - 190), (cx + 74, cy + 20), (cx - 74, cy + 20)], fill=(210, 235, 250, 60), outline=_rgba(p.lite, 230))
    d.ellipse([cx - 100, cy - 206, cx + 100, cy - 174], outline=_rgba(p.lite, 230), width=3)
    d.polygon([(cx, cy - 150), (cx + 52, cy - 60), (cx, cy - 20), (cx - 52, cy - 60)], fill=(110, 230, 140, 220))
    p.put(L)


def m_spikes(p: _Paint) -> None:
    p.glow(p.w / 2, p.h * 0.85, 400, p.acc, 100)
    L, d = p.layer()
    x = -20
    while x < p.w + 20:
        w, hh = p.rnd.randint(46, 90), p.rnd.randint(120, 330)
        d.polygon([(x, p.h), (x + w / 2, p.h - hh), (x + w, p.h)], fill=_rgba(_dk(p.acc, 0.6), 250), outline=_rgba(p.lite, 150))
        x += w * 0.78
    for i in range(0, p.w, 70):   # شريط تحذير
        d.polygon([(i, 0), (i + 35, 0), (i + 5, 36), (i - 30, 36)], fill=_rgba(p.acc, 190))
    p.put(L)


def m_signal(p: _Paint) -> None:
    ox, oy = p.w * 0.2, p.h * 0.78
    p.glow(ox, oy, 340, p.acc, 110)
    L, d = p.layer()
    for i in range(1, 9):
        r = i * 100
        d.arc([ox - r, oy - r, ox + r, oy + r], 270, 360, fill=_rgba(p.lite, max(30, 230 - i * 24)), width=5)
    for i in range(6):
        d.rounded_rectangle([p.w - 260 + i * 36, p.h - 90 - i * 46, p.w - 232 + i * 36, p.h - 70], radius=6, fill=_rgba(_mix(p.acc, p.acc2, i / 6), 220))
    p.put(L)


def m_bubble(p: _Paint) -> None:
    p.glow(p.w / 2, p.h / 2, 330, p.acc, 80)
    L, d = p.layer()
    for (x, y, w, h, a) in ((140, 120, 440, 190, 230), (400, 340, 460, 200, 215)):
        d.rounded_rectangle([x, y, x + w, y + h], radius=44, fill=_rgba(_dk(p.acc, 0.45), a), outline=_rgba(p.lite, 240), width=4)
        d.polygon([(x + 60, y + h - 2), (x + 30, y + h + 56), (x + 130, y + h - 2)], fill=_rgba(_dk(p.acc, 0.45), a), outline=_rgba(p.lite, 240))
        for i in range(3):
            d.rounded_rectangle([x + 50, y + 48 + i * 44, x + w - 50 - p.rnd.randint(0, 130), y + 66 + i * 44], radius=8, fill=_rgba(p.lite, 140))
    p.put(L)


def m_tree(p: _Paint) -> None:
    cx = p.w / 2
    p.glow(cx, p.h * 0.4, 360, p.acc, 100)
    L, d = p.layer()
    nodes = {"root": (cx, p.h - 90)}
    mids = [(cx - 250, p.h - 270), (cx, p.h - 290), (cx + 250, p.h - 270)]
    tops = [(cx - 330, p.h - 470), (cx - 170, p.h - 470), (cx - 80, p.h - 500), (cx + 80, p.h - 500), (cx + 170, p.h - 470), (cx + 330, p.h - 470)]
    for i, m in enumerate(mids):
        d.line([nodes["root"], m], fill=_rgba(p.lite, 200), width=6)
        for t in tops[i * 2:i * 2 + 2]:
            d.line([m, t], fill=_rgba(p.lite, 170), width=5)
    for (x, y), r in [(nodes["root"], 38)] + [(m, 30) for m in mids] + [(t, 24) for t in tops]:
        d.ellipse([x - r, y - r, x + r, y + r], fill=_rgba(_dk(p.acc, 0.5), 255), outline=_rgba(p.lite, 255), width=4)
        d.ellipse([x - r / 2, y - r / 2, x + r / 2, y + r / 2], fill=_rgba(p.acc, 255))
    p.put(L)


def m_medal(p: _Paint) -> None:
    cx, cy = p.w / 2, p.h * 0.58
    p.glow(cx, cy, 360, p.acc, 120)
    L, d = p.layer()
    d.polygon([(cx - 150, -10), (cx - 40, -10), (cx + 40, cy - 60), (cx - 70, cy - 60)], fill=_rgba(_dk(p.acc2, 0.25), 245))
    d.polygon([(cx + 150, -10), (cx + 40, -10), (cx - 40, cy - 60), (cx + 70, cy - 60)], fill=_rgba(_dk(p.acc, 0.15), 245))
    for r, a in ((170, 255), (140, 255), (112, 255)):
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=_rgba(_mix(p.acc, (255, 240, 170), 0.2 if r > 120 else 0.0), a), outline=_rgba(p.lite, 255), width=4)
    d.ellipse([cx - 96, cy - 96, cx + 96, cy + 96], fill=(24, 18, 46, 255))
    d.polygon(_star(cx, cy, 78, 32), fill=_rgba(p.lite, 255))
    p.put(L)


def m_shield(p: _Paint) -> None:
    cx, cy = p.w / 2, p.h / 2
    p.glow(cx, cy, 380, p.acc, 120)
    L, d = p.layer()
    for r, col, a in ((1, _dk(p.acc, 0.55), 250), (0.82, _dk(p.acc, 0.3), 255), (0.62, (22, 20, 46), 255)):
        w, h = 200 * r, 270 * r
        d.polygon([(cx - w, cy - h), (cx + w, cy - h), (cx + w, cy + h * 0.1), (cx, cy + h), (cx - w, cy + h * 0.1)], fill=_rgba(col, a), outline=_rgba(p.lite, 255), width=4)
    d.polygon(_star(cx, cy - 20, 80, 34), fill=_rgba(p.lite, 255))
    d.line([(cx, cy - 250), (cx, cy + 240)], fill=_rgba(p.lite, 120), width=3)
    p.put(L)


def m_anvil(p: _Paint) -> None:
    cx, cy = p.w * 0.5, p.h * 0.62
    p.glow(cx, cy - 60, 340, p.acc, 130)
    L, d = p.layer()
    d.polygon([(cx - 230, cy - 90), (cx + 170, cy - 90), (cx + 260, cy - 60), (cx + 170, cy - 30), (cx + 90, cy - 20), (cx + 60, cy + 50), (cx + 140, cy + 130),
               (cx + 170, cy + 190), (cx - 170, cy + 190), (cx - 140, cy + 130), (cx - 60, cy + 50), (cx - 90, cy - 20), (cx - 230, cy - 30)], fill=(30, 28, 50, 255), outline=_rgba(p.lite, 230))
    d.line([(cx - 200, cy - 82), (cx + 160, cy - 82)], fill=_rgba(p.lite, 255), width=5)
    d.line([(cx - 120, cy - 240), (cx + 60, cy - 120)], fill=(120, 80, 50, 255), width=18)
    d.polygon([(cx - 170, cy - 300), (cx - 90, cy - 330), (cx - 20, cy - 200), (cx - 100, cy - 170)], fill=(150, 160, 190, 255), outline=_rgba(p.lite, 255))
    for _ in range(50):
        x, y = cx + p.rnd.uniform(-60, 60), cy - 100 + p.rnd.uniform(-20, 10)
        a = p.rnd.uniform(-2.9, -0.2)
        l = p.rnd.uniform(20, 120)
        d.line([(x, y), (x + math.cos(a) * l, y + math.sin(a) * l)], fill=_rgba(p.lite, p.rnd.randint(120, 255)), width=3)
    p.put(L)


def m_fusion(p: _Paint) -> None:
    cx, cy = p.w / 2, p.h / 2
    p.glow(cx, cy, 400, p.acc, 150)
    L, d = p.layer()
    d.ellipse([cx - 280, cy - 140, cx + 20, cy + 160], outline=_rgba(p.acc, 255), width=10, fill=_rgba(p.acc, 55))
    d.ellipse([cx - 20, cy - 140, cx + 280, cy + 160], outline=_rgba(p.acc2, 255), width=10, fill=_rgba(p.acc2, 55))
    for i in range(14):
        a = math.pi * 2 * i / 14
        d.line([(cx, cy), (cx + math.cos(a) * 420, cy + math.sin(a) * 420)], fill=_rgba(p.lite, 50), width=3)
    p.put(L)
    p.glow(cx, cy + 10, 110, (255, 255, 255), 230)


def m_bigcard(p: _Paint) -> None:
    cx, cy = p.w / 2, p.h / 2
    p.glow(cx, cy, 380, p.acc, 130)
    cw, ch = 320, 470
    card = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    cd = ImageDraw.Draw(card)
    cd.rounded_rectangle([0, 0, cw - 1, ch - 1], radius=26, fill=(14, 12, 38, 250), outline=_rgba(p.lite, 255), width=6)
    cd.rounded_rectangle([20, 20, cw - 21, ch - 21], radius=18, outline=_rgba(p.acc, 160), width=3)
    cd.rounded_rectangle([40, 50, cw - 41, 300], radius=14, fill=_rgba(_dk(p.acc, 0.55), 255))
    cd.polygon(_star(cw / 2, 175, 84, 36), fill=_rgba(p.acc, 255))
    for i in range(4):
        cd.rounded_rectangle([44, 330 + i * 28, cw - 44 - (i % 2) * 60, 344 + i * 28], radius=6, fill=_rgba(p.lite, 140))
    for dx, ang in ((-210, 14), (210, -14)):
        sm = card.resize((cw * 2 // 3, ch * 2 // 3)).rotate(ang, expand=True, resample=Image.BICUBIC)
        sm.putalpha(sm.getchannel("A").point(lambda v: int(v * 0.5)))
        p.img.alpha_composite(sm, (int(cx + dx - sm.width / 2), int(cy + 40 - sm.height / 2)))
    r = card.rotate(-5, expand=True, resample=Image.BICUBIC)
    p.img.alpha_composite(r, (int(cx - r.width / 2), int(cy - r.height / 2)))


def m_stall(p: _Paint) -> None:
    p.glow(p.w / 2, p.h * 0.5, 360, p.acc, 100)
    L, d = p.layer()
    n = 10
    for i in range(n):
        x0, x1 = i * p.w / n, (i + 1) * p.w / n
        d.polygon([(x0, 40), (x1, 40), (x1, 150), ((x0 + x1) / 2, 180), (x0, 150)], fill=_rgba(p.acc if i % 2 == 0 else (240, 236, 220), 235))
    d.rectangle([60, 40, p.w - 60, 44], fill=_rgba(p.lite, 255))
    for sy in (330, 450):
        d.rectangle([90, sy, p.w - 90, sy + 14], fill=(70, 50, 40, 255))
        x = 110
        while x < p.w - 190:
            w = p.rnd.randint(50, 110)
            h = p.rnd.randint(40, 100)
            d.rounded_rectangle([x, sy - h, x + w, sy], radius=8, fill=_rgba(_hue(p.acc, p.rnd.randint(-50, 50)), 235), outline=_rgba(p.lite, 120), width=2)
            x += w + p.rnd.randint(14, 40)
    d.rectangle([60, 560, p.w - 60, p.h], fill=(40, 28, 24, 255), outline=_rgba(p.lite, 200), width=3)
    for lx in (220, 500, 780):
        d.line([(lx, 150), (lx, 230)], fill=_rgba(p.lite, 200), width=3)
        d.ellipse([lx - 22, 230, lx + 22, 280], fill=_rgba(p.lite, 255))
    p.put(L)
    for lx in (220, 500, 780):
        p.glow(lx, 255, 90, p.lite, 150)


def m_bag(p: _Paint) -> None:
    cx = p.w / 2
    p.glow(cx, p.h * 0.55, 360, p.acc, 100)
    L, d = p.layer()
    d.rounded_rectangle([cx - 170, 110, cx + 170, p.h - 70], radius=90, fill=_rgba(_dk(p.acc, 0.5), 255), outline=_rgba(p.lite, 230), width=5)
    d.pieslice([cx - 170, 110, cx + 170, 410], 180, 360, fill=_rgba(_dk(p.acc, 0.3), 255), outline=_rgba(p.lite, 230), width=5)
    d.rounded_rectangle([cx - 110, 360, cx + 110, 500], radius=30, fill=_rgba(_dk(p.acc, 0.35), 255), outline=_rgba(p.lite, 200), width=4)
    d.rectangle([cx - 16, 300, cx + 16, 350], fill=_rgba(p.lite, 255))
    d.arc([cx - 90, 40, cx + 90, 190], 180, 360, fill=_rgba(p.lite, 255), width=12)
    for sx in (-1, 1):
        d.arc([cx + sx * 210 - 70, 190, cx + sx * 210 + 70, 520], 90 if sx > 0 else 270, 270 if sx > 0 else 450, fill=_rgba(p.lite, 200), width=10)
    p.put(L)


def m_pulse(p: _Paint) -> None:
    p.glow(p.w / 2, p.h / 2, 380, p.acc, 90)
    L, d = p.layer()
    for i in range(1, 12):
        d.line([(i * 90, 0), (i * 90, p.h)], fill=_rgba(p.acc, 26), width=1)
    for j in range(1, 8):
        d.line([(0, j * 80), (p.w, j * 80)], fill=_rgba(p.acc, 26), width=1)
    pts, y0, x = [], p.h / 2, 0
    while x < p.w + 100:
        pts += [(x, y0), (x + 40, y0), (x + 55, y0 - 28), (x + 72, y0 + 34), (x + 92, y0 - 190 + p.rnd.randint(-30, 30)), (x + 112, y0 + 150), (x + 130, y0), (x + 190, y0)]
        x += 240
    d.line(pts, fill=_rgba(p.lite, 255), width=6, joint="curve")
    p.put(L)
    L, d = p.layer()
    d.line(pts, fill=_rgba(p.acc, 200), width=14)
    p.put(L, 10)


def m_frame(p: _Paint) -> None:
    p.glow(p.w / 2, p.h / 2, 360, p.acc, 70)
    L, d = p.layer()
    for (x, y, w, h) in ((90, 90, 330, 230), (460, 60, 250, 330), (750, 110, 190, 190), (130, 380, 220, 180), (400, 440, 340, 150), (780, 360, 170, 230)):
        d.rectangle([x, y, x + w, y + h], fill=_rgba(_dk(p.acc, 0.7), 255), outline=_rgba(p.lite, 240), width=6)
        d.rectangle([x + 14, y + 14, x + w - 14, y + h - 14], fill=_rgba(_mix(p.top, p.acc, 0.3), 255))
        d.polygon([(x + 14, y + h - 14), (x + w * 0.38, y + h * 0.4), (x + w * 0.58, y + h * 0.66), (x + w * 0.74, y + h * 0.5), (x + w - 14, y + h - 14)], fill=_rgba(_dk(p.acc, 0.35), 255))
        d.ellipse([x + w * 0.66, y + 26, x + w * 0.66 + 26, y + 52], fill=_rgba(p.lite, 255))
    p.put(L)


def m_palette(p: _Paint) -> None:
    cx, cy = p.w / 2, p.h / 2
    p.glow(cx, cy, 380, p.acc, 90)
    L, d = p.layer()
    d.ellipse([cx - 330, cy - 220, cx + 330, cy + 230], fill=(236, 226, 208, 245), outline=_rgba(p.lite, 255), width=5)
    d.ellipse([cx + 150, cy + 20, cx + 260, cy + 120], fill=(0, 0, 0, 0))
    for i in range(8):
        a = math.pi * 2 * i / 8 + 0.3
        x, y = cx + math.cos(a) * 210, cy + math.sin(a) * 120
        d.ellipse([x - 44, y - 44, x + 44, y + 44], fill=_rgba(_hue(p.acc, i * 45), 255), outline=(255, 255, 255, 200), width=3)
    d.line([(cx + 260, cy + 200), (cx + 400, cy - 150)], fill=(140, 90, 50, 255), width=16)
    d.polygon([(cx + 400, cy - 150), (cx + 420, cy - 220), (cx + 380, cy - 220)], fill=_rgba(p.acc2, 255))
    p.put(L)


def m_cycle(p: _Paint) -> None:
    cx, cy = p.w / 2, p.h / 2
    p.glow(cx, cy, 380, p.acc, 110)
    L, d = p.layer()
    for k, a0 in enumerate((20, 200)):
        d.arc([cx - 230, cy - 230, cx + 230, cy + 230], a0, a0 + 140, fill=_rgba(p.lite if k == 0 else p.acc2, 255), width=34)
        a = math.radians(a0 + 140)
        tx, ty = cx + math.cos(a) * 230, cy + math.sin(a) * 230
        tang = a + math.pi / 2
        d.polygon([(tx + math.cos(tang) * 70, ty + math.sin(tang) * 70), (tx + math.cos(a) * 62, ty + math.sin(a) * 62),
                   (tx - math.cos(a) * 62, ty - math.sin(a) * 62)], fill=_rgba(p.lite if k == 0 else p.acc2, 255))
    d.ellipse([cx - 60, cy - 60, cx + 60, cy + 60], outline=_rgba(p.lite, 200), width=5)
    p.put(L)


def m_exchange(p: _Paint) -> None:
    p.glow(p.w / 2, p.h / 2, 380, p.acc, 100)
    L, d = p.layer()
    for cx in (220, p.w - 220):
        d.ellipse([cx - 120, p.h / 2 - 120, cx + 120, p.h / 2 + 120], fill=_rgba(_mix(p.acc, (255, 240, 170), 0.25), 245), outline=_rgba(_dk(p.acc, 0.3), 255), width=6)
        d.ellipse([cx - 78, p.h / 2 - 78, cx + 78, p.h / 2 + 78], outline=_rgba(_dk(p.acc, 0.35), 230), width=5)
    for y, direction in ((p.h / 2 - 90, 1), (p.h / 2 + 90, -1)):
        x0, x1 = (350, 650) if direction > 0 else (650, 350)
        d.line([(x0, y), (x1 - direction * 36, y)], fill=_rgba(p.lite, 255), width=22)
        d.polygon([(x1, y), (x1 - direction * 64, y - 46), (x1 - direction * 64, y + 46)], fill=_rgba(p.lite, 255))
    p.put(L)


def m_lanterns(p: _Paint) -> None:
    L, d = p.layer()
    for i in range(9):
        x = 60 + i * 110 + p.rnd.randint(-20, 20)
        ln = p.rnd.randint(90, 260)
        d.line([(x, 0), (x, ln)], fill=_rgba(p.lite, 120), width=2)
        d.rounded_rectangle([x - 22, ln, x + 22, ln + 54], radius=12, fill=_rgba(_hue(p.acc, p.rnd.randint(-30, 30)), 240), outline=_rgba(p.lite, 255), width=2)
    x = 0
    while x < p.w:
        w, h = p.rnd.randint(120, 200), p.rnd.randint(130, 250)
        d.polygon([(x, p.h), (x, p.h - h), (x + w * 0.5, p.h - h - 40), (x + w, p.h - h), (x + w, p.h)], fill=(8, 6, 14, 255), outline=_rgba(p.acc, 80))
        x += w + p.rnd.randint(10, 50)
    p.put(L)
    for i in range(9):
        pass
    L, d = p.layer()
    for _ in range(9):
        x, y = p.rnd.uniform(40, p.w - 40), p.rnd.uniform(60, 300)
        d.ellipse([x - 70, y - 70, x + 70, y + 70], fill=_rgba(p.acc, 26))
    p.put(L, 22)


def m_demon(p: _Paint) -> None:
    cx, cy = p.w / 2, p.h * 0.55
    p.glow(cx, cy, 420, p.acc, 150)
    L, d = p.layer()
    for sx in (-1, 1):
        d.polygon([(cx + sx * 120, cy - 150), (cx + sx * 330, cy - 330), (cx + sx * 250, cy - 90), (cx + sx * 170, cy - 40)], fill=(20, 8, 16, 255), outline=_rgba(p.lite, 200))
    d.ellipse([cx - 190, cy - 190, cx + 190, cy + 210], fill=(14, 6, 14, 255), outline=_rgba(p.lite, 200), width=4)
    for sx in (-1, 1):
        d.polygon([(cx + sx * 40, cy - 40), (cx + sx * 150, cy - 90), (cx + sx * 130, cy - 20), (cx + sx * 50, cy + 10)], fill=_rgba(p.lite, 255))
    d.polygon([(cx - 100, cy + 100), (cx + 100, cy + 100), (cx + 70, cy + 190), (cx + 36, cy + 130), (cx, cy + 190), (cx - 36, cy + 130), (cx - 70, cy + 190)], fill=_rgba(p.acc, 220))
    p.put(L)
    for sx in (-1, 1):
        p.glow(cx + sx * 95, cy - 45, 46, (255, 240, 200), 230)


def m_halo(p: _Paint) -> None:
    cx, cy = p.w / 2, p.h / 2
    p.glow(cx, cy, 420, p.acc, 140)
    L, d = p.layer()
    for k in range(3):
        n, r0 = 24 - k * 6, 330 - k * 100
        for i in range(n):
            a = math.pi * 2 * i / n + k * 0.1
            d.polygon([(cx + math.cos(a - 0.07) * (r0 - 130), cy + math.sin(a - 0.07) * (r0 - 130)), (cx + math.cos(a) * r0, cy + math.sin(a) * r0),
                       (cx + math.cos(a + 0.07) * (r0 - 130), cy + math.sin(a + 0.07) * (r0 - 130))], fill=_rgba(_mix(p.acc, p.lite, k / 3), 150 + k * 30), outline=_rgba(p.lite, 120))
    for r in (70, 110):
        d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=_rgba(p.lite, 230), width=4)
    d.ellipse([cx - 40, cy - 40, cx + 40, cy + 40], fill=_rgba(p.lite, 255))
    p.put(L)


MOTIFS = {k[2:]: v for k, v in dict(globals()).items() if k.startswith("m_") and callable(v)}


def render_art(a: Art) -> Image.Image:
    """يرسم صورة المكان (1000×640 RGB) إجرائياً — حتمي: نفس المفتاح = نفس الصورة دائماً."""
    seed = int(hashlib.sha1(a.key.encode()).hexdigest()[:8], 16)
    p = _Paint(a.theme, seed, a.hue)
    MOTIFS.get(a.motif, m_tower)(p)
    return p.finish()


# ═════════════════════════════ مكتبة الملفات + التخزين المؤقت ═════════════════════════════
_dec_lock = threading.Lock()
_dec: "OrderedDict[str, Image.Image]" = OrderedDict()
DEC_MAX = 40



def _cache_get(key: str):
    with _dec_lock:
        im = _dec.get(key)
        if im is not None:
            _dec.move_to_end(key)
        return im


def _cache_put(key: str, im: Image.Image) -> None:
    with _dec_lock:
        _dec[key] = im
        _dec.move_to_end(key)
        while len(_dec) > DEC_MAX:
            _dec.popitem(last=False)


def lib_path(a: Art) -> Path:
    return LIB / a.folder / f"{a.fname}.jpg"


def generated(key: str, save: bool = True) -> Image.Image | None:
    """الصورة المولَّدة لمفتاح فن: من المكتبة على القرص، وإن غابت تُرسم وتُحفظ (إن أمكن الكتابة)."""
    a = REG.get(key)
    if a is None:
        return None
    hit = _cache_get("g:" + key)
    if hit is not None:
        return hit
    path = lib_path(a)
    im = None
    try:
        if path.is_file():
            im = Image.open(path).convert("RGB")
    except Exception as e:
        log.debug("مكتبة الهوية %s: %s", path, e)
    if im is None:
        im = render_art(a)
        if save:
            try:
                path.parent.mkdir(parents=True, exist_ok=True)
                im.save(path, "JPEG", quality=76, optimize=True)
            except OSError:
                pass
    _cache_put("g:" + key, im)
    return im


def _uploaded_image(slot: str, variant: int = 0) -> Image.Image | None:
    files = uploaded_files(slot)
    if not files:
        return None
    f = files[variant % len(files)]
    ck = f"u:{f}:{f.stat().st_mtime_ns}"
    hit = _cache_get(ck)
    if hit is not None:
        return hit
    try:
        im = Image.open(f)
        im.load()
        im = im.convert("RGB")
        im.thumbnail((1400, 1400))
    except Exception as e:
        log.debug("صورة مرفوعة تالفة %s: %s", f, e)
        return None
    _cache_put(ck, im)
    return im


def _fit(im: Image.Image, size: tuple[int, int]) -> Image.Image:
    from PIL import ImageOps
    return ImageOps.fit(im, size, Image.BILINEAR, centering=(0.5, 0.45))


def section_art_key(ident: Ident) -> list[str]:
    """مفاتيح الفن بالأولوية: الفرعي ثم الأمر."""
    keys = []
    if ident.sub:
        keys.append(f"sub:{ident.cmd}:{ident.sub}")
    keys.append(f"bg:{ident.cmd}")
    return keys


def section_backdrop(ident: Ident | None, size: tuple[int, int]) -> Image.Image | None:
    """خلفية القسم/القائمة الفرعية بحجم اللوحة: صورتك المرفوعة ← المولَّدة. لا ترفع استثناءً أبداً."""
    if ident is None:
        return None
    try:
        for k in section_art_key(ident):
            a = REG.get(k)
            if a is None:
                continue
            im = _uploaded_image(a.slot, ident.variant) or generated(k)
            if im is not None:
                return _fit(im, size)
    except Exception as e:     # الهوية ميزة تجميلية: لا تُسقط أي بطاقة
        log.debug("section_backdrop: %s", e)
    return None


_layer_lock = threading.Lock()
_layers: "OrderedDict[tuple, Image.Image]" = OrderedDict()
LAYER_MAX = 4


def section_layer(ident: Ident | None, size: tuple[int, int]) -> Image.Image | None:
    """طبقة RGBA جاهزة (خلفية القسم + تعتيم القراءة في دمجة واحدة) بحجم اللوحة، مخزّنة لآخر 4 أحجام: الرسم أسرع بكثير."""
    if ident is None:
        return None
    k = (ident.cmd, ident.sub, ident.variant, size)
    with _layer_lock:
        hit = _layers.get(k)
        if hit is not None:
            _layers.move_to_end(k)
            return hit
    bg = section_backdrop(ident, size)
    if bg is None:
        return None
    layer = Image.blend(Image.new("RGB", size, (6, 8, 22)), bg, 0.513).convert("RGBA")   # = خلفية 52% + تعتيم 33% مدموجين
    layer.putalpha(173)
    with _layer_lock:
        _layers[k] = layer
        while len(_layers) > LAYER_MAX:
            _layers.popitem(last=False)
    return layer


def art_bytes(key: str, variant: int | None = None) -> bytes | None:
    """صورة فن كـ JPEG bytes (مرفوعة تتقدم). للخلفيات التي يطلبها محرك القتال وغيره."""
    a = REG.get(key)
    if a is None:
        return None
    files = uploaded_files(a.slot)
    im = None
    if files:
        f = files[(variant if variant is not None else _rotate("art:" + key, len(files))) % len(files)]
        try:
            return f.read_bytes()
        except OSError:
            pass
    im = generated(key)
    if im is None:
        return None
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=85)
    return buf.getvalue()


def floor_art(floor: int, legacy_slot: str | None = None) -> bytes | None:
    """خلفية قتال الطابق: رفعتَها لفئة الطوابق الجديدة ← رفعتَها على الخانة القديمة (V3) ← المولَّدة."""
    key = f"floor:{floor_key(floor)}"
    a = REG[key]
    if not uploaded_files(a.slot) and legacy_slot:
        files = uploaded_files(legacy_slot)
        if files:
            f = pick("art:" + legacy_slot, files)
            try:
                return f.read_bytes()      # type: ignore[union-attr]
            except OSError:
                pass
    return art_bytes(key)


def slot_to_key(slot: str) -> str | None:
    """خانة رفع (مثل bg_floor_03 أو bgs_climb) ← مفتاح فن. None إن لم تكن من المكتبة."""
    for k, a in REG.items():
        if a.slot == slot:
            return k
    return None


# ═════════════════════════════ الشارات (صورة خاصة لكل أمر) ═════════════════════════════
def _emblem_img(spec: Spec, px: int) -> Image.Image:
    import shaping as sh
    S = px * 3
    top, bot, acc = (_hue(c, _hue_for(spec.slug)) for c in THEMES[spec.theme])
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    g = Image.radial_gradient("L").resize((S, S)).point(lambda v: 255 - v)
    fill = Image.composite(Image.new("RGBA", (S, S), _rgba(_lt(acc, 0.05), 255)), Image.new("RGBA", (S, S), _rgba(_dk(bot, 0.4), 255)), g.point(lambda v: int(v * 0.55)))
    m = Image.new("L", (S, S), 0)
    ImageDraw.Draw(m).ellipse([S * 0.06, S * 0.06, S * 0.94, S * 0.94], fill=255)
    im.paste(fill, (0, 0), m)
    d = ImageDraw.Draw(im)
    d.ellipse([S * 0.06, S * 0.06, S * 0.94, S * 0.94], outline=_rgba(_lt(acc, 0.25), 255), width=max(3, S // 28))
    d.ellipse([S * 0.14, S * 0.14, S * 0.86, S * 0.86], outline=_rgba(acc, 130), width=max(2, S // 70))
    icon = sh.icon_image(sh.icon_key(spec.emoji), int(S * 0.56))
    if icon is not None:
        im.alpha_composite(icon, ((S - icon.width) // 2, (S - icon.height) // 2))
    else:
        d.polygon(_star(S / 2, S / 2, S * 0.28, S * 0.12), fill=_rgba(acc, 255))
    return im.resize((px, px), Image.LANCZOS)


def emblem(ident_or_cmd, px: int = 56) -> Image.Image | None:
    """شارة الأمر (RGBA دائرية). صورتك المرفوعة للأمر (صور اضافة صورة_<الأمر>) تُقص دائرياً وتتقدم."""
    spec = ident_or_cmd if isinstance(ident_or_cmd, Spec) else (_BY_SLUG.get(ident_or_cmd.cmd) if isinstance(ident_or_cmd, Ident) else resolve(ident_or_cmd))
    if spec is None:
        return None
    ck = f"e:{spec.slug}:{px}"
    hit = _cache_get(ck)
    if hit is not None:
        return hit
    try:
        up = _uploaded_image(f"cmd_{spec.slug}", 0)
        if up is not None:
            S = px * 3
            sq = _fit(up, (S, S)).convert("RGBA")
            m = Image.new("L", (S, S), 0)
            ImageDraw.Draw(m).ellipse([S * 0.06, S * 0.06, S * 0.94, S * 0.94], fill=255)
            out = Image.new("RGBA", (S, S), (0, 0, 0, 0))
            out.paste(sq, (0, 0), m)
            ImageDraw.Draw(out).ellipse([S * 0.06, S * 0.06, S * 0.94, S * 0.94], outline=_rgba(_lt(THEMES[spec.theme][2], 0.2), 255), width=max(3, S // 28))
            im = out.resize((px, px), Image.LANCZOS)
        else:
            path = LIB / "emblems" / f"{spec.slug}.png"
            if path.is_file() and px <= 160:
                im = Image.open(path).convert("RGBA").resize((px, px), Image.LANCZOS)
            else:
                im = _emblem_img(spec, max(px, 160))
                try:
                    path.parent.mkdir(parents=True, exist_ok=True)
                    _emblem_img(spec, 160).save(path, "PNG", optimize=True)
                except OSError:
                    pass
                im = im.resize((px, px), Image.LANCZOS)
    except Exception as e:
        log.debug("emblem %s: %s", spec.slug, e)
        return None
    _cache_put(ck, im)
    return im


# ═════════════════════════════ صور احتياطية للسياقات والعتاد ═════════════════════════════
def hero_for_context(context: str, name: str | None = None) -> bytes | None:
    """صورة بطولية مولَّدة لسياق anime_images حين لا توجد صورة مرفوعة ولا مجلوبة (فئات النين لها صورها)."""
    if context in NEN_TYPES:
        return art_bytes(f"nen:{context}")
    cmd = CONTEXT_CMD.get(context)
    if context == "boss" and name:
        for k, (nm, *_r) in BOSS_BG.items():
            if k in re.sub(r"[^a-z]", "", name.lower()) or nm == name:
                return art_bytes(f"boss:{k}")
        return art_bytes("arena:boss")
    return art_bytes(f"bg:{cmd}") if cmd else None


def _medal(seed_key: str, emoji: str, rarity: int, size: int = 256) -> bytes:
    """ميدالية مولَّدة (خلفية ملوّنة حتمية + إطار + رمز كبير): لكل مفتاح لون ونمط مختلف."""
    import shaping as sh
    seed = int(hashlib.sha1(seed_key.encode()).hexdigest()[:6], 16)
    rar = ((154, 166, 182), (59, 156, 255), (176, 92, 255), (255, 176, 46))[max(0, min(3, rarity))]
    hue = seed % 90 - 45
    base, acc = _hue((20, 18, 44), hue), _hue(rar, hue // 3)
    g = Image.radial_gradient("L").resize((size, size))
    im = Image.composite(Image.new("RGBA", (size, size), _rgba(_dk(base, 0.2))), Image.new("RGBA", (size, size), _rgba(_mix(base, acc, 0.45))), g)
    rnd = random.Random(seed)
    d = ImageDraw.Draw(im, "RGBA")
    for _ in range(9):
        x, y, r = rnd.uniform(0, size), rnd.uniform(0, size), rnd.uniform(14, 60)
        d.ellipse([x - r, y - r, x + r, y + r], outline=_rgba(acc, rnd.randint(40, 110)), width=2)
    d.rounded_rectangle([5, 5, size - 6, size - 6], radius=size // 9, outline=_rgba(acc, 255), width=6)
    icon = sh.icon_image(sh.icon_key(emoji), int(size * 0.58))
    if icon is not None:
        im.alpha_composite(icon, ((size - icon.width) // 2, (size - icon.height) // 2))
    buf = io.BytesIO()
    im.convert("RGB").save(buf, "JPEG", quality=88)
    return buf.getvalue()


def gear_medal(slot: str, emoji: str, rarity: int, size: int = 256) -> bytes:
    """صورة مولَّدة لقطعة عتاد لم تُجلب لها صورة (لكل قطعة لون ونمط مختلف)، بدل الرمز الأجرد."""
    return _medal("gear:" + slot, emoji, rarity, size)


_ability_cache: dict[str, bytes] = {}


def ability_art(key: str, emoji: str, size: int = 192) -> bytes:
    """صورة خاصة لكل قدرة هاتسو (مخزّنة في المكتبة assets/identity/hatsu/<key>.jpg)."""
    hit = _ability_cache.get(key)
    if hit is not None:
        return hit
    path = LIB / "hatsu" / f"{re.sub(r'[^a-z0-9_]', '', key.lower())}.jpg"
    try:
        if path.is_file():
            data = path.read_bytes()
            _ability_cache[key] = data
            return data
    except OSError:
        pass
    data = _medal("hatsu:" + key, emoji, 2 + int(hashlib.sha1(key.encode()).hexdigest()[:2], 16) % 2, size)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    except OSError:
        pass
    _ability_cache[key] = data
    return data


# ═════════════════════════════ فحص التغطية والجودة ═════════════════════════════
def audit(command_names: Iterable[str] = (), help_pages: int | None = None, build: bool = True) -> dict:
    """تقرير: أوامر بلا هوية، مفاتيح فن بلا صورة، صور مكررة، وعدم تطابق الشرح. build=True يولّد المكتبة الناقصة."""
    names = list(command_names)
    rep: dict = {"commands": len(names), "no_identity": [n for n in names if resolve(n) is None],
                 "unused_specs": sorted(set(c.ar for c in CMDS) - set(names)) if names else [],
                 "missing_art": [], "missing_emblem": [], "duplicates": [], "art_total": len(REG)}
    seen: dict[str, str] = {}
    for k, a in REG.items():
        im = generated(k, save=build)
        if im is None:
            rep["missing_art"].append(k)
            continue
        h = hashlib.sha1(im.resize((64, 40)).tobytes()).hexdigest()
        if h in seen:
            rep["duplicates"].append((seen[h], k))
        seen[h] = k
    for c in CMDS:
        if emblem(c, 56) is None:
            rep["missing_emblem"].append(c.slug)
    if help_pages is not None:
        rep["help_mismatch"] = help_pages != len(HELP_SUBS)
    rep["ok"] = not (rep["no_identity"] or rep["missing_art"] or rep["missing_emblem"] or rep["duplicates"] or rep.get("help_mismatch"))
    return rep


def build_library(force: bool = False) -> int:
    """يبني كل ملفات المكتبة (خلفيات + شارات). يعيد عدد الملفات المكتوبة."""
    n = 0
    for k, a in REG.items():
        p = lib_path(a)
        if force or not p.is_file():
            p.parent.mkdir(parents=True, exist_ok=True)
            render_art(a).save(p, "JPEG", quality=76, optimize=True)
            _dec.pop("g:" + k, None)
            n += 1
    for c in CMDS:
        p = LIB / "emblems" / f"{c.slug}.png"
        if force or not p.is_file():
            p.parent.mkdir(parents=True, exist_ok=True)
            _emblem_img(c, 160).save(p, "PNG", optimize=True)
            n += 1
    try:       # صور قدرات الهاتسو
        import hatsu as ht
        for k, v in ht.HATSU.items():
            f = LIB / "hatsu" / f"{re.sub(r'[^a-z0-9_]', '', k.lower())}.jpg"
            if force or not f.is_file():
                _ability_cache.pop(k, None)
                if force and f.is_file():
                    f.unlink()
                ability_art(k, v["emoji"])
                n += 1
    except Exception as e:
        log.debug("hatsu art: %s", e)
    return n
