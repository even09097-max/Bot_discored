"""
بطاقات الشخصيات (هنتر × هنتر): القائمة، الإحصائيات، الاستدعاء، النجوم، وتأثير الفريق.

لا يعتمد على discord ولا على قاعدة البيانات (لذلك يُختبر مباشرة).
كل بطاقة: ندرة (0 عادي … 3 أسطوري) + دور في القتال (مهاجم/حامٍ/معالج/مسيطر) + مهارة نداء.
صور البطاقات تُجلب من الإنترنت وقت التشغيل (انظر anime_images.py → ImageHub.card_art) ولا تُرسم في الكود.
"""
from __future__ import annotations

import random
import re
import unicodedata

# ───────────────────────── الضبط ─────────────────────────
SUMMON_GEM_COST = 10
SUMMON_GOLD_COST = 600
SUMMON_PITY = 30                   # ضمان بطاقة ملحمية أو أعلى كل 30 استدعاء
SUMMON_WEIGHTS = [58, 30, 10, 2]   # عادي / نادر / ملحمي / أسطوري
MAX_STARS = 5
STAR_BONUS = 0.12                  # +12% من إحصائيات البطاقة لكل نجمة
TEAM_SIZE = 3
ASSIST_COOLDOWN = 3                # جولات بين كل «نداء فريق»
DUPLICATE_REFUND = [40, 120, 400, 1500]   # ذهب مقابل نسخة زائدة بعد اكتمال النجوم

RARITY_AR = ["عادي", "نادر", "ملحمي", "أسطوري"]

ROLES = {
    "striker": {"ar": "مهاجم", "emoji": "⚔️", "desc": "يوجّه ضربة قوية للخصم"},
    "tank": {"ar": "حامٍ", "emoji": "🛡️", "desc": "يمنحك درعاً يمتص الضرر"},
    "healer": {"ar": "معالج", "emoji": "💚", "desc": "يعالجك أثناء القتال"},
    "controller": {"ar": "مسيطر", "emoji": "🌀", "desc": "قد يشلّ الخصم دوراً كاملاً"},
}

# إحصائيات البطاقة الأساسية حسب الندرة (قبل تعديل الدور والنجوم)
BASE_STATS = {
    "atk": [2, 5, 10, 18],
    "def": [1, 3, 6, 11],
    "hp": [10, 25, 55, 100],
    "speed": [1, 2, 4, 7],
}
ROLE_MULT = {
    "striker": {"atk": 1.30, "def": 0.80, "hp": 0.90, "speed": 1.00},
    "tank": {"atk": 0.80, "def": 1.50, "hp": 1.30, "speed": 0.80},
    "healer": {"atk": 0.80, "def": 1.00, "hp": 1.25, "speed": 1.00},
    "controller": {"atk": 0.90, "def": 0.90, "hp": 0.90, "speed": 1.40},
}
# قوة «نداء الفريق» لكل ندرة
ASSIST_STRIKE = [0.35, 0.55, 0.85, 1.25]     # × هجوم اللاعب
ASSIST_HEAL = [0.05, 0.08, 0.12, 0.18]        # من الصحة القصوى
ASSIST_STUN = [0.30, 0.45, 0.60, 0.80]        # احتمال الشلل
ASSIST_SHIELD_TURNS = [1, 2, 2, 3]

# (المفتاح، الاسم العربي، اسم الويكي الإنجليزي، الندرة، الدور، فئة النين، مهارة النداء، أسماء مختصرة للبحث)
_ROWS = [
    # أسطوري
    ("gon", "غون فريكس", "Gon Freecss", 3, "striker", "enhancer", "جانكن قبضة الصخرة", ["غون", "gon"]),
    ("killua", "كيلوا زولديك", "Killua Zoldyck", 3, "striker", "transmuter", "سرعة الإله", ["كيلوا", "killua"]),
    ("hisoka", "هيسوكا مورو", "Hisoka Morow", 3, "controller", "transmuter", "علكة الحب", ["هيسوكا", "hisoka"]),
    ("netero", "إيزاك نتيرو", "Isaac Netero", 3, "tank", "enhancer", "بوذا ذو الألف يد", ["نتيرو", "netero"]),
    ("meruem", "ميروم", "Meruem", 3, "striker", None, "ملك النمل", ["ميروم", "meruem"]),
    ("chrollo", "كروللو لوسيلفر", "Chrollo Lucilfer", 3, "controller", "specialist", "سارق المهارات", ["كروللو", "كوركو", "chrollo"]),
    # ملحمي
    ("kurapika", "كورابيكا", "Kurapika", 2, "controller", "conjurer", "سلسلة الحبس", ["كورابيكا", "kurapika"]),
    ("illumi", "إلومي زولديك", "Illumi Zoldyck", 2, "controller", "manipulator", "دبابيس التحكم", ["ايلومي", "إلومي", "illumi"]),
    ("neferpitou", "نفرفيتو", "Neferpitou", 2, "healer", None, "الدمية المعالجة", ["نفرفيتو", "neferpitou"]),
    ("kite", "كايت", "Kite", 2, "striker", "conjurer", "المنجل الحارس", ["كايت", "كيتي", "kite"]),
    ("biscuit", "بيسكي كروجر", "Biscuit Krueger", 2, "tank", "transmuter", "تدريب الأستاذة", ["بيسكي", "biscuit"]),
    ("silva", "سيلفا زولديك", "Silva Zoldyck", 2, "tank", "enhancer", "ربّ العائلة", ["سيلفا", "silva"]),
    ("feitan", "فيتان", "Feitan Portor", 2, "striker", "transmuter", "شمس الجحيم", ["فيتان", "feitan"]),
    ("ging", "جينغ فريكس", "Ging Freecss", 2, "striker", None, "صائد الأساطير", ["جينغ", "جنج", "ging"]),
    ("zeno", "زينو زولديك", "Zeno Zoldyck", 2, "striker", "transmuter", "التنين الأسود", ["زينو", "zeno"]),
    # نادر
    ("leorio", "ليورو", "Leorio Paradinight", 1, "healer", "emitter", "الطبيب المتدرّب", ["ليورو", "leorio"]),
    ("wing", "وينغ", "Wing", 1, "tank", "enhancer", "درس الأستاذ", ["وينغ", "ونج", "wing"]),
    ("machi", "ماتشي", "Machi Komacine", 1, "controller", "transmuter", "خيوط الغزل", ["ماتشي", "machi"]),
    ("nobunaga", "نوبوناغا", "Nobunaga Hazama", 1, "striker", "enhancer", "قطع السيف", ["نوبوناغا", "nobunaga"]),
    ("pakunoda", "باكونودا", "Pakunoda", 1, "controller", "emitter", "قراءة الذاكرة", ["باكونودا", "pakunoda"]),
    ("shalnark", "شالنارك", "Shalnark", 1, "controller", "manipulator", "إبرة التحكم", ["شالنارك", "shalnark"]),
    ("knuckle", "ناكل", "Knuckle Bine", 1, "striker", "emitter", "القبضة المرسلة", ["ناكل", "knuckle"]),
    ("morel", "موريل", "Morel Mackernasey", 1, "controller", "conjurer", "غليون الدخان", ["موريل", "morel"]),
    ("shoot", "شووت", "Shoot McMahon", 1, "tank", "conjurer", "الحاجز الصلب", ["شووت", "shoot"]),
    # عادي
    ("kastro", "كاسترو", "Kastro", 0, "striker", "conjurer", "الظل المنقسم", ["كاسترو", "kastro"]),
    ("zushi", "زوشي", "Zushi", 0, "striker", None, "ضربة التلميذ", ["زوشي", "zushi"]),
    ("pokkle", "بوكل", "Pokkle", 0, "striker", None, "سهم الصيّاد", ["بوكل", "pokkle"]),
    ("menchi", "مينتشي", "Menchi", 0, "controller", None, "حكم الطاهية", ["مينتشي", "menchi"]),
    ("satotz", "ساتوتس", "Satotz", 0, "tank", None, "المرشد الصامت", ["ساتوتس", "satotz"]),
    ("tonpa", "تونبا", "Tonpa", 0, "controller", None, "خدعة المخضرم", ["تونبا", "tonpa"]),
    ("cheadle", "تشيدل", "Cheadle Yorkshire", 0, "healer", None, "إسعاف الجمعية", ["تشيدل", "cheadle"]),
]

CARDS: dict[str, dict] = {}
for _k, _ar, _en, _r, _role, _nen, _skill, _al in _ROWS:
    CARDS[_k] = {"key": _k, "name": _ar, "en": _en, "r": _r, "role": _role, "nen": _nen, "skill": _skill, "aliases": _al}
ORDER = list(CARDS)     # ترتيب العرض: الأعلى ندرة أولاً (كما في _ROWS)

_DIAC = re.compile(r"[\u0610-\u061A\u064B-\u065F\u0670\u0640]")
_MAP = str.maketrans({"أ": "ا", "إ": "ا", "آ": "ا", "ى": "ي", "ة": "ه", "ؤ": "و", "ئ": "ي"})


def norm(s: str) -> str:
    s = unicodedata.normalize("NFKC", s or "")
    return _DIAC.sub("", s).translate(_MAP).strip().lower()


def find(text: str) -> dict | None:
    """يبحث عن بطاقة بالاسم العربي أو الإنجليزي أو الاسم المختصر (يقبل جزءاً من الاسم)."""
    q = norm(text)
    if not q:
        return None
    best = None
    for c in CARDS.values():
        names = [norm(c["name"]), norm(c["en"]), *[norm(a) for a in c["aliases"]]]
        if q in names:
            return c
        if best is None and any(q in n or (len(n) > 2 and n in q) for n in names):
            best = c
    return best


def by_rarity(r: int) -> list[dict]:
    return [c for c in CARDS.values() if c["r"] == r]


# ───────────────────────── الإحصائيات ─────────────────────────
def stars_for(copies: int) -> int:
    """عدد النجوم من عدد النسخ: النسخة الأولى 0 نجوم، وكل نسخة إضافية نجمة حتى 5."""
    return max(0, min(MAX_STARS, copies - 1))


def card_stats(key: str, stars: int = 0) -> dict[str, int]:
    c = CARDS[key]
    mult = 1 + STAR_BONUS * stars
    return {s: max(1, round(BASE_STATS[s][c["r"]] * ROLE_MULT[c["role"]][s] * mult)) for s in BASE_STATS}


def team_bonus(cards: list[tuple[str, int]]) -> dict[str, int]:
    """مجموع إحصائيات الفريق التي تُضاف سلبياً للاعب. cards = [(المفتاح، عدد النسخ)]."""
    tot = {s: 0 for s in BASE_STATS}
    for key, copies in cards:
        if key in CARDS:
            for s, v in card_stats(key, stars_for(copies)).items():
                tot[s] += v
    return tot


def team_fighters(cards: list[tuple[str, int]]) -> list[dict]:
    """وصف مختصر لأعضاء الفريق يحمله المقاتل في المعركة (للنداء والعرض)."""
    out = []
    for key, copies in cards:
        c = CARDS.get(key)
        if c:
            out.append({"key": key, "name": c["name"], "r": c["r"], "role": c["role"], "skill": c["skill"],
                        "stars": stars_for(copies)})
    return out


def assist_power(member: dict) -> float:
    """مضاعف قوة نداء البطاقة بحسب نجومها."""
    return 1 + 0.10 * member["stars"]


# ───────────────────────── الاستدعاء ─────────────────────────
def roll_card(pity: int, rng: random.Random) -> tuple[dict, int]:
    """يستدعي بطاقة. يعيد (البطاقة، عداد الضمان الجديد)."""
    if pity + 1 >= SUMMON_PITY:
        r = rng.choices([2, 3], [85, 15])[0]
    else:
        r = rng.choices([0, 1, 2, 3], SUMMON_WEIGHTS)[0]
    card = rng.choice(by_rarity(r))
    return card, (0 if r >= 2 else pity + 1)


def drop_rate(r: int) -> str:
    total = sum(SUMMON_WEIGHTS)
    return f"{SUMMON_WEIGHTS[r] * 100 / total:.0f}%"
