"""
بوت «برج المعارك» (Heavens Arena) — أوامر عربية بكلمة واحدة، تعمل بالسلاش «/صعود» أو بالكتابة المباشرة «صعود» بدون أي علامة.
كل الواجهات صور مرسومة (قتال، ملف، حقيبة، سحب، زعيم...) وصور الأنمي تُجلب تلقائياً حسب السياق.

التشغيل:
    pip install -r requirements.txt
    ضع التوكن في ملف .env  (DISCORD_TOKEN=...)
    python bot.py
"""
from __future__ import annotations

import asyncio
import io
import logging
import os
import random
import re
import sys
import time
import unicodedata
from pathlib import Path

import discord
from discord import app_commands
from discord.ext import tasks

import cards as cd
import game as g
import hatsu as ht
import identity as idn
import render as R
import render2 as R2
import anime_images as A
import shaping as sh
from anime_images import ImageHub, fetch_bytes
from database import TZ_OFFSET_H, Database
from game import GameError

log = logging.getLogger("arena")
DUEL_COOLDOWN = 60  # ثانية
TEXT_CD = 1.2       # ثواني بين أوامر الكتابة لنفس اللاعب
ANNOUNCE_KINDS = [("all", "الكل"), ("floor", "الصعود"), ("level", "المستوى"), ("boss", "الزعماء"), ("gacha", "السحب"), ("war", "الحروب"),
                  ("event", "الأحداث")]
GACHA_ANNOUNCE_MIN_RARITY = 3   # أسطوري فقط


def load_env(path: str = ".env") -> None:
    """قارئ .env بسيط (بدون مكتبات إضافية)."""
    p = Path(path)
    if not p.exists():
        return
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


# ═════════════════════════ أدوات مساعدة ═════════════════════════
_TASHKEEL = re.compile("[ً-ٰٟـ]")
_NON_WORD = re.compile(r"[^\w]+", re.UNICODE)


def norm(s: str) -> str:
    """توحيد الكتابة العربية للمطابقة (تشكيل، همزات، ياء/ألف مقصورة، تاء مربوطة)."""
    s = _TASHKEEL.sub("", unicodedata.normalize("NFKC", s)).lower().strip()
    return s.translate(str.maketrans("أإآٱىة", "اااايه"))


def strip_al(w: str) -> str:
    return w[2:] if w.startswith("ال") and len(w) > 3 else w


def dname(user) -> str:
    """اسم صالح للرسم: يزيل الزخارف والرموز التي يظهرها الخط مربعات."""
    return (sh.clean(getattr(user, "display_name", "") or getattr(user, "name", "") or "").strip() or "لاعب")[:24]


def _fx(evs: list[dict]) -> tuple[str, tuple[str, str] | None]:
    """يحوّل أحداث آخر جولة إلى شعار كبير + رقم ضرر فوق المصاب."""
    banner = ""
    for e in evs:
        k = e["k"]
        if k == "sigcall":
            banner = f"🌋 {e.get('name', 'ضربة مميزة')}"
        elif k == "assist":
            banner = "🃏 نداء الفريق!"
        elif k == "rage" and not banner:
            banner = "😡 دخل وضع الغضب!"
        elif k == "crit" and not banner:
            banner = "💥 ضربة حرجة!"
    hits = [e for e in evs if e["k"] in ("hit", "crit", "skill", "sig", "miss", "reflect")]
    flash = None
    if hits:
        e = hits[-1]
        side = "e" if e["a"] == "p" else "p"
        flash = (side, "تفادي!" if e["k"] == "miss" else f"-{e['d']}")
    return banner, flash


async def send_gif(ix, slot: str) -> None:
    """يرسل GIF مرفوعاً للخانة (إن وُجد) كرسالة تالية. لا يفشل أبداً."""
    data = bot.hub.local_gif(slot)
    if not data:
        return
    try:
        await ix.followup.send(file=discord.File(io.BytesIO(data), filename="fx.gif"))
    except Exception:
        pass


def refresh_item_art() -> None:
    """صور العتاد: ما ترفعه أنت (assets/art) أولاً، ثم صور هانتر المجلوبة من الويكي (cache/gear)."""
    arts = {k: d for k in A.SLOTS if k.startswith("item_") for d in [bot.hub.local_art(k)] if d}
    arts.update(bot.hub.gear_art_map())
    R.set_item_art(arts)


def bg_slot(floor: int, mode: str = "climb") -> str:
    """خانة خلفية القتال: ساحة خاصة لكل نمط (صيد/زعيم/مبارزة/تحدٍّ مباشر/انتقام) وفئة طوابق مستقلة (11 فئة) للصعود.
    صور V3 القديمة (bg_street...) تبقى معتمدة عبر ImageHub.local_art إن لم ترفع صورة للفئة الجديدة."""
    if mode == "boss":
        return "bg_boss"
    if mode == "hunt":
        return "bg_hunt"
    if mode in ("duel", "live", "revenge"):
        return f"bg_arena_{mode}"
    return f"bg_floor_{idn.band_index(floor) + 1:02d}"


def to_file(data: bytes, name: str = "card.png") -> discord.File:
    if data[:3] == b"\xff\xd8\xff":   # JPEG (أسرع وأخف رفعاً)
        name = "card.jpg"
    return discord.File(io.BytesIO(data), filename=name)


async def draw(fn, *a, **k) -> bytes:
    """يشغّل دالة الرسم في thread حتى لا يتجمد البوت."""
    return await asyncio.to_thread(fn, *a, **k)


def fmt_dur(seconds: float) -> str:
    seconds = max(0, int(seconds))
    d, rem = divmod(seconds, 86400)
    h, rem = divmod(rem, 3600)
    m = rem // 60
    if d:
        return f"{d} يوم و{h} ساعة"
    if h:
        return f"{h} ساعة و{m} دقيقة"
    return f"{max(1, m)} دقيقة"


def is_admin(ix) -> bool:
    owners = {int(x) for x in os.environ.get("OWNER_IDS", "").replace(" ", "").split(",") if x.isdigit()}
    if ix.user.id in owners:
        return True
    perms = getattr(ix.user, "guild_permissions", None)
    return bool(perms and (perms.administrator or perms.manage_guild))


def need_admin(ix) -> None:
    if not is_admin(ix):
        raise GameError("هذا الأمر للإدارة فقط (صلاحية «إدارة السيرفر»).")


class ArenaTree(app_commands.CommandTree):
    """يضبط «الهوية البصرية» لكل أمر قبل تنفيذه: كل بطاقة تُرسم أثناءه تأخذ خلفية قسمه وشارته وثيمه تلقائياً."""

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        cmd = getattr(interaction, "command", None)
        idn.use(getattr(cmd, "name", None))
        return True


class ArenaBot(discord.Client):
    def __init__(self, text_commands: bool = True) -> None:
        intents = discord.Intents.default()
        self.text_commands = text_commands
        if text_commands:
            intents.message_content = True      # لازم لتشغيل الأوامر بدون علامة (فعّله من بوابة المطورين)
        super().__init__(intents=intents)
        self.tree = ArenaTree(self)
        self.db = Database(os.environ.get("DB_PATH", "tower_arena.db"))
        self.hub = ImageHub()
        self.active: set[int] = set()               # لاعبون في معركة مفتوحة (يمنع الصعود المزدوج)
        self.duel_last: dict[int, float] = {}
        self.text_last: dict[int, float] = {}
        self.seen: dict[int, float] = {}
        self.avatars: dict[int, tuple[float, bytes | None]] = {}
        self.rng = random.Random()
        self.text_index: dict[str, app_commands.Command] = {}

    async def setup_hook(self) -> None:
        await self.db.connect()
        dev = os.environ.get("DEV_GUILD_ID")
        if dev:   # مزامنة فورية على سيرفر الاختبار
            guild = discord.Object(id=int(dev))
            self.tree.copy_global_to(guild=guild)
            await self.tree.sync(guild=guild)
        else:
            await self.tree.sync()
        self.text_index = {norm(c.name): c for c in self.tree.get_commands()}
        refresh_item_art()
        asyncio.create_task(self._warm_gear())
        asyncio.create_task(self.hub.warm([("tower", None), ("victory", None), ("defeat", None), ("nen_test", None), ("gacha", None),
                                           *(("boss", t["search"]) for t in g.BOSSES)]))
        asyncio.create_task(self.hub.warm_cards(list(cd.CARDS.values())))   # صور بطاقات الأبطال تُحمَّل بهدوء في الخلفية
        if not housekeeping.is_running():
            housekeeping.start()

    async def _warm_gear(self) -> None:
        """يجلب صور عتاد هانتر الحقيقية في الخلفية ثم يحدّث الأيقونات المستخدمة في الرسم."""
        try:
            if await self.hub.warm_gear():
                refresh_item_art()
        except Exception as e:
            log.debug("warm_gear: %s", e)

    async def touch(self, user_id: int) -> None:
        """يسجل آخر تفاعل للاعب (لتحديد «متصل» في التحدي المباشر). مرة كل 30 ثانية كحد أقصى."""
        now = time.time()
        if now - self.seen.get(user_id, 0) >= 30:
            self.seen[user_id] = now
            try:
                await self.db.touch(user_id)
            except Exception as e:
                log.debug("touch: %s", e)

    async def on_interaction(self, interaction: discord.Interaction) -> None:
        if interaction.user is not None:
            await self.touch(interaction.user.id)

    async def close(self) -> None:
        await self.db.close()
        await super().close()

    async def on_ready(self) -> None:
        log.info("جاهز كـ %s | أوامر الكتابة: %s", self.user, "مفعّلة" if self.text_commands else "معطّلة")

    # ── صور اللاعبين ──
    async def avatar(self, user) -> bytes | None:
        hit = self.avatars.get(user.id)
        if hit and time.time() - hit[0] < 3600:
            return hit[1]
        try:
            url = user.display_avatar.replace(size=256, format="png").url
        except Exception:
            url = None
        data = await fetch_bytes(url) if url else None
        self.avatars[user.id] = (time.time(), data)
        return data

    # ── أوامر الكتابة بدون علامة ──
    async def on_message(self, message: discord.Message) -> None:
        if not self.text_commands or message.author.bot or not message.guild or not message.content:
            return
        tokens = message.content.strip().split()
        if not tokens:
            return
        word = norm(tokens[0].lstrip("/!"))
        cmd = self.text_index.get(word)
        if cmd is None:
            return
        params = cmd.parameters
        free_text = bool(params) and params[-1].type == discord.AppCommandOptionType.string and not params[-1].choices
        if not free_text and len(tokens) - 1 > len(params):
            return        # جملة عادية تبدأ بكلمة تشبه الأمر
        now = time.time()
        if now - self.text_last.get(message.author.id, 0) < TEXT_CD:
            return
        self.text_last[message.author.id] = now
        await self.touch(message.author.id)
        ctx = MsgContext(self, message)
        asyncio.create_task(_react(message, "⏳"))   # ردّ فوري بأن الأمر وصل
        try:
            kwargs = await parse_text_args(cmd, tokens[1:], message)
            idn.use(cmd.name)
            await cmd.callback(ctx, **kwargs)
        except GameError as e:
            await ctx.reply_text(f"❌ {e}")
        except UsageError as e:
            await ctx.reply_text(f"ℹ️ {e}")
        except Exception:
            log.exception("خطأ في أمر كتابة")
            await ctx.reply_text("⚠️ حدث خطأ غير متوقع. حاول مرة أخرى.")
        finally:
            asyncio.create_task(_unreact(message, "⏳"))


async def _react(message: discord.Message, emoji: str) -> None:
    try:
        await message.add_reaction(emoji)
    except Exception:
        pass


async def _unreact(message: discord.Message, emoji: str) -> None:
    try:
        await message.remove_reaction(emoji, message.guild.me)
    except Exception:
        pass


# ═════════════════════════ دعم الأوامر النصية (بدون علامة) ═════════════════════════
class UsageError(Exception):
    pass


class _Response:
    def __init__(self, ctx: "MsgContext") -> None:
        self.ctx = ctx
        self._done = False

    def is_done(self) -> bool:
        return self._done

    async def defer(self, **kw) -> None:
        self._done = True

    async def send_message(self, content=None, **kw) -> None:
        self._done = True
        self.ctx._first = await self.ctx.reply_text(content, **kw)


class _Followup:
    def __init__(self, ctx: "MsgContext") -> None:
        self.ctx = ctx

    async def send(self, content=None, **kw):
        kw.pop("wait", None)
        msg = await self.ctx.reply_text(content, **kw)
        if self.ctx._first is None:
            self.ctx._first = msg
        return msg


class MsgContext:
    """يشبه discord.Interaction بالقدر الذي تحتاجه أوامرنا، لكن من رسالة نصية عادية."""

    def __init__(self, client: ArenaBot, message: discord.Message) -> None:
        self.client = client
        self.message = message
        self.user = message.author
        self.guild = message.guild
        self.guild_id = message.guild.id if message.guild else 0
        self.channel = message.channel
        self.channel_id = message.channel.id
        self._first: discord.Message | None = None
        self.response = _Response(self)
        self.followup = _Followup(self)

    async def reply_text(self, content=None, **kw):
        kw.pop("ephemeral", None)
        kw = {k: v for k, v in kw.items() if v is not None}
        try:
            return await self.message.reply(content, mention_author=False, **kw)
        except discord.HTTPException:
            return await self.channel.send(content, **kw)

    async def original_response(self):
        return self._first

    async def edit_original_response(self, **kw):
        if self._first is not None:
            return await self._first.edit(**kw)


async def parse_text_args(cmd: app_commands.Command, tokens: list[str], message: discord.Message) -> dict:
    kwargs: dict = {}
    i = 0
    params = cmd.parameters
    for idx, p in enumerate(params):
        last = idx == len(params) - 1
        tok = tokens[i] if i < len(tokens) else None
        T = discord.AppCommandOptionType
        value = None
        if p.type in (T.user, T.channel):
            raw = tok
            if raw is not None:
                m = re.search(r"<[@#][!&]?(\d+)>|(\d{15,})", raw)
                if m:
                    oid = int(m.group(1) or m.group(2))
                    if p.type == T.user:
                        value = message.guild.get_member(oid)
                        if value is None:
                            try:
                                value = await message.guild.fetch_member(oid)
                            except discord.HTTPException:
                                value = None
                    else:
                        value = message.guild.get_channel(oid)
                    i += 1
            if value is None and p.type == T.user and p.required and message.mentions:
                value = message.mentions[0]
            if value is None and p.type == T.channel and p.required:
                value = message.channel
        elif p.type == T.integer or p.type == T.number:
            if tok is not None:
                digits = tok.translate(str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")).replace(",", "").replace("،", "")
                if re.fullmatch(r"-?\d+", digits):
                    value = int(digits)
                    i += 1
        elif p.type == T.attachment:
            value = message.attachments[0] if message.attachments else None
        elif p.type == T.boolean:
            if tok is not None:
                value = norm(tok) in ("نعم", "اي", "ايوه", "اعاده", "اعادة", "صح", "true", "yes", "1")
                i += 1
        else:   # نص أو اختيارات
            if p.choices:
                if tok is not None:
                    t = strip_al(norm(tok))
                    for c in p.choices:
                        words = [strip_al(w) for w in _NON_WORD.split(norm(c.name)) if w]
                        if t == strip_al(norm(str(c.value))) or (words and (t == words[0] or words[0].startswith(t) and len(t) >= 2)):
                            value = c.value
                            i += 1
                            break
            elif tok is not None:
                value = " ".join(tokens[i:]) if last else tok
                i = len(tokens) if last else i + 1
        if value is None:
            if p.required:
                usage = " ".join(f"<{q.display_name}>" if q.required else f"[{q.display_name}]" for q in params)
                raise UsageError(f"الاستخدام: {cmd.name} {usage}")
            continue
        kwargs[p.name] = value
    return kwargs


# ═════════════════════════ إرسال وإعلانات ═════════════════════════
bot = ArenaBot(text_commands=os.environ.get("TEXT_COMMANDS", "1") != "0")
tree = bot.tree


async def send_card(ix, data: bytes, view: discord.ui.View | None = None, ephemeral: bool = False, content: str | None = None):
    kw: dict = {"file": to_file(data), "ephemeral": ephemeral}
    if view is not None:
        kw["view"] = view
    if content:
        kw["content"] = content
    if ix.response.is_done():
        msg = await ix.followup.send(wait=True, **kw)
    else:
        await ix.response.send_message(**kw)
        msg = await ix.original_response()
    if view is not None and hasattr(view, "message"):
        view.message = msg
    return msg


async def announce(server_id: int, kind: str, content: str | None = None, data: bytes | None = None) -> None:
    """ينشر إعلاناً في القناة التي ضبطها المشرف (أمر «قناة»). لا يفشل أبداً."""
    try:
        cid = await bot.db.get_channel(server_id, kind)
        if not cid:
            return
        ch = bot.get_channel(cid) or await bot.fetch_channel(cid)
        kw: dict = {}
        if content:
            kw["content"] = content
        if data:
            kw["file"] = to_file(data)
        if kw:
            await ch.send(allowed_mentions=discord.AllowedMentions.none(), **kw)
    except Exception as e:
        log.debug("announce %s: %s", kind, e)


@tree.error
async def on_app_error(interaction: discord.Interaction, error: app_commands.AppCommandError) -> None:
    original = getattr(error, "original", error)
    if isinstance(original, GameError):
        msg = f"❌ {original}"
    else:
        log.exception("خطأ غير متوقع", exc_info=error)
        msg = "⚠️ حدث خطأ غير متوقع. حاول مرة أخرى."
    try:
        if interaction.response.is_done():
            await interaction.followup.send(msg, ephemeral=True)
        else:
            await interaction.response.send_message(msg, ephemeral=True)
    except discord.HTTPException:
        pass


# ═════════════════════════ واجهات (Views) ═════════════════════════
class OwnedView(discord.ui.View):
    def __init__(self, owner_id: int, timeout: float = 180) -> None:
        super().__init__(timeout=timeout)
        self.owner_id = owner_id
        self.message: discord.Message | None = None
        self.ident = idn.current()           # هوية الأمر الذي فتح هذه اللوحة: تبقى ثابتة عبر كل صفحاتها

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if self.ident is not None:
            idn.use(None, ident=self.ident)
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("❌ هذه اللوحة ليست لك! اكتب الأمر بنفسك.", ephemeral=True)
            return False
        return True

    async def on_timeout(self) -> None:
        if self.message:
            try:
                await self.message.edit(view=None)
            except discord.HTTPException:
                pass

    async def push(self, interaction: discord.Interaction, data: bytes, view: discord.ui.View | None = "self") -> None:
        """يستبدل صورة الرسالة (بعد defer) ويحدّث الأزرار."""
        v = self if view == "self" else view
        await interaction.edit_original_response(attachments=[to_file(data)], view=v)


# ───────────────────────── القتال ─────────────────────────
class HatsuSelect(discord.ui.Select):
    """قائمة قدرات هاتسو المتاحة الآن (من بطاقات فريقك). تعرض فقط ما يمكن استخدامه في هذا الدور."""

    def __init__(self) -> None:
        super().__init__(placeholder="🌀 قدرات هاتسو", min_values=1, max_values=1, row=2,
                         options=[discord.SelectOption(label="لا قدرة جاهزة", value="none")])

    def sync(self, battle: g.Battle) -> None:
        opts = []
        for mv, ok in battle.player_hatsu_moves():
            if not ok:
                continue
            info = ht.HATSU[mv]
            opts.append(discord.SelectOption(label=info["name"], value=mv, emoji=info["emoji"],
                                             description=f"{info['cost']} طاقة · {info['desc']}"[:100]))
        self.disabled = not opts
        self.options = opts or [discord.SelectOption(label="لا قدرة جاهزة (طاقة/تبريد)", value="none")]
        self.placeholder = "🌀 قدرات هاتسو" if opts else "🌀 هاتسو غير جاهزة"

    async def callback(self, interaction: discord.Interaction) -> None:
        view: BattleView = self.view  # type: ignore[assignment]
        if self.values[0] == "none":
            await interaction.response.defer()
            return
        view.battle.play_round("hatsu:" + self.values[0])
        await view._after(interaction)


class BattleView(OwnedView):
    def __init__(self, owner_id: int, battle: g.Battle, mode: str, floor: int, title: str, *, server_id: int, name: str,
                 theme: str = "default", player_art: bytes | None = None, enemy_art: bytes | None = None,
                 boss: dict | None = None, bg: bytes | None = None, hunt: tuple | None = None,
                 team_arts: dict[str, bytes] | None = None, holder: dict | None = None, revenge_id: int | None = None) -> None:
        super().__init__(owner_id, timeout=150)
        self.bg, self.hunt = bg, hunt
        self.holder, self.revenge_id = holder, revenge_id
        self.hatsu_select: HatsuSelect | None = None
        if battle.p.hatsu:
            self.hatsu_select = HatsuSelect()
            self.add_item(self.hatsu_select)
        self.team_arts = team_arts or {}
        self.battle, self.mode, self.floor, self.title = battle, mode, floor, title
        self.server_id, self.name, self.theme = server_id, name, theme
        self.player_art, self.enemy_art = player_art, enemy_art
        self.boss = boss
        self.boss_start_hp = battle.e.hp
        self.done = False
        self._sync_buttons()

    def _sync_buttons(self) -> None:
        p = self.battle.p
        if p.nen and not p.no_skill:
            info = g.NEN[p.nen]
            self.skill_btn.label = f"{info['skill']} ({info['cost']})"
            self.skill_btn.emoji = info["emoji"]
            self.skill_btn.disabled = not self.battle.player_skill_usable()
        else:
            self.skill_btn.label = "مهارة النين 🔒"
            self.skill_btn.disabled = True
        self.guard_btn.disabled = p.no_guard
        if self.hatsu_select is not None:
            self.hatsu_select.sync(self.battle)
        if p.team:
            ready = self.battle.assist_usable()
            self.assist_btn.disabled = not ready
            self.assist_btn.label = "نداء الفريق" if ready else f"نداء الفريق ({max(1, p.assist_cd)})"
        else:   # بدون فريق: لا نُظهر الزر أصلاً حتى لا يزحم الواجهة
            if self.assist_btn in self.children:
                self.remove_item(self.assist_btn)

    def card(self, title: str | None = None, theme: str | None = None) -> bytes:
        b = self.battle
        banner, flash = _fx(b.last_ev)
        return R.battle_card(title or self.title, b.round, g.fighter_view(b.p), g.fighter_view(b.e), b.log, self.player_art,
                             self.enemy_art, theme or self.theme, bg=self.bg, banner=banner, combo=b.combo, flash=flash,
                             team_arts=self.team_arts)

    async def on_timeout(self) -> None:
        if self.done:
            return
        self.done = True
        bot.active.discard(self.owner_id)
        if self.mode in ("climb", "hunt", "revenge"):
            await bot.db.set_hp(self.owner_id, self.battle.p.hp)   # انسحاب: تبقى صحتك الحالية
        elif self.mode == "boss" and self.boss:
            await self._boss_record()
        if self.message:
            try:
                data = await draw(self.card, "⌛ انتهى الوقت — اعتُبر انسحاباً", "lose")
                await self.message.edit(attachments=[to_file(data)], view=None)
            except discord.HTTPException:
                pass

    async def _boss_record(self) -> dict:
        dmg = max(0, self.boss_start_hp - self.battle.e.hp)
        res = await bot.db.boss_finish(self.boss["boss_id"], self.owner_id, dmg)
        if res["killed"]:
            await announce_settle(self.server_id, res["settle"])
        return res

    # ── الإنهاء ──
    async def _finish(self, interaction: discord.Interaction) -> None:
        self.done = True
        bot.active.discard(self.owner_id)
        self.stop()
        b, db = self.battle, bot.db
        notes: list[str] = []
        rewards: list[tuple[str, str]] = []
        kind, title, sub = "flee", "انسحاب", ""
        art_ctx = None
        ev_bg = None
        gif_slots: list[str] = []
        if self.mode == "hunt":
            hk = self.hunt
            if b.winner == "player":
                gold, xp = g.hunt_rewards(hk, self.floor, bot.rng)
                r = await db.hunt_finish(self.owner_id, True, b.p.hp, gold, xp, hk[7], bot.rng)
                kind, title, sub = "win", "صيد ناجح!", f"{hk[2]} {hk[1]}"
                rewards = [("💰", f"+{gold}"), ("✨", f"+{xp} XP")]
                if r["item"]:
                    iv = g.item_view({"item_id": r["item"]["item_id"], "item_name": r["item"]["name"], "item_type": r["item"]["type"],
                                      "stat": r["item"]["stat"], "stat_bonus": r["item"]["bonus"], "rarity": r["item"]["rarity"]})
                    notes.append(f"🎁 سقط منه: {iv['emoji']} {iv['name']} ({iv['bonus_text']})")
                if r["levels_gained"]:
                    notes.append(f"⭐ ارتقيت للمستوى {r['level']} (+{r['points']} نقاط تطوير)")
                    gif_slots.append("levelup")
                gif_slots.append("victory")
                art_ctx = "victory"
            elif b.winner == "enemy":
                await db.hunt_finish(self.owner_id, False, 0, 0, 0, 0)
                kind, title, sub = "lose", "فشل الصيد", f"{hk[2]} {hk[1]}"
                notes.append("الفريسة كانت أقوى منك. جهّز عتادك وعد من جديد.")
                gif_slots.append("defeat")
                art_ctx = "defeat"
            else:
                await db.set_hp(self.owner_id, b.p.hp)
                notes.append("انسحبت من الصيد.")
        elif self.mode == "climb":
            if b.winner == "player":
                res = await climb_win(self.owner_id, self.floor, b.p.hp, self.name, self.server_id, self.holder)
                kind, title, sub = "win", "انتصار!", f"الطابق {self.floor} · {g.floor_tier(self.floor)}"
                rewards, notes, gif_slots, art_ctx = res["rewards"], res["notes"], res["gifs"], "victory"
                ev_bg = bot.hub.local_art(f"ev_{res['event']}") if res.get("event") else None     # خلفية خاصة لكل حدث طابق
            elif b.winner == "enemy":
                r = await db.apply_loss(self.owner_id)
                kind, title, sub = "lose", "هزيمة", f"الطابق {self.floor}"
                rewards = [("💰", f"-{r['gold_lost']}")]
                notes.append("تبقّى لك ربع صحتك. ارتح قليلاً أو استخدم بطاقة شفاء («استخدام»).")
                gif_slots.append("defeat")
                art_ctx = "defeat"
            else:
                await db.set_hp(self.owner_id, b.p.hp)
                notes.append("انسحبت بدون خسارة ذهب. صحتك الحالية محفوظة.")
        elif self.mode == "revenge":
            if b.winner == "player":
                gold, _x = g.floor_rewards(self.floor, bot.rng)
                gold = int(gold * g.REVENGE_BONUS_GOLD)
                try:
                    res = await db.revenge_win(self.owner_id, self.revenge_id, gold)
                    await db.set_hp(self.owner_id, b.p.hp)
                    kind, title, sub = "win", "انتقام ناجح!", f"استعدت الطابق {self.floor}"
                    rewards = [("💰", f"+{gold}")]
                    notes.append(f"🔥 عاد الطابق {self.floor} لك. ظلك صار هو المسيطر من جديد.")
                    if res["usurped"]:
                        await announce(self.server_id, "floor", f"🔥 **{self.name}** انتقم واستعاد **الطابق {self.floor}** من <@{res['usurped']}>!")
                except GameError as e:
                    notes.append(str(e))
                art_ctx = "victory"
                gif_slots.append("victory")
            elif b.winner == "enemy":
                await db.set_hp(self.owner_id, max(1, int(g.LOSS_HP_PCT * b.p.max_hp)))
                kind, title, sub = "lose", "فشل الانتقام", f"الطابق {self.floor}"
                notes.append("الانتقام متاح حتى تنتهي مدته. جهّز نفسك وحاول ثانية.")
                art_ctx = "defeat"
            else:
                await db.set_hp(self.owner_id, b.p.hp)
                notes.append("انسحبت من الانتقام.")
        elif self.mode == "duel":
            if b.winner == "player":
                gold = 25 + min(100, self.floor)
                await db.duel_win(self.owner_id, gold)
                kind, title, rewards = "win", "فزت بالمبارزة!", [("💰", f"+{gold}")]
                art_ctx = "victory"
            elif b.winner == "enemy":
                kind, title = "lose", "خسرت المبارزة"
                notes.append("لا خسائر في المبارزات الودّية.")
                art_ctx = "defeat"
            else:
                notes.append("انسحبت من المبارزة.")
        else:   # boss
            res = await self._boss_record()
            kind, title = "win", f"أصبت الزعيم بـ {res['damage']:,}!"
            sub = f"متبقٍ من الزعيم {res['boss_hp']:,}"
            rewards = [("💥", f"{res['damage']:,}")]
            if res["killed"]:
                title, sub = "أسقطت الزعيم!", "كانت ضربتك القاضية!"
                notes.append("الغنائم أُضيفت لحقائب المشاركين 🎁")
                gif_slots.append("boss_win")
            art_ctx = "victory"
        art = (bot.hub.local_art(art_ctx) or (await bot.hub.art(art_ctx, timeout=1.5) if art_ctx else None)) if art_ctx else None
        art = art or self.enemy_art
        if self.mode == "boss" and kind == "win" and title.startswith("أسقطت"):
            idn.use("boss", "win")
        data = await draw(R.result_card, kind, title, sub, rewards, art, notes, bg=ev_bg or self.bg)
        await interaction.edit_original_response(attachments=[to_file(data)], view=None)
        for slot in gif_slots[:2]:
            await send_gif(interaction, slot)

    async def _after(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer()
        if self.battle.over:
            await self._finish(interaction)
        else:
            self._sync_buttons()
            await self.push(interaction, await draw(self.card))

    # ── الأزرار ──
    @discord.ui.button(label="هجوم", emoji="⚔️", style=discord.ButtonStyle.danger, row=0)
    async def attack_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.battle.play_round("attack")
        await self._after(interaction)

    @discord.ui.button(label="تحصّن", emoji="🛡️", style=discord.ButtonStyle.secondary, row=0)
    async def guard_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.battle.play_round("guard")
        await self._after(interaction)

    @discord.ui.button(label="مهارة", style=discord.ButtonStyle.primary, row=0)
    async def skill_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.battle.play_round("skill")
        await self._after(interaction)

    @discord.ui.button(label="نداء الفريق", emoji="🃏", style=discord.ButtonStyle.primary, row=0)
    async def assist_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.battle.play_round("assist")
        await self._after(interaction)

    @discord.ui.button(label="قتال تلقائي", emoji="⏩", style=discord.ButtonStyle.success, row=1)
    async def auto_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        while not self.battle.over:
            self.battle.play_round(self.battle.suggest_action())
        await self._after(interaction)

    @discord.ui.button(label="انسحاب", emoji="🏳️", style=discord.ButtonStyle.secondary, row=1)
    async def flee_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.battle.flee()
        await self._after(interaction)


async def announce_gang_events(events: list[dict], server_id: int) -> list[str]:
    """يعلن إكمال مهام العصابة، ويعيد سطوراً تُضاف لملاحظات اللاعب."""
    notes: list[str] = []
    for e in events or []:
        if e["type"] == "mission":
            txt = f"🏴 أكملتم مهمة العصابة: {e['title']} — +{e['gold']:,} 💰 للخزينة"
            notes.append(txt)
            await announce(server_id, "floor", txt)
        elif e["type"] == "all_clear":
            txt = f"🎁 العصابة أنجزت كل مهامها الأسبوعية! {e['crates']} صندوق عتاد وُزّع على {e['members']} من أعضائها — اكتب «صندوق»"
            notes.append(txt)
            await announce(server_id, "floor", txt)
    return notes


async def climb_win(uid: int, floor: int, hp: int, name: str, server_id: int, holder: dict | None = None) -> dict:
    """يطبّق نتيجة انتصار في الصعود: مكافآت، سيطرة على الطابق، نقاط نين، مهام. يعيد ما تعرضه بطاقة النتيجة."""
    db = bot.db
    u = await db.get_user(uid)
    notes: list[str] = []
    gifs: list[str] = []
    gold, xp = g.floor_rewards(floor, bot.rng)
    gold = int(gold * g.vow_gold_mult(u["vow"]))
    ev = await db.get_event()
    if ev:
        if ev["kind"] == "gold":
            gold = int(gold * ev["mult"])
            notes.append(f"🎉 حدث «ذهب ×{ev['mult']:g}» فعّال!")
        else:
            xp = int(xp * ev["mult"])
            notes.append(f"🎉 حدث «خبرة ×{ev['mult']:g}» فعّال!")
    if await db.take_blessing(uid):
        xp *= 2
        notes.append("✨ بركة المعبد ضاعفت خبرتك!")
    r = await db.apply_win(uid, hp, gold, xp)
    fe = g.roll_floor_event(bot.rng)
    ev_key = fe["key"] if fe else None
    if fe:
        done = await db.floor_event(uid, fe, gold, bot.rng)
        notes.append(f"{done['emoji']} {done['title']}: {done['text']}")
        gifs.append("event")
    rewards = [("💰", f"+{gold}"), ("✨", f"+{xp} XP")]
    if floor >= g.MAX_FLOOR:
        notes.append("👑 هزمت بطل البرج! أنت على القمة.")
    else:
        notes.append(f"🏰 صعدت إلى الطابق {r['floor']}")
    if r["levels_gained"]:
        notes.append(f"⭐ ارتقيت للمستوى {r['level']} (+{r['points']} نقاط تطوير — اكتب «تطوير»)")
        gifs.append("levelup")
    if r.get("tree_points"):
        notes.append(f"🌳 +{r['tree_points']} نقطة نين — اكتب «شجرة»")
    gifs.append("victory")
    if r.get("usurped"):
        notes.append(f"🏯 هزمت ظل {holder['username'] if holder else 'المسيطر'} وأصبحت مسيطر الطابق {floor}!")
        await announce(server_id, "floor", f"🏯 **{name}** سيطر على **الطابق {floor}** بعد هزيمة <@{r['usurped']}> — له الحق بالانتقام بكتابة «انتقام»")
    else:
        notes.append(f"🏯 أنت الآن مسيطر الطابق {floor}")
    await announce(server_id, "floor", f"🏰 **{name}** صعد إلى **الطابق {r['floor']}** ({g.floor_tier(r['floor'])})")
    if r["levels_gained"]:
        await announce(server_id, "level", f"⭐ **{name}** ارتقى إلى **المستوى {r['level']}**!")
    notes += await announce_gang_events(r.get("gang_events"), server_id)
    return {"rewards": rewards, "notes": notes, "gifs": gifs, "r": r, "event": ev_key}


async def build_enemy(user_id: int, floor: int) -> tuple[g.Fighter, dict | None]:
    """خصم الطابق: «ظل المسيطر» (Shadow Echo) إن كان للطابق مسيطر آخر، وإلا خصم الطابق المعتاد."""
    enemy = g.enemy_for_floor(floor, bot.rng)
    holder = await bot.db.floor_holder(floor, exclude_id=user_id)
    if holder:
        return g.echo_of(holder, enemy, f"👤 ظل {holder['username']} · مسيطر الطابق {floor}"), holder
    return enemy, None


def floor_art_ctx(floor: int) -> str:
    return "floor_master" if floor >= g.MASTER_FLOOR_START else "tower"


async def enemy_art_for(enemy: g.Fighter, art_ctx: str, art_name: str | None) -> bytes | None:
    """صورة الخصم: مرفوعة بالإدارة (زعيم/نمط) ← أي صورة من الإنترنت."""
    keys = []
    if art_name:
        keys.append(A._slug(art_name))
    if enemy.look:
        keys.append(f"enemy_{enemy.look}")
    for k in keys:
        d = bot.hub.local_art(k)
        if d:
            return d
    return await bot.hub.art(art_ctx, art_name, timeout=2.0)


def team_arts_for(*fighters: g.Fighter) -> dict[str, bytes]:
    """صور بطاقات فرق المقاتلين من الكاش فقط (لا انتظار على الشبكة وسط المعركة)."""
    arts: dict[str, bytes] = {}
    for f in fighters:
        for m in f.team:
            d = bot.hub.card_art_cached(m["key"])
            if d:
                arts[m["key"]] = d
    return arts


async def start_battle(ix, battle: g.Battle, mode: str, floor: int, title: str, *, theme: str, art_ctx: str, art_name: str | None = None,
                       boss: dict | None = None, hunt: tuple | None = None, holder: dict | None = None, revenge_id: int | None = None) -> None:
    uid = ix.user.id
    p_art, e_art = await asyncio.gather(bot.avatar(ix.user), enemy_art_for(battle.e, art_ctx, art_name))
    bg = bot.hub.local_art(bg_slot(floor, mode))
    view = BattleView(uid, battle, mode, floor, title, server_id=ix.guild_id or 0, name=dname(ix.user), theme=theme,
                      player_art=p_art, enemy_art=e_art, boss=boss, bg=bg, hunt=hunt, team_arts=team_arts_for(battle.p, battle.e),
                      holder=holder, revenge_id=revenge_id)
    await send_card(ix, await draw(view.card), view)


# ───────────────────────── التحدي المباشر (لاعب ضد المسيطر) ─────────────────────────
LIVE_ROUND_SECONDS = 45


class LiveInviteView(discord.ui.View):
    """دعوة للمسيطر المتصل: يقبل التحدي خلال مهلة قصيرة، وإلا يواجه المهاجم «ظله»."""

    def __init__(self, holder_id: int) -> None:
        super().__init__(timeout=g.LIVE_CHALLENGE_SECONDS)
        self.holder_id = holder_id
        self.accepted: bool | None = None

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.holder_id:
            await interaction.response.send_message("❌ هذا التحدي موجّه لصاحب الطابق فقط.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="قبول التحدي ⚔️", style=discord.ButtonStyle.success)
    async def accept_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        if self.holder_id in bot.active:
            await interaction.response.send_message("❌ عندك معركة مفتوحة، أكملها أولاً.", ephemeral=True)
            return
        self.accepted = True
        await interaction.response.defer()
        self.stop()

    @discord.ui.button(label="دع ظلي يقاتل 👤", style=discord.ButtonStyle.secondary)
    async def decline_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.accepted = False
        await interaction.response.defer()
        self.stop()


async def offer_live(ix, floor: int, holder: dict) -> bool:
    """يرسل التحدي للمسيطر المتصل وينتظر قراره. True = قبل، فيبدأ قتال مباشر."""
    member = ix.guild.get_member(holder["user_id"]) if ix.guild else None
    if member is None or holder["user_id"] in bot.active:
        return False
    view = LiveInviteView(holder["user_id"])
    text = (f"⚔️ {member.mention} — **{dname(ix.user)}** يتحدّاك على **الطابق {floor}** الذي تسيطر عليه!\n"
            f"عندك {g.LIVE_CHALLENGE_SECONDS} ثانية لتقبل القتال المباشر (دور بدور بينكما)، وإلا يقاتل ظلّك بدلاً منك.")
    try:
        msg = await ix.followup.send(text, view=view, wait=True, allowed_mentions=discord.AllowedMentions(users=[member]))
    except discord.HTTPException:
        return False
    await view.wait()
    try:
        await msg.edit(content=text.split("\n")[0] + ("\n✅ **قُبل التحدي!**" if view.accepted else "\n👤 لم يُقبل التحدي — يواجه ظلّه."), view=None)
    except (discord.HTTPException, AttributeError):
        pass
    return bool(view.accepted)


class LiveBattleView(discord.ui.View):
    """قتال تكتيكي بالأدوار بين لاعبين: كل جولة يختار كل لاعب حركته، وتُنفَّذ عند اكتمال الاختيارين (أو بعد مهلة)."""

    def __init__(self, challenger_id: int, holder_id: int, battle: g.Battle, floor: int, title: str, *, server_id: int,
                 names: tuple[str, str], arts: tuple[bytes | None, bytes | None], bg: bytes | None, holder: dict) -> None:
        super().__init__(timeout=900)
        self.cid, self.hid = challenger_id, holder_id
        self.battle, self.floor, self.title = battle, floor, title
        self.server_id, self.names, self.arts, self.bg, self.holder = server_id, names, arts, bg, holder
        self.choices: dict[int, str] = {}
        self.round_token = 0
        self.lock = asyncio.Lock()
        self.message: discord.Message | None = None
        self.done = False
        self.ident = idn.current()

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if self.ident is not None:
            idn.use(None, ident=self.ident)
        if interaction.user.id not in (self.cid, self.hid):
            await interaction.response.send_message("❌ هذه المعركة بين لاعبين آخرين.", ephemeral=True)
            return False
        return True

    def card(self, title: str | None = None, theme: str = "boss") -> bytes:
        b = self.battle
        banner, flash = _fx(b.last_ev)
        waiting = [self.names[i] for i, uid in enumerate((self.cid, self.hid)) if uid not in self.choices]
        sub = title or (f"{self.title} · بانتظار: {'، '.join(waiting)}" if self.choices else self.title)
        return R.battle_card(sub, b.round, g.fighter_view(b.p), g.fighter_view(b.e), b.log, self.arts[0], self.arts[1], theme, bg=self.bg,
                             banner=banner, combo=b.combo, flash=flash, team_arts=team_arts_for(b.p, b.e))

    def _action_for(self, uid: int) -> str:
        return self.choices.get(uid, "attack")

    async def _play(self) -> None:
        b = self.battle
        b.play_round(self._action_for(self.cid), self._action_for(self.hid))
        self.choices.clear()
        self.round_token += 1

    async def _pick(self, interaction: discord.Interaction, action: str) -> None:
        async with self.lock:
            if self.done:
                await interaction.response.send_message("انتهت المعركة.", ephemeral=True)
                return
            me = interaction.user.id
            actor = self.battle.p if me == self.cid else self.battle.e
            opp = self.battle.e if me == self.cid else self.battle.p
            if action == "skill" and not self.battle.skill_usable(actor, opp):
                action = "attack"
            elif action == "assist" and not self.battle.assist_usable(actor):
                action = "attack"
            elif action == "hatsu":
                ready = [h["move"] for h in actor.hatsu if self.battle.hatsu_usable(actor, h["move"], opp)]
                action = f"hatsu:{ready[0]}" if ready else "attack"
            self.choices[me] = action
            if len(self.choices) < 2:
                token = self.round_token
                await interaction.response.send_message(f"✅ سُجّلت حركتك. بانتظار خصمك ({LIVE_ROUND_SECONDS} ثانية كحد أقصى).", ephemeral=True)
                asyncio.create_task(self._round_timer(token))
                return
            await interaction.response.defer()
            await self._advance()

    async def _round_timer(self, token: int) -> None:
        await asyncio.sleep(LIVE_ROUND_SECONDS)
        async with self.lock:
            if self.done or token != self.round_token or not self.choices:
                return
            await self._advance()

    async def _advance(self) -> None:
        await self._play()
        if self.battle.over:
            await self._finish()
            return
        if self.message:
            try:
                await self.message.edit(attachments=[to_file(await draw(self.card))], view=self)
            except discord.HTTPException:
                pass

    async def on_timeout(self) -> None:
        async with self.lock:
            if self.done:
                return
            self.done = True
        bot.active.discard(self.cid)
        bot.active.discard(self.hid)
        await bot.db.set_hp(self.cid, self.battle.p.hp)
        if self.message:
            try:
                await self.message.edit(attachments=[to_file(await draw(self.card, "⌛ انتهى الوقت — اعتُبر انسحاباً", "lose"))], view=None)
            except discord.HTTPException:
                pass

    async def _finish(self) -> None:
        self.done = True
        bot.active.discard(self.cid)
        bot.active.discard(self.hid)
        self.stop()
        b, db = self.battle, bot.db
        notes: list[str] = []
        rewards: list[tuple[str, str]] = []
        if b.winner == "player":
            res = await climb_win(self.cid, self.floor, b.p.hp, self.names[0], self.server_id, self.holder)
            kind, title, sub = "win", f"هزمت {self.names[1]} مباشرة!", f"الطابق {self.floor}"
            rewards, notes = res["rewards"], res["notes"]
            notes.insert(0, f"⚔️ قتال مباشر ضد {self.names[1]}")
        else:
            r = await db.apply_loss(self.cid)
            reward = 120 + self.floor * 12
            await db.duel_win(self.hid, reward)
            kind, title, sub = "lose", f"صدّك {self.names[1]}!", f"الطابق {self.floor}"
            rewards = [("💰", f"-{r['gold_lost']}")]
            notes += [f"🏯 {self.names[1]} حمى طابقه وربح {reward} 💰", "تبقّى لك ربع صحتك. جهّز نفسك وحاول ثانية."]
        data = await draw(R.result_card, kind, title, sub, rewards, self.arts[1] if kind == "lose" else self.arts[0], notes, bg=self.bg)
        if self.message:
            try:
                await self.message.edit(attachments=[to_file(data)], view=None)
            except discord.HTTPException:
                pass

    @discord.ui.button(label="هجوم", emoji="⚔️", style=discord.ButtonStyle.danger, row=0)
    async def attack_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self._pick(interaction, "attack")

    @discord.ui.button(label="تحصّن", emoji="🛡️", style=discord.ButtonStyle.secondary, row=0)
    async def guard_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self._pick(interaction, "guard")

    @discord.ui.button(label="مهارة النين", emoji="✨", style=discord.ButtonStyle.primary, row=0)
    async def skill_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self._pick(interaction, "skill")

    @discord.ui.button(label="نداء الفريق", emoji="🃏", style=discord.ButtonStyle.primary, row=0)
    async def assist_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self._pick(interaction, "assist")

    @discord.ui.button(label="هاتسو", emoji="🌀", style=discord.ButtonStyle.success, row=1)
    async def hatsu_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self._pick(interaction, "hatsu")


async def start_live_battle(ix, u: dict, holder: dict, floor: int, enemy_template: g.Fighter) -> None:
    """يبدأ قتالاً مباشراً: المهاجم بصحته الحالية، والمسيطر بصحة كاملة (يدافع عن طابقه)."""
    uid, hid = ix.user.id, holder["user_id"]
    bot.active.add(hid)
    try:
        member = ix.guild.get_member(hid)
        hname = dname(member) if member else holder["username"]
        player = g.fighter_from_user(u, dname(ix.user))
        defender = g.fighter_from_user(holder, f"🏯 {hname}", full_hp=True)
        defender.is_player = False
        battle = g.Battle(player, defender, bot.rng)
        p_art = await bot.avatar(ix.user)
        h_art = await bot.avatar(member) if member else None
        bg = bot.hub.local_art(bg_slot(floor, "live"))
        view = LiveBattleView(uid, hid, battle, floor, f"⚔️ تحدٍّ مباشر · الطابق {floor}", server_id=ix.guild_id or 0,
                              names=(dname(ix.user), hname), arts=(p_art, h_art), bg=bg, holder=holder)
        await send_card(ix, await draw(view.card), view)
    except BaseException:
        bot.active.discard(hid)
        raise


# ═════════════════════════ أوامر البرج ═════════════════════════
def slash(name: str, desc: str):
    def deco(fn):
        return tree.command(name=name, description=desc)(app_commands.guild_only()(fn))
    return deco


@slash("صعود", "⚔️ قاتل في طابقك الحالي واصعد البرج")
async def climb(ix: discord.Interaction) -> None:
    uid = ix.user.id
    if uid in bot.active:
        raise GameError("عندك معركة مفتوحة بالفعل! أكملها أو انسحب منها.")
    bot.active.add(uid)
    try:
        await ix.response.defer()
        u = await bot.db.ensure_user(uid, dname(ix.user))
        if u["floor"] >= g.NEN_UNLOCK_FLOOR and not g.normalize_nen(u["nen_type"]):
            raise GameError(f"وصلت للطابق {u['floor']}! أجرِ اختبار الكأس أولاً بكتابة «اختبار» لفتح النين.")
        if u["cur_hp"] < g.MIN_HP_PCT_TO_CLIMB * u["t_hp"]:
            mins = max(1, round(u["minutes_to_climb"]))
            raise GameError(f"صحتك منخفضة ({u['cur_hp']}/{u['t_hp']}). ارتح حوالي {mins} دقيقة أو استخدم بطاقة شفاء («استخدام»).")
        enemy, holder = await build_enemy(uid, u["floor"])
        if holder and holder["online"] and await offer_live(ix, u["floor"], holder):
            await start_live_battle(ix, u, holder, u["floor"], enemy)       # المسيطر متصل وقبل: قتال بين لاعبين
            return
        player = g.fighter_from_user(u, dname(ix.user))
        battle = g.Battle(player, enemy, bot.rng)
        theme = "boss" if u["floor"] >= g.MASTER_FLOOR_START else "default"
        await start_battle(ix, battle, "climb", u["floor"], f"🏰 الطابق {u['floor']} · {g.floor_tier(u['floor'])}",
                           theme=theme, art_ctx=floor_art_ctx(u["floor"]), holder=holder)
    except BaseException:
        bot.active.discard(uid)
        raise


@slash("طابق", "🔭 اعرف خصمك ومكافأتك في الطابق الحالي")
async def floor_info(ix: discord.Interaction) -> None:
    await ix.response.defer()
    u = await bot.db.ensure_user(ix.user.id, dname(ix.user))
    e = g.enemy_for_floor(u["floor"], bot.rng)
    holder = await bot.db.floor_holder(u["floor"], exclude_id=ix.user.id)
    if holder:
        e = g.echo_of(holder, e)
    gold, xp = g.floor_rewards(u["floor"], bot.rng)
    art = await bot.hub.art(floor_art_ctx(u["floor"]), timeout=2.0)
    shadow = g.MASTER_FLOOR_START <= u["floor"] <= g.MASTER_FLOOR_END or holder is not None
    name = (f"ظل {holder['username']} (مسيطر)" if holder else
            "بطل البرج الأعظم" if u["floor"] >= g.BOSS_FLOOR else ("سيد الطابق" if shadow else "خصم الطابق"))
    data = await draw(R.tower_card, u["floor"], g.MAX_FLOOR, g.floor_tier(u["floor"]),
                      {"name": name, "hp": e.max_hp, "atk": e.atk, "defense": e.defense, "speed": e.speed, "nen": None,
                       "emoji": "👑" if u["floor"] >= g.BOSS_FLOOR else "🏯" if shadow else "👹"},
                      (gold, xp), art, (u["cur_hp"], u["t_hp"]), g.NEN_UNLOCK_FLOOR, g.MASTER_FLOOR_START, shadow,
                      "تقدير تقريبي")
    await send_card(ix, data, ephemeral=True)


@slash("مبارزة", "🥊 تحدَّ ظل لاعب آخر في مبارزة ودّية")
@app_commands.describe(member="اللاعب الذي ستواجه ظله")
@app_commands.rename(member="اللاعب")
async def duel(ix: discord.Interaction, member: discord.Member) -> None:
    uid = ix.user.id
    if member.bot or member.id == uid:
        raise GameError("اختر لاعباً آخر (ليس أنت ولا بوتاً).")
    if uid in bot.active:
        raise GameError("عندك معركة مفتوحة بالفعل!")
    wait = DUEL_COOLDOWN - (time.time() - bot.duel_last.get(uid, 0))
    if wait > 0:
        raise GameError(f"انتظر {int(wait)} ثانية قبل مبارزة جديدة.")
    target = await bot.db.get_user(member.id)
    if target is None:
        raise GameError("هذا اللاعب لم يبدأ رحلته بعد.")
    bot.active.add(uid)
    bot.duel_last[uid] = time.time()
    try:
        await ix.response.defer()
        u = await bot.db.ensure_user(uid, dname(ix.user))
        player = g.fighter_from_user(u, dname(ix.user), full_hp=True)   # المبارزة لا تستهلك صحتك
        enemy = g.shadow_fighter(target, f"ظل {dname(member)}")
        await start_battle(ix, g.Battle(player, enemy, bot.rng), "duel", target["floor"], "🥊 مبارزة الظلال", theme="blue", art_ctx="tower")
    except BaseException:
        bot.active.discard(uid)
        raise


# ═════════════════════════ الشخصية والنين ═════════════════════════
@slash("ملف", "📊 رخصة الصيّاد: بطاقة إحصائياتك")
@app_commands.describe(member="اتركه فارغاً لعرض ملفك")
@app_commands.rename(member="اللاعب")
async def profile(ix: discord.Interaction, member: discord.Member | None = None) -> None:
    await ix.response.defer()
    target = member or ix.user
    u = await bot.db.get_user(target.id)
    if u is None:
        raise GameError("لا يوجد ملف بعد. ابدأ رحلتك بكتابة «صعود»!")
    gname = None
    if u["guild_id"]:
        info = await bot.db.guild_info(target.id)
        gname = info["guild_name"] if info else None
    if u.get("title"):
        gname = f"{gname} · {u['title']}" if gname else u["title"]
    rank, stars = g.hunter_rank(u["floor"])
    u["nen"] = g.normalize_nen(u["nen_type"])
    vow = g.VOWS.get(u["vow"] or "")
    data = await draw(R.profile_card, u, await bot.avatar(target), rank, stars, g.floor_tier(u["floor"]), gname,
                      vow["name"] if vow else None, g.xp_needed(u["level"]))
    await send_card(ix, data)


@slash("اختبار", "🌊 اختبار الكأس والورقة لكشف فئة النين (الطابق 50+)")
@app_commands.describe(reroll="إعادة الاختبار مقابل جواهر")
@app_commands.rename(reroll="إعادة")
async def divination(ix: discord.Interaction, reroll: bool = False) -> None:
    await ix.response.defer()
    u = await bot.db.ensure_user(ix.user.id, dname(ix.user))
    if u["floor"] < g.NEN_UNLOCK_FLOOR:
        raise GameError(f"يجب أن تصل إلى الطابق {g.NEN_UNLOCK_FLOOR} أولاً (أنت في {u['floor']}).")
    current = g.normalize_nen(u["nen_type"])
    if current and not reroll:
        raise GameError(f"فئتك {g.nen_label(current)}. لإعادة الاختبار اكتب «اختبار إعادة» (تكلفة {g.REROLL_GEM_COST} 💎).")
    chosen = g.roll_nen(bot.rng)
    await bot.db.set_nen(ix.user.id, chosen, g.REROLL_GEM_COST if current else 0)
    art = await bot.hub.art("nen_test", timeout=2.0)
    data = await draw(R.nen_card, chosen, g.NEN[chosen], art, "اختبار الكأس والورقة", bool(current))
    await send_card(ix, data)
    await announce(ix.guild_id or 0, "level", f"🌊 **{dname(ix.user)}** أجرى اختبار الكأس وظهرت فئته: {g.nen_label(chosen)}")


@slash("مهارات", "🌀 اعرض فئة النين ومهارتك وسداسي التوافق")
async def skills(ix: discord.Interaction) -> None:
    await ix.response.defer(ephemeral=True)
    u = await bot.db.get_user(ix.user.id)
    nen = g.normalize_nen(u["nen_type"]) if u else None
    if not nen:
        data = await draw(R.list_card, "مهاراتك", "النين لم يُفتح بعد", [("🔒", "يُفتح عند الطابق", str(g.NEN_UNLOCK_FLOOR))], "🌀", "blue",
                          lines=["اصعد البرج ثم اكتب «اختبار» لكشف فئتك."])
    else:
        art = await bot.hub.art(nen, timeout=2.0)
        data = await draw(R.nen_card, nen, g.NEN[nen], art, "مهاراتك", False)
    await send_card(ix, data, ephemeral=True)


STAT_CHOICES = [app_commands.Choice(name="⚔️ هجوم (+2 لكل نقطة)", value="atk"), app_commands.Choice(name="🛡️ دفاع (+1)", value="def"),
                app_commands.Choice(name="❤️ صحة (+10)", value="hp"), app_commands.Choice(name="💨 سرعة (+1)", value="speed")]


@slash("تطوير", "📈 وزّع نقاط التطوير على إحصائياتك")
@app_commands.describe(stat="الإحصائية", amount="عدد النقاط")
@app_commands.rename(stat="الإحصائية", amount="العدد")
@app_commands.choices(stat=STAT_CHOICES)
async def upgrade(ix: discord.Interaction, stat: str, amount: app_commands.Range[int, 1, 100] = 1) -> None:
    await ix.response.defer(ephemeral=True)
    await bot.db.ensure_user(ix.user.id, dname(ix.user))
    u = await bot.db.upgrade_stat(ix.user.id, stat, amount)
    data = await draw(R.list_card, "تم التطوير", g.STAT_LABELS[stat].split(" ", 1)[1] if " " in g.STAT_LABELS[stat] else "",
                      [(g.STAT_LABELS[stat].split(" ")[0], "الزيادة", f"+{g.POINT_VALUE[stat] * amount}"),
                       ("⚔️", "الهجوم", str(u["t_atk"])), ("🛡️", "الدفاع", str(u["t_def"])), ("❤️", "الصحة", str(u["t_hp"])),
                       ("💨", "السرعة", str(u["t_speed"])), ("🎯", "نقاط متبقية", str(u["stat_points"]))], "📈", "win")
    await send_card(ix, data, ephemeral=True)


# ═════════════════════════ الحقيبة والسحب ═════════════════════════
INV_PER_PAGE = 9


async def inventory_image(user, page: int) -> tuple[bytes, int]:
    u = await bot.db.ensure_user(user.id, dname(user))
    items = await bot.db.inventory(user.id)
    pages = max(1, -(-len(items) // INV_PER_PAGE))
    page = max(1, min(page, pages))
    slots = {it["item_type"]: g.item_view(it) for it in items if it["is_equipped"]}
    chunk = [g.item_view(it) for it in items[(page - 1) * INV_PER_PAGE: page * INV_PER_PAGE]]
    data = await draw(R.inventory_card, chunk, slots, page, pages, len(items), dname(user), u["gold"], u["gems"])
    return data, pages


class InventoryView(OwnedView):
    def __init__(self, user, page: int, pages: int) -> None:
        super().__init__(user.id)
        self.user, self.page, self.pages = user, page, pages
        self._sync()

    def _sync(self) -> None:
        self.prev_btn.disabled = self.page <= 1
        self.next_btn.disabled = self.page >= self.pages

    async def _go(self, interaction: discord.Interaction, delta: int) -> None:
        await interaction.response.defer()
        self.page += delta
        data, self.pages = await inventory_image(self.user, self.page)
        self.page = max(1, min(self.page, self.pages))
        self._sync()
        await self.push(interaction, data)

    @discord.ui.button(label="التالي", emoji="◀️", style=discord.ButtonStyle.secondary)
    async def next_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self._go(interaction, +1)

    @discord.ui.button(label="السابق", emoji="▶️", style=discord.ButtonStyle.secondary)
    async def prev_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self._go(interaction, -1)


@slash("حقيبة", "🎒 حقيبتك وعتادك المجهّز")
@app_commands.describe(page="رقم الصفحة")
@app_commands.rename(page="الصفحة")
async def inventory(ix: discord.Interaction, page: app_commands.Range[int, 1, 50] = 1) -> None:
    await ix.response.defer(ephemeral=True)
    data, pages = await inventory_image(ix.user, page)
    await send_card(ix, data, InventoryView(ix.user, min(page, pages), pages), ephemeral=True)


CURRENCY_CHOICES = [app_commands.Choice(name=f"💰 ذهب ({g.GACHA_GOLD_COST})", value="gold"),
                    app_commands.Choice(name=f"💎 جواهر ({g.GACHA_GEM_COST})", value="gems")]


class PullAgainView(OwnedView):
    """أزرار «سحب مرة أخرى» تحت النتيجة: سحب فوري ×1 أو ×10 بدون إعادة كتابة الأمر."""

    def __init__(self, owner_id: int, pull, currency: str) -> None:
        super().__init__(owner_id, timeout=240)
        self.pull, self.currency = pull, currency

    async def _again(self, interaction: discord.Interaction, n: int) -> None:
        await interaction.response.defer()
        try:
            data, content = await self.pull(interaction.user, self.currency, n)
        except GameError as e:
            await interaction.followup.send(f"❌ {e}", ephemeral=True)
            return
        await interaction.edit_original_response(content=content, attachments=[to_file(data)], view=self)

    @discord.ui.button(label="سحب مرة أخرى ×1", emoji="🔁", style=discord.ButtonStyle.primary)
    async def one_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self._again(interaction, 1)

    @discord.ui.button(label="سحب ×10", emoji="⚡", style=discord.ButtonStyle.success)
    async def ten_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self._again(interaction, 10)


async def do_gacha(user, currency: str, count: int, guild_id: int = 0) -> tuple[bytes, str | None]:
    items = await bot.db.gacha_pull(user.id, currency, bot.rng, count)
    cost = (g.GACHA_GOLD_COST if currency == "gold" else g.GACHA_GEM_COST) * count
    spent = f"{cost} {'ذهب' if currency == 'gold' else 'جوهرة'}"
    views = [g.item_view({"item_id": it["item_id"], "item_name": it["name"], "item_type": it["type"], "stat": it["stat"],
                          "stat_bonus": it["bonus"], "rarity": it["rarity"]}) for it in items]
    best = max(v["rarity"] for v in views)
    data = await draw(R.gacha_result_card, views, items[-1]["pity"], g.PITY_LIMIT, spent, best, "سحب الحظ", "🃏")
    for v in views:
        if v["rarity"] >= GACHA_ANNOUNCE_MIN_RARITY:
            await announce(guild_id, "gacha", f"🌟 **{dname(user)}** سحب عنصراً **أسطورياً**: {v['emoji']} {v['name']} ({v['bonus_text']})!")
    return data, None


@slash("سحب", "🃏 اسحب بطاقات حظ (عتاد أو مرافق أو بطاقة شفاء) — نتيجة فورية")
@app_commands.describe(currency="طريقة الدفع", count="عدد السحبات (1 إلى 10)")
@app_commands.rename(currency="العملة", count="العدد")
@app_commands.choices(currency=CURRENCY_CHOICES)
async def gacha(ix: discord.Interaction, currency: str, count: app_commands.Range[int, 1, 10] = 1) -> None:
    await ix.response.defer()
    await bot.db.ensure_user(ix.user.id, dname(ix.user))
    gid = ix.guild_id or 0

    async def pull(user, cur, n):
        return await do_gacha(user, cur, n, gid)

    idn.use("gacha", "result")
    data, content = await pull(ix.user, currency, count)
    await send_card(ix, data, PullAgainView(ix.user.id, pull, currency), content=content)


# ───────────────────────── بطاقات الأبطال والفريق ─────────────────────────
SUMMON_CHOICES = [app_commands.Choice(name=f"💰 ذهب ({cd.SUMMON_GOLD_COST})", value="gold"),
                  app_commands.Choice(name=f"💎 جواهر ({cd.SUMMON_GEM_COST})", value="gems")]


async def do_summon(user, currency: str, count: int, guild_id: int = 0) -> tuple[bytes, str | None]:
    u = await bot.db.get_user(user.id)
    res = await bot.db.summon(user.id, currency, count, bot.rng)
    results = res["cards"]
    arts = await bot.hub.card_arts([cd.CARDS[r["key"]] for r in results], budget=5.0)
    data = await draw(R.summon_result_card, results, res["pity"], currency, res["cost"], dname(user), arts)
    tip = None
    if any(r["is_new"] for r in results) and not ((u or {}).get("team") or ""):
        tip = "💡 اكتب «فريق» ثم أسماء أبطالك لتجهيزهم: يقاتلون معك بإحصائياتهم وبزر «نداء الفريق»، وبعضهم يمنحك قدرات «هاتسو» خاصة."
    for r in results:
        if r["r"] >= GACHA_ANNOUNCE_MIN_RARITY and r["is_new"]:
            c = cd.CARDS[r["key"]]
            await announce(guild_id, "gacha", f"🌟 **{dname(user)}** استدعى بطلاً **أسطورياً**: 🎴 {c['name']}!")
    return data, tip


@slash("استدعاء", "🎴 استدعِ أبطال الأنمي كبطاقات تقاتل معك في الفريق — نتيجة فورية")
@app_commands.describe(currency="طريقة الدفع", count="عدد الاستدعاءات (1 إلى 10)")
@app_commands.rename(currency="العملة", count="العدد")
@app_commands.choices(currency=SUMMON_CHOICES)
async def summon_cmd(ix: discord.Interaction, currency: str, count: app_commands.Range[int, 1, 10] = 1) -> None:
    await ix.response.defer()
    await bot.db.ensure_user(ix.user.id, dname(ix.user))
    gid = ix.guild_id or 0

    async def pull(user, cur, n):
        return await do_summon(user, cur, n, gid)

    idn.use("summon", "result")
    data, tip = await pull(ix.user, currency, count)
    await send_card(ix, data, PullAgainView(ix.user.id, pull, currency), content=tip)


@slash("بطاقة", "🎴 تفاصيل بطل: قوته ومهارته وعدد نسخك منه")
@app_commands.describe(name="اسم الشخصية (عربي أو إنجليزي)")
@app_commands.rename(name="الاسم")
async def card_cmd(ix: discord.Interaction, name: str) -> None:
    await ix.response.defer()
    card = cd.find(name)
    if card is None:
        raise GameError(f"ما لقيت بطلاً باسم «{name[:30]}». اكتب «ألبوم» لتشوف كل الأبطال.")
    owned = {c["key"]: c["copies"] for c in await bot.db.cards_of(ix.user.id)}
    art = await bot.hub.card_art(card, budget=6.0)
    await send_card(ix, await draw(R.card_detail_card, card, art, owned.get(card["key"], 0), dname(ix.user)))


async def album_image(user, page: int) -> tuple[bytes, int, int]:
    """يرسم صفحة الألبوم. يعيد (الصورة، رقم الصفحة بعد التصحيح، عدد الصفحات)."""
    pages = R.album_pages()
    page = max(0, min(pages - 1, page))
    u = await bot.db.get_user(user.id)
    owned = {c["key"]: c["copies"] for c in await bot.db.cards_of(user.id)}
    keys = cd.ORDER[page * R.ALBUM_PER_PAGE:(page + 1) * R.ALBUM_PER_PAGE]
    arts = await bot.hub.card_arts([cd.CARDS[k] for k in keys if k in owned], budget=5.0)
    team = [k for k in ((u or {}).get("team") or "").split(",") if k]
    return await draw(R.album_card, owned, page, dname(user), arts, team), page, pages


class AlbumView(OwnedView):
    def __init__(self, user, page: int, pages: int) -> None:
        super().__init__(user.id, timeout=240)
        self.user, self.page, self.pages = user, page, pages
        self._sync()

    def _sync(self) -> None:
        self.prev_btn.disabled = self.page <= 0
        self.next_btn.disabled = self.page >= self.pages - 1

    async def _go(self, interaction: discord.Interaction, delta: int) -> None:
        await interaction.response.defer()
        data, self.page, self.pages = await album_image(self.user, self.page + delta)
        self._sync()
        await self.push(interaction, data)

    @discord.ui.button(label="التالي", emoji="◀️", style=discord.ButtonStyle.secondary)
    async def next_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self._go(interaction, +1)

    @discord.ui.button(label="السابق", emoji="▶️", style=discord.ButtonStyle.secondary)
    async def prev_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self._go(interaction, -1)


@slash("ألبوم", "📚 ألبوم بطاقاتك (ما تملكه وما ينقصك)")
@app_commands.describe(page="رقم الصفحة")
@app_commands.rename(page="الصفحة")
async def album_cmd(ix: discord.Interaction, page: app_commands.Range[int, 1, 20] = 1) -> None:
    await ix.response.defer(ephemeral=True)
    data, page0, pages = await album_image(ix.user, page - 1)
    await send_card(ix, data, AlbumView(ix.user, page0, pages), ephemeral=True)


_CARD_SEP = re.compile(r"[,،+\n]+|\s+و\s+")
CLEAR_WORDS = {"مسح", "افراغ", "تفريغ", "ازاله", "حذف", "clear"}


def _exact_card(phrase: str) -> dict | None:
    q = cd.norm(phrase)
    for c in cd.CARDS.values():
        if q in (cd.norm(c["name"]), cd.norm(c["en"]), *(cd.norm(a) for a in c["aliases"])):
            return c
    return None


def parse_card_names(text: str) -> list[dict]:
    """«غون كيلوا ليورو» أو «غون، كيلوا» ← بطاقات. الاسم المركب (مثل «غون فريكس») يُلتقط إن طابق تماماً."""
    parts = [p.strip() for p in _CARD_SEP.split(text) if p.strip()]
    found: list[dict] = []

    def add(c: dict | None, raw: str) -> None:
        if c is None:
            raise GameError(f"ما لقيت بطلاً باسم «{raw[:30]}». اكتب «ألبوم» لتشوف الأسماء.")
        if c not in found:
            found.append(c)

    for part in parts:
        toks = part.split()
        i = 0
        while i < len(toks):
            for n in (3, 2, 1):
                c = _exact_card(" ".join(toks[i:i + n])) if i + n <= len(toks) else None
                if c:
                    add(c, toks[i])
                    i += n
                    break
            else:
                add(cd.find(toks[i]), toks[i])
                i += 1
    return found


async def team_image(user, u: dict) -> bytes:
    members = [{"key": m["key"], "stars": m["stars"]} for m in (u.get("team_cards") or [])]
    arts = await bot.hub.card_arts([cd.CARDS[m["key"]] for m in members], budget=5.0)
    return await draw(R.team_card, members, u.get("team_bonus") or {}, dname(user), arts)


@slash("فريق", f"🎴 اعرض فريقك أو اختر أبطاله (حتى {cd.TEAM_SIZE}) — «فريق مسح» لإفراغه")
@app_commands.describe(names="أسماء الأبطال، مثال: غون كيلوا ليورو (اتركه فارغاً لعرض فريقك)")
@app_commands.rename(names="الأسماء")
async def team_cmd(ix: discord.Interaction, names: str = "") -> None:
    await ix.response.defer()
    u = await bot.db.ensure_user(ix.user.id, dname(ix.user))
    text = names.strip()
    if text:
        if cd.norm(text) in CLEAR_WORDS:
            keys: list[str] = []
        else:
            keys = [c["key"] for c in parse_card_names(text)]
        await bot.db.set_team(ix.user.id, keys)
        u = await bot.db.get_user(ix.user.id)
    await send_card(ix, await team_image(ix.user, u))


async def item_result(ix, title: str, rows: list, emoji: str, theme: str = "default", lines: list[str] | None = None) -> None:
    await send_card(ix, await draw(R.list_card, title, "", rows, emoji, theme, lines=lines), ephemeral=True)


@slash("تجهيز", "🛡️ جهّز عنصراً من حقيبتك")
@app_commands.describe(item_id="رقم العنصر من «حقيبة»")
@app_commands.rename(item_id="الرقم")
async def equip(ix: discord.Interaction, item_id: int) -> None:
    await ix.response.defer(ephemeral=True)
    it = g.item_view(await bot.db.equip(ix.user.id, item_id), equipped=True)
    await item_result(ix, "تم التجهيز", [(it["emoji"], it["name"], it["bonus_text"])], "🛡️", "win")


@slash("استخدام", "📜 استخدم بطاقة شفاء")
@app_commands.describe(item_id="رقم البطاقة من «حقيبة»")
@app_commands.rename(item_id="الرقم")
async def use_card(ix: discord.Interaction, item_id: int) -> None:
    await ix.response.defer(ephemeral=True)
    r = await bot.db.use_spell(ix.user.id, item_id)
    await item_result(ix, "تم الشفاء", [("💚", r["name"], f"+{r['healed']} صحة"), ("❤️", "صحتك الآن", f"{r['hp']} / {r['max']}")], "📜", "win")


@slash("بيع", "💰 بِع عنصراً من حقيبتك")
@app_commands.describe(item_id="رقم العنصر")
@app_commands.rename(item_id="الرقم")
async def sell(ix: discord.Interaction, item_id: int) -> None:
    await ix.response.defer(ephemeral=True)
    it, price = await bot.db.sell(ix.user.id, item_id)
    await item_result(ix, "تم البيع", [(g.item_emoji(it["item_name"], it["item_type"]), it["item_name"], f"{price} 💰")], "💰", "gold")


@slash("يومي", "🎁 مكافأتك اليومية")
async def daily(ix: discord.Interaction) -> None:
    await ix.response.defer(ephemeral=True)
    await bot.db.ensure_user(ix.user.id, dname(ix.user))
    r = await bot.db.claim_daily(ix.user.id)
    await item_result(ix, "مكافأتك اليومية", [("💰", "ذهب", f"+{r['gold']}"), ("💎", "جواهر", f"+{r['gems']}"), ("🔥", "سلسلة الأيام", str(r["streak"]))],
                      "🎁", "gold", lines=["تابع كل يوم لتزيد المكافأة، وكل 7 أيام جواهر إضافية!"])


RANK_CHOICES = [app_commands.Choice(name="🏰 الطابق", value="floor"), app_commands.Choice(name="⭐ المستوى", value="level"),
                app_commands.Choice(name="💰 الثروة", value="gold"), app_commands.Choice(name="🏆 الانتصارات", value="wins"),
                app_commands.Choice(name="👹 الزعيم", value="boss")]


@slash("ترتيب", "🏆 ترتيب أقوى المقاتلين")
@app_commands.describe(by="نوع الترتيب")
@app_commands.rename(by="النوع")
@app_commands.choices(by=RANK_CHOICES)
async def top(ix: discord.Interaction, by: str = "floor") -> None:
    await ix.response.defer()
    if by == "boss":
        boss, _ = await bot.db.ensure_boss(ix.guild_id or 0)
        board = await bot.db.boss_board(boss["boss_id"], None, 10)
        rows = [{"name": t["name"] or str(t["user_id"]), "value": f"{t['damage']:,}", "extra": f"{t['hits']} ضربة"} for t in board["top"]]
        data = await draw(R.leaderboard_card, "ضرر الزعيم", "👹", rows, " 💥")
    else:
        players = await bot.db.top_players(10, by)
        if not players:
            raise GameError("لا يوجد لاعبون بعد.")
        meta = {"floor": ("أبطال البرج", "🏆", lambda r: str(r["floor"]), " 🏰"), "level": ("أعلى المستويات", "⭐", lambda r: str(r["level"]), " ⭐"),
                "gold": ("الأثرياء", "💰", lambda r: f"{r['gold']:,}", " 💰"), "wins": ("أكثر انتصاراً", "🏆", lambda r: str(r["wins"]), " ⚔️")}[by]
        rows = [{"name": r["username"] or str(r["user_id"]), "value": meta[2](r), "extra": f"الطابق {r['floor']} · مستوى {r['level']}"} for r in players]
        data = await draw(R.leaderboard_card, meta[0], meta[1], rows, meta[3])
    await send_card(ix, data)


# ═════════════════════════ المتجر والتحويل والنذور ═════════════════════════
class ShopView(OwnedView):
    def __init__(self, user) -> None:
        super().__init__(user.id)
        self.user = user
        for key, name, pct, price, rarity in g.SHOP:
            b = discord.ui.Button(label=f"{name} — {price}", emoji="💚", style=discord.ButtonStyle.success)
            b.callback = self._make(key)
            self.add_item(b)

    def _make(self, key: str):
        async def cb(interaction: discord.Interaction) -> None:
            await interaction.response.defer()
            try:
                r = await bot.db.buy_spell(self.user.id, key)
                note = f"✅ اشتريت {r['name']} بـ {r['cost']} 💰"
            except GameError as e:
                note = f"❌ {e}"
            await interaction.edit_original_response(attachments=[to_file(await shop_image(self.user, note))], view=self)
        return cb


async def shop_image(user, note: str = "") -> bytes:
    u = await bot.db.ensure_user(user.id, dname(user))
    rows = [("📜", f"{name} (+{pct}% شفاء)", f"{price} 💰") for _, name, pct, price, _ in g.SHOP]
    art = await bot.hub.art("shop", timeout=2.0)
    return await draw(R.list_card, "المتجر", "بطاقات شفاء فورية", rows, "🛒", "gold", art, lines=[note or "اختر بطاقة بالأزرار أدناه."],
                      chips=[("💰", f"{u['gold']:,}"), ("💎", f"{u['gems']:,}")])


@slash("متجر", "🛒 اشترِ بطاقات شفاء بالذهب")
async def shop(ix: discord.Interaction) -> None:
    await ix.response.defer(ephemeral=True)
    await send_card(ix, await shop_image(ix.user), ShopView(ix.user), ephemeral=True)


@slash("تحويل", "🤝 حوّل ذهباً للاعب آخر (ضريبة 5%)")
@app_commands.describe(member="المستلم", amount="المبلغ")
@app_commands.rename(member="اللاعب", amount="المبلغ")
async def transfer(ix: discord.Interaction, member: discord.Member, amount: app_commands.Range[int, 1, 10_000_000]) -> None:
    if member.bot:
        raise GameError("لا يمكنك التحويل لبوت.")
    await ix.response.defer()
    await bot.db.ensure_user(ix.user.id, dname(ix.user))
    r = await bot.db.transfer_gold(ix.user.id, member.id, amount)
    data = await draw(R.list_card, "تم التحويل", f"إلى {dname(member)}", [("💰", "المبلغ المرسل", f"{r['sent']:,}"),
                      ("🧾", "الضريبة (تُحرق)", f"{r['tax']:,}"), ("🤝", "وصل للمستلم", f"{r['received']:,}")], "🤝", "gold")
    await send_card(ix, data)


VOW_CHOICES = [app_commands.Choice(name=f"{v['emoji']} {v['name'].split(' ', 1)[1]}", value=k) for k, v in g.VOWS.items()] + \
              [app_commands.Choice(name="🔓 فك", value="none")]


@slash("نذر", "🩸 اقطع نذراً مقابل قوة (النذور والقيود). بدون خيار يعرض نذرك")
@app_commands.describe(vow="النذر")
@app_commands.rename(vow="النذر")
@app_commands.choices(vow=VOW_CHOICES)
async def vow_cmd(ix: discord.Interaction, vow: str | None = None) -> None:
    await ix.response.defer(ephemeral=True)
    u = await bot.db.ensure_user(ix.user.id, dname(ix.user))
    cost = 0
    if vow:
        cost = await bot.db.set_vow(ix.user.id, "" if vow == "none" else vow)
        u["vow"] = "" if vow == "none" else vow
    cur = g.VOWS.get(u["vow"] or "")
    lines = [f"نذرك الحالي: {cur['emoji']} {cur['name']}", cur["desc"]] if cur else ["لا نذر حالياً. القيود تمنحك قوة أكبر!"]
    if vow and cost:
        lines.append(f"دفعت {cost} 💎 لتغيير النذر.")
    lines += [f"{v['emoji']} {v['name']}: {v['desc']}" for v in g.VOWS.values()] if not vow else []
    art = await bot.hub.art("vow", timeout=2.0)
    data = await draw(R.list_card, "النذور والقيود", f"أول نذر مجاني، التغيير يكلّف {g.VOW_SWITCH_GEMS} 💎", [], "🩸", "boss", art, lines=lines,
                      footer="اكتب: نذر دم / صمت / غضب / جشع / فك")
    await send_card(ix, data, ephemeral=True)


# ═════════════════════════ العصابات والحرب ═════════════════════════
GANG_ACTIONS = [app_commands.Choice(name=n, value=v) for n, v in (
    ("معلومات", "info"), ("تأسيس", "create"), ("انضمام", "join"), ("مغادرة", "leave"), ("قبول", "accept"), ("طرد", "kick"),
    ("تعيين", "setrole"), ("إيداع", "deposit"), ("حرب", "war"), ("طلبات", "requests"))]


async def gang_image(user) -> bytes:
    info = await bot.db.guild_info(user.id)
    if not info:
        raise GameError(f"أنت لست في عصابة. أسّس واحدة بـ «عصابة تأسيس اسم» (الطابق {ht.GANG_MIN_FLOOR} + {ht.GANG_COST_GOLD:,} ذهب + "
                        f"{ht.GANG_COST_GEMS} جوهرة) أو اطلب الانضمام بـ «عصابة انضمام اسم».")
    art = await bot.hub.art("gang", timeout=2.0)
    return await draw(R2.gang_card, info, user.id, art)


async def _gang_role_ops(guild: discord.Guild | None, member, *, add: list[int] = (), remove: list[int] = ()) -> str:
    """يضيف/يزيل رتب ديسكورد للعضو. لا يفشل أبداً؛ يعيد ملاحظة إن تعذّر بسبب الصلاحيات."""
    if guild is None or member is None:
        return ""
    try:
        add_roles = [r for r in (guild.get_role(i) for i in add if i) if r]
        rem_roles = [r for r in (guild.get_role(i) for i in remove if i) if r]
        if add_roles:
            await member.add_roles(*add_roles, reason="عصابات برج المعارك")
        if rem_roles:
            await member.remove_roles(*rem_roles, reason="عصابات برج المعارك")
    except (discord.Forbidden, discord.HTTPException):
        return "⚠️ تعذّر تعديل رتب ديسكورد: أعطِ البوت صلاحية «إدارة الرتب» وارفع رتبته فوق رتب العصابات."
    return ""


async def _gang_create_roles(ix, gang: dict) -> str:
    try:
        lr = await ix.guild.create_role(name=f"[زعيم عصابة: {gang['name']}]"[:100], colour=discord.Colour.gold(), hoist=True, mentionable=False,
                                        reason="تأسيس عصابة")
        mr = await ix.guild.create_role(name=f"[عصابة: {gang['name']}]"[:100], colour=discord.Colour.dark_red(), mentionable=False,
                                        reason="تأسيس عصابة")
        await bot.db.gang_set_roles(gang["gang_id"], lr.id, mr.id)
        await ix.user.add_roles(lr, mr, reason="تأسيس عصابة")
    except (discord.Forbidden, discord.HTTPException):
        return "⚠️ ما قدرت أنشئ رتب العصابة: أعطِ البوت صلاحية «إدارة الرتب» وارفع رتبته فوق الرتب العادية، ثم أعد التأسيس بعد المغادرة."
    return ""


def _gang_money_args(text: str | None) -> tuple[str, int]:
    toks = (text or "").replace(",", "").replace("،", "").split()
    cur, amount = None, None
    for t in toks:
        n = strip_al(norm(t))
        if n in ("ذهب", "gold", "دهب"):
            cur = "gold"
        elif n in ("جواهر", "جوهره", "gems", "gem", "جوهرة"):
            cur = "gems"
        else:
            digits = t.translate(str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789"))
            if digits.isdigit():
                amount = int(digits)
    if cur is None or amount is None:
        raise GameError("الصيغة: عصابة إيداع ذهب 1000  (أو جواهر 20)")
    return cur, amount


@slash("عصابة", "🏴 العصابات: معلومات · تأسيس · انضمام · قبول · طرد · تعيين · إيداع · حرب")
@app_commands.describe(action="الإجراء (اتركه فارغاً لمعلومات عصابتك)", member="اللاعب (للقبول أو الطرد أو التعيين)",
                       name="الاسم، أو الرتبة (نائب/عضو)، أو «ذهب 1000» للإيداع")
@app_commands.rename(action="الإجراء", member="اللاعب", name="النص")
@app_commands.choices(action=GANG_ACTIONS)
async def gang_cmd(ix: discord.Interaction, action: str = "info", member: discord.Member | None = None, name: str | None = None) -> None:
    await gang_action(ix, action, member, name)


async def gang_action(ix, action: str, member, name: str | None) -> None:
    idn.use("gang", action)                 # خلفية خاصة لكل إجراء (معلومات/تأسيس/انضمام/خزينة/حرب...)
    await ix.response.defer()
    uid, db = ix.user.id, bot.db
    await db.ensure_user(uid, dname(ix.user))
    if action == "info":
        await send_card(ix, await gang_image(ix.user))
    elif action == "create":
        if not name:
            raise GameError("اكتب اسم العصابة: عصابة تأسيس الصقور")
        gang = await db.create_guild(uid, name, ix.guild_id or 0)
        warn = await _gang_create_roles(ix, gang)
        await send_card(ix, await draw(R.list_card, "تأسست عصابة!", gang["name"],
                                       [("👑", "الزعيم", dname(ix.user)), ("💰", "رسوم التأسيس", f"{ht.GANG_COST_GOLD:,} ذهب + {ht.GANG_COST_GEMS} جوهرة")],
                                       "🏴", "gold", await bot.hub.art("gang", timeout=2.0),
                                       lines=[f"يطلب الآخرون الانضمام بـ «عصابة انضمام {gang['name']}» وتقبلهم أنت بـ «عصابة قبول @لاعب»"]),
                        content=warn or None)
        await announce(ix.guild_id or 0, "war", f"🏴 **{dname(ix.user)}** أسّس عصابة **{gang['name']}**!")
    elif action == "join":
        if not name:
            raise GameError("اكتب اسم العصابة: عصابة انضمام الصقور")
        res = await db.join_guild(uid, name)
        await send_card(ix, await draw(R.list_card, "أُرسل طلبك!", res["name"], [("🏴", "العصابة", res["name"]), ("⏳", "الحالة", "بانتظار قبول الزعيم أو النائب")], "📨", "win"))
        await ix.followup.send(f"📨 <@{res['leader_id']}> — **{dname(ix.user)}** يطلب الانضمام لعصابتك. اقبله بـ «عصابة قبول @{dname(ix.user)}»",
                               allowed_mentions=discord.AllowedMentions(users=True))
    elif action == "requests":
        info = await db.guild_info(uid)
        if not info:
            raise GameError("أنت لست في عصابة.")
        rows = [("📨", r["username"], f"مستوى {r['level']} · طابق {r['floor']}") for r in info["requests"][:12]] or [("✅", "لا طلبات", "—")]
        await send_card(ix, await draw(R.list_card, "طلبات الانضمام", info["guild_name"], rows, "📨"), ephemeral=True)
    elif action == "accept":
        if member is None:
            raise GameError("منشن اللاعب: عصابة قبول @لاعب")
        res = await db.gang_accept(uid, member.id)
        warn = await _gang_role_ops(ix.guild, member, add=[res["member_role"]])
        await send_card(ix, await draw(R.list_card, "انضم عضو جديد!", res["name"], [("🧑", "العضو", dname(member)), ("🏴", "العصابة", res["name"])], "✅", "win"),
                        content=warn or None)
        await ix.followup.send(f"🏴 {member.mention} انضم إلى **{res['name']}**!", allowed_mentions=discord.AllowedMentions(users=[member]))
    elif action == "kick":
        if member is None:
            raise GameError("منشن اللاعب: عصابة طرد @لاعب")
        res = await db.gang_kick(uid, member.id)
        warn = await _gang_role_ops(ix.guild, member, remove=[res["member_role"], res["leader_role"]])
        await send_card(ix, await draw(R.list_card, "تم الطرد", res["name"], [("🚪", "العضو", dname(member))], "🚪", "lose"), content=warn or None)
    elif action == "setrole":
        if member is None or not name:
            raise GameError("الصيغة: عصابة تعيين @لاعب نائب   (أو عضو)")
        role = {"نائب": "deputy", "نايب": "deputy", "deputy": "deputy", "عضو": "member", "member": "member"}.get(norm(name.split()[0]))
        if role is None:
            raise GameError("الرتبة: نائب أو عضو.")
        res = await db.gang_set_role(uid, member.id, role)
        await send_card(ix, await draw(R.list_card, "تغيير رتبة", res["name"], [("🛡️" if role == "deputy" else "🧑", dname(member), ht.GANG_ROLES[role])], "🏴"))
    elif action == "deposit":
        cur, amount = _gang_money_args(name)
        res = await db.gang_deposit(uid, cur, amount)
        e = "💰" if cur == "gold" else "💎"
        await send_card(ix, await draw(R.list_card, "إيداع في الخزينة", res["name"], [(e, "أودعت", f"{amount:,}"), ("🏦", "رصيد الخزينة", f"{res['treasury']:,}")], "🏦", "gold"))
    elif action == "leave":
        res = await db.leave_guild(uid)
        warn = await _gang_role_ops(ix.guild, ix.user, remove=[res["member_role"], res["leader_role"]])
        lines = []
        if res["disbanded"]:
            for rid in (res["leader_role"], res["member_role"]):
                role = ix.guild.get_role(rid) if rid else None
                if role:
                    try:
                        await role.delete(reason="حل العصابة")
                    except (discord.Forbidden, discord.HTTPException):
                        pass
            lines.append("حُلّت العصابة لأنك كنت آخر عضو.")
        elif res["new_leader"]:
            nl = ix.guild.get_member(res["new_leader"])
            warn += await _gang_role_ops(ix.guild, nl, add=[res["leader_role"]])
            lines.append(f"انتقلت القيادة إلى {dname(nl) if nl else res['new_leader']}.")
        await send_card(ix, await draw(R.list_card, "غادرت العصابة", res["name"], [("👋", "العصابة", res["name"])], "👋", lines=lines), ephemeral=True,
                        content=warn or None)
    elif action == "war":
        await _declare_war(ix, name)


async def _declare_war(ix, name: str | None) -> None:
    uid = ix.user.id
    if name:
        w = await bot.db.declare_war(uid, name, ix.guild_id or 0)
        await announce(ix.guild_id or 0, "war", f"⚔️ **{w['name_a']}** تعلن الحرب على **{w['name_b']}**! تستمر {g.WAR_DURATION_H} ساعة — "
                                                f"الفائزة تسلب بين {round(ht.STEAL_PCT[0] * 100)}% و{round(ht.STEAL_PCT[1] * 100)}% من خزينة الخاسرة!")
    else:
        w = await bot.db.war_status(uid)
        if not w:
            raise GameError("عصابتك ليست في حرب. الزعيم يعلنها بكتابة «حرب اسم_العصابة».")
    await send_card(ix, await draw(R.war_card, war_dict(w)))


@slash("تأسيس", "🏴 أسّس عصابة جديدة (اختصار)")
@app_commands.describe(name="اسم العصابة")
@app_commands.rename(name="الاسم")
async def gang_create_short(ix: discord.Interaction, name: str) -> None:
    await gang_action(ix, "create", None, name)


@slash("انضمام", "✅ اطلب الانضمام إلى عصابة بالاسم (اختصار)")
@app_commands.describe(name="اسم العصابة")
@app_commands.rename(name="الاسم")
async def gang_join_short(ix: discord.Interaction, name: str) -> None:
    await gang_action(ix, "join", None, name)


@slash("مغادرة", "👋 غادر عصابتك (اختصار)")
async def gang_leave_short(ix: discord.Interaction) -> None:
    await gang_action(ix, "leave", None, None)


def war_dict(w: dict, uid_guild: int | None = None) -> dict:
    left = w["end_ts"] - time.time()
    a, b = w["score_a"], w["score_b"]
    note = "تعادل حتى الآن!" if a == b else f"تتقدم عصابة {w['name_a'] if a > b else w['name_b']}"
    return {**w, "time_left": f"باقي {fmt_dur(left)}", "note": note}


@slash("حرب", "⚔️ أعلن حرباً على عصابة، أو اعرض حربك الحالية")
@app_commands.describe(name="اسم العصابة المعادية (اتركه فارغاً لعرض الحرب الحالية)")
@app_commands.rename(name="العصابة")
async def war(ix: discord.Interaction, name: str | None = None) -> None:
    await ix.response.defer()
    await bot.db.ensure_user(ix.user.id, dname(ix.user))
    await _declare_war(ix, name)


# ═════════════════════════ الزعيم ═════════════════════════
def boss_template(b: dict) -> dict:
    return next((t for t in g.BOSSES if t["key"] == b["boss_key"]), g.BOSSES[0])


async def boss_image(user, boss: dict, note: str = "") -> bytes:
    tpl = boss_template(boss)
    board = await bot.db.boss_board(boss["boss_id"], user.id)
    now = time.time()
    if boss["status"] == "active":
        left = fmt_dur(boss["end_ts"] - now)
        note = note or "الضربة الأخيرة تنال جائزة إضافية"
    else:
        res = boss["end_ts"] + g.BOSS_RESPAWN_H * 3600 - now
        left = "انتهى" if res <= 0 else f"التالي بعد {fmt_dur(res)}"
        note = "هُزم!" if boss["status"] == "dead" else "هرب الزعيم..."
    art = await bot.hub.art("boss", tpl["search"], timeout=2.0)
    idn.use("boss", "fight")
    return await draw(R.boss_card, {"name": tpl["name"], "title": tpl["title"], "emoji": tpl["emoji"], "hp": boss["hp"], "max_hp": boss["max_hp"]},
                      art, [{"name": t["name"] or str(t["user_id"]), "damage": t["damage"]} for t in board["top"]],
                      board["me"], left, board["attempts_left"], note)


class BossView(OwnedView):
    def __init__(self, user, boss: dict) -> None:
        super().__init__(user.id, timeout=240)
        self.user, self.boss = user, boss
        self.attack_btn.disabled = boss["status"] != "active"

    @discord.ui.button(label="هاجم الزعيم", emoji="⚔️", style=discord.ButtonStyle.danger)
    async def attack_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        uid = interaction.user.id
        if uid in bot.active:
            await interaction.response.send_message("❌ عندك معركة مفتوحة بالفعل!", ephemeral=True)
            return
        await interaction.response.defer()
        bot.active.add(uid)
        try:
            u = await bot.db.ensure_user(uid, dname(interaction.user))
            b = await bot.db.boss_begin(uid, self.boss["boss_id"])
            tpl = boss_template(b)
            enemy = g.boss_fighter(tpl, b["hp"], bot.rng, u["floor"])
            enemy.max_hp = b["max_hp"]          # الشريط يعرض مخزون الزعيم الكامل
            player = g.fighter_from_user(u, dname(interaction.user), full_hp=True)
            battle = g.Battle(player, enemy, bot.rng)
            battle.max_rounds, battle.timeout_result = g.BOSS_ROUNDS, "timeout"
            p_art = await bot.avatar(interaction.user)
            e_art = await bot.hub.art("boss", tpl["search"], timeout=2.0)
            view = BattleView(uid, battle, "boss", 0, f"👹 {tpl['name']} — {g.BOSS_ROUNDS} جولات", server_id=interaction.guild_id or 0,
                              name=dname(interaction.user), theme="boss", player_art=p_art, enemy_art=e_art, boss=b,
                              bg=bot.hub.local_art(f"bgb_{tpl['key']}") or bot.hub.local_art("bg_boss"),      # خلفية خاصة بكل زعيم
                              team_arts=team_arts_for(player))
            msg = await interaction.followup.send(file=to_file(await draw(view.card)), view=view, wait=True)
            view.message = msg
        except BaseException:
            bot.active.discard(uid)
            if isinstance(sys.exc_info()[1], GameError):
                await interaction.followup.send(f"❌ {sys.exc_info()[1]}", ephemeral=True)
                return
            raise

    @discord.ui.button(label="تحديث", emoji="🔄", style=discord.ButtonStyle.secondary)
    async def refresh_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.defer()
        boss, _ = await bot.db.ensure_boss(interaction.guild_id or 0)
        self.boss = boss
        self.attack_btn.disabled = boss["status"] != "active"
        await self.push(interaction, await boss_image(self.user, boss))


@slash("زعيم", "👹 زعيم الأسبوع: اضربه مع بقية اللاعبين لتنالوا الغنائم")
async def boss_cmd(ix: discord.Interaction) -> None:
    await ix.response.defer()
    await bot.db.ensure_user(ix.user.id, dname(ix.user))
    boss, settle = await bot.db.ensure_boss(ix.guild_id or 0, bot.rng)
    if settle:
        await announce_settle(ix.guild_id or 0, settle)
    if boss["status"] == "active" and abs(boss["start_ts"] - time.time()) < 5:
        tpl = boss_template(boss)
        await announce(ix.guild_id or 0, "boss", f"👹 **ظهر زعيم جديد: {tpl['name']}** — {tpl['title']}! اكتبوا «زعيم» وانضموا للهجوم!")
    await send_card(ix, await boss_image(ix.user, boss), BossView(ix.user, boss))


async def announce_settle(server_id: int, s: dict) -> None:
    tpl = next((t for t in g.BOSSES if t["key"] == s["key"]), g.BOSSES[0])
    players = s["players"]
    if not players and not s["killed"]:
        return
    if s["killed"]:
        head = f"🏆 **سقط الزعيم {tpl['name']}!**"
    else:
        head = f"💨 **هرب الزعيم {tpl['name']}** قبل أن يُهزم (مكافأة تعزية للمشاركين)."
    medals = ["🥇", "🥈", "🥉"]
    lines = [head] + [f"{medals[i]} **{p['username']}** — {p['damage']:,} ضرر (+{p['gold']} 💰 +{p['gems']} 💎)" for i, p in enumerate(players[:3])]
    if s["killed"] and s.get("last_hit"):
        last = next((p for p in players if p["user_id"] == s["last_hit"]), None)
        if last:
            lines.append(f"🎯 الضربة القاضية: **{last['username']}**")
    await announce(server_id, "boss", "\n".join(lines))


# ═════════════════════════ المهام ═════════════════════════
def _mrow(m: dict) -> dict:
    return {"emoji": m["emoji"], "title": m["title"], "progress": m["progress"], "target": m["target"], "gold": m["gold"], "gems": m.get("gems") or 0,
            "claimed": bool(m["claimed"])}


async def missions_image(user) -> bytes:
    """بطاقة واحدة: مهام اليوم + المهام الأسبوعية + مهام العصابة (إن كنت في عصابة)."""
    db = bot.db
    daily, weekly, info = await db.missions(user.id), await db.weekly(user.id), await db.guild_info(user.id)
    d_all, w_all = all(m["claimed"] for m in daily), all(m["claimed"] for m in weekly)
    local = time.time() + TZ_OFFSET_H * 3600
    left_d = 86400 - (local % 86400)
    left_w = 7 * 86400 - ((local // 86400 - 4) % 7) * 86400 - (local % 86400)
    d_note = f"أنجز الثلاث لمكافأة إضافية 💎 {g.MISSION_BONUS_GEMS}" if not d_all else "أنجزت كل مهام اليوم! 🎉"
    w_note = f"أنجز الثلاث لمكافأة أسبوعية 💎 {ht.WEEKLY_BONUS_GEMS}" if not w_all else "أنجزت كل مهام الأسبوع! 🎉"
    art = await bot.hub.art("tower", timeout=1.5)
    return await draw(R2.missions_full_card, [_mrow(m) for m in daily], [_mrow(m) for m in weekly], d_note, w_note, fmt_dur(left_d), fmt_dur(left_w),
                      (info or {}).get("missions"), (info or {}).get("guild_name", ""), art)


class MissionsView(OwnedView):
    def __init__(self, user) -> None:
        super().__init__(user.id)
        self.user = user

    @discord.ui.button(label="استلام المكافآت", emoji="🎁", style=discord.ButtonStyle.success)
    async def claim_btn(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.defer()
        parts: list[str] = []
        try:
            r = await bot.db.claim_missions(self.user.id)
            parts.append(f"🎁 اليومية: {r['claimed']} مهام +{r['gold']} 💰 +{r['gems']} 💎" + (" (شامل مكافأة الإنجاز الكامل!)" if r["bonus"] else ""))
        except GameError:
            pass
        try:
            r = await bot.db.claim_weekly(self.user.id)
            parts.append(f"🗓️ الأسبوعية: {r['claimed']} مهام +{r['gold']} 💰 +{r['gems']} 💎" + (f" (شامل مكافأة الأسبوع {r['bonus']} 💎!)" if r["bonus"] else ""))
        except GameError:
            pass
        await interaction.followup.send("\n".join(parts) or "❌ لا توجد مهام مكتملة لاستلامها الآن.", ephemeral=True)
        await self.push(interaction, await missions_image(self.user))


@slash("مهام", "📋 مهام الصيّاد: اليومية والأسبوعية ومهام عصابتك")
async def missions_cmd(ix: discord.Interaction) -> None:
    await ix.response.defer()
    await bot.db.ensure_user(ix.user.id, dname(ix.user))
    await send_card(ix, await missions_image(ix.user), MissionsView(ix.user))


# ═════════════════════════ سجل العملات والتحكم (الإدارة) ═════════════════════════
def fmt_when(ts: float) -> str:
    return time.strftime("%m/%d %H:%M", time.gmtime(ts + 3 * 3600))


async def ledger_image(user_id: int, name: str, limit: int = 12) -> bytes:
    u = await bot.db.get_user(user_id)
    if u is None:
        raise GameError("هذا اللاعب لم يبدأ رحلته بعد.")
    rows = await bot.db.ledger_rows(user_id, limit)
    rr = [{"currency": r["currency"], "label": g.REASON_AR.get(r["reason"], r["reason"]) + (f" · {r['note']}" if r["note"] and r["reason"] in ("shop", "admin") else ""),
           "amount": r["amount"], "balance": r["balance"], "when": fmt_when(r["ts"])} for r in rows]
    return await draw(R.ledger_card, f"سجل عملات {name}", f"آخر {len(rr)} عملية", rr, u["gold"], u["gems"])


@slash("سجل", "📊 سجل عملاتك: كل ذهب وجواهر دخلت أو خرجت ولماذا")
@app_commands.describe(member="لاعب آخر (للإدارة فقط)")
@app_commands.rename(member="اللاعب")
async def ledger_cmd(ix: discord.Interaction, member: discord.Member | None = None) -> None:
    await ix.response.defer(ephemeral=True)
    target = member or ix.user
    if target.id != ix.user.id:
        need_admin(ix)
    await bot.db.ensure_user(ix.user.id, dname(ix.user))
    await send_card(ix, await ledger_image(target.id, target.display_name), ephemeral=True)


PERIODS = {"day": ("آخر 24 ساعة", 86400), "week": ("آخر 7 أيام", 7 * 86400), "all": ("كل الوقت", 0)}


async def economy_image(currency: str, period: str, server_name: str) -> bytes:
    label, secs = PERIODS[period]
    s = await bot.db.ledger_summary(currency, time.time() - secs if secs else 0)
    ar = lambda lst: [(g.REASON_AR.get(r, r), v) for r, v in lst[:6]]   # noqa: E731
    return await draw(R.economy_card, f"اقتصاد {server_name}", label, currency, s["circulating"], ar(s["sources"]), ar(s["sinks"]))


class ControlView(OwnedView):
    def __init__(self, user, server_name: str) -> None:
        super().__init__(user.id, timeout=300)
        self.user, self.server_name = user, server_name
        self.currency, self.period = "gold", "week"
        self.cur_select.options = [discord.SelectOption(label="الذهب", value="gold", emoji="💰", default=True),
                                   discord.SelectOption(label="الجواهر", value="gems", emoji="💎")]
        self.per_select.options = [discord.SelectOption(label=v[0], value=k, default=(k == "week")) for k, v in PERIODS.items()]

    async def _refresh(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer()
        for o in self.cur_select.options:
            o.default = o.value == self.currency
        for o in self.per_select.options:
            o.default = o.value == self.period
        idn.use("control", self.period)
        await self.push(interaction, await economy_image(self.currency, self.period, self.server_name))

    @discord.ui.select(placeholder="العملة", row=0, options=[discord.SelectOption(label="الذهب", value="gold")])
    async def cur_select(self, interaction: discord.Interaction, select: discord.ui.Select) -> None:
        self.currency = select.values[0]
        await self._refresh(interaction)

    @discord.ui.select(placeholder="الفترة", row=1, options=[discord.SelectOption(label="أسبوع", value="week")])
    async def per_select(self, interaction: discord.Interaction, select: discord.ui.Select) -> None:
        self.period = select.values[0]
        await self._refresh(interaction)


@slash("تحكم", "🛠️ لوحة الإدارة: أين تذهب كل العملات؟ (أو سجل لاعب معيّن)")
@app_commands.describe(member="اختياري: اعرض سجل لاعب بدل الاقتصاد العام")
@app_commands.rename(member="اللاعب")
async def control(ix: discord.Interaction, member: discord.Member | None = None) -> None:
    need_admin(ix)
    await ix.response.defer(ephemeral=True)
    if member:
        await send_card(ix, await ledger_image(member.id, dname(member), 14), ephemeral=True)
        return
    name = ix.guild.name if ix.guild else "السيرفر"
    await send_card(ix, await economy_image("gold", "week", name), ControlView(ix.user, name), ephemeral=True)


@slash("منح", "🎁 امنح أو اسحب ذهباً/جواهر من لاعب (إدارة، يُسجَّل في السجل)")
@app_commands.describe(member="اللاعب", currency="العملة", amount="المبلغ (سالب للسحب)")
@app_commands.rename(member="اللاعب", currency="العملة", amount="المبلغ")
@app_commands.choices(currency=[app_commands.Choice(name="💰 ذهب", value="gold"), app_commands.Choice(name="💎 جواهر", value="gems")])
async def grant(ix: discord.Interaction, member: discord.Member, currency: str, amount: int) -> None:
    need_admin(ix)
    await ix.response.defer(ephemeral=True)
    bal = await bot.db.admin_grant(member.id, currency, amount, f"بواسطة {dname(ix.user)}")
    await item_result(ix, "تم", [("💰" if currency == "gold" else "💎", dname(member), f"{amount:+,}"), ("🏦", "رصيده الآن", f"{bal:,}")], "🎁", "gold")


@slash("قناة", "📢 حدّد قناة إعلانات البوت (الصعود، الزعماء، السحب...). بدون قناة يعرض الإعدادات")
@app_commands.describe(kind="نوع الإعلان", channel="القناة (اتركها فارغة لعرض الإعدادات، واختر «حذف» لإزالتها)")
@app_commands.rename(kind="النوع", channel="القناة")
@app_commands.choices(kind=[app_commands.Choice(name=f"{'📢' if k == 'all' else '•'} {n}", value=k) for k, n in ANNOUNCE_KINDS])
async def set_channel(ix: discord.Interaction, kind: str = "all", channel: discord.TextChannel | None = None) -> None:
    need_admin(ix)
    await ix.response.defer(ephemeral=True)
    sid = ix.guild_id or 0
    note = ""
    if channel is not None:
        await bot.db.set_channel(sid, kind, channel.id)
        note = f"✅ إعلانات «{dict(ANNOUNCE_KINDS)[kind]}» ستُنشر في #{channel.name}"
    cfg = await bot.db.get_channels(sid)
    names = {}
    for k, cid in cfg.items():
        ch = ix.guild.get_channel(cid) if ix.guild else None
        names[k] = f"#{ch.name}" if ch else f"#{cid}"
    rows = [("📢", n, names.get(k, "غير محددة")) for k, n in ANNOUNCE_KINDS]
    data = await draw(R.list_card, "قنوات الإعلانات", "اكتب: قناة الصعود #القناة", rows, "📢", "blue", lines=[note] if note else None,
                      footer="«الكل» تُستخدم لأي نوع بدون قناة خاصة")
    await send_card(ix, data, ephemeral=True)


@slash("بينغ", "🏓 افحص أن البوت شغّال وسرعة استجابته")
async def ping_cmd(ix: discord.Interaction) -> None:
    lat = bot.latency
    ms = f" · زمن الاستجابة {round(lat * 1000)}ms" if lat == lat and lat != float("inf") else ""
    await ix.response.defer()
    await send_card(ix, await draw(R.list_card, "البوت شغّال", "فحص الاتصال", [("⚡", "الحالة", "متصل"), ("📡", "زمن الاستجابة", ms.replace(" · زمن الاستجابة ", "") or "—")], "⚡"))


@slash("قول", "💬 اجعل البوت يكتب رسالة في قناة معيّنة (إدارة)")
@app_commands.describe(channel="القناة", text="الرسالة")
@app_commands.rename(channel="القناة", text="الرسالة")
async def say(ix: discord.Interaction, channel: discord.TextChannel, text: str) -> None:
    need_admin(ix)
    await ix.response.defer(ephemeral=True)
    await channel.send(text[:1900], allowed_mentions=discord.AllowedMentions.none())
    await item_result(ix, "أُرسلت الرسالة", [("📢", "القناة", f"#{channel.name}")], "💬", "win")


@slash("حدث", "🎉 فعّل حدثاً بمضاعفة الذهب أو الخبرة لعدة ساعات (إدارة)")
@app_commands.describe(kind="نوع الحدث", hours="المدة بالساعات (0 للإيقاف)", mult="المضاعف")
@app_commands.rename(kind="النوع", hours="الساعات", mult="المضاعف")
@app_commands.choices(kind=[app_commands.Choice(name="💰 ذهب", value="gold"), app_commands.Choice(name="✨ خبرة", value="xp")])
async def event_cmd(ix: discord.Interaction, kind: str, hours: app_commands.Range[int, 0, 168] = 2, mult: app_commands.Range[int, 2, 5] = 2) -> None:
    need_admin(ix)
    await ix.response.defer(ephemeral=True)
    if hours == 0:
        await bot.db.set_event(None)
        await item_result(ix, "أُوقف الحدث", [("🛑", "الحالة", "متوقف")], "🎉")
        return
    await bot.db.set_event(kind, mult, hours)
    em, label = g.EVENT_KINDS[kind]
    await announce(ix.guild_id or 0, "event", f"🎉 **حدث جديد:** {label} ×{mult} لمدة {hours} ساعة! اصعدوا البرج الآن! {em}")
    await item_result(ix, "بدأ الحدث", [(em, label, f"×{mult}"), ("⏳", "المدة", f"{hours} ساعة")], "🎉", "gold")


# ═════════════════════════ التطوير والصيد والإنجازات ═════════════════════════
@slash("تحسين", "🔨 حسّن عتادك من +1 إلى +5 بالذهب لزيادة قوته (بدون رقم يعرض التكاليف)")
@app_commands.describe(item_id="رقم العنصر من «حقيبة»")
@app_commands.rename(item_id="الرقم")
async def enhance_cmd(ix: discord.Interaction, item_id: int | None = None) -> None:
    await ix.response.defer(ephemeral=True)
    await bot.db.ensure_user(ix.user.id, dname(ix.user))
    if item_id is None:
        inv = [it for it in await bot.db.inventory(ix.user.id) if it["item_type"] != "Spell"]
        inv.sort(key=lambda it: (-it["is_equipped"], -g.RARITIES.index(it["rarity"])))
        rows = []
        for it in inv[:8]:
            v = g.item_view(it)
            lvl = it["lvl"] or 0
            cost = "أقصى مستوى" if lvl >= g.MAX_ENH else f"{g.enhance_cost(it['rarity'], lvl):,} 💰 ({int(g.ENH_CHANCE[lvl] * 100)}%)"
            rows.append((v["emoji"], f"#{it['item_id']} {v['name']} +{lvl}", cost))
        if not rows:
            raise GameError("ما عندك عتاد للتحسين. اسحب بطاقات أولاً بكتابة «سحب».")
        await item_result(ix, "ورشة التحسين", rows, "🔨", "gold",
                          lines=["اكتب: تحسين رقم — كل مستوى يزيد قوة العنصر 25%", "الفشل يكلّفك الذهب فقط، ولا يضيع العنصر."])
        await send_gif(ix, "enhance")
        return
    r = await bot.db.enhance(ix.user.id, item_id, bot.rng)
    v = g.item_view({"item_id": item_id, "item_name": r["name"], "item_type": r["type"], "stat": r["stat"], "stat_bonus": r["bonus"],
                     "rarity": r["rarity"], "lvl": r["lvl"]})
    if r["ok"]:
        await item_result(ix, "نجح التحسين!", [(v["emoji"], f"{r['name']} +{r['lvl']}", v["bonus_text"]), ("💰", "التكلفة", f"{r['cost']:,}")],
                          "🔨", "win", lines=["مستوى أعلى = قوة أكبر وسعر بيع أعلى." if r["lvl"] < g.MAX_ENH else "وصل العنصر أقصى مستوى! 🌟"])
        await send_gif(ix, "enhance")
    else:
        await item_result(ix, "فشل التحسين", [(v["emoji"], f"{r['name']} +{r['lvl']}", "بقي كما هو"), ("💰", "التكلفة", f"{r['cost']:,}")],
                          "💥", "lose", lines=[f"فرصة النجاح كانت {int(r['chance'] * 100)}%. حاول مرة أخرى!"])


FUSE_CHOICES = [app_commands.Choice(name="⚪ عادي ← نادر", value="0"), app_commands.Choice(name="🔵 نادر ← ملحمي", value="1"),
                app_commands.Choice(name="🟣 ملحمي ← أسطوري", value="2")]


@slash("دمج", "🧪 ادمج 3 عناصر غير مجهّزة من نفس الندرة في عنصر أندر (بدون خيار يعرض ما تملك)")
@app_commands.describe(rarity="الندرة التي تريد دمجها")
@app_commands.rename(rarity="الندرة")
@app_commands.choices(rarity=FUSE_CHOICES)
async def fuse_cmd(ix: discord.Interaction, rarity: str | None = None) -> None:
    await ix.response.defer(ephemeral=True)
    await bot.db.ensure_user(ix.user.id, dname(ix.user))
    if rarity is None:
        inv = await bot.db.inventory(ix.user.id)
        rows = []
        for i in range(3):
            n = sum(1 for it in inv if it["rarity"] == g.RARITIES[i] and not it["is_equipped"] and it["item_type"] != "Spell")
            rows.append((["⚪", "🔵", "🟣"][i], f"{g.RARITY_AR[i]} ← {g.RARITY_AR[i + 1]}", f"{n}/{g.FUSE_COUNT} · {g.FUSE_COST[i]} 💰"))
        await item_result(ix, "مختبر الدمج", rows, "🧪", "blue",
                          lines=["اكتب: دمج عادي / نادر / ملحمي", "يُستهلك أضعف 3 عناصر (غير مجهّزة) وتحصل على عنصر عشوائي أندر."])
        await send_gif(ix, "fuse")
        return
    r = await bot.db.fuse(ix.user.id, int(rarity), bot.rng)
    v = g.item_view({"item_id": r["item_id"], "item_name": r["name"], "item_type": r["type"], "stat": r["stat"],
                     "stat_bonus": r["bonus"], "rarity": r["rarity"]})
    await item_result(ix, "نجح الدمج!", [(v["emoji"], v["name"], v["bonus_text"]), ("💰", "التكلفة", f"{r['cost']:,}"), ("🔢", "الرقم الجديد", f"#{r['item_id']}")],
                      "🧪", "gold", lines=[f"{g.RARITY_AR[int(rarity)]} ×3 ← {g.RARITY_AR[int(rarity) + 1]}"])
    await send_gif(ix, "fuse")
    if v["rarity"] >= GACHA_ANNOUNCE_MIN_RARITY:
        await announce(ix.guild_id or 0, "gacha", f"🧪 **{dname(ix.user)}** دمج عناصره وحصل على **أسطوري**: {v['emoji']} {v['name']}!")


HUNT_CHOICES = [app_commands.Choice(name=f"{h[2]} {h[1]} (طابق {h[3]}+)", value=h[0]) for h in g.HUNTS]


@slash("صيد", "🏹 رحلة صيد سريعة لجمع الذهب والخبرة والعتاد (كل 10 دقائق). بدون خيار يعرض الصيد المتاح")
@app_commands.describe(target="فريسة الصيد")
@app_commands.rename(target="الفريسة")
@app_commands.choices(target=HUNT_CHOICES)
async def hunt_cmd(ix: discord.Interaction, target: str | None = None) -> None:
    uid = ix.user.id
    await ix.response.defer()
    u = await bot.db.ensure_user(uid, dname(ix.user))
    if target is None:
        left = max(0, g.HUNT_CD - (time.time() - u["last_hunt"]))
        rows = [(h[2], h[1], "متاح ✅" if u["floor"] >= h[3] else f"🔒 طابق {h[3]}") for h in g.HUNTS]
        art = bot.hub.local_art("hunt") or await bot.hub.art("hunt", timeout=1.5)
        await send_card(ix, await draw(R.list_card, "رحلات الصيد", f"الراحة: {fmt_dur(left)}" if left else "جاهز للصيد!", rows, "🏹", "default", art,
                                       lines=["اكتب: صيد ذئاب  — مثال", "قتال سريع بجولات قصيرة، يعطي ذهباً وخبرة وفرصة سقوط عتاد."]), ephemeral=True)
        return
    if uid in bot.active:
        raise GameError("عندك معركة مفتوحة بالفعل!")
    hk = next(h for h in g.HUNTS if h[0] == target)
    bot.active.add(uid)
    try:
        u = await bot.db.hunt_begin(uid, hk[3])
        enemy = g.hunt_enemy(hk, u["floor"], bot.rng)
        player = g.fighter_from_user(u, dname(ix.user))
        battle = g.Battle(player, enemy, bot.rng)
        battle.max_rounds = 8
        await start_battle(ix, battle, "hunt", u["floor"], f"🏹 صيد {hk[1]}", theme="blue", art_ctx="hunt", hunt=hk)
    except BaseException:
        bot.active.discard(uid)
        raise


@slash("انجازات", "🏅 إنجازاتك ومكافآتها (تُستلم تلقائياً عند تحقيقها)")
async def achievements_cmd(ix: discord.Interaction) -> None:
    await ix.response.defer(ephemeral=True)
    await bot.db.ensure_user(ix.user.id, dname(ix.user))
    r = await bot.db.achievements(ix.user.id)
    pending = sorted((x for x in r["rows"] if not x["done"]), key=lambda x: -x["have"] / x["need"])[:8]
    rows = [(x["emoji"], f"{x['title']} — {x['desc']}", f"{x['have']:,}/{x['need']:,}") for x in pending]
    lines = [f"🏅 أنجزت {r['done']} من {r['total']}"]
    for n in r["new"]:
        lines.append(f"🎉 إنجاز جديد: {n['emoji']} {n['title']} · {n['gold']} 💰 · {n['gems']} 💎")
    if not rows:
        rows = [("👑", "أنجزت كل شيء!", "أسطورة")]
    art = bot.hub.local_art("achieve") or await bot.hub.art("achieve", timeout=1.0)
    await send_card(ix, await draw(R.list_card, "الإنجازات", "الأقرب إلى الاكتمال", rows, "🏅", "gold", art, lines=lines), ephemeral=True)
    if r["new"]:
        await send_gif(ix, "achieve")


# ═════════════════════════ إدارة الصور والـ GIF ═════════════════════════
ART_ACTIONS = [app_commands.Choice(name="➕ اضافة", value="add"), app_commands.Choice(name="🗑️ حذف", value="del"),
               app_commands.Choice(name="📋 قائمة", value="list")]
GROUP_ICON = {"مشاهد": "🎬", "خلفيات": "🌆", "النين": "🌀", "زعماء": "👹", "خصوم": "⚔️", "عتاد": "🎒", "عتاد هانتر": "🎒"}
GROUP_ICON.update(idn.groups())


@slash("صور", "🖼️ إدارة صور وGIF اللعبة لأي مكان: اضافة / حذف / قائمة (للإدارة)")
@app_commands.describe(action="ماذا تريد؟", place="المكان (اكتب «صور قائمة» لرؤية كل الأماكن)", file="صورة أو GIF مرفقة",
                       url="أو رابط مباشر لصورة / رقم الصورة عند الحذف")
@app_commands.rename(action="العملية", place="المكان", file="الملف", url="الرابط")
@app_commands.choices(action=ART_ACTIONS)
async def art_cmd(ix: discord.Interaction, action: str, place: str | None = None, file: discord.Attachment | None = None,
                  url: str | None = None) -> None:
    need_admin(ix)
    await ix.response.defer(ephemeral=True)
    hub = bot.hub
    counts = hub.counts()
    if action == "list":
        grp = next((g_ for g_ in A.GROUPS if place and A._norm_word(place) == A._norm_word(g_)), None)
        if grp is None:
            rows = []
            for g_ in A.GROUPS:
                keys = [k for k, v in A.SLOTS.items() if v[2] == g_]
                rows.append((GROUP_ICON[g_], f"{g_}", f"{sum(1 for k in keys if counts[k])}/{len(keys)} مكان مليء"))
            await item_result(ix, "أماكن الصور", rows, "🖼️", "blue",
                              lines=["اكتب: صور قائمة <المجموعة>  لعرض أماكنها", "اكتب: صور اضافة <المكان> مع إرفاق صورة أو GIF"])
            return
        rows = [(GROUP_ICON[grp], f"{v[0]} — {v[1]}", f"{counts[k]} 🖼️") for k, v in A.SLOTS.items() if v[2] == grp]
        await item_result(ix, f"مجموعة {grp}", rows, GROUP_ICON[grp], "blue", lines=["الكلمة الأولى هي ما تكتبه: صور اضافة <الكلمة> + ملف"])
        return
    slot = A.resolve_slot(place or "")
    if slot is None:
        raise GameError("لم أعرف المكان. اكتب «صور قائمة» لترى الأماكن (مثل: سيف، هيسوكا، فوز، شارع).")
    label = A.SLOTS[slot][1]
    if action == "del":
        idx = int(url) if url and url.strip().isdigit() else None
        n = hub.remove_local(slot, idx)
        refresh_item_art()
        await item_result(ix, "تم الحذف" if n else "لا شيء للحذف", [("🗑️", label, f"{n} ملف")], "🗑️", "lose" if not n else "win")
        return
    # إضافة: مرفقات الرسالة النصية + مرفق السلاش + رابط
    atts: list[discord.Attachment] = list(getattr(getattr(ix, "message", None), "attachments", []) or [])
    if file is not None and file not in atts:
        atts.append(file)
    blobs: list[tuple[bytes, str]] = []
    for a_ in atts[:10]:
        try:
            blobs.append((await a_.read(), a_.filename))
        except discord.HTTPException:
            pass
    if url and url.strip().startswith("http"):
        data = await fetch_bytes(url.strip(), timeout=10.0)
        if data:
            blobs.append((data, url))
    if not blobs:
        raise GameError("أرفق صورة أو GIF مع الأمر، أو ضع رابط صورة مباشر. مثال: صور اضافة سيف  (مع صورة).")
    ok = bad = 0
    err = ""
    for data, name in blobs:
        try:
            await asyncio.to_thread(hub.add_local, slot, data, name)
            ok += 1
        except ValueError as e:
            bad += 1
            err = str(e)
    refresh_item_art()
    rows = [("✅", label, f"أُضيف {ok}")]
    if bad:
        rows.append(("⚠️", "تعذّر", f"{bad}"))
    lines = [err] if err else ["ستظهر الصورة فوراً في اللعبة. GIF يُرسل متحركاً في اللحظات المناسبة."]
    await item_result(ix, "تمت إضافة الصور" if ok else "لم تُضف الصور", rows, "🖼️", "win" if ok else "lose", lines=lines)


@slash("هوية", "🎨 فحص الهوية البصرية: لكل أمر صورة وخلفية وثيم؟ وأي صور مكررة؟ (للإدارة)")
async def identity_cmd(ix: discord.Interaction) -> None:
    need_admin(ix)
    await ix.response.defer(ephemeral=True)
    names = [c.name for c in tree.get_commands()]
    rep = await asyncio.to_thread(idn.audit, names, len(HELP_PAGES))
    mine = sum(1 for a in idn.REG.values() if idn.uploaded_files(a.slot)) + sum(1 for c in idn.CMDS if idn.uploaded_files(f"cmd_{c.slug}"))
    ok = len(names) - len(rep["no_identity"])
    rows = [("🎬", "أوامر لها هوية", f"{ok} / {len(names)}"), ("🖼️", "خلفيات في المكتبة المنظمة", str(rep["art_total"])),
            ("📤", "أماكن فيها صورك المرفوعة", str(mine)), ("♻️", "صور مكررة", str(len(rep["duplicates"])))]
    lines = ["✅ كل أمر رئيسي له صورة وخلفية وثيم." if rep["ok"] else "⚠️ يوجد نقص: " + "، ".join(rep["no_identity"] + rep["missing_art"] + rep["missing_emblem"])[:300],
             "ارفع صورك بـ «صور اضافة صورة_<الأمر>» أو «صور اضافة خلفية_<الأمر>» وتتقدم على المولَّد."]
    await item_result(ix, "الهوية البصرية", rows, "🎨", "win" if rep["ok"] else "lose", lines=lines)


# ═════════════════════════ الشرح ═════════════════════════
HELP_PAGES = [
    ("البداية والبرج", "🏰",
     f"أنت صيّاد في برج المعارك: {g.MAX_FLOOR} طابقاً، وكل طابق حلبة سيطرة. تهزم خصم الطابق فتصير «مسيطره»، ومن بعدك يقاتل «ظلّك». الأوامر كلها كلمة واحدة بالعربي: اكتبها مباشرة في الشات أو استخدم / .",
     [("صعود", "قاتل في طابقك الحالي"), ("طابق", "اعرف خصمك (أو مسيطر الطابق) ومكافأتك"), ("ملف", "رخصة الصيّاد وإحصائياتك"), ("يومي", "مكافأة يومية + سلسلة أيام"),
      ("ترتيب", "الأبطال: طابق/مستوى/ثروة/زعيم"), ("مبارزة", "قاتل ظل لاعب آخر ودّياً")],
     ["تحتاج 40% صحة على الأقل للصعود، والصحة تتعافى 10% كل دقيقة"]),
    ("سيطرة الطوابق والانتقام", "🏯",
     "كل طابق له مسيطر واحد: آخر لاعب هزم خصمه. إن هاجمك لاعب وأنت غائب يقاتل «ظلّك» (Shadow Echo) بأحدث إحصائياتك وبطاقاتك ونينك. إن كنت متصلاً يصلك تحدٍّ مباشر تقبله خلال 30 ثانية فيصير قتالاً بين لاعبين.",
     [("صعود", "عند طابق له مسيطر: ظلّه أو تحدٍّ مباشر"), ("انتقام", f"استعد طابقاً خسرته (مهلة {g.REVENGE_HOURS} ساعة، غنيمة ×{g.REVENGE_BONUS_GOLD:g})"), ("طابق", "تعرف من يسيطر على طابقك"),
      ("موسم", "الترتيب والجوائز وقاعة الأبطال")],
     [f"قوة الظل محصورة بين {round(g.ECHO_FLOOR_PCT * 100)}% و{round(g.ECHO_CAP * 100)}% من خصم الطابق المعتاد حتى لا يكون مستحيلاً",
      "تصلك رسالة خاصة عند خسارة طابقك، والإعلان يظهر في قناة الطوابق"]),
    ("القتال", "⚔️",
     "القتال بالأدوار: الأسرع يبدأ. الدفاع يخفف الضرر. كل جولة تختار حركتك بالأزرار تحت الصورة، وقائمة «هاتسو» لقدرات أبطال فريقك.",
     [("⚔️ هجوم", "ضرر عادي"), ("🛡️ تحصّن", "نصف الضرر + طاقة"), ("🌀 مهارة", "مهارة النين الخاصة بك"), ("🌀 هاتسو", "قدرة بطل من فريقك (قائمة)"),
      ("⏩ تلقائي", "يكمل القتال عنك"), ("🏳️ انسحاب", "بدون خسارة ذهب")],
     ["تفوّق الفئات: تعزيز ‹ تحويل ‹ تجسيد ‹ تلاعب ‹ إرسال ‹ تعزيز (+25%)",
      "ضربة حرجة (×1.6) للأسرع، وتفادي للأسرع. ضربات متتالية تبني «كومبو»",
      "الأسياد والزعماء عندهم ضربة مميزة كل 3 جولات، والزعيم يغضب عند نصف صحته"]),
    ("النين وشجرته وهاتسو", "🌳",
     f"عند الطابق {g.NEN_UNLOCK_FLOOR} تفتح النين: اختبار الكأس يكشف فئتك. تكسب نقطة نين مع كل مستوى وكل {ht.TREE_POINT_PER_FLOORS} طوابق، وتصرفها في شجرة من 3 مسارات (قوة · دفاع · سرعة) وتفرّعين لكل مسار. وبطاقات الأبطال تمنحك قدرات هاتسو خاصة.",
     [("شجرة", "اعرض شجرتك وارتقِ بعقدها من القائمة"), ("هاتسو", "قدرات غون وكيلوا وكورابيكا وهيسوكا"), ("اختبار", "اكشف فئة النين (إعادة = 100 💎)"),
      ("مهارات", "مهارتك وسداسي التوافق"), ("نذر", "اقطع نذراً: دم/صمت/غضب/جشع"), ("تطوير", "وزّع نقاط المستوى")],
     [f"إعادة توزيع الشجرة = {ht.TREE_RESPEC_GEMS} 💎 وترجع كل نقاطك", "جانكن (غون) · الإعصار والصاعقة (كيلوا) · سلسلة الحبس وزمان الإمبراطور (كورابيكا) · علكة بونجي (هيسوكا)"]),
    ("الحقيبة والسحب", "🎒",
     "اسحب عتاداً ومرافقين وبطاقات شفاء، والنتيجة تظهر فوراً بدون انتظار. بعد السحب أزرار «سحب ×1 / ×10» لتكرره بضغطة. الضمان: ملحمي أو أعلى كل 20 سحبة.",
     [("سحب", "سحبة أو 10 دفعة واحدة"), ("سحب_عتاد", f"عتاد هانتر الحقيقي بتأثيرات ({ht.GEAR_GOLD_COST} 💰 أو {ht.GEAR_GEM_COST} 💎)"), ("صندوق", "افتح صناديق العتاد الحصرية"),
      ("حقيبة", "كل عناصرك بصور"), ("تجهيز", "جهّز عنصراً برقمه"), ("استخدام", "فعّل بطاقة شفاء")],
     ["ألوان الندرة: رمادي عادي · أزرق نادر · بنفسجي ملحمي · ذهبي أسطوري", "العتاد: سيف نوبوناغا · يو يو كيلوا · سلاسل كورابيكا · عيون القرمزي ... ولكل قطعة تأثير (حرجة، مراوغة، سرقة صحة...)"]),
    ("البطاقات والفريق", "🎴",
     f"استدعِ أبطال هانتر × هانتر كبطاقات. كل نسخة مكررة تضيف نجمة (+{round(cd.STAR_BONUS * 100)}% لقوة البطاقة). اختر {cd.TEAM_SIZE} منهم لفريقك: يزيدون إحصائياتك دائماً، ويساعدونك بزر «نداء الفريق» داخل القتال.",
     [("استدعاء", f"{cd.SUMMON_GOLD_COST} 💰 أو {cd.SUMMON_GEM_COST} 💎 للبطاقة (حتى 10)"), ("ألبوم", "كل بطاقاتك وما ينقصك"), ("بطاقة", "تفاصيل بطل باسمه"),
      ("فريق", "اختر أبطالك: «فريق غون كيلوا ليورو»"), ("فريق مسح", "أفرغ فريقك"), ("🃏 نداء الفريق", f"زر في القتال، كل {cd.ASSIST_COOLDOWN} جولات")],
     [f"الضمان: بطاقة ملحمية أو أعلى كل {cd.SUMMON_PITY} استدعاء",
      "الأدوار: مهاجم يضرب · حارس يحميك · معالج يشفيك · مسيطر يشلّ الخصم",
      f"بعد اكتمال {cd.MAX_STARS} نجوم تتحول النسخ الزائدة إلى ذهب"]),
    ("التطوير والصيد", "🔨",
     "العتاد ليس للزينة: حسّنه لقوة أكبر، ادمج الزائد في عتاد أندر، وأكمل الطقم لمكافأة على كل إحصائياتك. والصيد قتال سريع كل 10 دقائق.",
     [("تحسين", "عنصر من +1 إلى +5 (كل مستوى +25% قوة)"), ("دمج", "3 عناصر من نفس الندرة ← عنصر أندر"), ("صيد", "رحلة صيد لذهب وخبرة وعتاد"),
      ("انجازات", "مكافآت تُستلم تلقائياً"), ("بيع", "سعر البيع يرتفع مع التحسين"), ("تجهيز", "قطعتان من نفس الطقم +5%، ثلاث +12%، أربع +25%")],
     ["أطقم: التدريب · الصيّاد · الظلال · الملوك (آخر كلمة في اسم العنصر)", "في البرج أحداث عشوائية: كنوز وينابيع وفخاخ وبركات"]),
    ("الزعيم والمهام", "👹",
     "كل أسبوع يظهر زعيم عملاق يشترك الجميع في هزيمته. كلما زاد ضررك زادت غنيمتك. والمهام: يومية وأسبوعية وللعصابة، وكلها في بطاقة واحدة.",
     [("زعيم", "اعرض الزعيم واضربه (3 محاولات يومياً)"), ("مهام", "يومية + أسبوعية + مهام عصابتك"), ("تحويل", "حوّل ذهباً (ضريبة 5%)")],
     ["بين كل ضربتين 5 دقائق راحة", f"إنجاز المهام الأسبوعية الثلاث = مكافأة {ht.WEEKLY_BONUS_GEMS} 💎"]),
    ("العصابات والحروب", "🏴",
     f"أسّس عصابتك: تحتاج الطابق {ht.GANG_MIN_FLOOR} و{ht.GANG_COST_GOLD:,} 💰 و{ht.GANG_COST_GEMS} 💎. تحصل على رتبة ديسكورد «[زعيم عصابة: الاسم]»، وللأعضاء رتبة «[عصابة: الاسم]». للعصابة خزينة مشتركة ومهام أسبوعية بجوائز وصناديق عتاد حصرية.",
     [("عصابة", "معلومات عصابتك: خزينة، أعضاء، مهام"), ("عصابة تأسيس الاسم", "أسّس عصابة"), ("عصابة انضمام الاسم", "اطلب الانضمام"),
      ("عصابة قبول @لاعب", "الزعيم/النائب يقبل"), ("عصابة طرد @لاعب", "طرد عضو"), ("عصابة تعيين @لاعب نائب", "الزعيم فقط"),
      ("عصابة إيداع ذهب 1000", "ساهم في الخزينة"), ("عصابة حرب الاسم", "الزعيم يعلن الحرب"), ("عصابة مغادرة", "اخرج من عصابتك")],
     [f"الفائزة في الحرب تسلب بين {round(ht.STEAL_PCT[0] * 100)}% و{round(ht.STEAL_PCT[1] * 100)}% من خزينة الخاسرة",
      "انتصار البرج = 2 نقطة حرب، وضربة الزعيم = 1 نقطة", f"سعة العصابة {ht.GANG_MAX_MEMBERS} عضواً"]),
    ("السوق الأسود والمواسم", "🏴",
     f"السوق الأسود يفتح لساعات محدودة (كل {ht.MARKET_PERIOD_H} ساعة تقريباً) بعروض وأسعار متغيرة: عتاد ملحمي وأسطوري، أحجار نين، وصناديق. وكل {ht.SEASON_DAYS} يوماً ينتهي موسم: جوائز وألقاب حصرية للأوائل ثم تُصفَّر الطوابق.",
     [("سوق_اسود", "اعرض العروض واشترِ من القائمة"), ("موسم", "الترتيب والجوائز وقاعة الأبطال"), ("صندوق", "افتح ما حصلت عليه")],
     [f"لكل لاعب شراء واحد من كل عرض، والكميات محدودة", "حجر النين = نقطة في شجرتك", "بعد الموسم تبقى مستوياتك وعتادك وبطاقاتك، وتُصفَّر الطوابق والسيطرة"]),
    ("الاقتصاد والإدارة", "🛠️",
     "أوامر للمشرفين لمراقبة كل ذهب وجواهر اللعبة وإدارة السيرفر. تتطلب صلاحية «إدارة السيرفر».",
     [("سجل", "سجل عملاتك (عملية بعملية)"), ("تحكم", "أين تذهب كل العملات؟"), ("منح", "امنح أو اسحب عملة"), ("قناة", "حدّد قنوات الإعلانات"),
      ("arena_setfloor", "اضبط طابق لاعب: arena_setfloor @لاعب 50"), ("arena_giveitem", "أعطِ عتاداً أو موارد: arena_giveitem @لاعب 2 سيف نوبوناغا"),
      ("arena_reset", "أعد ضبط تقدم لاعب: arena_reset @لاعب"), ("سوق_اسود فتح_ساعات", "افتح السوق يدوياً"), ("موسم إنهاء", "أنهِ الموسم الآن"),
      ("حدث", "ذهب أو خبرة مضاعفة"), ("صور", "أضف صورة/GIF لأي مكان في اللعبة")],
     ["«قناة» تجعل البوت يعلن الصعود والزعماء والسحبات الأسطورية",
      "«صور اضافة سيف» مع إرفاق صورة: تظهر بدل الأيقونة. «صور قائمة» لرؤية كل الأماكن"]),
]


class HelpView(OwnedView):
    def __init__(self, user, page: int = 0) -> None:
        super().__init__(user.id, timeout=300)
        self.page = page
        self.sel.options = [discord.SelectOption(label=t, value=str(i), emoji=e, default=(i == page)) for i, (t, e, *_r) in enumerate(HELP_PAGES)]

    @discord.ui.select(placeholder="اختر قسم الشرح", options=[discord.SelectOption(label="x", value="0")])
    async def sel(self, interaction: discord.Interaction, select: discord.ui.Select) -> None:
        await interaction.response.defer()
        self.page = int(select.values[0])
        for o in self.sel.options:
            o.default = o.value == select.values[0]
        await self.push(interaction, await help_image(self.page))


async def help_image(page: int) -> bytes:
    title, emoji, intro, entries, tips = HELP_PAGES[page]
    idn.use("help", f"p{page}")             # خلفية مستقلة لكل قسم من أقسام الشرح
    return await draw(R.help_card, title, emoji, intro, entries, page + 1, len(HELP_PAGES), tips)


@slash("شرح", "📖 شرح اللعبة بالصور: كل الأوامر والأنظمة")
@app_commands.describe(section=f"رقم القسم (1 إلى {len(HELP_PAGES)})")
@app_commands.rename(section="القسم")
async def help_cmd(ix: discord.Interaction, section: app_commands.Range[int, 1, len(HELP_PAGES)] = 1) -> None:
    await ix.response.defer()
    p = section - 1
    await send_card(ix, await help_image(p), HelpView(ix.user, p))


# ═════════════════════════ مهام الخلفية ═════════════════════════
@tasks.loop(seconds=60)
async def housekeeping() -> None:
    try:
        for w in await bot.db.finish_due_wars():
            res = {"a": f"🏆 فازت **{w['name_a']}**!", "b": f"🏆 فازت **{w['name_b']}**!", "draw": "🤝 انتهت الحرب بالتعادل!"}[w["result"]]
            idn.use("war")
            data = await draw(R.war_card, {**w, "time_left": "انتهت الحرب", "note": res.replace("**", "").replace("🏆 ", "").replace("🤝 ", "")})
            st = w.get("stolen") or {}
            loot = (f"\n💰 غنمت العصابة الفائزة **{st['gold']:,}** ذهب و**{st['gems']}** جوهرة ({round(st['pct'] * 100)}% من خزينة الخاسرة)"
                    if st.get("gold") or st.get("gems") else "")
            await announce(w["server_id"], "war", f"⚔️ **انتهت حرب {w['name_a']} ضد {w['name_b']}!** {res}{loot}", data)
        ext = sys.modules.get("commands_ext")
        if ext is not None:
            await ext.season_tick()
            await ext.revenge_notify()
        servers = await bot.db.due_boss_servers()
        for sid in servers:
            _, settle = await bot.db.ensure_boss(sid, bot.rng)
            if settle:
                await announce_settle(sid, settle)
    except Exception:
        log.exception("فشل عمل الخلفية")


@housekeeping.before_loop
async def _hk_wait() -> None:
    await bot.wait_until_ready()


def main() -> None:
    load_env()
    level = getattr(logging, os.environ.get("LOG_LEVEL", "INFO").strip().upper(), logging.INFO)
    logging.basicConfig(level=level if isinstance(level, int) else logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    token = os.environ.get("DISCORD_TOKEN")
    if not token:
        sys.exit("❌ لم أجد DISCORD_TOKEN. ضعه في ملف .env أو كمتغير بيئة (لا تكتبه داخل الكود).")
    try:
        bot.run(token, log_handler=None)
    except discord.PrivilegedIntentsRequired:
        print("\n⚠️ أوامر الكتابة بدون علامة تحتاج تفعيل «Message Content Intent» من بوابة المطورين:\n"
              "   discord.com/developers → تطبيقك → Bot → Privileged Gateway Intents → MESSAGE CONTENT INTENT\n"
              "↻ أعيد التشغيل الآن بأوامر السلاش فقط (/صعود ...). فعّل الخيار ثم أعد تشغيل البوت لتعمل الكتابة المباشرة.\n")
        os.environ["TEXT_COMMANDS"] = "0"
        os.execv(sys.executable, [sys.executable] + sys.argv)


sys.modules.setdefault("bot", sys.modules[__name__])      # كي يستورد commands_ext هذا الملف نفسه لا نسخة ثانية
import commands_ext  # noqa: E402,F401  — يسجّل أوامر التحديث (شجرة، هاتسو، سوق أسود، موسم، انتقام، عتاد، إدارة)


if __name__ == "__main__":
    main()
