"""
بيانات التحديث الكبير (لا تعتمد على discord ولا على قاعدة البيانات، فتُختبر مباشرة):

  • قدرات النين الخاصة بالأنمي (Hatsu): مرتبطة ببطاقات الأبطال (غون، كيلوا، كورابيكا، هيسوكا)
  • شجرة مهارات النين البصرية (3 مسارات × 2 تفرّع)
  • عتاد وموارد من أنمي Hunter x Hunter (سحب العتاد) — الصور تُجلب من الويكي وقت التشغيل ولا تُرسم
  • السوق الأسود (نوافذ فتح محدودة وأسعار متغيرة)
  • المواسم والألقاب
  • العصابات: الشروط والمهام الأسبوعية
  • المهام الأسبوعية الفردية
"""
from __future__ import annotations

import math
import os
import random

# ═════════════════════════ قدرات النين (Hatsu) ═════════════════════════
# كل قدرة: المالك (مفتاح بطاقة)، الاسم، الرمز، تكلفة الطاقة، التبريد بالجولات، الوصف
HATSU: dict[str, dict] = {
    "gon_rock": {"owner": "gon", "name": "جانكن — حجرة", "en": "Rock", "emoji": "✊", "cost": 30, "cd": 3,
                 "desc": "تركّز كل النين في قبضتك: ضربة قاضية بضرر كاسح (×2.8)."},
    "gon_paper": {"owner": "gon", "name": "جانكن — ورقة", "en": "Paper", "emoji": "🖐️", "cost": 25, "cd": 2,
                  "desc": "هجوم بعيد المدى يتجاوز 50% من دفاع الخصم (×1.5)."},
    "gon_scissors": {"owner": "gon", "name": "جانكن — مقص", "en": "Scissors", "emoji": "✌️", "cost": 25, "cd": 2,
                     "desc": "ضربة سريعة تُحدث نزيفاً لـ3 أدوار وتُبطئ الخصم 20%."},
    "killua_whirlwind": {"owner": "killua", "name": "سرعة الإله — الإعصار", "en": "Whirlwind", "emoji": "🌪️", "cost": 20, "cd": 5,
                         "desc": "3 أدوار: تراوغ أكثر (+45%) وتضرب أولاً دائماً."},
    "killua_thunder": {"owner": "killua", "name": "سرعة الإله — الصاعقة", "en": "Thunderbolt", "emoji": "⚡", "cost": 30, "cd": 4,
                       "desc": "تشلّ الخصم دوراً كاملاً وتكسر طاقته فيفقد مهاراته دورين."},
    "kurapika_chain": {"owner": "kurapika", "name": "سلسلة الحبس", "en": "Chain Jail", "emoji": "⛓️", "cost": 30, "cd": 6,
                       "desc": "تحظر كل قدرات النين والهاتسو على الخصم 4 أدوار."},
    "kurapika_emperor": {"owner": "kurapika", "name": "زمان الإمبراطور", "en": "Emperor Time", "emoji": "👁️", "cost": 20, "cd": 8,
                         "desc": "3 أدوار: مهارات النين مضاعفة +100% على حساب 20% من صحتك القصوى."},
    "hisoka_bungee": {"owner": "hisoka", "name": "علكة بونجي", "en": "Bungee Gum", "emoji": "🎀", "cost": 25, "cd": 4,
                      "desc": "تسحب الخصم لضربة وتجبره على الهجوم الأساسي فقط، وتعكس ضربته القادمة عليه."},
}
CARD_HATSU: dict[str, list[str]] = {}
for _k, _v in HATSU.items():
    CARD_HATSU.setdefault(_v["owner"], []).append(_k)

HATSU_STAR_POWER = 0.10      # +10% قوة القدرة لكل نجمة على البطاقة


def hatsu_for_team(team: list[dict]) -> list[dict]:
    """يحوّل فريق البطاقات إلى قائمة قدرات هاتسو جاهزة للمعركة: [{move, power, owner}]."""
    out = []
    for m in team or []:
        for mv in CARD_HATSU.get(m.get("key"), []):
            out.append({"move": mv, "power": 1 + HATSU_STAR_POWER * m.get("stars", 0), "owner": m["key"]})
    return out


# ═════════════════════════ شجرة مهارات النين ═════════════════════════
TREE_MAX_LEVEL = 5
TREE_RESPEC_GEMS = 30
TREE_POINT_PER_LEVEL = 1
TREE_POINT_PER_FLOORS = 5          # نقطة إضافية كل 5 طوابق جديدة
# المفتاح → (الاسم، الرمز، الأب، الوصف لكل مستوى، تكلفة أساسية، شرط مستوى الأب)
TREE_NODES: dict[str, dict] = {
    "core": {"name": "مركز النين", "emoji": "🌟", "parent": None, "cost": 0, "req": 0, "branch": "core",
             "desc": "نواة هالتك. تُفتح تلقائياً وتغذّي كل المسارات."},
    "power": {"name": "مسار القوة", "emoji": "🗡️", "parent": "core", "cost": 1, "req": 0, "branch": "power",
              "desc": "+4% هجوم لكل مستوى."},
    "defense": {"name": "مسار الدفاع", "emoji": "🛡️", "parent": "core", "cost": 1, "req": 0, "branch": "defense",
                "desc": "+4% صحة قصوى و+3% دفاع لكل مستوى."},
    "speed": {"name": "مسار السرعة", "emoji": "⚡", "parent": "core", "cost": 1, "req": 0, "branch": "speed",
              "desc": "+4% سرعة لكل مستوى."},
    "finisher": {"name": "الضربة القاضية", "emoji": "💥", "parent": "power", "cost": 2, "req": 2, "branch": "power",
                 "desc": "+2% حرجة و+3% تحطيم دروع الخصم لكل مستوى."},
    "nenboost": {"name": "تعزيز النين", "emoji": "🔥", "parent": "power", "cost": 2, "req": 2, "branch": "power",
                 "desc": "+8% قوة مهارات النين و+1 استعادة طاقة لكل مستوى."},
    "absorb": {"name": "امتصاص الضرر", "emoji": "🧱", "parent": "defense", "cost": 2, "req": 2, "branch": "defense",
               "desc": "−2% من كل ضرر تتلقاه لكل مستوى."},
    "aurawall": {"name": "جدار الهالة", "emoji": "🔰", "parent": "defense", "cost": 2, "req": 2, "branch": "defense",
                 "desc": "درع هالة في بداية القتال بـ5% من صحتك لكل مستوى، يمتص 60% من الضربات."},
    "swift": {"name": "السرعة الفائقة", "emoji": "💨", "parent": "speed", "cost": 2, "req": 2, "branch": "speed",
              "desc": "+2% مراوغة و+3% ضربة مزدوجة لكل مستوى."},
    "mirror": {"name": "عكس الضربات", "emoji": "🪞", "parent": "speed", "cost": 2, "req": 2, "branch": "speed",
               "desc": "+3% عكس 30% من الضرر و+6% قوة قدرات البطاقات (القدرات الكامنة) لكل مستوى."},
}
TREE_BRANCH_COLOR = {"core": (255, 214, 90), "power": (255, 110, 80), "defense": (80, 170, 255), "speed": (250, 220, 70)}
TREE_BRANCH_AR = {"power": "القوة والضرر", "defense": "الدفاع والحيوية", "speed": "السرعة والخاصة"}
TREE_ORDER = ["core", "power", "defense", "speed", "finisher", "nenboost", "absorb", "aurawall", "swift", "mirror"]


def parse_tree(raw: str | None) -> dict[str, int]:
    """يقرأ عمود users.tree (نص مثل power:2,finisher:1) إلى قاموس. يتجاهل ما ليس صالحاً."""
    out: dict[str, int] = {}
    for part in (raw or "").split(","):
        k, _, v = part.partition(":")
        if k in TREE_NODES and k != "core" and v.strip().isdigit():
            out[k] = min(TREE_MAX_LEVEL, int(v))
    return out


def dump_tree(levels: dict[str, int]) -> str:
    return ",".join(f"{k}:{v}" for k, v in levels.items() if v > 0 and k in TREE_NODES)


def node_cost(key: str, current: int) -> int:
    """تكلفة الارتقاء من المستوى الحالي إلى التالي (تزداد تدريجياً)."""
    return TREE_NODES[key]["cost"] + current // 2


def can_upgrade(levels: dict[str, int], key: str, points: int) -> tuple[bool, str]:
    node = TREE_NODES.get(key)
    if node is None or key == "core":
        return False, "عقدة غير موجودة."
    cur = levels.get(key, 0)
    if cur >= TREE_MAX_LEVEL:
        return False, "هذه العقدة بلغت أقصى مستوى."
    parent = node["parent"]
    if parent and parent != "core" and levels.get(parent, 0) < node["req"]:
        return False, f"تحتاج «{TREE_NODES[parent]['name']}» بمستوى {node['req']} أولاً."
    cost = node_cost(key, cur)
    if points < cost:
        return False, f"تحتاج {cost} نقاط نين (عندك {points})."
    return True, ""


def spent_points(levels: dict[str, int]) -> int:
    return sum(node_cost(k, i) for k, lv in levels.items() if k in TREE_NODES for i in range(lv))


def tree_effects(levels: dict[str, int]) -> dict[str, float]:
    """يحوّل مستويات العقد إلى مؤثرات رقمية تستخدمها قاعدة البيانات (نِسَب الإحصائيات) والمعركة."""
    lv = lambda k: levels.get(k, 0)  # noqa: E731
    return {
        "atk_pct": 0.04 * lv("power"),
        "hp_pct": 0.04 * lv("defense"),
        "def_pct": 0.03 * lv("defense"),
        "speed_pct": 0.04 * lv("speed"),
        "crit": min(0.15, 0.02 * lv("finisher")),
        "pierce": min(0.20, 0.03 * lv("finisher")),
        "amp": 0.08 * lv("nenboost"),
        "aura_regen": lv("nenboost"),
        "reduce": min(0.10, 0.02 * lv("absorb")),
        "shield_pct": 0.05 * lv("aurawall"),
        "dodge": min(0.10, 0.02 * lv("swift")),
        "double": min(0.15, 0.03 * lv("swift")),
        "reflect": min(0.15, 0.03 * lv("mirror")),
        "assist": 0.06 * lv("mirror"),
    }


# ═════════════════════════ العتاد والموارد (سحب العتاد) ═════════════════════════
GEAR_GOLD_COST = 500
GEAR_GEM_COST = 15
GEAR_PITY = 20                      # ضمان ملحمي أو أعلى كل 20 سحبة عتاد
GEAR_WEIGHTS = [52, 32, 13, 3]      # عادي / نادر / ملحمي / أسطوري
GEAR_BONUS = {"atk": [4, 10, 22, 48], "def": [3, 7, 14, 30], "hp": [20, 50, 110, 240], "speed": [3, 5, 10, 18]}
# تأثيرات إضافية: crit/pierce/dodge/lifesteal/assist بنسبة مئوية، aura = طاقة إضافية لكل جولة
FX_LABEL = {"crit": "حرجة", "pierce": "اختراق دفاع", "dodge": "مراوغة", "lifesteal": "سرقة صحة", "assist": "قوة النداء", "aura": "طاقة/جولة"}
FX_CAP = {"crit": 0.25, "pierce": 0.30, "dodge": 0.20, "lifesteal": 0.20, "assist": 0.60, "aura": 10}

# المفتاح: (الاسم العربي، الرمز، النوع، الإحصائية، الندرة 0-3، التأثير، صفحات الويكي للصورة، شخصيات للبحث)
_GEAR_ROWS = [
    ("nobunaga_sword", "سيف نوبوناغا", "🗡️", "Weapon", "atk", 1, "crit:2", ["Nobunaga Hazama"], ["Nobunaga Hazama"]),
    ("killua_yoyo", "يو يو كيلوا", "🪀", "Weapon", "atk", 2, "dodge:3", ["Killua Zoldyck", "Yo-yo"], ["Killua Zoldyck"]),
    ("chrollo_knives", "خناجر كورو", "🔪", "Weapon", "atk", 2, "pierce:4", ["Chrollo Lucilfer", "Bandit's Secret"], ["Chrollo Lucilfer"]),
    ("kurapika_chains", "سلاسل كورابيكا", "⛓️", "Weapon", "atk", 3, "pierce:6,assist:8", ["Kurapika", "Chain Jail"], ["Kurapika"]),
    ("hisoka_cards", "ورق هيسوكا", "🃏", "Weapon", "atk", 1, "crit:2", ["Hisoka Morow"], ["Hisoka Morow"]),
    ("ging_rod", "سنارة جينغ", "🎣", "Weapon", "atk", 0, "", ["Ging Freecss", "Fishing Rod"], ["Ging Freecss"]),
    ("feitan_umbrella", "مظلة فيتان", "☂️", "Weapon", "atk", 1, "crit:3", ["Feitan Portor"], ["Feitan Portor"]),
    ("phantom_cloak", "عباءة فرقة العناكب", "🧥", "Armor", "def", 2, "dodge:4", ["Phantom Troupe"], ["Chrollo Lucilfer"]),
    ("zoldyck_robe", "ثوب عائلة زولديك", "🥋", "Armor", "def", 2, "dodge:3,lifesteal:2", ["Zoldyck Family"], ["Silva Zoldyck"]),
    ("leorio_suit", "بدلة ليورو", "🦺", "Armor", "def", 0, "aura:1", ["Leorio Paradinight"], ["Leorio Paradinight"]),
    ("ant_carapace", "درع النمل الملكي", "🪲", "Armor", "def", 3, "lifesteal:5,dodge:2", ["Meruem", "Chimera Ants"], ["Meruem"]),
    ("hunter_vest", "سترة الصياد", "🦺", "Armor", "def", 0, "", ["Hunter Association"], ["Wing"]),
    ("hunter_cap", "قبعة الصياد", "🧢", "Helmet", "hp", 0, "", ["Hunter License"], ["Gon Freecss"]),
    ("kurta_headband", "عصابة رأس كورتا", "🎗️", "Helmet", "hp", 1, "assist:5", ["Kurta Clan"], ["Kurapika"]),
    ("zeno_crown", "إكليل التنين", "🐉", "Helmet", "hp", 2, "aura:2,crit:2", ["Zeno Zoldyck"], ["Zeno Zoldyck"]),
    ("meruem_crown", "تاج ملك النمل", "👑", "Helmet", "hp", 3, "aura:5,assist:10", ["Meruem"], ["Meruem"]),
    ("kon_foxbear", "كون الثعلب الدب", "🦊", "Companion", "speed", 1, "dodge:2", ["Kon", "Fox Bear"], ["Kite"]),
    ("pitou_chimera", "قط الكيميرا", "🐈‍⬛", "Companion", "speed", 2, "aura:3", ["Neferpitou"], ["Neferpitou"]),
    ("zushi_homunculus", "الدمية الصغيرة", "🪆", "Companion", "speed", 0, "", ["Zushi"], ["Zushi"]),
    ("nen_stones", "أحجار النين", "💎", "Relic", "hp", 1, "aura:2", ["Nen"], ["Wing"]),
    ("greed_card", "بطاقة جريد آيلاند", "🎴", "Relic", "speed", 1, "assist:6", ["Greed Island", "Greed Island (Game)"], ["Biscuit Krueger"]),
    ("bandit_secret", "كتاب سرقة المهارات", "📕", "Relic", "atk", 3, "assist:12,crit:3", ["Bandit's Secret"], ["Chrollo Lucilfer"]),
    ("scarlet_eyes", "عيون القرمزي", "👁️", "Relic", "atk", 3, "crit:5,pierce:6", ["Scarlet Eyes", "Kurta Clan"], ["Kurapika"]),
    ("water_goblet", "كأس الماء", "🥛", "Relic", "hp", 0, "", ["Water Divination"], ["Wing"]),
    ("heavens_medal", "ميدالية الحلبة", "🏅", "Relic", "def", 0, "", ["Heavens Arena"], ["Gon Freecss"]),
]
GEAR: dict[str, dict] = {}
for _k, _ar, _em, _t, _st, _r, _fx, _wiki, _chars in _GEAR_ROWS:
    GEAR[_k] = {"key": _k, "name": _ar, "emoji": _em, "type": _t, "stat": _st, "r": _r, "fx": _fx,
                "wiki": _wiki, "chars": _chars, "slot": f"gear_{_k}"}
GEAR_BY_NAME = {v["name"]: v for v in GEAR.values()}
GEAR_BY_RARITY = {r: [v for v in GEAR.values() if v["r"] == r] for r in range(4)}
GEAR_TYPE_EMOJI = {"Relic": "🔮"}
RARITY_AR = ["عادي", "نادر", "ملحمي", "أسطوري"]


def parse_fx(raw: str | None) -> dict[str, float]:
    """نص التأثيرات 'crit:4,assist:10' → {'crit': 0.04, 'assist': 0.10, 'aura': 2}."""
    out: dict[str, float] = {}
    for part in (raw or "").split(","):
        k, _, v = part.partition(":")
        if k in FX_LABEL and v.strip().lstrip("-").isdigit():
            n = int(v)
            out[k] = float(n) if k == "aura" else n / 100
    return out


def fx_text(raw: str | None) -> str:
    fx = parse_fx(raw)
    parts = []
    for k, v in fx.items():
        parts.append(f"+{int(v)} {FX_LABEL[k]}" if k == "aura" else f"+{round(v * 100)}% {FX_LABEL[k]}")
    return " · ".join(parts)


def sum_fx(rows: list[str]) -> dict[str, float]:
    tot: dict[str, float] = {}
    for raw in rows:
        for k, v in parse_fx(raw).items():
            tot[k] = tot.get(k, 0) + v
    return {k: min(FX_CAP[k], v) for k, v in tot.items()}


def roll_gear(pity: int, rng: random.Random, min_rarity: int = 0, legend_chance: float | None = None) -> tuple[dict, int]:
    """يسحب قطعة عتاد. يعيد (القطعة كصف جاهز للإدخال في الحقيبة، عداد الضمان الجديد)."""
    if pity + 1 >= GEAR_PITY or min_rarity >= 2:
        lc = 0.17 if legend_chance is None else legend_chance
        r = 3 if rng.random() < lc else 2
    else:
        r = rng.choices([0, 1, 2, 3], GEAR_WEIGHTS)[0]
    r = max(r, min_rarity)
    g = rng.choice(GEAR_BY_RARITY[r])
    return gear_item(g), (0 if r >= 2 else pity + 1)


def gear_item(g: dict) -> dict:
    return {"name": g["name"], "type": g["type"], "stat": g["stat"], "bonus": GEAR_BONUS[g["stat"]][g["r"]],
            "rarity": ["common", "rare", "epic", "legendary"][g["r"]], "effect": g["fx"], "gear_key": g["key"]}


def find_gear(text: str) -> dict | None:
    """يبحث عن قطعة عتاد بالاسم العربي أو المفتاح (يقبل جزءاً من الاسم)."""
    q = (text or "").strip().lower().replace("_", " ")
    if not q:
        return None
    for v in GEAR.values():
        if q in (v["name"].lower(), v["key"].replace("_", " ")):
            return v
    for v in GEAR.values():
        if q in v["name"].lower() or q in v["key"].replace("_", " "):
            return v
    return None


# ═════════════════════════ السوق الأسود ═════════════════════════
MARKET_PERIOD_H = 12                 # دورة السوق
MARKET_OPEN_H = 3                    # مدة الفتح داخل كل دورة
MARKET_MAX_BUY = 1                   # أقصى مرات شراء كل عرض للاعب الواحد
STONE_POINTS = 1                     # كل حجر نين = نقطة شجرة نين
_MARKET_BASE = {2: (4200, 55), 3: (15000, 190)}      # سعر الذهب/الجواهر الأساسي لعتاد ملحمي/أسطوري


def market_window(now: float, tz_offset_h: float = 3.0, force_until: float = 0.0) -> dict:
    """نافذة السوق الأسود الحالية. تبدأ كل دورة بتأخير عشوائي ثابت (حسب رقم الدورة) فتتغير مواعيد الفتح."""
    period_s = MARKET_PERIOD_H * 3600
    local = now + tz_offset_h * 3600
    idx = int(local // period_s)
    rnd = random.Random(idx * 7919 + 13)
    delay = rnd.uniform(0.5, MARKET_PERIOD_H - MARKET_OPEN_H - 0.5) * 3600
    start = idx * period_s + delay - tz_offset_h * 3600
    end = start + MARKET_OPEN_H * 3600
    open_ = start <= now < end
    if now < start:
        next_open = start
    else:
        nrnd = random.Random((idx + 1) * 7919 + 13)
        next_open = (idx + 1) * period_s + nrnd.uniform(0.5, MARKET_PERIOD_H - MARKET_OPEN_H - 0.5) * 3600 - tz_offset_h * 3600
    if force_until > now:
        open_, end = True, max(end if open_ else 0, force_until)
    return {"open": open_, "period": idx, "start": start, "end": end, "next_open": next_open}


def market_stock(period: int) -> list[dict]:
    """عروض الدورة (ثابتة لنفس الدورة، تتغير الأسعار بين الدورات)."""
    rnd = random.Random(period * 104729 + 7)
    offers: list[dict] = []
    epics, legends = GEAR_BY_RARITY[2], GEAR_BY_RARITY[3]
    picks = [(rnd.choice(epics), 2), (rnd.choice(epics), 2), (rnd.choice(legends), 3), (rnd.choice(legends if rnd.random() < 0.3 else epics), 3 if rnd.random() < 0.3 else 2)]
    seen: set[str] = set()
    for g, r in picks:
        if g["key"] in seen:
            alts = [x for x in GEAR_BY_RARITY[g["r"]] if x["key"] not in seen]
            g = rnd.choice(alts) if alts else g
        seen.add(g["key"])
        gold, gems = _MARKET_BASE[g["r"]]
        mult = rnd.uniform(0.7, 1.45)
        use_gems = rnd.random() < 0.4
        offers.append({"slot": len(offers), "kind": "gear", "key": g["key"], "name": g["name"], "emoji": g["emoji"], "r": g["r"],
                       "gold": 0 if use_gems else int(gold * mult // 50 * 50), "gems": int(gems * mult) if use_gems else 0,
                       "qty": 1 if g["r"] == 3 else rnd.randint(1, 3)})
    n = rnd.choice([1, 2, 3])
    offers.append({"slot": len(offers), "kind": "stone", "key": "stone", "name": f"حجر نين ×{n}", "emoji": "💠", "r": 2, "n": n,
                   "gold": int(n * 2600 * rnd.uniform(0.75, 1.3) // 50 * 50), "gems": 0, "qty": rnd.randint(2, 4)})
    offers.append({"slot": len(offers), "kind": "crate", "key": "crate", "name": "صندوق عتاد حصري", "emoji": "📦", "r": 2,
                   "gold": 0, "gems": int(40 * rnd.uniform(0.75, 1.3)), "qty": rnd.randint(1, 3)})
    return offers


# ═════════════════════════ الصناديق ═════════════════════════
CRATE_MIN_RARITY = 2                  # صندوق العتاد الحصري يعطي ملحمياً أو أعلى
CRATE_LEGEND_CHANCE = 0.22


# ═════════════════════════ المواسم ═════════════════════════
SEASON_DAYS = int(os.environ.get("SEASON_DAYS", "30"))
SEASON_PLAYER_REWARDS = [   # (ذهب، جواهر، لقب)
    (30000, 300, "👑 ملك الموسم"), (20000, 200, "🥈 ولي عهد البرج"), (12000, 120, "🥉 حارس القمة"),
]
SEASON_TOP_REWARD = (4000, 40, "🌟 من نخبة الموسم")       # المراكز 4-10
SEASON_GANG_REWARD = (40000, 250, "🏴 العصابة المسيطرة")  # لكل عضو في العصابة الأولى (يُقسَّم ذهبها على الأعضاء)
SEASON_TOP_N = 10


# ═════════════════════════ العصابات ═════════════════════════
GANG_MIN_FLOOR = 40
GANG_COST_GOLD = 100_000
GANG_COST_GEMS = 250
GANG_MAX_MEMBERS = 20
GANG_NAME_MIN, GANG_NAME_MAX = 3, 24
STEAL_PCT = (0.15, 0.20)              # نسبة ما تسلبه العصابة الفائزة من خزينة الخاسرة
GANG_ROLES = {"leader": "زعيم", "deputy": "نائب", "member": "عضو"}
GANG_DEPOSIT_MIN = 100
CRATES_PER_MEMBER_ON_CLEAR = 1
# مهام العصابة الأسبوعية: (المفتاح، الرمز، العنوان، هدف لكل عضو، ذهب للخزينة لكل عضو)
GANG_MISSIONS = [
    ("points", "⚔️", "اجمعوا {n:,} نقطة قتالية", 60, 400),
    ("boss", "👹", "ألحقوا {n:,} ضرر بزعيم الأسبوع", 6000, 500),
    ("wins", "🏰", "اكسبوا {n:,} معركة في البرج", 8, 300),
]
POINTS_PER_WIN_BASE = 10


def combat_points(floor: int) -> int:
    return POINTS_PER_WIN_BASE + floor // 5


def gang_mission_targets(members: int) -> list[dict]:
    m = max(2, min(members, GANG_MAX_MEMBERS))
    return [{"key": k, "emoji": e, "title": t.format(n=per * m), "target": per * m, "gold": g * m}
            for k, e, t, per, g in GANG_MISSIONS]


# ═════════════════════════ المهام الأسبوعية (فردية) ═════════════════════════
WEEKLY_BONUS_GEMS = 20
# المفتاح، الرمز، العنوان، خيارات الهدف، ذهب، جواهر
WEEKLY_POOL = [
    ("floors", "🏰", "اصعد {n} طوابق في البرج", (4, 6, 8), 700, 6),
    ("gold", "💰", "اجمع {n:,} ذهب", (4000, 7000, 12000), 600, 5),
    ("wins", "⚔️", "اكسب {n} معركة", (15, 25), 650, 5),
    ("boss", "👹", "اضرب الزعيم {n} مرات", (3, 5), 800, 8),
    ("tree", "🌳", "طوّر شجرة النين {n} مرات", (3, 5), 600, 6),
]


def roll_weekly(seed: str) -> list[dict]:
    rnd = random.Random(seed)
    out = []
    for key, emoji, title, counts, gold, gems in rnd.sample(WEEKLY_POOL, 3):
        n = rnd.choice(counts)
        scale = counts.index(n) + 1
        out.append({"key": key, "emoji": emoji, "title": title.format(n=n), "target": n, "gold": gold * scale, "gems": gems * scale})
    return out


def clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def fmt_pct(v: float) -> str:
    return f"{round(v * 100)}%"


def ceil_div(a: int, b: int) -> int:
    return math.ceil(a / b)
