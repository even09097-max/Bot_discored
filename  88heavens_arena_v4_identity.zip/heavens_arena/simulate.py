"""
محاكاة موازنة: لاعب يصعد البرج بدون أي عتاد، ونقيس نسبة الفوز وطول القتال.
شغّلها بعد أي تعديل على ENEMY_CURVE في game.py:  python simulate.py
"""
from __future__ import annotations

import random
import statistics
import sys

import game as g

ALLOC = ["atk", "hp", "atk", "def", "hp", "atk", "speed", "hp", "def", "atk"]  # توزيع متوازن
BUCKETS = [(1, 9), (10, 19), (20, 39), (40, 59), (60, 79), (80, 89), (90, 99), (100, 100)]


def new_player() -> dict:
    return {"level": 1, "xp": 0, "floor": 1, "atk": 15, "def": 5, "hp": 100, "speed": 10,
            "cur": 100, "nen": None, "pts_given": 0}


def to_user(p: dict) -> dict:
    return {"level": p["level"], "t_hp": p["hp"], "cur_hp": p["cur"], "t_atk": p["atk"],
            "t_def": p["def"], "t_speed": p["speed"], "nen_type": p["nen"] or "None", "username": "sim"}


def level_up(p: dict) -> None:
    while p["xp"] >= g.xp_needed(p["level"]):
        p["xp"] -= g.xp_needed(p["level"])
        p["level"] += 1
        p["hp"] += g.LEVEL_HP_BONUS
        for _ in range(g.POINTS_PER_LEVEL):
            stat = ALLOC[p["pts_given"] % len(ALLOC)]
            p["pts_given"] += 1
            p[stat] += g.POINT_VALUE[stat]


def run_one(rng: random.Random, stats: dict) -> dict:
    p = new_player()
    attempts = 0
    while p["floor"] <= g.MAX_FLOOR and attempts < 3000:
        if p["floor"] >= g.NEN_UNLOCK_FLOOR and not p["nen"]:
            p["nen"] = g.roll_nen(rng)
        if p["cur"] < g.MIN_HP_PCT_TO_CLIMB * p["hp"]:
            p["cur"] = p["hp"]                      # يستريح (الوقت لا يهم هنا)
        enemy = g.enemy_for_floor(p["floor"], rng)
        battle = g.Battle(g.fighter_from_user(to_user(p), "p"), enemy, rng)
        while not battle.over:
            battle.play_round(battle.suggest_action())
        attempts += 1
        key = next(b for b in BUCKETS if b[0] <= p["floor"] <= b[1])
        s = stats.setdefault(key, {"w": 0, "n": 0, "rounds": [], "hp_lost": []})
        s["n"] += 1
        s["rounds"].append(battle.round)
        if battle.winner == "player":
            s["w"] += 1
            s["hp_lost"].append(1 - battle.p.hp / battle.p.max_hp if battle.p.max_hp else 0)
            p["cur"] = battle.p.hp
            _, xp = g.floor_rewards(p["floor"], rng)
            p["xp"] += xp
            level_up(p)
            if p["floor"] >= g.MAX_FLOOR:
                break
            p["floor"] += 1
        else:
            p["cur"] = max(1, int(g.LOSS_HP_PCT * p["hp"]))
    return {"floor": p["floor"], "level": p["level"], "attempts": attempts}


def main(runs: int = 150) -> None:
    rng = random.Random(7)
    stats: dict = {}
    results = [run_one(rng, stats) for _ in range(runs)]
    print(f"{'الطوابق':<12}{'فوز%':>7}{'جولات':>8}{'خسارة HP عند الفوز':>22}")
    for b in BUCKETS:
        s = stats.get(b)
        if not s:
            continue
        lost = statistics.mean(s["hp_lost"]) * 100 if s["hp_lost"] else 0
        print(f"{b[0]:>3}-{b[1]:<7}{100 * s['w'] / s['n']:>7.0f}{statistics.mean(s['rounds']):>8.1f}{lost:>21.0f}%")
    reached = sum(1 for r in results if r["floor"] >= g.MAX_FLOOR)
    print(f"\nوصلوا للطابق 100: {reached}/{runs} | متوسط المستوى النهائي: "
          f"{statistics.mean(r['level'] for r in results):.0f} | "
          f"متوسط عدد المعارك: {statistics.mean(r['attempts'] for r in results):.0f}")


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 150)
