"""
طبقة قاعدة البيانات.

- sqlite3 المدمج داخل thread (asyncio.to_thread) حتى لا تبلوك حلقة البوت.
- مخطط موحّد + ترقية تلقائية لقاعدة قديمة (تضيف الأعمدة والجداول الناقصة بدون حذف بيانات).
- كل تغيير مالي يمر عبر _money فيُسجَّل في جدول ledger (سجل العملات) داخل نفس المعاملة.
"""
from __future__ import annotations

import asyncio
import json
import os
import random
import sqlite3
import time
from typing import Any, Callable

import cards as cd
import game as g
import hatsu as ht
from game import GameError
from db_ext import DatabaseExt

TZ_OFFSET_H = float(os.environ.get("TZ_OFFSET_HOURS", "3"))   # العراق = +3

USER_COLUMNS = {
    "username": "TEXT",
    "level": "INTEGER NOT NULL DEFAULT 1",
    "xp": "INTEGER NOT NULL DEFAULT 0",
    "floor": "INTEGER NOT NULL DEFAULT 1",
    "hp": "INTEGER NOT NULL DEFAULT 100",
    "max_hp": "INTEGER NOT NULL DEFAULT 100",
    "atk": "INTEGER NOT NULL DEFAULT 15",
    "def": "INTEGER NOT NULL DEFAULT 5",
    "speed": "INTEGER NOT NULL DEFAULT 10",
    "nen_type": "TEXT DEFAULT 'None'",
    "gold": "INTEGER NOT NULL DEFAULT 500",
    "gems": "INTEGER NOT NULL DEFAULT 10",
    "guild_id": "INTEGER DEFAULT NULL",
    "stat_points": "INTEGER NOT NULL DEFAULT 0",
    "hp_updated": "REAL NOT NULL DEFAULT 0",
    "pity": "INTEGER NOT NULL DEFAULT 0",
    "last_daily": "REAL NOT NULL DEFAULT 0",
    "daily_streak": "INTEGER NOT NULL DEFAULT 0",
    "wins": "INTEGER NOT NULL DEFAULT 0",
    "losses": "INTEGER NOT NULL DEFAULT 0",
    "vow": "TEXT DEFAULT ''",
    "boss_last": "REAL NOT NULL DEFAULT 0",
    "boss_day": "INTEGER NOT NULL DEFAULT 0",
    "boss_used": "INTEGER NOT NULL DEFAULT 0",
    "last_hunt": "REAL NOT NULL DEFAULT 0",
    "hunts": "INTEGER NOT NULL DEFAULT 0",
    "pulls": "INTEGER NOT NULL DEFAULT 0",
    "best_enh": "INTEGER NOT NULL DEFAULT 0",
    "blessing": "INTEGER NOT NULL DEFAULT 0",
    "team": "TEXT DEFAULT ''",                       # مفاتيح بطاقات الفريق مفصولة بفواصل
    "summon_pity": "INTEGER NOT NULL DEFAULT 0",     # عدّاد ضمان الاستدعاء (منفصل عن ضمان السحب)
    "summons": "INTEGER NOT NULL DEFAULT 0",
    # ── تحديث 3: النين والعتاد والعصابات والمواسم ──
    "tree": "TEXT DEFAULT ''",                        # مستويات شجرة النين: power:2,finisher:1
    "tree_pts": "INTEGER NOT NULL DEFAULT 0",         # نقاط شجرة النين غير المصروفة
    "last_seen": "REAL NOT NULL DEFAULT 0",           # آخر تفاعل مع البوت (لتحديد «متصل» للتحدي المباشر)
    "title": "TEXT DEFAULT ''",                       # لقب حصري من المواسم
    "crates": "INTEGER NOT NULL DEFAULT 0",           # صناديق عتاد حصرية
    "gear_pity": "INTEGER NOT NULL DEFAULT 0",
    "gear_pulls": "INTEGER NOT NULL DEFAULT 0",
    "gang_role": "TEXT DEFAULT 'member'",             # leader / deputy / member
}
INVENTORY_COLUMNS = {
    "user_id": "INTEGER",
    "item_name": "TEXT",
    "item_type": "TEXT",
    "stat": "TEXT",
    "stat_bonus": "INTEGER NOT NULL DEFAULT 0",
    "rarity": "TEXT DEFAULT 'common'",
    "is_equipped": "INTEGER NOT NULL DEFAULT 0",
    "lvl": "INTEGER NOT NULL DEFAULT 0",
    "effect": "TEXT DEFAULT ''",                      # تأثيرات عتاد هانتر: crit:4,assist:10
    "gear_key": "TEXT DEFAULT ''",
}
GUILD_COLUMNS = {        # «العصابة» (الاسم القديم: عصابة)
    "guild_name": "TEXT",
    "leader_id": "INTEGER",
    "score": "INTEGER NOT NULL DEFAULT 0",
    "last_war_end": "REAL NOT NULL DEFAULT 0",
    "gold": "INTEGER NOT NULL DEFAULT 0",             # الخزينة المشتركة
    "gems": "INTEGER NOT NULL DEFAULT 0",
    "server_id": "INTEGER NOT NULL DEFAULT 0",
    "leader_role": "INTEGER NOT NULL DEFAULT 0",      # رتبة ديسكورد: [زعيم عصابة: الاسم]
    "member_role": "INTEGER NOT NULL DEFAULT 0",      # رتبة ديسكورد: [عصابة: الاسم]
    "created_ts": "REAL NOT NULL DEFAULT 0",
}
EXTRA_TABLES = {
    "cards": ("user_id INTEGER NOT NULL, card_key TEXT NOT NULL, PRIMARY KEY (user_id, card_key)", {
        "copies": "INTEGER NOT NULL DEFAULT 1", "first_ts": "REAL NOT NULL DEFAULT 0"}),
    "ledger": ("id INTEGER PRIMARY KEY AUTOINCREMENT", {
        "ts": "REAL NOT NULL DEFAULT 0", "user_id": "INTEGER", "currency": "TEXT", "amount": "INTEGER NOT NULL DEFAULT 0",
        "balance": "INTEGER NOT NULL DEFAULT 0", "reason": "TEXT", "note": "TEXT DEFAULT ''"}),
    "settings": ("rowid_ INTEGER PRIMARY KEY AUTOINCREMENT", {
        "scope": "INTEGER NOT NULL DEFAULT 0", "k": "TEXT", "v": "TEXT"}),
    "boss": ("boss_id INTEGER PRIMARY KEY AUTOINCREMENT", {
        "server_id": "INTEGER", "boss_key": "TEXT", "max_hp": "INTEGER", "hp": "INTEGER", "start_ts": "REAL", "end_ts": "REAL",
        "status": "TEXT DEFAULT 'active'", "last_hit": "INTEGER DEFAULT 0", "settled": "INTEGER NOT NULL DEFAULT 0"}),
    "boss_dmg": ("rowid_ INTEGER PRIMARY KEY AUTOINCREMENT", {
        "boss_id": "INTEGER", "user_id": "INTEGER", "damage": "INTEGER NOT NULL DEFAULT 0", "hits": "INTEGER NOT NULL DEFAULT 0"}),
    "wars": ("war_id INTEGER PRIMARY KEY AUTOINCREMENT", {
        "guild_a": "INTEGER", "guild_b": "INTEGER", "name_a": "TEXT", "name_b": "TEXT", "start_ts": "REAL", "end_ts": "REAL",
        "score_a": "INTEGER NOT NULL DEFAULT 0", "score_b": "INTEGER NOT NULL DEFAULT 0", "status": "TEXT DEFAULT 'active'",
        "server_id": "INTEGER DEFAULT 0"}),
    "war_points": ("rowid_ INTEGER PRIMARY KEY AUTOINCREMENT", {
        "war_id": "INTEGER", "user_id": "INTEGER", "guild_id": "INTEGER", "points": "INTEGER NOT NULL DEFAULT 0"}),
    "achievements": ("rowid_ INTEGER PRIMARY KEY AUTOINCREMENT", {
        "user_id": "INTEGER", "akey": "TEXT", "ts": "REAL NOT NULL DEFAULT 0"}),
    "missions": ("rowid_ INTEGER PRIMARY KEY AUTOINCREMENT", {
        "user_id": "INTEGER", "day": "INTEGER", "slot": "INTEGER", "mkey": "TEXT", "title": "TEXT", "emoji": "TEXT",
        "target": "INTEGER", "progress": "INTEGER NOT NULL DEFAULT 0", "gold": "INTEGER", "gems": "INTEGER",
        "claimed": "INTEGER NOT NULL DEFAULT 0"}),
    # الطابق ← المسيطر عليه الآن
    "floors": ("floor INTEGER PRIMARY KEY", {
        "holder_id": "INTEGER", "since": "REAL NOT NULL DEFAULT 0", "wins": "INTEGER NOT NULL DEFAULT 0"}),
    # سجل الانتقام: من خسر طابقه ولمن
    "revenge": ("id INTEGER PRIMARY KEY AUTOINCREMENT", {
        "victim_id": "INTEGER", "taker_id": "INTEGER", "floor": "INTEGER", "ts": "REAL NOT NULL DEFAULT 0",
        "status": "TEXT DEFAULT 'open'", "away": "INTEGER NOT NULL DEFAULT 0", "notified": "INTEGER NOT NULL DEFAULT 0"}),
    "gang_requests": ("rowid_ INTEGER PRIMARY KEY AUTOINCREMENT", {
        "user_id": "INTEGER", "gang_id": "INTEGER", "ts": "REAL NOT NULL DEFAULT 0"}),
    "gang_missions": ("rowid_ INTEGER PRIMARY KEY AUTOINCREMENT", {
        "gang_id": "INTEGER", "week": "INTEGER", "slot": "INTEGER", "mkey": "TEXT", "title": "TEXT", "emoji": "TEXT",
        "target": "INTEGER", "progress": "INTEGER NOT NULL DEFAULT 0", "gold": "INTEGER NOT NULL DEFAULT 0",
        "done": "INTEGER NOT NULL DEFAULT 0"}),
    "gang_contrib": ("rowid_ INTEGER PRIMARY KEY AUTOINCREMENT", {
        "gang_id": "INTEGER", "week": "INTEGER", "user_id": "INTEGER", "points": "INTEGER NOT NULL DEFAULT 0",
        "damage": "INTEGER NOT NULL DEFAULT 0", "wins": "INTEGER NOT NULL DEFAULT 0"}),
    "weekly_missions": ("rowid_ INTEGER PRIMARY KEY AUTOINCREMENT", {
        "user_id": "INTEGER", "week": "INTEGER", "slot": "INTEGER", "mkey": "TEXT", "title": "TEXT", "emoji": "TEXT",
        "target": "INTEGER", "progress": "INTEGER NOT NULL DEFAULT 0", "gold": "INTEGER", "gems": "INTEGER",
        "claimed": "INTEGER NOT NULL DEFAULT 0"}),
    "seasons": ("season_id INTEGER PRIMARY KEY AUTOINCREMENT", {
        "start_ts": "REAL", "end_ts": "REAL", "status": "TEXT DEFAULT 'active'", "name": "TEXT"}),
    "season_hall": ("rowid_ INTEGER PRIMARY KEY AUTOINCREMENT", {
        "season_id": "INTEGER", "kind": "TEXT", "rank": "INTEGER", "ref_id": "INTEGER", "name": "TEXT", "title": "TEXT",
        "floor": "INTEGER", "level": "INTEGER"}),
    "market_buys": ("rowid_ INTEGER PRIMARY KEY AUTOINCREMENT", {
        "user_id": "INTEGER", "period": "INTEGER", "slot": "INTEGER", "qty": "INTEGER NOT NULL DEFAULT 0"}),
}
MAX_GUILD_MEMBERS = ht.GANG_MAX_MEMBERS
WEEKLY_GOLD_REASONS = {"climb", "hunt", "boss", "daily", "duel", "mission", "achieve", "war", "event", "sell", "revenge", "weekly"}


def day_index(now: float | None = None) -> int:
    return int(((now or time.time()) + TZ_OFFSET_H * 3600) // 86400)


class Database(DatabaseExt):
    def __init__(self, path: str = "tower_arena.db"):
        self.path = path
        self._conn: sqlite3.Connection | None = None
        self._lock = asyncio.Lock()

    # ───────────── البنية ─────────────
    async def connect(self) -> None:
        def _open() -> sqlite3.Connection:
            conn = sqlite3.connect(self.path, check_same_thread=False)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA foreign_keys=ON")
            return conn

        self._conn = await asyncio.to_thread(_open)
        await self._run(self._create_schema)

    async def close(self) -> None:
        if self._conn:
            await asyncio.to_thread(self._conn.close)
            self._conn = None

    @staticmethod
    def _ensure_table(conn: sqlite3.Connection, table: str, pk_sql: str, columns: dict[str, str]) -> None:
        conn.execute(f"CREATE TABLE IF NOT EXISTS {table} ({pk_sql})")
        existing = {r["name"] for r in conn.execute(f"PRAGMA table_info({table})")}
        for col, ddl in columns.items():
            if col not in existing:
                conn.execute(f'ALTER TABLE {table} ADD COLUMN "{col}" {ddl}')

    def _create_schema(self, conn: sqlite3.Connection) -> None:
        self._ensure_table(conn, "users", "user_id INTEGER PRIMARY KEY", USER_COLUMNS)
        self._ensure_table(conn, "inventory", "item_id INTEGER PRIMARY KEY AUTOINCREMENT", INVENTORY_COLUMNS)
        self._ensure_table(conn, "guilds", "guild_id INTEGER PRIMARY KEY AUTOINCREMENT", GUILD_COLUMNS)
        for table, (pk, cols) in EXTRA_TABLES.items():
            self._ensure_table(conn, table, pk, cols)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_users_rank ON users(floor DESC, level DESC)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_inv_user ON inventory(user_id)")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_guild_name ON guilds(guild_name)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ledger_user ON ledger(user_id, id DESC)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ledger_ts ON ledger(ts)")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_settings ON settings(scope, k)")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_bossdmg ON boss_dmg(boss_id, user_id)")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_warpts ON war_points(war_id, user_id)")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_missions ON missions(user_id, day, slot)")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_ach ON achievements(user_id, akey)")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_greq ON gang_requests(user_id, gang_id)")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_gmis ON gang_missions(gang_id, week, slot)")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_gcon ON gang_contrib(gang_id, week, user_id)")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_wmis ON weekly_missions(user_id, week, slot)")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_mbuy ON market_buys(user_id, period, slot)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_revenge ON revenge(victim_id, status)")
        self._migrate_v3(conn)

    @staticmethod
    def _migrate_v3(conn: sqlite3.Connection) -> None:
        """ترقية لمرة واحدة من 251 طابقاً إلى 100: يُحوَّل كل طابق نسبياً (251 ← 100) وتُمنح نقاط نين بعدد مستويات اللاعب."""
        if conn.execute("SELECT 1 FROM settings WHERE scope = 0 AND k = 'migr_v3'").fetchone():
            return
        old_max = 251
        for r in conn.execute("SELECT user_id, floor, level FROM users").fetchall():
            if r["floor"] > 1:
                nf = max(1, min(g.MAX_FLOOR, -(-r["floor"] * g.MAX_FLOOR // old_max)))
                conn.execute("UPDATE users SET floor = ? WHERE user_id = ?", (nf, r["user_id"]))
            conn.execute("UPDATE users SET tree_pts = ? WHERE user_id = ? AND tree_pts = 0",
                         (max(0, r["level"] - 1) * ht.TREE_POINT_PER_LEVEL, r["user_id"]))
        conn.execute("INSERT OR IGNORE INTO settings (scope, k, v) VALUES (0, 'migr_v3', '1')")

    async def _run(self, fn: Callable[[sqlite3.Connection], Any]) -> Any:
        """ينفذ fn داخل معاملة واحدة، متسلسلاً، بعيداً عن حلقة الأحداث."""
        assert self._conn is not None, "استدعِ connect() أولاً"

        def _exec() -> Any:
            try:
                result = fn(self._conn)
                self._conn.commit()
                return result
            except BaseException:
                self._conn.rollback()
                raise

        async with self._lock:
            return await asyncio.to_thread(_exec)

    # ───────────── مساعدات داخلية (متزامنة) ─────────────
    @staticmethod
    def _user_with_totals(conn: sqlite3.Connection, user_id: int) -> dict | None:
        row = conn.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)).fetchone()
        if row is None:
            return None
        u = dict(row)
        bonus: dict[str, int] = {}
        names: list[str] = []
        gear_fx: list[str] = []
        for r in conn.execute(
                "SELECT item_name, stat, stat_bonus, lvl, effect FROM inventory "
                "WHERE user_id = ? AND is_equipped = 1 AND item_type != 'Spell' AND stat IS NOT NULL", (user_id,)):
            bonus[r["stat"]] = bonus.get(r["stat"], 0) + g.enhanced_bonus(r["stat_bonus"], r["lvl"] or 0)
            names.append(r["item_name"])
            if r["effect"]:
                gear_fx.append(r["effect"])
        levels = ht.parse_tree(u.get("tree"))
        te = ht.tree_effects(levels)
        gfx = ht.sum_fx(gear_fx)
        u["tree_levels"] = levels
        u["fx"] = {
            "crit": min(0.40, gfx.get("crit", 0) + te["crit"]), "pierce": min(0.50, gfx.get("pierce", 0) + te["pierce"]),
            "dodge": min(0.30, gfx.get("dodge", 0) + te["dodge"]), "lifesteal": gfx.get("lifesteal", 0),
            "assist": gfx.get("assist", 0) + te["assist"], "aura": gfx.get("aura", 0) + te["aura_regen"],
            "amp": te["amp"], "reduce": te["reduce"], "reflect": te["reflect"], "double": te["double"],
            "shield_pct": te["shield_pct"],
        }
        u["tree_effects"] = te
        pct, set_name, pieces = g.set_bonus_pct(names)
        u["set_name"], u["set_pct"], u["set_pieces"] = set_name, pct, pieces
        # بطاقات الفريق: إحصائيات سلبية دائمة تُضاف بعد مضاعف الطقم (فتبقى أرقام الفريق المعروضة هي ما يُضاف فعلاً)
        team_keys = [k for k in (u.get("team") or "").split(",") if k]
        team_cards: list[dict] = []
        tb = {"atk": 0, "def": 0, "speed": 0, "hp": 0}
        if team_keys:
            owned = {r["card_key"]: r["copies"] for r in conn.execute(
                "SELECT card_key, copies FROM cards WHERE user_id = ?", (user_id,))}
            pairs = [(k, owned[k]) for k in team_keys if k in owned]
            tb = cd.team_bonus(pairs)
            team_cards = cd.team_fighters(pairs)
        u["team_cards"], u["team_bonus"] = team_cards, tb
        u["t_atk"] = round((u["atk"] + bonus.get("atk", 0)) * (1 + pct) * (1 + te["atk_pct"])) + tb["atk"]
        u["t_def"] = round((u["def"] + bonus.get("def", 0)) * (1 + pct) * (1 + te["def_pct"])) + tb["def"]
        u["t_speed"] = round((u["speed"] + bonus.get("speed", 0)) * (1 + pct) * (1 + te["speed_pct"])) + tb["speed"]
        u["t_hp"] = round((u["max_hp"] + bonus.get("hp", 0)) * (1 + pct) * (1 + te["hp_pct"])) + tb["hp"]
        u["power"] = g.power_of(u["t_atk"], u["t_def"], u["t_hp"], u["t_speed"])
        elapsed_min = max(0.0, time.time() - u["hp_updated"]) / 60
        regen = int(elapsed_min * g.REGEN_PCT_PER_MIN * u["t_hp"])
        u["cur_hp"] = max(0, min(u["t_hp"], u["hp"] + regen))
        u["minutes_to_climb"] = 0.0
        need = g.MIN_HP_PCT_TO_CLIMB * u["t_hp"] - u["cur_hp"]
        if need > 0:
            u["minutes_to_climb"] = need / (g.REGEN_PCT_PER_MIN * u["t_hp"])
        return u

    @staticmethod
    def _set_hp(conn: sqlite3.Connection, user_id: int, hp: int) -> None:
        conn.execute("UPDATE users SET hp = ?, hp_updated = ? WHERE user_id = ?",
                     (max(0, int(hp)), time.time(), user_id))

    @staticmethod
    def _money(conn: sqlite3.Connection, user_id: int, currency: str, delta: int, reason: str, note: str = "") -> int:
        """يغيّر رصيد اللاعب ويكتب العملية في السجل. يرفع GameError لو الرصيد لا يكفي. يعيد الرصيد الجديد."""
        if currency not in ("gold", "gems"):
            raise GameError("عملة غير صالحة.")
        delta = int(delta)
        if delta == 0:
            return conn.execute(f"SELECT {currency} AS b FROM users WHERE user_id = ?", (user_id,)).fetchone()["b"]
        if delta < 0:
            cur = conn.execute(f"UPDATE users SET {currency} = {currency} + ? WHERE user_id = ? AND {currency} >= ?",
                               (delta, user_id, -delta))
            if cur.rowcount == 0:
                raise GameError(f"رصيدك لا يكفي ({-delta} {'💰' if currency == 'gold' else '💎'}).")
        else:
            conn.execute(f"UPDATE users SET {currency} = {currency} + ? WHERE user_id = ?", (delta, user_id))
        bal = conn.execute(f"SELECT {currency} AS b FROM users WHERE user_id = ?", (user_id,)).fetchone()["b"]
        conn.execute("INSERT INTO ledger (ts, user_id, currency, amount, balance, reason, note) VALUES (?,?,?,?,?,?,?)",
                     (time.time(), user_id, currency, delta, bal, reason, note))
        if currency == "gold" and delta > 0 and reason in WEEKLY_GOLD_REASONS:
            Database._bump_week(conn, user_id, "gold", delta)
        return bal

    # ───────────── الإعدادات والأحداث ─────────────
    async def get_setting(self, scope: int, key: str) -> str | None:
        def fn(conn):
            r = conn.execute("SELECT v FROM settings WHERE scope = ? AND k = ?", (scope, key)).fetchone()
            return r["v"] if r else None
        return await self._run(fn)

    async def set_setting(self, scope: int, key: str, value: str | None) -> None:
        def fn(conn):
            if value is None:
                conn.execute("DELETE FROM settings WHERE scope = ? AND k = ?", (scope, key))
            else:
                conn.execute("INSERT INTO settings (scope, k, v) VALUES (?,?,?) "
                             "ON CONFLICT(scope, k) DO UPDATE SET v = excluded.v", (scope, key, value))
        await self._run(fn)

    async def get_channel(self, server_id: int, kind: str) -> int | None:
        """قناة الإعلانات لنوع معيّن (floor/boss/gacha/war/event) وإلا القناة العامة all."""
        def fn(conn):
            for k in (f"ch:{kind}", "ch:all"):
                r = conn.execute("SELECT v FROM settings WHERE scope = ? AND k = ?", (server_id, k)).fetchone()
                if r and r["v"]:
                    return int(r["v"])
            return None
        return await self._run(fn)

    async def set_channel(self, server_id: int, kind: str, channel_id: int | None) -> None:
        await self.set_setting(server_id, f"ch:{kind}", str(channel_id) if channel_id else None)

    async def get_channels(self, server_id: int) -> dict[str, int]:
        def fn(conn):
            return {r["k"][3:]: int(r["v"]) for r in conn.execute(
                "SELECT k, v FROM settings WHERE scope = ? AND k LIKE 'ch:%'", (server_id,))}
        return await self._run(fn)

    async def get_event(self) -> dict | None:
        raw = await self.get_setting(0, "event")
        if not raw:
            return None
        try:
            ev = json.loads(raw)
        except ValueError:
            return None
        return ev if ev.get("until", 0) > time.time() else None

    async def set_event(self, kind: str | None, mult: float = 2.0, hours: float = 1) -> None:
        if not kind:
            await self.set_setting(0, "event", None)
        else:
            await self.set_setting(0, "event", json.dumps({"kind": kind, "mult": mult, "until": time.time() + hours * 3600}))

    # ───────────── اللاعبون ─────────────
    async def ensure_user(self, user_id: int, username: str) -> dict:
        def fn(conn):
            conn.execute("INSERT OR IGNORE INTO users (user_id, username, hp_updated) VALUES (?, ?, ?)",
                         (user_id, username, time.time()))
            conn.execute("UPDATE users SET username = ? WHERE user_id = ?", (username, user_id))
            return self._user_with_totals(conn, user_id)
        return await self._run(fn)

    async def get_user(self, user_id: int) -> dict | None:
        return await self._run(lambda conn: self._user_with_totals(conn, user_id))

    async def set_hp(self, user_id: int, hp: int) -> None:
        await self._run(lambda conn: self._set_hp(conn, user_id, hp))

    async def add_gold(self, user_id: int, amount: int, reason: str = "duel") -> None:
        await self._run(lambda conn: self._money(conn, user_id, "gold", amount, reason))

    async def top_players(self, limit: int = 10, by: str = "floor") -> list[dict]:
        order = {"floor": "floor DESC, level DESC, xp DESC", "level": "level DESC, xp DESC", "gold": "gold DESC",
                 "wins": "wins DESC, floor DESC"}.get(by, "floor DESC, level DESC, xp DESC")

        def fn(conn):
            rows = conn.execute(
                f"SELECT user_id, username, floor, level, gold, wins FROM users ORDER BY {order} LIMIT ?", (limit,)).fetchall()
            return [dict(r) for r in rows]
        return await self._run(fn)

    async def count_users(self) -> int:
        return await self._run(lambda conn: conn.execute("SELECT COUNT(*) AS c FROM users").fetchone()["c"])

    async def shadow_candidates(self, exclude_id: int, limit: int = 10) -> list[dict]:
        """أقوى اللاعبين الآخرين، لاستخدام ظلالهم كخصوم في طوابق أسياد البرج."""
        def fn(conn):
            ids = [r["user_id"] for r in conn.execute(
                "SELECT user_id FROM users WHERE user_id != ? ORDER BY floor DESC, level DESC LIMIT ?",
                (exclude_id, limit))]
            return [self._user_with_totals(conn, i) for i in ids]
        return await self._run(fn)

    # ───────────── المهام والحرب (داخل المعاملة) ─────────────
    @staticmethod
    def _ensure_missions(conn: sqlite3.Connection, user_id: int, day: int) -> list[dict]:
        rows = conn.execute("SELECT * FROM missions WHERE user_id = ? AND day = ? ORDER BY slot", (user_id, day)).fetchall()
        if not rows:
            for slot, m in enumerate(g.roll_missions(f"{user_id}:{day}")):
                conn.execute("INSERT INTO missions (user_id, day, slot, mkey, title, emoji, target, gold, gems) VALUES (?,?,?,?,?,?,?,?,?)",
                             (user_id, day, slot, m["key"], m["title"], m["emoji"], m["target"], m["gold"], m["gems"]))
            rows = conn.execute("SELECT * FROM missions WHERE user_id = ? AND day = ? ORDER BY slot", (user_id, day)).fetchall()
        return [dict(r) for r in rows]

    @classmethod
    def _bump(cls, conn: sqlite3.Connection, user_id: int, key: str, n: int = 1) -> None:
        day = day_index()
        cls._ensure_missions(conn, user_id, day)
        conn.execute("UPDATE missions SET progress = MIN(target, progress + ?) WHERE user_id = ? AND day = ? AND mkey = ?",
                     (n, user_id, day, key))

    @staticmethod
    def _war_add(conn: sqlite3.Connection, user_id: int, pts: int) -> None:
        gid = conn.execute("SELECT guild_id FROM users WHERE user_id = ?", (user_id,)).fetchone()["guild_id"]
        if not gid:
            return
        now = time.time()
        w = conn.execute("SELECT * FROM wars WHERE status = 'active' AND end_ts > ? AND (guild_a = ? OR guild_b = ?)",
                         (now, gid, gid)).fetchone()
        if not w:
            return
        col = "score_a" if w["guild_a"] == gid else "score_b"
        conn.execute(f"UPDATE wars SET {col} = {col} + ? WHERE war_id = ?", (pts, w["war_id"]))
        conn.execute("INSERT INTO war_points (war_id, user_id, guild_id, points) VALUES (?,?,?,?) "
                     "ON CONFLICT(war_id, user_id) DO UPDATE SET points = points + excluded.points",
                     (w["war_id"], user_id, gid, pts))

    # ───────────── مهام أسبوعية وعصابة وسيطرة الطوابق (داخل المعاملة) ─────────────
    @staticmethod
    def _week(now: float | None = None) -> int:
        """رقم الأسبوع (يبدأ الاثنين بتوقيت TZ_OFFSET_HOURS)."""
        return (day_index(now) - 4) // 7

    @classmethod
    def _ensure_weekly(cls, conn: sqlite3.Connection, user_id: int, week: int) -> list[dict]:
        rows = conn.execute("SELECT * FROM weekly_missions WHERE user_id = ? AND week = ? ORDER BY slot", (user_id, week)).fetchall()
        if not rows:
            for slot, m in enumerate(ht.roll_weekly(f"w{user_id}:{week}")):
                conn.execute("INSERT INTO weekly_missions (user_id, week, slot, mkey, title, emoji, target, gold, gems) VALUES (?,?,?,?,?,?,?,?,?)",
                             (user_id, week, slot, m["key"], m["title"], m["emoji"], m["target"], m["gold"], m["gems"]))
            rows = conn.execute("SELECT * FROM weekly_missions WHERE user_id = ? AND week = ? ORDER BY slot", (user_id, week)).fetchall()
        return [dict(r) for r in rows]

    @classmethod
    def _bump_week(cls, conn: sqlite3.Connection, user_id: int, key: str, n: int = 1) -> None:
        week = cls._week()
        cls._ensure_weekly(conn, user_id, week)
        conn.execute("UPDATE weekly_missions SET progress = MIN(target, progress + ?) WHERE user_id = ? AND week = ? AND mkey = ?",
                     (n, user_id, week, key))

    @classmethod
    def _ensure_gang_missions(cls, conn: sqlite3.Connection, gang_id: int, week: int) -> list[dict]:
        rows = conn.execute("SELECT * FROM gang_missions WHERE gang_id = ? AND week = ? ORDER BY slot", (gang_id, week)).fetchall()
        if not rows:
            n = conn.execute("SELECT COUNT(*) AS c FROM users WHERE guild_id = ?", (gang_id,)).fetchone()["c"]
            for slot, m in enumerate(ht.gang_mission_targets(n)):
                conn.execute("INSERT INTO gang_missions (gang_id, week, slot, mkey, title, emoji, target, gold) VALUES (?,?,?,?,?,?,?,?)",
                             (gang_id, week, slot, m["key"], m["title"], m["emoji"], m["target"], m["gold"]))
            rows = conn.execute("SELECT * FROM gang_missions WHERE gang_id = ? AND week = ? ORDER BY slot", (gang_id, week)).fetchall()
        return [dict(r) for r in rows]

    @classmethod
    def _gang_progress(cls, conn: sqlite3.Connection, user_id: int, key: str, n: int) -> list[dict]:
        """يضيف مساهمة اللاعب لمهام عصابته الأسبوعية. يعيد أحداثاً للإعلان (إكمال مهمة / إنجاز الكل)."""
        row = conn.execute("SELECT guild_id FROM users WHERE user_id = ?", (user_id,)).fetchone()
        gid = row["guild_id"] if row else None
        if not gid or n <= 0 or key not in ("points", "boss", "wins"):
            return []
        week = cls._week()
        missions = cls._ensure_gang_missions(conn, gid, week)
        col = {"points": "points", "boss": "damage", "wins": "wins"}[key]
        conn.execute(f"INSERT INTO gang_contrib (gang_id, week, user_id, {col}) VALUES (?,?,?,?) "
                     f"ON CONFLICT(gang_id, week, user_id) DO UPDATE SET {col} = {col} + excluded.{col}", (gid, week, user_id, n))
        events: list[dict] = []
        for m in missions:
            if m["mkey"] != key or m["done"]:
                continue
            prog = min(m["target"], m["progress"] + n)
            done = prog >= m["target"]
            conn.execute("UPDATE gang_missions SET progress = ?, done = ? WHERE gang_id = ? AND week = ? AND slot = ?",
                         (prog, int(done), gid, week, m["slot"]))
            if done:
                conn.execute("UPDATE guilds SET gold = gold + ? WHERE guild_id = ?", (m["gold"], gid))
                events.append({"type": "mission", "gang_id": gid, "title": m["title"], "emoji": m["emoji"], "gold": m["gold"]})
        left = conn.execute("SELECT COUNT(*) AS c FROM gang_missions WHERE gang_id = ? AND week = ? AND done = 0", (gid, week)).fetchone()["c"]
        if events and left == 0:
            ids = [r["user_id"] for r in conn.execute(
                "SELECT c.user_id FROM gang_contrib c JOIN users u ON u.user_id = c.user_id AND u.guild_id = c.gang_id "
                "WHERE c.gang_id = ? AND c.week = ? AND (c.points + c.damage + c.wins) > 0", (gid, week))]
            for uid in ids:
                conn.execute("UPDATE users SET crates = crates + ? WHERE user_id = ?", (ht.CRATES_PER_MEMBER_ON_CLEAR, uid))
            events.append({"type": "all_clear", "gang_id": gid, "crates": len(ids) * ht.CRATES_PER_MEMBER_ON_CLEAR, "members": len(ids)})
        return events

    @staticmethod
    def _take_floor(conn: sqlite3.Connection, user_id: int, floor: int) -> tuple[int | None, int | None]:
        """يجعل اللاعب مسيطراً على الطابق. يعيد (المسيطر السابق إن كان لاعباً آخر، رقم سجل الانتقام)."""
        row = conn.execute("SELECT holder_id FROM floors WHERE floor = ?", (floor,)).fetchone()
        prev = row["holder_id"] if row else None
        conn.execute("INSERT INTO floors (floor, holder_id, since, wins) VALUES (?,?,?,1) "
                     "ON CONFLICT(floor) DO UPDATE SET holder_id = excluded.holder_id, since = excluded.since, wins = floors.wins + 1",
                     (floor, user_id, time.time()))
        if prev and prev != user_id:
            seen = conn.execute("SELECT last_seen FROM users WHERE user_id = ?", (prev,)).fetchone()
            away = int(not seen or time.time() - (seen["last_seen"] or 0) > g.ONLINE_WINDOW)
            cur = conn.execute("INSERT INTO revenge (victim_id, taker_id, floor, ts, status, away) VALUES (?,?,?,?, 'open', ?)",
                               (prev, user_id, floor, time.time(), away))
            return prev, cur.lastrowid
        return None, None

    # ───────────── نتائج المعارك ─────────────
    async def apply_win(self, user_id: int, hp_after: int, gold: int, xp: int) -> dict:
        """يضيف المكافآت ويرفع الطابق ويعالج الارتقاء بالمستوى. يعيد ملخصاً."""
        def fn(conn):
            u = self._user_with_totals(conn, user_id)
            level, cur_xp = u["level"], u["xp"] + xp
            gained = 0
            while cur_xp >= g.xp_needed(level):
                cur_xp -= g.xp_needed(level)
                level += 1
                gained += 1
            new_floor = min(g.MAX_FLOOR, max(u["floor"], u["floor"] + 1) if u["floor"] < g.MAX_FLOOR else g.MAX_FLOOR)
            tree_gain = gained * ht.TREE_POINT_PER_LEVEL + max(0, new_floor // ht.TREE_POINT_PER_FLOORS - u["floor"] // ht.TREE_POINT_PER_FLOORS)
            conn.execute(
                "UPDATE users SET level = ?, xp = ?, floor = ?, wins = wins + 1, "
                "stat_points = stat_points + ?, max_hp = max_hp + ?, hp = ?, hp_updated = ?, tree_pts = tree_pts + ? WHERE user_id = ?",
                (level, cur_xp, new_floor, gained * g.POINTS_PER_LEVEL, gained * g.LEVEL_HP_BONUS,
                 max(1, int(hp_after)), time.time(), tree_gain, user_id))
            self._money(conn, user_id, "gold", gold, "climb", f"الطابق {u['floor']}")
            if u["guild_id"]:
                conn.execute("UPDATE guilds SET score = score + 1 WHERE guild_id = ?", (u["guild_id"],))
            self._war_add(conn, user_id, g.WAR_POINTS_WIN)
            self._bump(conn, user_id, "win")
            self._bump_week(conn, user_id, "wins", 1)
            if new_floor > u["floor"]:
                self._bump_week(conn, user_id, "floors", 1)
            usurped, revenge_id = self._take_floor(conn, user_id, u["floor"])
            gang_events = self._gang_progress(conn, user_id, "points", ht.combat_points(u["floor"])) + \
                self._gang_progress(conn, user_id, "wins", 1)
            return {"levels_gained": gained, "level": level, "floor": new_floor, "old_floor": u["floor"],
                    "points": gained * g.POINTS_PER_LEVEL, "gold": gold, "xp": xp, "tree_points": tree_gain,
                    "usurped": usurped, "revenge_id": revenge_id, "gang_events": gang_events}
        return await self._run(fn)

    async def apply_loss(self, user_id: int) -> dict:
        def fn(conn):
            u = self._user_with_totals(conn, user_id)
            lost = min(u["gold"], int(u["gold"] * g.vow_loss_pct(u["vow"])))
            if lost:
                self._money(conn, user_id, "gold", -lost, "loss", f"الطابق {u['floor']}")
            conn.execute("UPDATE users SET losses = losses + 1 WHERE user_id = ?", (user_id,))
            self._set_hp(conn, user_id, max(1, int(g.LOSS_HP_PCT * u["t_hp"])))
            return {"gold_lost": lost}
        return await self._run(fn)

    async def duel_win(self, user_id: int, gold: int) -> None:
        def fn(conn):
            self._money(conn, user_id, "gold", gold, "duel")
            self._bump(conn, user_id, "duel")
        await self._run(fn)

    # ───────────── الترقية والنين والنذر ─────────────
    async def upgrade_stat(self, user_id: int, stat: str, amount: int) -> dict:
        if stat not in g.POINT_VALUE or amount < 1:
            raise GameError("إحصائية أو كمية غير صالحة.")
        column = {"atk": "atk", "def": "def", "hp": "max_hp", "speed": "speed"}[stat]
        gain = g.POINT_VALUE[stat] * amount

        def fn(conn):
            cur = conn.execute(
                f'UPDATE users SET stat_points = stat_points - ?, "{column}" = "{column}" + ? '
                "WHERE user_id = ? AND stat_points >= ?", (amount, gain, user_id, amount))
            if cur.rowcount == 0:
                raise GameError("ما عندك نقاط تطوير كافية. ترتقي بالمستوى لتحصل على المزيد.")
            self._bump(conn, user_id, "upgrade")
            return self._user_with_totals(conn, user_id)
        return await self._run(fn)

    async def set_nen(self, user_id: int, nen: str, cost_gems: int = 0) -> None:
        def fn(conn):
            if cost_gems:
                self._money(conn, user_id, "gems", -cost_gems, "reroll")
            conn.execute("UPDATE users SET nen_type = ? WHERE user_id = ?", (nen, user_id))
        await self._run(fn)

    async def set_vow(self, user_id: int, vow: str) -> int:
        """vow='' يعني فك النذر. أول نذر مجاني، والتغيير أو الفك يكلّف جواهر. يعيد التكلفة."""
        if vow and vow not in g.VOWS:
            raise GameError("نذر غير معروف.")

        def fn(conn):
            cur = conn.execute("SELECT vow FROM users WHERE user_id = ?", (user_id,)).fetchone()["vow"] or ""
            if cur == vow:
                raise GameError("هذا هو نذرك الحالي بالفعل." if vow else "ما عندك نذر لتفكّه.")
            cost = g.VOW_SWITCH_GEMS if cur else 0
            if cost:
                self._money(conn, user_id, "gems", -cost, "vow")
            conn.execute("UPDATE users SET vow = ? WHERE user_id = ?", (vow, user_id))
            return cost
        return await self._run(fn)

    # ───────────── الحقيبة ─────────────
    async def inventory(self, user_id: int) -> list[dict]:
        def fn(conn):
            return [dict(r) for r in conn.execute(
                "SELECT * FROM inventory WHERE user_id = ? ORDER BY is_equipped DESC, item_id", (user_id,))]
        return await self._run(fn)

    async def gacha_pull(self, user_id: int, currency: str, rng: random.Random | None = None, count: int = 1) -> list[dict]:
        rng = rng or random.Random()
        if currency not in ("gold", "gems"):
            raise GameError("عملة غير صالحة.")
        if not 1 <= count <= 10:
            raise GameError("العدد بين 1 و10.")
        cost = (g.GACHA_GOLD_COST if currency == "gold" else g.GACHA_GEM_COST) * count

        def fn(conn):
            self._money(conn, user_id, currency, -cost, "gacha", f"×{count}")
            pity = conn.execute("SELECT pity FROM users WHERE user_id = ?", (user_id,)).fetchone()["pity"]
            out = []
            for _ in range(count):
                item, pity = g.roll_item(pity, rng)
                cur = conn.execute(
                    "INSERT INTO inventory (user_id, item_name, item_type, stat, stat_bonus, rarity) VALUES (?,?,?,?,?,?)",
                    (user_id, item["name"], item["type"], item["stat"], item["bonus"], item["rarity"]))
                item["item_id"] = cur.lastrowid
                out.append(item)
            conn.execute("UPDATE users SET pity = ?, pulls = pulls + ? WHERE user_id = ?", (pity, count, user_id))
            for it in out:
                it["pity"] = pity
            self._bump(conn, user_id, "gacha", count)
            return out
        return await self._run(fn)

    async def equip(self, user_id: int, item_id: int) -> dict:
        def fn(conn):
            it = conn.execute("SELECT * FROM inventory WHERE item_id = ? AND user_id = ?", (item_id, user_id)).fetchone()
            if it is None:
                raise GameError("هذا العنصر ليس في حقيبتك.")
            if it["item_type"] == "Spell":
                raise GameError("البطاقات تُستخدم بالأمر «استخدام» وليست للتجهيز.")
            conn.execute("UPDATE inventory SET is_equipped = 0 WHERE user_id = ? AND item_type = ?",
                         (user_id, it["item_type"]))
            conn.execute("UPDATE inventory SET is_equipped = 1 WHERE item_id = ?", (item_id,))
            return dict(it)
        return await self._run(fn)

    async def sell(self, user_id: int, item_id: int) -> tuple[dict, int]:
        def fn(conn):
            it = conn.execute("SELECT * FROM inventory WHERE item_id = ? AND user_id = ?", (item_id, user_id)).fetchone()
            if it is None:
                raise GameError("هذا العنصر ليس في حقيبتك.")
            if it["is_equipped"]:
                raise GameError("انزع العنصر أولاً (جهّز بديلاً له) قبل بيعه.")
            r = g.RARITIES.index(it["rarity"]) if it["rarity"] in g.RARITIES else 0
            price = g.sell_value(it["rarity"], it["lvl"] or 0)
            conn.execute("DELETE FROM inventory WHERE item_id = ?", (item_id,))
            self._money(conn, user_id, "gold", price, "sell", it["item_name"])
            self._bump(conn, user_id, "sell")
            return dict(it), price
        return await self._run(fn)

    async def use_spell(self, user_id: int, item_id: int) -> dict:
        def fn(conn):
            it = conn.execute("SELECT * FROM inventory WHERE item_id = ? AND user_id = ?", (item_id, user_id)).fetchone()
            if it is None:
                raise GameError("هذه البطاقة ليست في حقيبتك.")
            if it["item_type"] != "Spell":
                raise GameError("هذا ليس بطاقة. استخدم «تجهيز» لتجهيز العتاد.")
            u = self._user_with_totals(conn, user_id)
            heal = int(u["t_hp"] * it["stat_bonus"] / 100)
            new_hp = min(u["t_hp"], u["cur_hp"] + heal)
            self._set_hp(conn, user_id, new_hp)
            conn.execute("DELETE FROM inventory WHERE item_id = ?", (item_id,))
            return {"name": it["item_name"], "healed": new_hp - u["cur_hp"], "hp": new_hp, "max": u["t_hp"]}
        return await self._run(fn)

    # ───────────── بطاقات الشخصيات والفريق ─────────────
    async def summon(self, user_id: int, currency: str, count: int = 1, rng: random.Random | None = None) -> dict:
        """استدعاء بطاقات شخصيات. النسخة المكررة تمنح نجمة (حتى cd.MAX_STARS) وما زاد يتحول إلى ذهب."""
        rng = rng or random.Random()
        if currency not in ("gold", "gems"):
            raise GameError("عملة غير صالحة.")
        if not 1 <= count <= 10:
            raise GameError("عدد الاستدعاءات من 1 إلى 10.")
        cost = (cd.SUMMON_GOLD_COST if currency == "gold" else cd.SUMMON_GEM_COST) * count

        def fn(conn):
            self._money(conn, user_id, currency, -cost, "summon", f"×{count}")
            pity = conn.execute("SELECT summon_pity FROM users WHERE user_id = ?", (user_id,)).fetchone()["summon_pity"]
            owned = {r["card_key"]: r["copies"] for r in conn.execute(
                "SELECT card_key, copies FROM cards WHERE user_id = ?", (user_id,))}
            results, refund_total = [], 0
            for _ in range(count):
                card, pity = cd.roll_card(pity, rng)
                key = card["key"]
                before = owned.get(key, 0)
                refund = 0
                if before and cd.stars_for(before) >= cd.MAX_STARS:      # اكتملت النجوم: النسخة الزائدة تتحول لذهب
                    refund = cd.DUPLICATE_REFUND[card["r"]]
                    refund_total += refund
                    after = before
                else:
                    after = before + 1
                    conn.execute(
                        "INSERT INTO cards (user_id, card_key, copies, first_ts) VALUES (?,?,1,?) "
                        "ON CONFLICT(user_id, card_key) DO UPDATE SET copies = copies + 1", (user_id, key, time.time()))
                owned[key] = after
                results.append({"key": key, "r": card["r"], "is_new": before == 0, "stars": cd.stars_for(after),
                                "star_up": before > 0 and refund == 0, "refund": refund})
            conn.execute("UPDATE users SET summon_pity = ?, summons = summons + ? WHERE user_id = ?", (pity, count, user_id))
            if refund_total:
                self._money(conn, user_id, "gold", refund_total, "card_refund")
            self._bump(conn, user_id, "gacha", count)       # الاستدعاء يحتسب في مهمة «السحب» اليومية
            return {"cards": results, "pity": pity, "cost": cost, "currency": currency, "refund": refund_total}
        return await self._run(fn)

    async def cards_of(self, user_id: int) -> list[dict]:
        """بطاقات اللاعب مرتبة بالندرة (الأعلى أولاً) ثم ترتيب القائمة."""
        def fn(conn):
            rows = conn.execute("SELECT card_key, copies FROM cards WHERE user_id = ?", (user_id,)).fetchall()
            out = [{"key": r["card_key"], "copies": r["copies"], "stars": cd.stars_for(r["copies"])}
                   for r in rows if r["card_key"] in cd.CARDS]
            out.sort(key=lambda c: (-cd.CARDS[c["key"]]["r"], cd.ORDER.index(c["key"])))
            return out
        return await self._run(fn)

    async def set_team(self, user_id: int, keys: list[str]) -> list[str]:
        keys = list(dict.fromkeys(keys))
        if len(keys) > cd.TEAM_SIZE:
            raise GameError(f"الفريق حتى {cd.TEAM_SIZE} بطاقات فقط.")
        if any(k not in cd.CARDS for k in keys):
            raise GameError("بطاقة غير معروفة.")

        def fn(conn):
            owned = {r["card_key"] for r in conn.execute("SELECT card_key FROM cards WHERE user_id = ?", (user_id,))}
            for k in keys:
                if k not in owned:
                    raise GameError(f"ما تملك بطاقة {cd.CARDS[k]['name']} بعد. استدعِها أولاً.")
            conn.execute("UPDATE users SET team = ? WHERE user_id = ?", (",".join(keys), user_id))
            return keys
        return await self._run(fn)

    # ───────────── التحسين والدمج ─────────────
    async def enhance(self, user_id: int, item_id: int, rng: random.Random | None = None) -> dict:
        rng = rng or random.Random()

        def fn(conn):
            it = conn.execute("SELECT * FROM inventory WHERE item_id = ? AND user_id = ?", (item_id, user_id)).fetchone()
            if it is None:
                raise GameError("هذا العنصر ليس في حقيبتك.")
            if it["item_type"] == "Spell":
                raise GameError("البطاقات لا تُحسَّن.")
            lvl = it["lvl"] or 0
            if lvl >= g.MAX_ENH:
                raise GameError(f"العنصر وصل أقصى تحسين (+{g.MAX_ENH}).")
            cost = g.enhance_cost(it["rarity"], lvl)
            self._money(conn, user_id, "gold", -cost, "enhance", f"{it['item_name']} +{lvl}→+{lvl + 1}")
            ok = rng.random() < g.ENH_CHANCE[lvl]
            if ok:
                conn.execute("UPDATE inventory SET lvl = ? WHERE item_id = ?", (lvl + 1, item_id))
                conn.execute("UPDATE users SET best_enh = MAX(best_enh, ?) WHERE user_id = ?", (lvl + 1, user_id))
            new_lvl = lvl + 1 if ok else lvl
            return {"ok": ok, "lvl": new_lvl, "cost": cost, "chance": g.ENH_CHANCE[lvl], "name": it["item_name"], "type": it["item_type"],
                    "rarity": it["rarity"], "stat": it["stat"], "bonus": g.enhanced_bonus(it["stat_bonus"], new_lvl), "item_id": item_id}
        return await self._run(fn)

    async def fuse(self, user_id: int, rarity_idx: int, rng: random.Random | None = None) -> dict:
        """يدمج 3 عناصر غير مجهّزة (الأرخص أولاً) من ندرة معيّنة في عنصر من الندرة التالية."""
        rng = rng or random.Random()
        if not 0 <= rarity_idx < len(g.RARITIES) - 1:
            raise GameError("لا يمكن دمج هذه الندرة.")
        rar = g.RARITIES[rarity_idx]

        def fn(conn):
            rows = conn.execute(
                "SELECT * FROM inventory WHERE user_id = ? AND rarity = ? AND is_equipped = 0 AND item_type != 'Spell' "
                "ORDER BY lvl, item_id LIMIT ?", (user_id, rar, g.FUSE_COUNT)).fetchall()
            if len(rows) < g.FUSE_COUNT:
                raise GameError(f"تحتاج {g.FUSE_COUNT} عناصر {g.RARITY_AR[rarity_idx]} غير مجهّزة (عندك {len(rows)}).")
            cost = g.FUSE_COST[rarity_idx]
            self._money(conn, user_id, "gold", -cost, "fuse", f"{g.RARITY_AR[rarity_idx]}→{g.RARITY_AR[rarity_idx + 1]}")
            for r in rows:
                conn.execute("DELETE FROM inventory WHERE item_id = ?", (r["item_id"],))
            item = g.roll_item_rarity(rarity_idx + 1, rng)
            cur = conn.execute("INSERT INTO inventory (user_id, item_name, item_type, stat, stat_bonus, rarity) VALUES (?,?,?,?,?,?)",
                               (user_id, item["name"], item["type"], item["stat"], item["bonus"], item["rarity"]))
            item["item_id"] = cur.lastrowid
            item["cost"] = cost
            return item
        return await self._run(fn)

    # ───────────── الصيد وأحداث الطوابق ─────────────
    async def hunt_begin(self, user_id: int, min_floor: int) -> dict:
        def fn(conn):
            u = self._user_with_totals(conn, user_id)
            if u["floor"] < min_floor:
                raise GameError(f"هذا الصيد يُفتح عند الطابق {min_floor}.")
            left = g.HUNT_CD - (time.time() - u["last_hunt"])
            if left > 0:
                raise GameError(f"أنت مرهق من الصيد السابق. انتظر {int(left // 60)} دقيقة و{int(left % 60)} ثانية.")
            if u["cur_hp"] < g.MIN_HP_PCT_TO_CLIMB * u["t_hp"] * 0.5:
                raise GameError("صحتك منخفضة جداً للصيد. ارتح أو استخدم بطاقة شفاء.")
            conn.execute("UPDATE users SET last_hunt = ? WHERE user_id = ?", (time.time(), user_id))
            return u
        return await self._run(fn)

    async def hunt_finish(self, user_id: int, won: bool, hp_after: int, gold: int, xp: int, drop_chance: float,
                          rng: random.Random | None = None) -> dict:
        rng = rng or random.Random()

        def fn(conn):
            u = self._user_with_totals(conn, user_id)
            out = {"gold": 0, "xp": 0, "levels_gained": 0, "level": u["level"], "item": None, "points": 0}
            self._set_hp(conn, user_id, max(1, hp_after) if won else max(1, int(0.3 * u["t_hp"])))
            if not won:
                return out
            level, cur_xp = u["level"], u["xp"] + xp
            gained = 0
            while cur_xp >= g.xp_needed(level):
                cur_xp -= g.xp_needed(level)
                level += 1
                gained += 1
            conn.execute("UPDATE users SET level = ?, xp = ?, stat_points = stat_points + ?, max_hp = max_hp + ?, hunts = hunts + 1 WHERE user_id = ?",
                         (level, cur_xp, gained * g.POINTS_PER_LEVEL, gained * g.LEVEL_HP_BONUS, user_id))
            self._money(conn, user_id, "gold", gold, "hunt")
            out.update(gold=gold, xp=xp, levels_gained=gained, level=level, points=gained * g.POINTS_PER_LEVEL)
            if rng.random() < drop_chance:
                item, _ = g.roll_item_min(0, rng, 0)
                if item["type"] != "Spell" or True:
                    cur = conn.execute("INSERT INTO inventory (user_id, item_name, item_type, stat, stat_bonus, rarity) VALUES (?,?,?,?,?,?)",
                                       (user_id, item["name"], item["type"], item["stat"], item["bonus"], item["rarity"]))
                    item["item_id"] = cur.lastrowid
                    out["item"] = item
            self._bump(conn, user_id, "win")
            return out
        return await self._run(fn)

    async def floor_event(self, user_id: int, ev: dict, floor_gold: int, rng: random.Random | None = None) -> dict:
        """ينفّذ حدث طابق (بعد الفوز). يعيد وصفاً لما حدث."""
        rng = rng or random.Random()
        k = ev["key"]

        def fn(conn):
            u = self._user_with_totals(conn, user_id)
            out = dict(ev)
            if k == "chest":
                gold = floor_gold * 2
                self._money(conn, user_id, "gold", gold, "event", ev["title"])
                out["text"] = f"+{gold} ذهب"
            elif k == "gems":
                n = rng.randint(1, 3)
                self._money(conn, user_id, "gems", n, "event", ev["title"])
                out["text"] = f"+{n} جوهرة"
            elif k == "heal":
                new = min(u["t_hp"], u["cur_hp"] + u["t_hp"] // 2)
                self._set_hp(conn, user_id, new)
                out["text"] = "استعدت نصف صحتك"
            elif k == "item":
                item, _ = g.roll_item_min(0, rng, 0)
                cur = conn.execute("INSERT INTO inventory (user_id, item_name, item_type, stat, stat_bonus, rarity) VALUES (?,?,?,?,?,?)",
                                   (user_id, item["name"], item["type"], item["stat"], item["bonus"], item["rarity"]))
                item["item_id"] = cur.lastrowid
                out["text"] = f"حصلت على {item['name']}"
                out["item"] = item
            elif k == "trap":
                dmg = max(1, u["cur_hp"] // 6)
                self._set_hp(conn, user_id, max(1, u["cur_hp"] - dmg))
                out["text"] = f"خسرت {dmg} من الصحة"
            elif k == "blessing":
                conn.execute("UPDATE users SET blessing = 1 WHERE user_id = ?", (user_id,))
                out["text"] = "خبرة المعركة القادمة ×2"
            return out
        return await self._run(fn)

    async def take_blessing(self, user_id: int) -> bool:
        def fn(conn):
            r = conn.execute("SELECT blessing FROM users WHERE user_id = ?", (user_id,)).fetchone()
            if r and r["blessing"]:
                conn.execute("UPDATE users SET blessing = 0 WHERE user_id = ?", (user_id,))
                return True
            return False
        return await self._run(fn)

    # ───────────── الإنجازات ─────────────
    async def achievements(self, user_id: int, claim: bool = True) -> dict:
        def fn(conn):
            u = self._user_with_totals(conn, user_id)
            done = {r["akey"] for r in conn.execute("SELECT akey FROM achievements WHERE user_id = ?", (user_id,))}
            boss_hits = conn.execute("SELECT COALESCE(SUM(hits),0) AS s FROM boss_dmg WHERE user_id = ?", (user_id,)).fetchone()["s"]
            legend = conn.execute("SELECT COUNT(*) AS c FROM inventory WHERE user_id = ? AND rarity = 'legendary'", (user_id,)).fetchone()["c"]
            stats = {"floor": u["floor"], "level": u["level"], "wins": u["wins"], "pulls": u["pulls"], "hunts": u["hunts"],
                     "best_enh": u["best_enh"], "legend": legend, "boss_hits": boss_hits, "guild": 1 if u["guild_id"] else 0, "gold": u["gold"]}
            rows, newly = [], []
            for key, emoji, title, desc, (field, need), gold, gems in g.ACHIEVEMENTS:
                have = stats.get(field, 0)
                ok = have >= need
                if ok and key not in done and claim:
                    conn.execute("INSERT OR IGNORE INTO achievements (user_id, akey, ts) VALUES (?,?,?)", (user_id, key, time.time()))
                    if gold:
                        self._money(conn, user_id, "gold", gold, "achieve", title)
                    if gems:
                        self._money(conn, user_id, "gems", gems, "achieve", title)
                    newly.append({"key": key, "emoji": emoji, "title": title, "gold": gold, "gems": gems})
                    done.add(key)
                rows.append({"key": key, "emoji": emoji, "title": title, "desc": desc, "done": key in done,
                             "have": min(have, need), "need": need, "gold": gold, "gems": gems})
            return {"rows": rows, "new": newly, "done": len(done), "total": len(g.ACHIEVEMENTS)}
        return await self._run(fn)

    # ───────────── المتجر والتحويل ─────────────
    async def buy_spell(self, user_id: int, tier: str, count: int = 1) -> dict:
        entry = next((s for s in g.SHOP if s[0] == tier), None)
        if entry is None:
            raise GameError("هذا المنتج غير موجود.")
        _, name, pct, price, rarity = entry

        def fn(conn):
            self._money(conn, user_id, "gold", -price * count, "shop", f"{name} ×{count}")
            for _ in range(count):
                conn.execute("INSERT INTO inventory (user_id, item_name, item_type, stat, stat_bonus, rarity) VALUES (?,?,?,?,?,?)",
                             (user_id, name, "Spell", "heal", pct, g.RARITIES[rarity]))
            return {"name": name, "count": count, "cost": price * count}
        return await self._run(fn)

    async def transfer_gold(self, from_id: int, to_id: int, amount: int) -> dict:
        if from_id == to_id:
            raise GameError("لا يمكنك التحويل لنفسك.")
        if amount < g.TRANSFER_MIN:
            raise GameError(f"أقل مبلغ للتحويل {g.TRANSFER_MIN} 💰.")
        tax = max(1, int(amount * g.TRANSFER_TAX))

        def fn(conn):
            if not conn.execute("SELECT 1 FROM users WHERE user_id = ?", (to_id,)).fetchone():
                raise GameError("هذا اللاعب لم يبدأ رحلته بعد.")
            self._money(conn, from_id, "gold", -amount, "transfer_out", f"→ {to_id}")
            self._money(conn, to_id, "gold", amount - tax, "transfer_in", f"← {from_id}")
            conn.execute("INSERT INTO ledger (ts, user_id, currency, amount, balance, reason, note) VALUES (?,?,?,?,?,?,?)",
                         (time.time(), from_id, "gold", 0, 0, "tax", f"ضريبة {tax}"))   # توثيق الضريبة المحروقة
            return {"sent": amount, "received": amount - tax, "tax": tax}
        return await self._run(fn)

    async def admin_grant(self, user_id: int, currency: str, amount: int, note: str = "") -> int:
        def fn(conn):
            if not conn.execute("SELECT 1 FROM users WHERE user_id = ?", (user_id,)).fetchone():
                raise GameError("هذا اللاعب لم يبدأ رحلته بعد.")
            return self._money(conn, user_id, currency, amount, "admin", note)
        return await self._run(fn)

    # ───────────── المكافأة اليومية ─────────────
    async def claim_daily(self, user_id: int) -> dict:
        def fn(conn):
            u = conn.execute("SELECT last_daily, daily_streak FROM users WHERE user_id = ?", (user_id,)).fetchone()
            now = time.time()
            since = now - u["last_daily"]
            if u["last_daily"] and since < 20 * 3600:
                left = int((20 * 3600 - since) / 60)
                raise GameError(f"المكافأة اليومية جاهزة بعد {left // 60} ساعة و{left % 60} دقيقة.")
            streak = u["daily_streak"] + 1 if u["last_daily"] and since < 48 * 3600 else 1
            gold = g.DAILY_GOLD + min(streak, 7) * 50
            gems = g.DAILY_GEMS + (5 if streak % 7 == 0 else 0)
            self._money(conn, user_id, "gold", gold, "daily")
            self._money(conn, user_id, "gems", gems, "daily")
            conn.execute("UPDATE users SET last_daily = ?, daily_streak = ? WHERE user_id = ?", (now, streak, user_id))
            self._bump(conn, user_id, "daily")
            return {"gold": gold, "gems": gems, "streak": streak}
        return await self._run(fn)

    # ───────────── المهام ─────────────
    async def missions(self, user_id: int) -> list[dict]:
        return await self._run(lambda conn: self._ensure_missions(conn, user_id, day_index()))

    async def claim_missions(self, user_id: int) -> dict:
        def fn(conn):
            rows = self._ensure_missions(conn, user_id, day_index())
            gold = gems = n = 0
            for m in rows:
                if m["progress"] >= m["target"] and not m["claimed"]:
                    conn.execute("UPDATE missions SET claimed = 1 WHERE user_id = ? AND day = ? AND slot = ?",
                                 (user_id, m["day"], m["slot"]))
                    gold += m["gold"]
                    gems += m["gems"]
                    n += 1
            if not n:
                raise GameError("لا توجد مهام مكتملة لاستلامها الآن.")
            bonus = 0
            rows = self._ensure_missions(conn, user_id, day_index())
            if all(m["claimed"] for m in rows):
                bonus = g.MISSION_BONUS_GEMS
                if conn.execute("SELECT 1 FROM ledger WHERE user_id = ? AND reason = 'mission_bonus' AND ts >= ?",
                                (user_id, time.time() - 86400)).fetchone() is None:
                    gems += bonus
                else:
                    bonus = 0
            if gold:
                self._money(conn, user_id, "gold", gold, "mission")
            if gems:
                self._money(conn, user_id, "gems", gems, "mission_bonus" if bonus else "mission")
            return {"claimed": n, "gold": gold, "gems": gems, "bonus": bonus}
        return await self._run(fn)

    # ───────────── سجل العملات ─────────────
    async def ledger_rows(self, user_id: int, limit: int = 12, offset: int = 0) -> list[dict]:
        def fn(conn):
            return [dict(r) for r in conn.execute(
                "SELECT * FROM ledger WHERE user_id = ? AND amount != 0 ORDER BY id DESC LIMIT ? OFFSET ?", (user_id, limit, offset))]
        return await self._run(fn)

    async def ledger_summary(self, currency: str, since: float = 0, user_id: int | None = None) -> dict:
        """من أين تدخل العملة وأين تذهب (مجمّعة حسب السبب). الضريبة تُحسب كمصرف."""
        def fn(conn):
            q = "SELECT reason, SUM(amount) AS s FROM ledger WHERE currency = ? AND ts >= ? AND amount != 0"
            args: list = [currency, since]
            if user_id:
                q += " AND user_id = ?"
                args.append(user_id)
            rows = conn.execute(q + " GROUP BY reason", args).fetchall()
            sources, sinks = [], []
            for r in rows:
                (sources if r["s"] > 0 else sinks).append((r["reason"], abs(r["s"])))
            if currency == "gold":   # الضريبة مسجّلة بمبلغ 0 والقيمة في note؛ نجمعها هنا
                tax = 0
                tq = "SELECT note FROM ledger WHERE reason = 'tax' AND ts >= ?"
                targs: list = [since]
                if user_id:
                    tq += " AND user_id = ?"
                    targs.append(user_id)
                for r in conn.execute(tq, targs):
                    try:
                        tax += int(str(r["note"]).split()[-1])
                    except ValueError:
                        pass
                if tax:
                    sinks.append(("tax", tax))
            circ = conn.execute(f"SELECT COALESCE(SUM({currency}), 0) AS c FROM users").fetchone()["c"]
            sources.sort(key=lambda x: -x[1])
            sinks.sort(key=lambda x: -x[1])
            return {"sources": sources, "sinks": sinks, "circulating": circ}
        return await self._run(fn)

    # ───────────── الزعماء ─────────────
    @staticmethod
    def _boss_row(conn, boss_id: int) -> dict:
        return dict(conn.execute("SELECT * FROM boss WHERE boss_id = ?", (boss_id,)).fetchone())

    def _settle_boss(self, conn, boss: dict, killed: bool) -> dict:
        """يوزّع الغنائم على المشاركين. يعيد ملخصاً للإعلان."""
        rows = [dict(r) for r in conn.execute(
            "SELECT d.user_id, d.damage, u.username FROM boss_dmg d JOIN users u ON u.user_id = d.user_id "
            "WHERE d.boss_id = ? AND d.damage > 0 ORDER BY d.damage DESC", (boss["boss_id"],))]
        total = sum(r["damage"] for r in rows) or 1
        rng = random.Random()
        paid = []
        for rank, r in enumerate(rows, 1):
            gold, gems, min_r = g.boss_rewards(r["damage"] / total, rank, killed and r["user_id"] == boss["last_hit"], killed)
            self._money(conn, r["user_id"], "gold", gold, "boss", f"زعيم #{boss['boss_id']}")
            if gems:
                self._money(conn, r["user_id"], "gems", gems, "boss", f"زعيم #{boss['boss_id']}")
            item = None
            if killed:
                it, _ = g.roll_item_min(0, rng, min_r)
                cur = conn.execute(
                    "INSERT INTO inventory (user_id, item_name, item_type, stat, stat_bonus, rarity) VALUES (?,?,?,?,?,?)",
                    (r["user_id"], it["name"], it["type"], it["stat"], it["bonus"], it["rarity"]))
                it["item_id"] = cur.lastrowid
                item = it
            paid.append({**r, "gold": gold, "gems": gems, "item": item, "rank": rank})
        conn.execute("UPDATE boss SET settled = 1 WHERE boss_id = ?", (boss["boss_id"],))
        return {"boss_id": boss["boss_id"], "key": boss["boss_key"], "killed": killed, "players": paid, "last_hit": boss["last_hit"]}

    async def ensure_boss(self, server_id: int, rng: random.Random | None = None) -> tuple[dict, dict | None]:
        """يعيد (الزعيم الحالي، ملخص تسوية إن انتهى زعيم سابق للتو). ينشئ زعيماً جديداً عند الحاجة."""
        rng = rng or random.Random()

        def fn(conn):
            now = time.time()
            settle = None
            last = conn.execute("SELECT * FROM boss WHERE server_id = ? ORDER BY boss_id DESC LIMIT 1", (server_id,)).fetchone()
            if last is not None:
                last = dict(last)
                if last["status"] == "active" and last["end_ts"] <= now:
                    conn.execute("UPDATE boss SET status = 'escaped' WHERE boss_id = ?", (last["boss_id"],))
                    last["status"] = "escaped"
                    settle = self._settle_boss(conn, last, killed=False)
                if last["status"] == "active":
                    return last, None
                if now < last["end_ts"] + g.BOSS_RESPAWN_H * 3600:   # زعيم منتهٍ: ننتظر قبل الظهور التالي
                    return last, settle
            count = conn.execute("SELECT COUNT(*) AS c FROM users").fetchone()["c"]
            n_prev = conn.execute("SELECT COUNT(*) AS c FROM boss WHERE server_id = ?", (server_id,)).fetchone()["c"]
            tpl = g.BOSSES[n_prev % len(g.BOSSES)]
            hp = g.boss_max_hp(count)
            cur = conn.execute(
                "INSERT INTO boss (server_id, boss_key, max_hp, hp, start_ts, end_ts, status) VALUES (?,?,?,?,?,?, 'active')",
                (server_id, tpl["key"], hp, hp, now, now + g.BOSS_DURATION_H * 3600))
            return self._boss_row(conn, cur.lastrowid), settle
        return await self._run(fn)

    async def boss_board(self, boss_id: int, user_id: int | None = None, limit: int = 5) -> dict:
        def fn(conn):
            top = [dict(r) for r in conn.execute(
                "SELECT d.user_id, d.damage, d.hits, u.username AS name FROM boss_dmg d JOIN users u ON u.user_id = d.user_id "
                "WHERE d.boss_id = ? AND d.damage > 0 ORDER BY d.damage DESC LIMIT ?", (boss_id, limit))]
            me = None
            if user_id:
                row = conn.execute("SELECT damage, hits FROM boss_dmg WHERE boss_id = ? AND user_id = ?", (boss_id, user_id)).fetchone()
                if row:
                    rank = conn.execute("SELECT COUNT(*) + 1 AS r FROM boss_dmg WHERE boss_id = ? AND damage > ?",
                                        (boss_id, row["damage"])).fetchone()["r"]
                    me = {"damage": row["damage"], "hits": row["hits"], "rank": rank}
            u = conn.execute("SELECT boss_last, boss_day, boss_used FROM users WHERE user_id = ?", (user_id,)).fetchone() if user_id else None
            used = u["boss_used"] if u and u["boss_day"] == day_index() else 0
            return {"top": top, "me": me, "attempts_left": max(0, g.BOSS_DAILY_ATTEMPTS - used),
                    "cooldown_left": max(0, int(g.BOSS_COOLDOWN - (time.time() - u["boss_last"]))) if u else 0}
        return await self._run(fn)

    async def boss_begin(self, user_id: int, boss_id: int) -> dict:
        """يحجز محاولة هجوم (يتحقق من الزعيم والحد اليومي والتبريد)."""
        def fn(conn):
            now = time.time()
            b = self._boss_row(conn, boss_id)
            if b["status"] != "active" or b["end_ts"] <= now or b["hp"] <= 0:
                raise GameError("هذا الزعيم انتهى. استخدم «زعيم» لرؤية الزعيم الجديد.")
            u = conn.execute("SELECT boss_last, boss_day, boss_used FROM users WHERE user_id = ?", (user_id,)).fetchone()
            today = day_index(now)
            used = u["boss_used"] if u["boss_day"] == today else 0
            if used >= g.BOSS_DAILY_ATTEMPTS:
                raise GameError("استنفدت محاولاتك اليومية على الزعيم. تتجدد غداً.")
            wait = g.BOSS_COOLDOWN - (now - u["boss_last"])
            if wait > 0:
                raise GameError(f"استرح {int(wait) // 60} دقيقة و{int(wait) % 60} ثانية قبل ضربتك التالية.")
            conn.execute("UPDATE users SET boss_last = ?, boss_day = ?, boss_used = ? WHERE user_id = ?",
                         (now, today, used + 1, user_id))
            return b
        return await self._run(fn)

    async def boss_finish(self, boss_id: int, user_id: int, damage: int) -> dict:
        def fn(conn):
            b = self._boss_row(conn, boss_id)
            dmg = max(0, min(int(damage), b["hp"])) if b["status"] == "active" else 0
            if dmg:
                conn.execute("UPDATE boss SET hp = hp - ? WHERE boss_id = ?", (dmg, boss_id))
                conn.execute("INSERT INTO boss_dmg (boss_id, user_id, damage, hits) VALUES (?,?,?,1) "
                             "ON CONFLICT(boss_id, user_id) DO UPDATE SET damage = damage + excluded.damage, hits = hits + 1",
                             (boss_id, user_id, dmg))
            self._bump(conn, user_id, "boss")
            self._bump_week(conn, user_id, "boss", 1)
            gang_events = self._gang_progress(conn, user_id, "boss", dmg)
            self._war_add(conn, user_id, g.WAR_POINTS_BOSS)
            b = self._boss_row(conn, boss_id)
            settle = None
            if b["status"] == "active" and b["hp"] <= 0:
                conn.execute("UPDATE boss SET status = 'dead', last_hit = ?, end_ts = ? WHERE boss_id = ?", (user_id, time.time(), boss_id))
                b = self._boss_row(conn, boss_id)
                settle = self._settle_boss(conn, b, killed=True)
            return {"damage": dmg, "boss_hp": b["hp"], "killed": settle is not None, "settle": settle, "gang_events": gang_events}
        return await self._run(fn)

    async def due_boss_servers(self) -> list[int]:
        """سيرفرات فيها زعيم نشط انتهى وقته (ليُسوَّى ويُعلن هروبه)."""
        def fn(conn):
            return [r["server_id"] for r in conn.execute(
                "SELECT DISTINCT server_id FROM boss WHERE status = 'active' AND end_ts <= ?", (time.time(),))]
        return await self._run(fn)

    # ───────────── العصابات (النقابات سابقاً): انظر db_ext.py ─────────────

    # ───────────── حرب العصابات ─────────────
    @staticmethod
    def _active_war(conn, guild_id: int) -> dict | None:
        r = conn.execute("SELECT * FROM wars WHERE status = 'active' AND end_ts > ? AND (guild_a = ? OR guild_b = ?)",
                         (time.time(), guild_id, guild_id)).fetchone()
        return dict(r) if r else None

    async def declare_war(self, user_id: int, target_name: str, server_id: int = 0, duration_h: float | None = None) -> dict:
        def fn(conn):
            now = time.time()
            me = conn.execute("SELECT guild_id FROM users WHERE user_id = ?", (user_id,)).fetchone()
            if not me or not me["guild_id"]:
                raise GameError("يجب أن تكون في عصابة لتعلن الحرب.")
            a = dict(conn.execute("SELECT * FROM guilds WHERE guild_id = ?", (me["guild_id"],)).fetchone())
            if a["leader_id"] != user_id:
                raise GameError("قائد العصابة فقط يعلن الحرب.")
            b = conn.execute("SELECT * FROM guilds WHERE guild_name = ?", (target_name.strip(),)).fetchone()
            if b is None:
                raise GameError("ما لقيت عصابة بهذا الاسم.")
            b = dict(b)
            if b["guild_id"] == a["guild_id"]:
                raise GameError("لا يمكنك محاربة نقابتك.")
            for gd in (a, b):
                n = conn.execute("SELECT COUNT(*) AS c FROM users WHERE guild_id = ?", (gd["guild_id"],)).fetchone()["c"]
                if n < g.WAR_MIN_MEMBERS:
                    raise GameError(f"عصابة «{gd['guild_name']}» تحتاج {g.WAR_MIN_MEMBERS} أعضاء على الأقل للحرب.")
                if self._active_war(conn, gd["guild_id"]):
                    raise GameError(f"عصابة «{gd['guild_name']}» في حرب حالياً.")
                if now < gd["last_war_end"] + g.WAR_COOLDOWN_H * 3600:
                    raise GameError(f"عصابة «{gd['guild_name']}» ترتاح من حرب سابقة. حاول لاحقاً.")
            hours = duration_h if duration_h is not None else g.WAR_DURATION_H
            cur = conn.execute(
                "INSERT INTO wars (guild_a, guild_b, name_a, name_b, start_ts, end_ts, server_id) VALUES (?,?,?,?,?,?,?)",
                (a["guild_id"], b["guild_id"], a["guild_name"], b["guild_name"], now, now + hours * 3600, server_id))
            return dict(conn.execute("SELECT * FROM wars WHERE war_id = ?", (cur.lastrowid,)).fetchone())
        return await self._run(fn)

    async def war_status(self, user_id: int) -> dict | None:
        def fn(conn):
            me = conn.execute("SELECT guild_id FROM users WHERE user_id = ?", (user_id,)).fetchone()
            if not me or not me["guild_id"]:
                return None
            return self._active_war(conn, me["guild_id"])
        return await self._run(fn)

    async def finish_due_wars(self) -> list[dict]:
        """ينهي الحروب المنتهية ويوزّع الجوائز. يعيد قائمة ملخصات للإعلان."""
        def fn(conn):
            out = []
            for w in [dict(r) for r in conn.execute("SELECT * FROM wars WHERE status = 'active' AND end_ts <= ?", (time.time(),))]:
                if w["score_a"] == w["score_b"]:
                    result = "draw"
                else:
                    result = "a" if w["score_a"] > w["score_b"] else "b"
                paid = 0
                for r in conn.execute("SELECT user_id, guild_id, points FROM war_points WHERE war_id = ? AND points > 0", (w["war_id"],)).fetchall():
                    if result == "draw":
                        key = "draw"
                    else:
                        key = "win" if (result == "a") == (r["guild_id"] == w["guild_a"]) else "lose"
                    gold, gems = g.WAR_REWARD[key]
                    self._money(conn, r["user_id"], "gold", gold, "war", f"حرب #{w['war_id']}")
                    self._money(conn, r["user_id"], "gems", gems, "war", f"حرب #{w['war_id']}")
                    paid += 1
                stolen = {"gold": 0, "gems": 0, "pct": 0.0}
                if result != "draw":
                    win_gid = w["guild_a"] if result == "a" else w["guild_b"]
                    lose_gid = w["guild_b"] if result == "a" else w["guild_a"]
                    conn.execute("UPDATE guilds SET score = score + 10 WHERE guild_id = ?", (win_gid,))
                    stolen = self._steal_treasury(conn, win_gid, lose_gid, w["war_id"])
                conn.execute("UPDATE wars SET status = 'done' WHERE war_id = ?", (w["war_id"],))
                conn.execute("UPDATE guilds SET last_war_end = ? WHERE guild_id IN (?, ?)", (time.time(), w["guild_a"], w["guild_b"]))
                w["result"], w["paid"], w["stolen"] = result, paid, stolen
                out.append(w)
            return out
        return await self._run(fn)
