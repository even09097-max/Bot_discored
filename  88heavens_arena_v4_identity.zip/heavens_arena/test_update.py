"""اختبارات التحديث الكبير: 100 طابق، ظل المسيطر، الانتقام، هاتسو، شجرة النين، العتاد، العصابات، المهام، السوق، المواسم.
شغّلها:  python test_update.py"""
from __future__ import annotations

import asyncio
import random
import time

import game as g
import hatsu as ht
from game import GameError
from test_core import fighter, rich, with_db


def team(*keys: str, stars: int = 0) -> list[dict]:
    import cards as cd
    return cd.team_fighters([(k, stars + 1) for k in keys])


# ───────────────────────── محرك القتال ─────────────────────────
def test_tower_constants():
    assert g.MAX_FLOOR == 100 and g.BOSS_FLOOR == 100 and g.MASTER_FLOOR_START == 90
    rng = random.Random(1)
    assert g.enemy_for_floor(100, rng).max_hp > g.enemy_for_floor(50, rng).max_hp > g.enemy_for_floor(1, rng).max_hp
    e = g.enemy_for_floor(95, rng)
    assert e.sig_name and e.look == "master"


def test_hatsu_moves():
    rng = random.Random(5)
    gon = fighter(atk=40, is_player=True, aura=100, max_aura=100)
    gon.hatsu = ht.hatsu_for_team(team("gon", "killua", "kurapika"))
    assert {h["move"] for h in gon.hatsu} == {"gon_rock", "gon_paper", "gon_scissors", "killua_whirlwind", "killua_thunder",
                                              "kurapika_chain", "kurapika_emperor"}
    foe = fighter(hp=5000, max_hp=5000, defense=10, nen="enhancer", aura=60)
    bt = g.Battle(gon, foe, rng)
    bt.play_round("hatsu:gon_rock")
    assert foe.hp < 5000 and gon.aura < 100 and not bt.hatsu_usable(gon, "gon_rock")      # تبريد
    # مقص: نزيف + إبطاء
    bt.play_round("hatsu:gon_scissors")
    assert foe.slowed and foe.poison_turns > 0 or foe.hp < 5000
    # سلسلة الحبس تحظر النين والهاتسو
    bt.play_round("hatsu:kurapika_chain")
    assert foe.skill_lock > 0 and not bt.skill_usable(foe, gon)
    # الصاعقة تشلّ وتكسر الطاقة
    foe2 = fighter(hp=5000, max_hp=5000, nen="emitter", aura=60)
    g2 = fighter(atk=40, is_player=True, aura=100, max_aura=100)
    g2.hatsu = ht.hatsu_for_team(team("killua"))
    b2 = g.Battle(g2, foe2, random.Random(2))
    b2.play_round("hatsu:killua_thunder")
    assert foe2.aura <= g.AURA_REGEN + 1 and foe2.skill_lock >= 1
    # إعصار: يضرب أولاً ولو كان أبطأ
    slow = fighter(speed=1, is_player=True, aura=100, max_aura=100)
    slow.hatsu = ht.hatsu_for_team(team("killua"))
    fast = fighter(speed=50, hp=5000, max_hp=5000)
    b3 = g.Battle(slow, fast, random.Random(3))
    b3.play_round("hatsu:killua_whirlwind")
    assert slow.first_strike > 0 and slow.evade_turns > 0
    # زمان الإمبراطور: يكلّف صحة ويضاعف المهارات
    kp = fighter(atk=40, hp=1000, max_hp=1000, is_player=True, aura=100, max_aura=100, nen="enhancer")
    kp.hatsu = ht.hatsu_for_team(team("kurapika"))
    b4 = g.Battle(kp, fighter(hp=9999, max_hp=9999), random.Random(4))
    b4.play_round("hatsu:kurapika_emperor")
    assert kp.hp <= 1000 - 200 + 1 and kp.amp_turns > 0 or kp.hp < 1000
    # علكة بونجي
    hs = fighter(atk=40, is_player=True, aura=100, max_aura=100)
    hs.hatsu = ht.hatsu_for_team(team("hisoka"))
    tgt = fighter(hp=9999, max_hp=9999, nen="enhancer", aura=60)
    b5 = g.Battle(hs, tgt, random.Random(6))
    b5.play_round("hatsu:hisoka_bungee")
    assert hs.reflect_turns > 0 or tgt.forced_attack >= 0
    # قدرة غير مملوكة لا تعمل وتتحول لهجوم عادي
    plain = fighter(is_player=True, aura=100, max_aura=100)
    b6 = g.Battle(plain, fighter(hp=9999, max_hp=9999), random.Random(7))
    b6.play_round("hatsu:gon_rock")
    assert plain.aura >= 100 - 1 or plain.aura == plain.max_aura


def test_hatsu_battles_always_end():
    for s in range(120):
        rng = random.Random(s)
        p = fighter(nen=rng.choice(list(g.NEN)), is_player=True, atk=25, aura=80, max_aura=80)
        p.hatsu = ht.hatsu_for_team(team(*rng.sample(["gon", "killua", "kurapika", "hisoka"], 3)))
        p.fx = {"crit": .1, "dodge": .1, "double": .1, "lifesteal": .05, "reflect": .1, "reduce": .05, "pierce": .1, "amp": .2}
        e = g.enemy_for_floor(rng.randint(1, 100), rng)
        bt = g.Battle(p, e, rng)
        while not bt.over:
            bt.play_round(bt.suggest_action())
        assert bt.winner in ("player", "enemy")


def test_pvp_enemy_action():
    a = fighter(atk=30, is_player=True)
    b = fighter(atk=30, hp=300, max_hp=300)
    bt = g.Battle(a, b, random.Random(1))
    bt.play_round("attack", enemy_action="guard")
    assert b.hp < 300 and any("يتحصّن" in line for line in bt.log)


def test_echo_blend_caps():
    rng = random.Random(1)
    gen = g.enemy_for_floor(10, rng)
    huge = {"user_id": 9, "username": "قوي", "t_hp": 10 ** 6, "t_atk": 10 ** 4, "t_def": 10 ** 3, "t_speed": 10 ** 3, "cur_hp": 10 ** 6,
            "level": 50, "nen_type": "emitter", "vow": "", "team_cards": [], "fx": {}}
    e = g.echo_of(huge, gen)
    assert e.echo and e.max_hp == round(gen.max_hp * g.ECHO_CAP) and e.atk == round(gen.atk * g.ECHO_CAP)
    tiny = {**huge, "t_hp": 1, "t_atk": 1, "t_def": 0, "t_speed": 1, "cur_hp": 1}
    e2 = g.echo_of(tiny, gen)
    assert e2.max_hp == round(gen.max_hp * g.ECHO_FLOOR_PCT)


# ───────────────────────── شجرة النين ─────────────────────────
def test_tree_rules():
    lv: dict = {}
    assert not ht.can_upgrade(lv, "finisher", 99)[0]               # يحتاج مسار القوة 2
    assert ht.can_upgrade(lv, "power", 1)[0]
    lv = {"power": 2}
    assert ht.can_upgrade(lv, "finisher", 2)[0] and not ht.can_upgrade(lv, "finisher", 1)[0]
    assert ht.node_cost("power", 0) == 1 and ht.node_cost("power", 4) == 3
    assert ht.parse_tree(ht.dump_tree({"power": 3, "swift": 1})) == {"power": 3, "swift": 1}
    assert ht.parse_tree("x:2,power:99,core:3") == {"power": 5}
    eff = ht.tree_effects({"power": 5, "swift": 5, "absorb": 5})
    assert abs(eff["atk_pct"] - 0.20) < 1e-9 and eff["dodge"] <= 0.10 and eff["reduce"] <= 0.10


async def t_tree_db():
    async def body(db, d):
        await db.ensure_user(1, "أ")
        base = await db.get_user(1)
        await db.grant_tree_points(1, 20)
        r = await db.tree_upgrade(1, "power")
        assert r["level"] == 1 and r["points"] == 19
        await db.tree_upgrade(1, "power")
        u = await db.get_user(1)
        assert u["t_atk"] > base["t_atk"] and u["tree_levels"] == {"power": 2}
        await db.tree_upgrade(1, "finisher")
        u = await db.get_user(1)
        assert u["fx"]["crit"] > 0 and u["fx"]["pierce"] > 0
        try:
            await db.tree_upgrade(1, "mirror"); assert False
        except GameError:
            pass
        spent = ht.spent_points({"power": 2, "finisher": 1})
        pts_before = (await db.get_user(1))["tree_pts"]
        try:
            await db.tree_respec(1); assert False                       # 30 جوهرة غير متوفرة
        except GameError:
            pass
        await db._run(lambda c: c.execute("UPDATE users SET gems = 100 WHERE user_id = 1"))
        r = await db.tree_respec(1)
        u = await db.get_user(1)
        assert r["refunded"] == spent and u["tree_pts"] == pts_before + spent and not u["tree_levels"]
    await with_db(body)


# ───────────────────────── سيطرة الطوابق والانتقام ─────────────────────────
async def t_floor_control_and_revenge():
    async def body(db, d):
        for i in (1, 2, 3):
            await db.ensure_user(i, f"p{i}")
        r1 = await db.apply_win(1, 50, 10, 10)               # اللاعب 1 يهزم الطابق 1 فيصير مسيطراً
        assert r1["usurped"] is None and r1["tree_points"] >= 0
        h = await db.floor_holder(1)
        assert h["user_id"] == 1
        assert await db.floor_holder(1, exclude_id=1) is None
        r2 = await db.apply_win(2, 50, 10, 10)               # اللاعب 2 يهزم المسيطر ويأخذ الطابق
        assert r2["usurped"] == 1 and r2["revenge_id"]
        assert (await db.floor_holder(1))["user_id"] == 2
        assert await db.floors_held(2) == [1] and await db.floors_held(1) == []
        rv = await db.revenge_open(1)
        assert len(rv) == 1 and rv[0]["floor"] == 1 and rv[0]["taker_id"] == 2
        un = await db.revenge_unnotified()
        assert len(un) == 1 and await db.revenge_unnotified() == []        # الإشعار يُرسل مرة واحدة
        gold = (await db.get_user(1))["gold"]
        out = await db.revenge_win(1, rv[0]["id"], 300)
        assert out["usurped"] == 2 and (await db.get_user(1))["gold"] == gold + 300
        assert (await db.floor_holder(1))["user_id"] == 1
        assert await db.revenge_open(1) == [] and len(await db.revenge_open(2)) == 1
        try:
            await db.revenge_win(1, rv[0]["id"], 1); assert False
        except GameError:
            pass
        # انتهاء الصلاحية
        await db._run(lambda c: c.execute("UPDATE revenge SET ts = 1"))
        assert await db.revenge_open(2) == []
        # حضور اللاعب
        assert not await db.is_online(3)
        await db.touch(3)
        assert await db.is_online(3)
    await with_db(body)


# ───────────────────────── العتاد والصناديق ─────────────────────────
def test_gear_catalog():
    assert len(ht.GEAR) >= 24
    for gr in ht.GEAR.values():
        assert gr["type"] in ("Weapon", "Armor", "Helmet", "Companion", "Relic") and gr["stat"] in ht.GEAR_BONUS
        assert ht.parse_fx(gr["fx"]) or not gr["fx"]
    assert ht.find_gear("سيف نوبوناغا")["key"] == "nobunaga_sword" and ht.find_gear("يو يو")["key"] == "killua_yoyo"
    assert g.item_slot("خناجر كورو") == "gear_chrollo_knives" and g.item_emoji("سلاسل كورابيكا") == "⛓️"
    rng = random.Random(3)
    seen = set()
    pity = 0
    for _ in range(400):
        it, pity = ht.roll_gear(pity, rng)
        seen.add(it["rarity"])
    assert seen == {"common", "rare", "epic", "legendary"}
    assert ht.roll_gear(ht.GEAR_PITY - 1, random.Random(1))[0]["rarity"] in ("epic", "legendary")
    assert ht.sum_fx(["crit:20", "crit:20"])["crit"] == ht.FX_CAP["crit"]


async def t_gear_db():
    async def body(db, d):
        await db.ensure_user(1, "أ")
        await db._run(lambda c: c.execute("UPDATE users SET gold = 20000, gems = 100 WHERE user_id = 1"))
        items = await db.gear_pull(1, "gold", 10, random.Random(1))
        assert len(items) == 10 and all(i["item_id"] for i in items)
        assert (await db.get_user(1))["gold"] == 20000 - ht.GEAR_GOLD_COST * 10
        try:
            await db.gear_pull(1, "gems", 11); assert False
        except GameError:
            pass
        # المهام اليومية تحسب سحب العتاد
        # تجهيز عتاد بتأثير
        gear = await db.give_gear(1, ht.GEAR["scarlet_eyes"], 1)
        before = await db.get_user(1)
        await db.equip(1, gear[0]["item_id"])
        after = await db.get_user(1)
        assert after["t_atk"] > before["t_atk"] and after["fx"]["crit"] >= 0.05 and after["fx"]["pierce"] >= 0.06
        f = g.fighter_from_user(after, "x")
        assert f.fx["crit"] >= 0.05
        # صناديق
        try:
            await db.open_crates(1); assert False
        except GameError:
            pass
        await db._run(lambda c: c.execute("UPDATE users SET crates = 2 WHERE user_id = 1"))
        out = await db.open_crates(1, 5, random.Random(2))
        assert len(out) == 2 and all(o["rarity"] in ("epic", "legendary") for o in out)
        assert (await db.get_user(1))["crates"] == 0
    await with_db(body)


# ───────────────────────── السوق الأسود ─────────────────────────
def test_market_window_and_stock():
    now = 1_800_000_000.0
    w = ht.market_window(now, 3)
    assert w["start"] < w["end"] and abs((w["end"] - w["start"]) - ht.MARKET_OPEN_H * 3600) < 1
    assert ht.market_window(w["start"] + 5, 3)["open"] and not ht.market_window(w["end"] + 5, 3)["open"]
    assert ht.market_window(now, 3, force_until=now + 100)["open"]
    s1, s2 = ht.market_stock(100), ht.market_stock(100)
    assert s1 == s2 and len(s1) == 6
    assert any(ht.market_stock(p) != s1 for p in range(101, 110))           # الأسعار والعروض تتغير بين الدورات
    for o in s1:
        assert o["gold"] > 0 or o["gems"] > 0


async def t_market_db():
    async def body(db, d):
        await db.ensure_user(1, "أ"); await db.ensure_user(2, "ب")
        await db._run(lambda c: c.execute("UPDATE users SET gold = 1000000, gems = 5000"))
        await db.set_setting(0, "bm_force", str(time.time() - 10))             # أمر فتح قديم منتهٍ
        st = await db.market_state(1)
        if not st["open"]:                                                    # خارج نافذة الفتح الطبيعية: الشراء مرفوض
            try:
                await db.market_buy(1, 0); assert False
            except GameError:
                pass
        await db.market_force(1)
        st = await db.market_state(1)
        assert st["open"] and len(st["stock"]) == 6
        gear_slot = next(o["slot"] for o in st["stock"] if o["kind"] == "gear")
        res = await db.market_buy(1, gear_slot)
        assert res["item"]["item_id"]
        try:
            await db.market_buy(1, gear_slot); assert False                  # مرة واحدة للاعب
        except GameError:
            pass
        stone = next(o["slot"] for o in st["stock"] if o["kind"] == "stone")
        pts = (await db.get_user(1))["tree_pts"]
        await db.market_buy(1, stone)
        assert (await db.get_user(1))["tree_pts"] > pts
        crate = next(o["slot"] for o in st["stock"] if o["kind"] == "crate")
        await db.market_buy(1, crate)
        assert (await db.get_user(1))["crates"] == 1
        st2 = await db.market_state(2)
        assert st2["stock"][gear_slot]["left"] == st["stock"][gear_slot]["qty"] - 1 and st2["stock"][gear_slot]["mine"] == 0
        await db.market_force(0)
    await with_db(body)


# ───────────────────────── العصابات ─────────────────────────
async def t_gangs():
    async def body(db, d):
        for i in range(1, 6):
            await db.ensure_user(i, f"p{i}")
        try:
            await db.create_guild(1, "الصقور"); assert False             # طابق منخفض
        except GameError as e:
            assert str(ht.GANG_MIN_FLOOR) in str(e)
        await db._run(lambda c: c.execute("UPDATE users SET floor = 45 WHERE user_id = 1"))
        try:
            await db.create_guild(1, "الصقور"); assert False             # لا ذهب كافٍ
        except GameError:
            pass
        await rich(db, 1, 2, 3, 4)
        r = await db.create_guild(1, "الصقور", 77)
        u = await db.get_user(1)
        assert u["gold"] == 500 + 200000 - ht.GANG_COST_GOLD and u["gems"] == 10 + 500 - ht.GANG_COST_GEMS
        await db.gang_set_roles(r["gang_id"], 11, 12)
        for who in (2, 3, 5):
            await db.join_guild(who, "الصقور")
        try:
            await db.gang_accept(2, 3); assert False                      # عضو عادي لا يقبل
        except GameError:
            pass
        a = await db.gang_accept(1, 2)
        assert a["member_role"] == 12 and a["target_name"] == "p2"
        await db.gang_accept(1, 3)
        try:
            await db.gang_accept(1, 4); assert False                      # لم يطلب
        except GameError:
            pass
        info = await db.guild_info(1)
        assert len(info["members"]) == 3 and info["members"][0]["gang_role"] == "leader" and len(info["requests"]) == 1
        # الرتب
        await db.gang_set_role(1, 2, "deputy")
        try:
            await db.gang_set_role(2, 3, "deputy"); assert False
        except GameError:
            pass
        await db.gang_accept(2, 5)                                        # النائب يقبل
        try:
            await db.gang_kick(2, 1); assert False                        # لا يطرد الزعيم
        except GameError:
            pass
        k = await db.gang_kick(2, 5)
        assert k["target_name"] == "p5" and (await db.get_user(5))["guild_id"] is None
        # خزينة
        d1 = await db.gang_deposit(3, "gold", 1000)
        assert d1["treasury"] == 1000
        try:
            await db.gang_deposit(3, "gold", 5); assert False
        except GameError:
            pass
        await db.gang_deposit(3, "gems", 10)
        # عصابة ثانية وحرب بخسارة 15-20% من الخزينة
        await db.create_guild(4, "العقارب")
        await db.gang_deposit(4, "gold", 10000)
        await db._run(lambda c: c.execute("UPDATE users SET guild_id = (SELECT guild_id FROM guilds WHERE guild_name='العقارب') WHERE user_id = 4"))
        await rich(db, 5); await db.join_guild(5, "العقارب"); await db.gang_accept(4, 5)
        try:
            await db.declare_war(2, "العقارب"); assert False              # النائب لا يعلن الحرب
        except GameError:
            pass
        w = await db.declare_war(1, "الصقور" if False else "العقارب", 77)
        await db.apply_win(1, 50, 1, 1); await db.apply_win(3, 50, 1, 1)
        await db._run(lambda c: c.execute("UPDATE wars SET end_ts = 1"))
        done = await db.finish_due_wars()
        st = done[0]["stolen"]
        assert done[0]["result"] == "a" and 0.15 <= st["pct"] <= 0.20 and st["gold"] == int(10000 * st["pct"])
        mine = await db.guild_info(1); other = await db.guild_info(4)
        assert mine["gold"] >= 1000 + st["gold"] and other["gold"] == 10000 - st["gold"]
        # مغادرة الزعيم تنقل القيادة للنائب
        res = await db.leave_guild(1)
        assert res["was_leader"] and res["new_leader"] == 2 and not res["disbanded"]
        info = await db.guild_info(2)
        assert info["leader_id"] == 2 and info["my_role"] == "leader"
        await db.leave_guild(2); await db.leave_guild(3)
        assert await db.guild_info(3) is None
    await with_db(body)


async def t_gang_missions_and_crates():
    async def body(db, d):
        for i in (1, 2):
            await db.ensure_user(i, f"p{i}")
        await rich(db, 1, 2)
        await db.create_guild(1, "النسور"); await db.join_guild(2, "النسور"); await db.gang_accept(1, 2)
        info = await db.guild_info(1)
        ms = {m["mkey"]: m for m in info["missions"]}
        assert set(ms) == {"points", "boss", "wins"} and ms["points"]["target"] == 60 * 2
        t0 = (await db.guild_info(1))["gold"]
        events = []
        for _ in range(40):                                        # مساهمة بالنقاط والانتصارات
            r = await db.apply_win(1, 50, 1, 1)
            events += r["gang_events"]
        assert any(e["type"] == "mission" for e in events)
        assert (await db.guild_info(1))["gold"] > t0
        ev2 = await db._run(lambda c: db._gang_progress(c, 2, "boss", ms["boss"]["target"]))
        assert any(e["type"] == "all_clear" for e in ev2)
        assert (await db.get_user(1))["crates"] == 1 and (await db.get_user(2))["crates"] == 1
    await with_db(body)


# ───────────────────────── المواسم ─────────────────────────
async def t_seasons():
    async def body(db, d):
        for i in (1, 2, 3, 4):
            await db.ensure_user(i, f"p{i}")
        await rich(db, 1, 2); await db.create_guild(1, "الملوك"); await db.join_guild(2, "الملوك"); await db.gang_accept(1, 2)
        for uid, fl in ((1, 80), (2, 60), (3, 30), (4, 10)):
            await db._run(lambda c, uid=uid, fl=fl: c.execute("UPDATE users SET floor = ?, wins = 5 WHERE user_id = ?", (fl, uid)))
        await db.apply_win(1, 50, 1, 1)
        s = await db.season_current()
        assert s["name"] == "الموسم 1" and s["left"] > 0
        assert await db.finish_due_season() is None                         # لم ينتهِ
        gold0 = (await db.get_user(1))["gold"]
        out = await db.finish_due_season(force=True)
        assert [p["user_id"] for p in out["players"]][:3] == [1, 2, 3] and out["gang"]["name"] == "الملوك"
        u1 = await db.get_user(1)
        assert u1["title"] == ht.SEASON_PLAYER_REWARDS[0][2] and u1["gold"] == gold0 + ht.SEASON_PLAYER_REWARDS[0][0]
        assert u1["floor"] == 1 and (await db.get_user(4))["floor"] == 1       # تصفير الطوابق
        assert await db.floor_holder(1) is None and (await db.guild_info(1))["score"] == 0
        assert out["new"]["season_id"] == 2
        hall = await db.season_hall()
        assert hall["season_id"] == 1 and hall["players"][0]["name"] == "p1" and hall["gang"]["name"] == "الملوك"
    await with_db(body)


# ───────────────────────── المهام الأسبوعية والإدارة ─────────────────────────
async def t_weekly_and_admin():
    async def body(db, d):
        await db.ensure_user(1, "أ")
        rows = await db.weekly(1)
        assert len(rows) == 3 and {r["mkey"] for r in rows} <= {m[0] for m in ht.WEEKLY_POOL}
        try:
            await db.claim_weekly(1); assert False
        except GameError:
            pass
        for r in rows:
            await db._run(lambda c, r=r: c.execute("UPDATE weekly_missions SET progress = target WHERE user_id = 1 AND slot = ?", (r["slot"],)))
        gems = (await db.get_user(1))["gems"]
        out = await db.claim_weekly(1)
        assert out["claimed"] == 3 and out["bonus"] == ht.WEEKLY_BONUS_GEMS and (await db.get_user(1))["gems"] == gems + out["gems"]
        try:
            await db.claim_weekly(1); assert False
        except GameError:
            pass
        # الذهب المكتسب يحتسب في المهام الأسبوعية
        await db.ensure_user(2, "ب")
        wk = await db.weekly(2)
        if any(r["mkey"] == "gold" for r in wk):
            await db.add_gold(2, 100, "climb")
            assert next(r for r in await db.weekly(2) if r["mkey"] == "gold")["progress"] == 100
        # إدارة
        r = await db.admin_set_floor(2, 55)
        assert r["new"] == 55 and (await db.get_user(2))["floor"] == 55
        for bad in (0, 101):
            try:
                await db.admin_set_floor(2, bad); assert False
            except GameError:
                pass
        await db.apply_win(2, 50, 1, 1)
        await db.grant_tree_points(2, 3)
        await db.admin_reset(2)
        u = await db.get_user(2)
        assert u["floor"] == 1 and u["level"] == 1 and u["tree_pts"] == 0 and await db.floors_held(2) == []
        try:
            await db.admin_reset(999); assert False
        except GameError:
            pass
    await with_db(body)


def test_mission_pool_has_new_types():
    keys = {m[0] for m in g.MISSION_POOL}
    assert {"tree", "gear"} <= keys
    ms = g.roll_missions("x")
    assert len(ms) == 3
    assert ht.gang_mission_targets(5)[0]["target"] == 300


def main() -> None:
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    atests = [v for k, v in sorted(globals().items()) if k.startswith("t_")]
    for fn in tests:
        fn()
        print("✓", fn.__name__)
    for fn in atests:
        asyncio.run(fn())
        print("✓", fn.__name__)
    print("\nكل اختبارات التحديث نجحت")


if __name__ == "__main__":
    main()
