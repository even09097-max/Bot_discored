"""
رسم بطاقات اللعبة كصور (Pillow): قتال، ملف، حقيبة، سحب، نين، زعيم، ترتيب، شرح...
كل الدوال تعيد bytes (PNG) وهي متزامنة؛ استدعِها عبر asyncio.to_thread.
"""
from __future__ import annotations

import io
import math
import random
from typing import Iterable

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageOps

import cards as cd
import identity as idn
import shaping as sh

# ───────────────────────── الألوان ─────────────────────────
BG_TOP, BG_BOT = (10, 14, 36), (34, 14, 56)
GOLD = (255, 200, 70)
WHITE = (245, 247, 255)
MUTED = (160, 170, 200)
RED, GREEN, BLUE, PURPLE, ORANGE, CYAN = (235, 70, 80), (70, 210, 120), (70, 160, 255), (170, 100, 255), (255, 140, 50), (80, 220, 240)
RARITY_COL = [(154, 166, 182), (59, 156, 255), (176, 92, 255), (255, 176, 46)]
ROLE_EMOJI = {"striker": "⚔️", "tank": "🛡️", "healer": "💚", "controller": "🌀"}   # دور بطاقة الشخصية في القتال
NEN_COL = {
    "enhancer": (255, 120, 60), "transmuter": (180, 90, 255), "conjurer": (70, 200, 130),
    "emitter": (255, 210, 60), "manipulator": (70, 170, 255), "specialist": (240, 70, 140),
}
NEN_ORDER = ["enhancer", "transmuter", "conjurer", "manipulator", "emitter", "specialist"]   # ترتيب سداسي النين
NEN_EMOJI = {"enhancer": "💪", "transmuter": "🧪", "conjurer": "🔮", "emitter": "🚀", "manipulator": "🎭", "specialist": "🃏"}
NEN_AR = {"enhancer": "التعزيز", "transmuter": "التحويل", "conjurer": "التجسيد", "emitter": "الإرسال",
          "manipulator": "التلاعب", "specialist": "التخصص"}
THEMES = {
    "default": ((10, 14, 36), (34, 14, 56), (120, 80, 255)),
    "win": ((8, 30, 28), (14, 40, 60), (70, 220, 140)),
    "lose": ((36, 10, 18), (24, 12, 40), (235, 70, 80)),
    "gold": ((34, 22, 8), (40, 14, 40), (255, 190, 60)),
    "boss": ((38, 8, 22), (14, 8, 36), (255, 70, 90)),
    "blue": ((8, 18, 44), (14, 30, 64), (70, 160, 255)),
}
THEMES.update(idn.THEMES)      # ثيمات الأقسام (برج، نذر، عصابات، سوق...) من identity.py


def _a(c: tuple, a: int) -> tuple:
    return (c[0], c[1], c[2], a)


def _mix(c1: tuple, c2: tuple, t: float) -> tuple:
    return tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))


def _lighten(c: tuple, t: float = 0.35) -> tuple:
    return _mix(c, (255, 255, 255), t)


def _darken(c: tuple, t: float = 0.45) -> tuple:
    return _mix(c, (0, 0, 0), t)


ITEM_ART: dict[str, Image.Image] = {}


def set_item_art(art: dict[str, bytes]) -> None:
    """صور العتاد المرفوعة من الإدارة: {مفتاح الخانة: bytes}. يُستدعى عند التشغيل وعند كل إضافة."""
    ITEM_ART.clear()
    for k, data in art.items():
        im = load_image(data)
        if im is not None:
            ITEM_ART[k] = im


def load_image(data: bytes | None) -> Image.Image | None:
    if not data:
        return None
    try:
        im = Image.open(io.BytesIO(data))
        im.load()
        return im.convert("RGBA")
    except Exception:
        return None


# ───────────────────────── اللوحة ─────────────────────────
_BG_CACHE: dict = {}


class Canvas:
    def __init__(self, w: int, h: int, theme: str = "default", ss: int = 2, seed: int = 7, sect: bool = True):
        self.w, self.h, self.s = w, h, ss
        # هوية الأمر الجاري (خلفية القسم + شارة + ثيم)؛ None خارج الأوامر أو للبطاقات التي لها خلفيتها الخاصة (sect=False)
        self.ident = idn.current() if sect else None
        self.emblem = True
        self.emblem_xy = (12, 6)
        self.emblem_px = 46
        if self.ident is not None and theme not in ("win", "lose"):     # ألوان النتيجة (فوز/خسارة) تبقى؛ والباقي بثيم القسم
            theme = idn.theme_of(self.ident)
        top, bot, accent = THEMES.get(theme, THEMES["default"])
        self.accent = accent
        key = (w, h, theme, ss, seed)
        hit = _BG_CACHE.get(key)
        if hit is None:
            self.img = Image.new("RGBA", (w * ss, h * ss))
            grad = Image.linear_gradient("L").resize((w * ss, h * ss))
            self.img = Image.composite(Image.new("RGBA", self.img.size, _a(bot, 255)),
                                       Image.new("RGBA", self.img.size, _a(top, 255)), grad)
            self.d = ImageDraw.Draw(self.img)
            self._atmosphere(seed)
            if len(_BG_CACHE) < 24:
                _BG_CACHE[key] = self.img.copy()
        else:
            self.img = hit.copy()
            self.d = ImageDraw.Draw(self.img)
        if self.ident is not None:
            self._section_backdrop()

    def _section_backdrop(self) -> None:
        """خلفية مستقلة لهذا القسم/القائمة الفرعية تحت المحتوى (تُعتَّم ليبقى النص مقروءاً)."""
        layer = idn.section_layer(self.ident, self.img.size)
        if layer is None:
            return
        self.img.alpha_composite(layer)
        self._redraw()

    def _stamp_emblem(self) -> None:
        """شارة الأمر (صورته الخاصة) في الزاوية العلوية اليسرى."""
        em = idn.emblem(self.ident, self.X(self.emblem_px))
        if em is not None:
            self.img.alpha_composite(em, (self.X(self.emblem_xy[0]), self.X(self.emblem_xy[1])))

    def _layer(self, x0: int, y0: int, x1: int, y1: int):
        """طبقة شفافة بحجم المنطقة فقط (أسرع بكثير من طبقة بحجم اللوحة كلها). يعيد (layer, draw, ox, oy)."""
        x0, y0 = max(0, int(x0)), max(0, int(y0))
        x1, y1 = min(self.img.width, int(x1) + 1), min(self.img.height, int(y1) + 1)
        if x1 <= x0 or y1 <= y0:
            return None, None, 0, 0
        layer = Image.new("RGBA", (x1 - x0, y1 - y0), (0, 0, 0, 0))
        return layer, ImageDraw.Draw(layer), x0, y0

    def _put(self, layer, ox: int, oy: int) -> None:
        if layer is not None:
            self.img.alpha_composite(layer, (ox, oy))

    # ── مساعدات الإحداثيات ──
    def X(self, v: float) -> int:
        return int(round(v * self.s))

    def box(self, b: Iterable[float]) -> tuple[int, int, int, int]:
        x0, y0, x1, y1 = b
        return self.X(x0), self.X(y0), self.X(x1), self.X(y1)

    def _redraw(self) -> None:
        self.d = ImageDraw.Draw(self.img)

    # ── الخلفية ──
    def _atmosphere(self, seed: int) -> None:
        rnd = random.Random(seed)
        self.glow(self.w * 0.15, self.h * 0.1, self.w * 0.55, self.accent, 70)
        self.glow(self.w * 0.9, self.h * 0.95, self.w * 0.5, _mix(self.accent, (255, 60, 140), 0.6), 55)
        layer = Image.new("RGBA", self.img.size, (0, 0, 0, 0))
        ld = ImageDraw.Draw(layer)
        step = self.X(46)
        for i in range(-self.h * self.s // step, self.w * self.s // step + 4):   # خطوط قطرية خفيفة
            ld.line([(i * step, 0), (i * step + self.h * self.s, self.h * self.s)], fill=(255, 255, 255, 7), width=self.X(1))
        for _ in range(int(self.w * self.h / 9000)):   # جزيئات هالة
            x, y, r = rnd.uniform(0, self.w), rnd.uniform(0, self.h), rnd.uniform(0.8, 2.4)
            ld.ellipse([self.X(x - r), self.X(y - r), self.X(x + r), self.X(y + r)], fill=(*_lighten(self.accent, 0.5), rnd.randint(40, 120)))
        self.img.alpha_composite(layer)
        vig = Image.radial_gradient("L").resize(self.img.size)
        vig = vig.point(lambda v: int(max(0, v - 120) * 1.1))
        self.img.alpha_composite(Image.merge("RGBA", (Image.new("L", self.img.size, 0),) * 3 + (vig,)))
        self._redraw()

    def glow(self, cx: float, cy: float, r: float, color: tuple, alpha: int = 120) -> None:
        size = self.X(r * 2)
        g = Image.radial_gradient("L").resize((size, size))
        g = ImageOps.invert(g).point(lambda v: int(v * v / 255 * alpha / 255))
        layer = Image.merge("RGBA", (Image.new("L", g.size, color[0]), Image.new("L", g.size, color[1]),
                                     Image.new("L", g.size, color[2]), g))
        self._paste_clipped(layer, self.X(cx) - size // 2, self.X(cy) - size // 2)

    def _in(self, cx: float, cy: float, r: float) -> bool:
        return cx - r >= 0 and cy - r >= 0 and cx + r <= self.w and cy + r <= self.h

    def _paste_clipped(self, layer: Image.Image, x: int, y: int) -> None:
        W, H = self.img.size
        cx0, cy0 = max(0, x), max(0, y)
        cx1, cy1 = min(W, x + layer.width), min(H, y + layer.height)
        if cx1 <= cx0 or cy1 <= cy0:
            return
        part = layer.crop((cx0 - x, cy0 - y, cx1 - x, cy1 - y))
        self.img.alpha_composite(part, (cx0, cy0))

    # ── أشكال ──
    def _mask(self, b: tuple, radius: float) -> Image.Image:
        m = Image.new("L", self.img.size, 0)
        ImageDraw.Draw(m).rounded_rectangle(self.box(b), radius=self.X(radius), fill=255)
        return m

    def panel(self, b: tuple, radius: float = 18, fill: tuple = (255, 255, 255, 20), outline: tuple | None = (255, 255, 255, 55),
              width: float = 1.5, shadow: bool = True) -> None:
        x0, y0, x1, y1 = self.box(b)
        if shadow:
            pad = self.X(14)
            layer, d, ox, oy = self._layer(x0 - pad, y0 - pad, x1 + pad, y1 + pad + self.X(5))
            if layer is not None:
                d.rounded_rectangle([x0 - ox, y0 - oy + self.X(5), x1 - ox, y1 - oy + self.X(5)], radius=self.X(radius), fill=(0, 0, 0, 90))
                small = layer.resize((max(1, layer.width // 2), max(1, layer.height // 2)), Image.BILINEAR)
                small = small.filter(ImageFilter.GaussianBlur(self.X(4)))
                self._put(small.resize(layer.size, Image.BILINEAR), ox, oy)
        layer, d, ox, oy = self._layer(x0 - 2, y0 - 2, x1 + 2, y1 + 2)
        if layer is not None:
            d.rounded_rectangle([x0 - ox, y0 - oy, x1 - ox, y1 - oy], radius=self.X(radius), fill=fill, outline=outline,
                                width=self.X(width) if outline else 0)
            self._put(layer, ox, oy)

    def gradient_rect(self, b: tuple, c1: tuple, c2: tuple, radius: float = 10, horizontal: bool = False) -> None:
        x0, y0, x1, y1 = self.box(b)
        if x1 <= x0 or y1 <= y0:
            return
        gw, gh = x1 - x0, y1 - y0
        g = Image.linear_gradient("L")
        g = g.rotate(90, expand=True) if horizontal else g
        g = g.resize((gw, gh))
        layer = Image.composite(Image.new("RGBA", (gw, gh), _a(c2, 255)), Image.new("RGBA", (gw, gh), _a(c1, 255)), g)
        m = Image.new("L", (gw, gh), 0)
        ImageDraw.Draw(m).rounded_rectangle([0, 0, gw - 1, gh - 1], radius=self.X(radius), fill=255)
        self.img.paste(layer, (x0, y0), m)
        self._redraw()

    def bar(self, b: tuple, frac: float, c1: tuple, c2: tuple, back: tuple = (0, 0, 0, 120), radius: float | None = None) -> None:
        x0, y0, x1, y1 = b
        radius = radius if radius is not None else (y1 - y0) / 2
        X0, Y0, X1, Y1 = self.box(b)
        layer, d, ox, oy = self._layer(X0 - 2, Y0 - 2, X1 + 2, Y1 + 2)
        if layer is not None:
            d.rounded_rectangle([X0 - ox, Y0 - oy, X1 - ox, Y1 - oy], radius=self.X(radius), fill=back, outline=(255, 255, 255, 60), width=self.X(1))
            self._put(layer, ox, oy)
        frac = max(0.0, min(1.0, frac))
        if frac > 0:
            fw = max((y1 - y0), (x1 - x0) * frac) if frac > 0.01 else (y1 - y0)
            fw = min(fw, x1 - x0)
            self.gradient_rect((x0 + 1.5, y0 + 1.5, x0 + fw - 1.5, y1 - 1.5), c1, c2, radius=max(1, radius - 1.5), horizontal=True)
            gb = self.box((x0 + 3, y0 + 2.5, x0 + fw - 3, y0 + (y1 - y0) * 0.45))
            layer, d, ox, oy = self._layer(gb[0], gb[1], gb[2], gb[3])
            if layer is not None:
                d.rounded_rectangle([gb[0] - ox, gb[1] - oy, gb[2] - ox, gb[3] - oy], radius=self.X(radius / 2), fill=(255, 255, 255, 55))
                self._put(layer, ox, oy)

    def line(self, p0: tuple, p1: tuple, color: tuple, width: float = 2) -> None:
        a, b = (self.X(p0[0]), self.X(p0[1])), (self.X(p1[0]), self.X(p1[1]))
        pad = self.X(width) + 2
        layer, d, ox, oy = self._layer(min(a[0], b[0]) - pad, min(a[1], b[1]) - pad, max(a[0], b[0]) + pad, max(a[1], b[1]) + pad)
        if layer is not None:
            d.line([(a[0] - ox, a[1] - oy), (b[0] - ox, b[1] - oy)], fill=color, width=self.X(width))
            self._put(layer, ox, oy)

    def polygon(self, pts: list[tuple], fill: tuple, outline: tuple | None = None, width: float = 2) -> None:
        sp = [(self.X(x), self.X(y)) for x, y in pts]
        pad = self.X(width) + 2
        xs, ys = [p[0] for p in sp], [p[1] for p in sp]
        layer, d, ox, oy = self._layer(min(xs) - pad, min(ys) - pad, max(xs) + pad, max(ys) + pad)
        if layer is None:
            return
        lp = [(x - ox, y - oy) for x, y in sp]
        d.polygon(lp, fill=fill)
        if outline:
            d.line(lp + [lp[0]], fill=outline, width=self.X(width), joint="curve")
        self._put(layer, ox, oy)

    def ellipse(self, cx: float, cy: float, r: float, fill: tuple | None = None, outline: tuple | None = None, width: float = 2) -> None:
        x0, y0, x1, y1 = self.X(cx - r), self.X(cy - r), self.X(cx + r), self.X(cy + r)
        pad = self.X(width) + 2
        layer, d, ox, oy = self._layer(x0 - pad, y0 - pad, x1 + pad, y1 + pad)
        if layer is not None:
            d.ellipse([x0 - ox, y0 - oy, x1 - ox, y1 - oy], fill=fill, outline=outline, width=self.X(width) if outline else 0)
            self._put(layer, ox, oy)

    def rays(self, cx: float, cy: float, r: float, color: tuple, n: int = 14, alpha: int = 60, spin: float = 0.0) -> None:
        size = self.X(r * 2)
        layer = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        ld = ImageDraw.Draw(layer)
        c = size / 2
        for i in range(n):
            a0 = spin + i * 2 * math.pi / n
            a1 = a0 + math.pi / n
            ld.polygon([(c, c), (c + c * math.cos(a0), c + c * math.sin(a0)), (c + c * math.cos(a1), c + c * math.sin(a1))], fill=_a(color, alpha))
        mask = ImageOps.invert(Image.radial_gradient("L").resize((size, size)))
        layer.putalpha(ImageChops.multiply(layer.getchannel("A"), mask))
        self._paste_clipped(layer, self.X(cx) - size // 2, self.X(cy) - size // 2)

    # ── نصوص وأيقونات ──
    def text(self, x: float, y: float, text: str, size: float = 24, fill: tuple = WHITE, align: str = "r",
             weight: str = "bold", shadow: bool = True, gap: float = 1.15) -> float:
        font = sh.get_font(weight, max(8, int(size * self.s)))
        if shadow:
            sh.draw_rich(self.img, self.d, self.X(x) + self.X(1.6), self.X(y) + self.X(2), text, font, (0, 0, 0, 150), align, gap)
        w = sh.draw_rich(self.img, self.d, self.X(x), self.X(y), text, font, fill, align, gap)
        return w / self.s

    def text_width(self, text: str, size: float, weight: str = "bold", gap: float = 1.15) -> float:
        return sh.rich_width(sh.get_font(weight, max(8, int(size * self.s))), text, gap) / self.s

    def fit_text(self, x: float, y: float, text: str, max_w: float, size: float = 24, **kw) -> float:
        while size > 11 and self.text_width(text, size, kw.get("weight", "bold")) > max_w:
            size -= 1
        return self.text(x, y, text, size, **kw)

    def icon(self, emoji: str, cx: float, cy: float, size: float = 32) -> None:
        ic = sh.icon_image(sh.icon_key(emoji), self.X(size))
        if ic is not None:
            self.img.alpha_composite(ic, (self.X(cx) - ic.width // 2, self.X(cy) - ic.height // 2))

    def item_icon(self, it: dict, cx: float, cy: float, size: float) -> None:
        """صورة العنصر (إن رُفعت له صورة) وإلا أيقونته الجاهزة."""
        art = ITEM_ART.get(it.get("slot") or "")
        if art is None:
            self.icon(it["emoji"], cx, cy, size)
            return
        d = self.X(size * 1.15)
        im = ImageOps.fit(art, (d, d), Image.LANCZOS, centering=(0.5, 0.4)).convert("RGBA")
        m = Image.new("L", (d, d), 0)
        ImageDraw.Draw(m).rounded_rectangle([0, 0, d - 1, d - 1], radius=int(d * 0.18), fill=255)
        im.putalpha(ImageChops.multiply(im.getchannel("A"), m))
        self._paste_clipped(im, self.X(cx) - d // 2, self.X(cy) - d // 2)

    def badge(self, cx: float, cy: float, text: str, color: tuple, size: float = 18, min_w: float = 0) -> None:
        w = max(min_w, self.text_width(text, size) + 22)
        self.panel((cx - w / 2, cy - size * 0.95, cx + w / 2, cy + size * 0.95), radius=size, fill=_a(_darken(color, 0.35), 230),
                   outline=_a(_lighten(color, 0.3), 255), width=1.5, shadow=False)
        self.text(cx, cy, text, size, WHITE, "m", shadow=False)

    # ── صور ──
    def circle_image(self, art: Image.Image | None, cx: float, cy: float, r: float, ring: tuple = GOLD, fallback: str = "👤",
                     ring_w: float = 5) -> None:
        d = self.X(r * 2)
        self.glow(cx, cy, r * 1.55, ring, 110)
        base = Image.new("RGBA", (d, d), (0, 0, 0, 0))
        if art is not None:
            base = ImageOps.fit(art, (d, d), Image.LANCZOS, centering=(0.5, 0.25))
        else:
            ImageDraw.Draw(base).ellipse([0, 0, d - 1, d - 1], fill=_a(_darken(ring, 0.6), 255))
            ic = sh.icon_image(sh.icon_key(fallback), int(d * 0.58))
            if ic is not None:
                base.alpha_composite(ic, ((d - ic.width) // 2, (d - ic.height) // 2))
        m = Image.new("L", (d, d), 0)
        ImageDraw.Draw(m).ellipse([0, 0, d - 1, d - 1], fill=255)
        self.img.paste(base.convert("RGBA"), (self.X(cx) - d // 2, self.X(cy) - d // 2), m)
        self.ellipse(cx, cy, r + ring_w / 2, outline=ring, width=ring_w)
        self.ellipse(cx, cy, r + ring_w + 3, outline=_a(ring, 90), width=1.5)

    def cover(self, art: Image.Image | None, b: tuple, radius: float = 16, dark: float = 0.35, fallback_color: tuple | None = None,
              emoji: str | None = None, blur: float = 0) -> None:
        x0, y0, x1, y1 = self.box(b)
        w, h = x1 - x0, y1 - y0
        if w <= 0 or h <= 0:
            return
        if art is not None:
            layer = ImageOps.fit(art, (w, h), Image.LANCZOS, centering=(0.5, 0.3))
            if blur:
                layer = layer.filter(ImageFilter.GaussianBlur(self.X(blur)))
        else:
            c = fallback_color or self.accent
            layer = Image.composite(Image.new("RGBA", (w, h), _a(_darken(c, 0.75), 255)), Image.new("RGBA", (w, h), _a(_darken(c, 0.35), 255)),
                                    Image.linear_gradient("L").resize((w, h)))
            if emoji:
                ic = sh.icon_image(sh.icon_key(emoji), int(min(w, h) * 0.55))
                if ic is not None:
                    ic2 = ic.copy()
                    ic2.putalpha(ic2.getchannel("A").point(lambda v: int(v * 0.55)))
                    layer.alpha_composite(ic2, ((w - ic2.width) // 2, (h - ic2.height) // 2))
        if dark:
            layer.alpha_composite(Image.new("RGBA", (w, h), (0, 0, 0, int(255 * dark))))
        m = Image.new("L", (w, h), 0)
        ImageDraw.Draw(m).rounded_rectangle([0, 0, w - 1, h - 1], radius=self.X(radius), fill=255)
        self.img.paste(layer.convert("RGBA"), (x0, y0), m)
        self._redraw()

    def backdrop(self, art: Image.Image | None, dark: float = 0.58) -> None:
        """يجعل صورة (أو GIF أول إطار) خلفية للبطاقة كلها مع تعتيم لتبقى النصوص مقروءة."""
        if art is None:
            return
        layer = ImageOps.fit(art, self.img.size, Image.BILINEAR, centering=(0.5, 0.4)).convert("RGBA")
        self.img.alpha_composite(Image.blend(layer, Image.new("RGBA", layer.size, (6, 8, 22, 255)), dark))

    def fade_bottom(self, b: tuple, color: tuple = (8, 10, 26), strength: int = 235) -> None:
        x0, y0, x1, y1 = self.box(b)
        g = Image.linear_gradient("L").resize((x1 - x0, y1 - y0)).point(lambda v: int(v * strength / 255))
        layer = Image.merge("RGBA", (Image.new("L", g.size, color[0]), Image.new("L", g.size, color[1]), Image.new("L", g.size, color[2]), g))
        self.img.alpha_composite(layer, (x0, y0))
        self._redraw()

    # ── العناوين ──
    def header(self, title: str, subtitle: str = "", y: float = 44, emoji: str = "", accent: tuple | None = None) -> None:
        accent = accent or self.accent
        self.line((40, y + 26), (self.w - 40, y + 26), _a(accent, 120), 2)
        self.line((self.w - 40, y + 26), (self.w - 40 - 150, y + 26), _a(_lighten(accent, 0.4), 255), 3)
        x = self.w - 40
        if emoji:
            self.icon(emoji, x - 22, y - 2, 44)
            x -= 58
        self.text(x, y - 6, title, 38, WHITE, "r", "black")
        if subtitle:
            self.text(self.w - 42, y + 52, subtitle, 18, MUTED, "r", "regular", shadow=False)

    def footer(self, text: str) -> None:
        self.text(self.w / 2, self.h - 20, text, 14, (255, 255, 255, 110), "m", "regular", shadow=False)

    def finish(self) -> bytes:
        if self.emblem and self.ident is not None:
            self._stamp_emblem()
        out = self.img.resize((self.w, self.h), Image.BILINEAR if self.s == 2 else Image.LANCZOS).convert("RGB")
        buf = io.BytesIO()
        out.save(buf, "JPEG", quality=90, subsampling=0, optimize=False)
        return buf.getvalue()


# ───────────────────────── مكوّنات مشتركة ─────────────────────────
def stat_tile(cv: Canvas, b: tuple, emoji: str, label: str, value: str, color: tuple = BLUE) -> None:
    cv.panel(b, 14, fill=_a(_darken(color, 0.6), 150), outline=_a(color, 160))
    cx = (b[0] + b[2]) / 2
    cv.icon(emoji, b[2] - 30, (b[1] + b[3]) / 2, 34)
    cv.text(b[2] - 56, b[1] + (b[3] - b[1]) * 0.30, label, 15, MUTED, "r", "regular", shadow=False)
    cv.text(b[2] - 56, b[1] + (b[3] - b[1]) * 0.68, value, 25, WHITE, "r", "black")


def chip(cv: Canvas, x: float, y: float, emoji: str, text: str, color: tuple = GOLD, size: float = 22, align: str = "r") -> float:
    w = cv.text_width(text, size, "black") + size * 2.7
    x0 = x - w if align == "r" else x
    cv.panel((x0, y - size, x0 + w, y + size), radius=size, fill=_a(_darken(color, 0.65), 200), outline=_a(color, 200), shadow=False)
    cv.icon(emoji, x0 + w - size * 1.05, y, size * 1.35)
    cv.text(x0 + w - size * 2.1, y, text, size, WHITE, "r", "black", shadow=False)
    return w


def rarity_frame(cv: Canvas, b: tuple, rarity: int, emoji: str, selected: bool = False) -> None:
    col = RARITY_COL[rarity]
    cv.panel(b, 14, fill=_a(_darken(col, 0.7), 215), outline=_a(_lighten(col, 0.25), 255), width=2.5 if rarity > 1 else 1.8)
    cx, cy = (b[0] + b[2]) / 2, (b[1] + b[3]) / 2
    if rarity >= 2:
        cv.glow(cx, cy, (b[2] - b[0]) * 0.7, col, 140)
    cv.icon(emoji, cx, cy, min(b[2] - b[0], b[3] - b[1]) * 0.62)


def hexagon_points(cx: float, cy: float, r: float, rot: float = -math.pi / 2) -> list[tuple[float, float]]:
    return [(cx + r * math.cos(rot + i * math.pi / 3), cy + r * math.sin(rot + i * math.pi / 3)) for i in range(6)]


def nen_hexagon(cv: Canvas, cx: float, cy: float, r: float, active: str | None, small: bool = False) -> None:
    """سداسي النين: كل فئة على رأس، المتخصص في الأسفل. الفئة الفعّالة تتوهج."""
    pts = hexagon_points(cx, cy, r)
    cv.polygon(pts, _a((255, 255, 255), 10), _a((255, 255, 255), 90), 2.5)
    for p in pts:
        cv.line((cx, cy), p, (255, 255, 255, 35), 1.5)
    for i, key in enumerate(NEN_ORDER):
        px, py = pts[i]
        col = NEN_COL[key]
        on = key == active
        rr = r * (0.26 if small else 0.27) * (1.18 if on else 1)
        if on:
            cv.glow(px, py, rr * 2.4, col, 200)
        cv.ellipse(px, py, rr, fill=_a(_darken(col, 0.55 if on else 0.75), 245), outline=_a(_lighten(col, 0.2), 255 if on else 120),
                   width=3 if on else 1.5)
        cv.icon(NEN_EMOJI[key], px, py, rr * 1.25)
        if not small:
            ly = py - rr - 16 if py < cy else py + rr + 16
            cv.text(px, ly, NEN_AR[key], 17, WHITE if on else MUTED, "m", "bold", shadow=on)


# ───────────────────────── بطاقة القتال ─────────────────────────
def _status_icons(f: dict) -> list[str]:
    out = []
    if f.get("shield") or f.get("aura_shield"):
        out.append("🔰")
    if f.get("reflect"):
        out.append("🔄")
    if f.get("stun"):
        out.append("💫")
    if f.get("poison"):
        out.append("☠️")
    if f.get("boost"):
        out.append("💪")
    if f.get("guard"):
        out.append("🛡️")
    if f.get("evade"):
        out.append("🌪️")
    if f.get("locked"):
        out.append("⛓️")
    if f.get("amp"):
        out.append("👁️")
    return out


def _team_strip(cv: Canvas, x: float, y: float, team: list[dict], arts: dict[str, Image.Image]) -> None:
    """صور مصغّرة دائرية لبطاقات الفريق (عمودياً) بإطار لون الندرة، داخل لوحة المقاتل."""
    for i, m in enumerate(team[:cd.TEAM_SIZE]):
        cv.circle_image(arts.get(m["key"]), x, y + i * 56, 21, RARITY_COL[m["r"]], fallback=ROLE_EMOJI[m["role"]], ring_w=2.5)


def _fighter_panel(cv: Canvas, b: tuple, f: dict, art: Image.Image | None, side_color: tuple, you: bool,
                   team_arts: dict[str, Image.Image] | None = None) -> None:
    x0, y0, x1, y1 = b
    cx = (x0 + x1) / 2
    ring = NEN_COL.get(f.get("nen") or "", side_color)
    cv.panel(b, 22, fill=_a(_darken(side_color, 0.72), 150), outline=_a(side_color, 170), width=2)
    cv.circle_image(art, cx, y0 + 92, 66, ring, fallback=f.get("emoji", "👤" if you else "👹"))
    if f.get("nen"):
        cv.icon(NEN_EMOJI[f["nen"]], cx + 52, y0 + 142, 34)
    st = _status_icons(f)
    for i, e in enumerate(st[:5]):
        cv.icon(e, x1 - 28, y0 + 34 + i * 32, 26)
    cv.fit_text(cx, y0 + 192, f["name"], x1 - x0 - 30, 24, fill=WHITE, align="m", weight="black")
    # الصحة
    by = y0 + 232
    cv.bar((x0 + 22, by, x1 - 22, by + 26), f["hp"] / max(1, f["max_hp"]), (255, 90, 90) if f["hp"] / max(1, f["max_hp"]) < 0.35 else (80, 220, 120),
           (40, 150, 90) if f["hp"] / max(1, f["max_hp"]) >= 0.35 else (190, 40, 60))
    cv.icon("❤️", x1 - 36, by + 13, 24)
    cv.text(cx, by + 13, f"{f['hp']} / {f['max_hp']}", 16, WHITE, "m", "bold")
    if f.get("max_aura"):
        ay = by + 36
        cv.bar((x0 + 22, ay, x1 - 22, ay + 16), f["aura"] / max(1, f["max_aura"]), (90, 190, 255), (60, 110, 255))
        cv.icon("🔷", x1 - 36, ay + 8, 20)
        cv.text(cx, ay + 8, f"{f['aura']} / {f['max_aura']}", 12, WHITE, "m", "bold", shadow=False)
    sy = y1 - 24
    cv.text(cx + 78, sy, str(f["atk"]), 17, WHITE, "m", "bold", shadow=False)
    cv.icon("⚔️", cx + 100, sy, 20)
    cv.text(cx, sy, str(f["defense"]), 17, WHITE, "m", "bold", shadow=False)
    cv.icon("🛡️", cx + 22, sy, 20)
    cv.text(cx - 78, sy, str(f["speed"]), 17, WHITE, "m", "bold", shadow=False)
    cv.icon("💨", cx - 56, sy, 20)
    if f.get("team"):
        _team_strip(cv, x0 + 36, y0 + 60, f["team"], team_arts or {})


def battle_card(title: str, rnd: int, player: dict, enemy: dict, log: list[str], player_art: bytes | None = None,
                enemy_art: bytes | None = None, theme: str = "default", footer: str = "", bg: bytes | None = None,
                banner: str = "", combo: int = 0, flash: tuple[str, str] | None = None,
                team_arts: dict[str, bytes] | None = None) -> bytes:
    """flash = (جهة الضرر 'p'/'e', نص الضرر) يظهر فوق المقاتل المصاب. team_arts = {مفتاح البطاقة: صورتها} لشريط الفريق."""
    cv = Canvas(1000, 650, theme, sect=False)
    t_arts = {k: im for k, b_ in (team_arts or {}).items() if (im := load_image(b_)) is not None}
    cv.backdrop(load_image(bg))
    cv.text(500, 34, title, 30, WHITE, "m", "black")
    cv.line((60, 62), (940, 62), _a(cv.accent, 140), 2)
    cv.badge(500, 88, f"الجولة {rnd}" if rnd else "استعد!", cv.accent, 17, 130)
    if combo >= 2:
        cv.badge(500, 124, f"🔥 كومبو ×{combo}", ORANGE, 15, 120)
    _fighter_panel(cv, (600, 110, 970, 450), player, load_image(player_art), BLUE, True, t_arts)
    _fighter_panel(cv, (30, 110, 400, 450), enemy, load_image(enemy_art), RED, False, t_arts)
    if flash:
        side, txt = flash
        cv.text(785 if side == "p" else 215, 150, txt, 38, (255, 90, 90) if side == "p" else (255, 220, 90), "m", "black")
    cv.glow(500, 250, 80, (255, 220, 120), 90)
    cv.text(500, 270, "VS", 54, GOLD, "m", "black")
    if banner:
        cv.badge(500, 340, banner, RED, 20, 260)
    else:
        cv.icon("⚔️", 500, 200, 38)
    cv.panel((30, 468, 970, 630), 18, fill=(0, 0, 0, 130), outline=_a(cv.accent, 120))
    lines = log[-4:] or ["اختر حركتك!"]
    for i, ln in enumerate(lines):
        age = len(lines) - 1 - i
        col = WHITE if age == 0 else (200, 205, 225) if age == 1 else (150, 156, 180)
        cv.fit_text(955, 492 + i * 35, ln, 880, 21, fill=col, align="r", weight="bold" if age == 0 else "regular", shadow=age == 0)
    if footer:
        cv.footer(footer)
    return cv.finish()


def result_card(kind: str, title: str, subtitle: str, rewards: list[tuple[str, str]], art: bytes | None = None,
                notes: list[str] | None = None, player: str = "", bg: bytes | None = None) -> bytes:
    theme = {"win": "win", "lose": "lose"}.get(kind, "default")
    h = 470 + 36 * len(notes or [])
    cv = Canvas(1000, h, theme, sect=False)
    cv.backdrop(load_image(bg), 0.5)
    col = {"win": GREEN, "lose": RED}.get(kind, MUTED)
    emoji = {"win": "🏆", "lose": "💀", "flee": "🏳️"}.get(kind, "⏳")
    if kind == "win":
        cv.rays(500, 150, 420, GOLD, 18, 45)
    cv.glow(500, 150, 260, col, 150)
    cv.circle_image(load_image(art), 500, 130, 62, col, fallback=emoji)
    cv.text(500, 255, title, 56, WHITE, "m", "black")
    if subtitle:
        cv.text(500, 305, subtitle, 22, MUTED, "m", "regular", shadow=False)
    n = len(rewards)
    if n:
        total = sum(cv.text_width(t, 24, "black") + 70 for _, t in rewards) + 16 * (n - 1)
        x = 500 + total / 2
        for e, t in rewards:
            w = chip(cv, x, 375, e, t, GOLD if e in ("💰", "🪙") else col if e != "💎" else CYAN, 24)
            x -= w + 16
    y = 430
    for note in notes or []:
        cv.text(500, y, note, 21, WHITE, "m", "bold")
        y += 36
    return cv.finish()


# ───────────────────────── الملف الشخصي ─────────────────────────
def profile_card(u: dict, avatar: bytes | None, rank_name: str, stars: int, tier: str, guild: str | None, vow: str | None,
                 xp_need: int, boss_dmg: int = 0) -> bytes:
    cv = Canvas(1000, 600, "gold")
    cv.emblem_xy = (748, 32)
    cv.panel((24, 24, 976, 576), 28, fill=(10, 8, 24, 150), outline=_a(GOLD, 200), width=3)
    cv.text(956, 62, "رخصة الصيّاد", 26, GOLD, "r", "black")
    cv.text(44, 62, "HEAVENS ARENA", 20, (255, 255, 255, 140), "l", "bold", shadow=False)
    cv.line((48, 88), (952, 88), _a(GOLD, 150), 2)
    cv.circle_image(load_image(avatar), 820, 220, 92, GOLD, fallback="🧑")
    cv.fit_text(820, 345, u["username"] or "لاعب", 250, 34, fill=WHITE, align="m", weight="black")
    cv.text(820, 385, tier, 20, MUTED, "m", "bold", shadow=False)
    for i in range(5):
        if i < stars:
            cv.icon("⭐", 820 + (i - 2) * 38, 428, 32)
        else:
            cv.ellipse(820 + (i - 2) * 38, 428, 11, fill=(255, 255, 255, 30), outline=(255, 255, 255, 80), width=1.5)
    cv.text(820, 470, rank_name, 22, GOLD, "m", "black")
    if guild:
        cv.text(820, 520, f"🏰 {guild}", 19, WHITE, "m", "bold", shadow=False)
    # الجانب الأيسر: الإحصائيات
    stat_tile(cv, (440, 110, 700, 175), "🏰", "الطابق", str(u["floor"]), ORANGE)
    stat_tile(cv, (160 + 0, 110, 420, 175), "⭐", "المستوى", str(u["level"]), GOLD)
    stat_tile(cv, (440, 190, 700, 255), "⚔️", "الهجوم", str(u["t_atk"]), RED)
    stat_tile(cv, (160, 190, 420, 255), "🛡️", "الدفاع", str(u["t_def"]), BLUE)
    stat_tile(cv, (440, 270, 700, 335), "💨", "السرعة", str(u["t_speed"]), CYAN)
    stat_tile(cv, (160, 270, 420, 335), "❤️", "الصحة القصوى", str(u["t_hp"]), GREEN)
    # أشرطة
    cv.text(700, 372, "الخبرة", 17, MUTED, "r", "regular", shadow=False)
    cv.bar((160, 385, 700, 407), u["xp"] / max(1, xp_need), (255, 210, 90), (255, 140, 40))
    cv.text(430, 396, f"{u['xp']} / {xp_need}", 14, WHITE, "m", "bold", shadow=False)
    cv.text(700, 430, "الصحة", 17, MUTED, "r", "regular", shadow=False)
    cv.bar((160, 443, 700, 465), u["cur_hp"] / max(1, u["t_hp"]), (80, 220, 120), (40, 150, 90))
    cv.text(430, 454, f"{u['cur_hp']} / {u['t_hp']}", 14, WHITE, "m", "bold", shadow=False)
    # النين
    nk = u.get("nen")
    if nk:
        cv.ellipse(100, 515, 38, fill=_a(_darken(NEN_COL[nk], 0.6), 230), outline=NEN_COL[nk], width=3)
        cv.icon(NEN_EMOJI[nk], 100, 515, 46)
        cv.text(150, 500, "فئة النين", 14, MUTED, "l", "regular", shadow=False)
        cv.text(150, 530, NEN_AR[nk], 22, WHITE, "l", "black")
    else:
        cv.text(60, 515, "🔒 النين يُفتح عند الطابق 50", 18, MUTED, "l", "bold", shadow=False)
    # الأسفل
    cv.text(700, 505, f"💰 {u['gold']:,}    💎 {u['gems']:,}", 22, WHITE, "r", "black")
    cv.text(700, 545, f"انتصارات {u['wins']}  ·  هزائم {u['losses']}" + (f"  ·  نذر: {vow}" if vow else ""), 16, MUTED, "r", "regular", shadow=False)
    if u.get("stat_points"):
        cv.badge(400, 60, f"{u['stat_points']} نقاط تطوير", GREEN, 16)
    return cv.finish()


# ───────────────────────── الحقيبة ─────────────────────────
SLOT_LABEL = {"Weapon": ("⚔️", "السلاح"), "Armor": ("🛡️", "الدرع"), "Helmet": ("⛑️", "الخوذة"), "Companion": ("🐾", "المرافق"), "Relic": ("🔮", "الأثر")}


def _item_tile(cv: Canvas, b: tuple, it: dict) -> None:
    x0, y0, x1, y1 = b
    r = it["rarity"]
    col = RARITY_COL[r]
    cv.panel(b, 16, fill=_a(_darken(col, 0.72), 200), outline=_a(_lighten(col, 0.2), 255 if it.get("equipped") else 150),
             width=3 if it.get("equipped") else 1.5)
    if r >= 2:
        cv.glow(x1 - 48, (y0 + y1) / 2, 60, col, 110)
    cv.item_icon(it, x1 - 48, (y0 + y1) / 2 - 4, 58)
    cv.fit_text(x1 - 92, y0 + 28, it["name"] + (f" +{it['lvl']}" if it.get("lvl") else ""), x1 - x0 - 110, 20, fill=WHITE, align="r", weight="black")
    cv.text(x1 - 92, y0 + 58, it["bonus_text"], 18, _lighten(col, 0.45), "r", "bold")
    if it.get("fx_text"):
        cv.fit_text(x1 - 92, y0 + 84, it["fx_text"], x1 - x0 - 110, 14, fill=_lighten(CYAN, 0.2), align="r", weight="regular", shadow=False)
    cv.text(x0 + 14, y1 - 18, f"#{it['item_id']}", 16, MUTED, "l", "bold", shadow=False)
    if it.get("equipped"):
        cv.badge(x0 + 52, y0 + 22, "مُجهّز", GREEN, 14)
    stars = r + 1
    for i in range(stars):
        cv.icon("⭐", x1 - 100 - i * 18, y1 - 20, 16)


def inventory_card(items: list[dict], slots: dict[str, dict | None], page: int, pages: int, total: int, avatar_name: str = "",
                   gold: int = 0, gems: int = 0) -> bytes:
    rows = max(1, math.ceil(len(items) / 3))
    h = 330 + rows * 128 + 40
    cv = Canvas(1000, h, "blue")
    cv.header("حقيبتك", f"{total} عنصر" + (f" · {avatar_name}" if avatar_name else ""), emoji="🎒")
    cv.text(70 + 0, 62, f"💰 {gold:,}   💎 {gems:,}", 21, WHITE, "l", "black")
    cv.text(955, 134, "العتاد المجهّز", 20, GOLD, "r", "black")
    for i, (typ, (em, lab)) in enumerate(SLOT_LABEL.items()):
        x1 = 960 - i * 188
        b = (x1 - 180, 160, x1, 270)
        it = slots.get(typ)
        if it:
            col = RARITY_COL[it["rarity"]]
            cv.panel(b, 16, fill=_a(_darken(col, 0.72), 200), outline=_a(_lighten(col, 0.2), 230), width=2.5)
            cv.item_icon(it, b[0] + 42, (b[1] + b[3]) / 2, 56)
            cv.fit_text(b[2] - 10, b[1] + 30, it["name"], 98, 17, fill=WHITE, align="r", weight="black")
            cv.text(b[2] - 10, b[1] + 60, it["bonus_text"], 16, _lighten(RARITY_COL[it["rarity"]], 0.45), "r", "bold")
            cv.text(b[2] - 10, b[1] + 90, f"#{it['item_id']}", 14, MUTED, "r", "regular", shadow=False)
        else:
            cv.panel(b, 16, fill=(255, 255, 255, 12), outline=(255, 255, 255, 60))
            cv.icon(em, b[0] + 42, (b[1] + b[3]) / 2, 46)
            cv.text(b[2] - 14, (b[1] + b[3]) / 2 - 12, lab, 20, MUTED, "r", "bold", shadow=False)
            cv.text(b[2] - 14, (b[1] + b[3]) / 2 + 16, "فارغ", 15, (255, 255, 255, 110), "r", "regular", shadow=False)
    cv.text(955, 312, "كل العناصر", 20, GOLD, "r", "black")
    if not items:
        cv.text(500, 400, "لا توجد عناصر في هذه الصفحة", 24, MUTED, "m")
    for i, it in enumerate(items):
        col, row = i % 3, i // 3
        x1 = 960 - col * 318
        _item_tile(cv, (x1 - 300, 340 + row * 128, x1, 340 + row * 128 + 114), it)
    cv.text(500, h - 24, f"صفحة {page} من {pages}   ·   جهّز بـ «تجهيز رقم» وبِع بـ «بيع رقم»", 16, MUTED, "m", "regular", shadow=False)
    return cv.finish()


# ───────────────────────── السحب ─────────────────────────
def _gacha_card(cv: Canvas, cx: float, cy: float, w: float, h: float, it: dict, small: bool = False) -> None:
    """بطاقة عنصر كبيرة: صورة العتاد الحقيقية (من الأنمي أو التي رفعتها) تملأ أعلى البطاقة، وإلا أيقونة كبيرة."""
    r = it["rarity"]
    col = RARITY_COL[r]
    b = (cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)
    if r >= 2:
        cv.rays(cx, cy, max(w, h) * (0.9 if r == 3 else 0.7), col, 16, 55 if r == 3 else 35)
    cv.glow(cx, cy, max(w, h) * 0.75, col, 150 if r >= 2 else 70)
    cv.panel(b, 22, fill=_a(_darken(col, 0.78), 245), outline=_a(_lighten(col, 0.3), 255), width=3.5 if r >= 2 else 2.2)
    art = ITEM_ART.get(it.get("slot") or "")
    top = b[1] + h * 0.60
    if art is not None:
        cv.cover(art, (b[0] + 9, b[1] + 9, b[2] - 9, top), 16, dark=0.0)
        cv.fade_bottom((b[0] + 9, top - h * 0.12, b[2] - 9, top), _darken(col, 0.78), 200)
    else:
        isz = min(w * 0.64, h * 0.44)
        cv.glow(cx, b[1] + h * 0.30, isz * 0.9, col, 160)
        cv.item_icon(it, cx, b[1] + h * 0.30, isz)
    cv.panel((b[0] + 7, b[1] + 7, b[2] - 7, b[3] - 7), 17, fill=(0, 0, 0, 0), outline=_a(col, 110), width=1.2, shadow=False)
    fs = max(14, w * 0.095)
    cv.fit_text(cx, b[1] + h * 0.675, it["name"] + (f" +{it['lvl']}" if it.get("lvl") else ""), w - 26, fs * 1.25, fill=WHITE, align="m", weight="black")
    cv.text(cx, b[1] + h * 0.765, it["bonus_text"], fs * 1.0, _lighten(col, 0.5), "m", "bold")
    if it.get("fx_text"):
        cv.fit_text(cx, b[1] + h * 0.845, it["fx_text"], w - 26, fs * 0.78, fill=_lighten(CYAN, 0.25), align="m", weight="regular", shadow=False)
    n = r + 1
    sz = max(12, w * 0.08)
    for i in range(n):
        cv.icon("⭐", cx + (i - (n - 1) / 2) * sz * 1.2, b[1] + h * 0.935, sz)
    if it.get("new_best"):
        cv.badge(cx, b[1] + 6, "جديد!", GOLD, max(12, w * 0.07))
    if it.get("is_gear"):
        cv.badge(b[2] - 44, b[1] + 26, "عتاد هانتر", PURPLE, max(11, w * 0.055))


def gacha_pack_card(count: int = 1, title: str = "جاري السحب...", emoji: str = "🃏") -> bytes:
    cv = Canvas(1000, 560, "gold")
    cv.header(title, "", emoji=emoji)
    cv.rays(500, 310, 380, GOLD, 18, 40)
    n = 1 if count == 1 else min(5, count)
    for i in range(n):
        cx = 500 + (i - (n - 1) / 2) * (110 if n > 1 else 0)
        w, h = (250, 340) if n == 1 else (150, 230)
        cv.glow(cx, 320, 150, GOLD, 120)
        cv.panel((cx - w / 2, 320 - h / 2, cx + w / 2, 320 + h / 2), 22, fill=(40, 20, 80, 240), outline=_a(GOLD, 255), width=3)
        cv.panel((cx - w / 2 + 10, 320 - h / 2 + 10, cx + w / 2 - 10, 320 + h / 2 - 10), 16, fill=(0, 0, 0, 0), outline=_a(GOLD, 120), shadow=False)
        cv.text(cx, 320, "؟", 110 if n == 1 else 70, GOLD, "m", "black")
    return cv.finish()


def _pity_bar(cv: Canvas, pity: int, total: int | None = None, label: str = "ملحمي أو أعلى مضمون") -> None:
    total = total or cd.SUMMON_PITY
    y = cv.h - 38
    r, w = cv.w - 45, cv.w
    cv.text(r, y, "الضمان", 16, MUTED, "r", "regular", shadow=False)
    cv.bar((w * 0.38, y - 9, w * 0.88, y + 9), pity / max(1, total - 1), (190, 96, 255), (255, 184, 40))
    cv.text(w * 0.63, y, f"{pity} / {total - 1}", 12, WHITE, "m", "bold", shadow=False)
    cv.text(w * 0.36, y, label, 14, MUTED, "r", "regular", shadow=False)


def gacha_result_card(items: list[dict], pity: int, pity_limit: int, spent: str, best: int, title: str = "نتيجة السحب",
                      emoji: str = "🃏", pity_label: str = "ملحمي أو أعلى مضمون") -> bytes:
    """نتيجة سحب فورية (بدون انتظار) ببطاقات كبيرة: واحدة بحجم ضخم أو حتى 10 في شبكة 5×2 عريضة."""
    n = len(items)
    theme = "gold" if best >= 2 else "blue"
    if n == 1:
        cv = Canvas(1100, 1080, theme)
        cv.header(title, spent, emoji=emoji)
        _gacha_card(cv, 550, 560, 560, 780, items[0])
    else:
        rows = math.ceil(n / 5)
        cw, ch, gap = 270, 380, 18
        cv = Canvas(1500, 190 + rows * (ch + gap) + 90, theme)
        cv.header(f"{title} ×{n}", spent, emoji=emoji)
        for i, it in enumerate(items):
            row, k = divmod(i, 5)
            in_row = min(5, n - row * 5)
            x0 = cv.w / 2 + (in_row * (cw + gap) - gap) / 2 - (k + 1) * cw - k * gap
            _gacha_card(cv, x0 + cw / 2, 190 + row * (ch + gap) + ch / 2, cw, ch, it)
    _pity_bar(cv, pity, pity_limit, pity_label)
    return cv.finish()


# ───────────────────────── النين ─────────────────────────
def nen_card(key: str, info: dict, art: bytes | None, title: str = "اختبار الكأس والورقة", rerolled: bool = False,
             show_affinity: bool = True) -> bytes:
    col = NEN_COL[key]
    cv = Canvas(1000, 660, "blue")
    cv.cover(load_image(art), (24, 24, 976, 210), 24, dark=0.45, fallback_color=col, emoji="🌊")
    cv.fade_bottom((24, 110, 976, 210), (10, 14, 40), 220)
    cv.text(956, 62, title, 38, WHITE, "r", "black")
    cv.text(956, 112, info["water"], 24, _lighten(col, 0.5), "r", "bold")
    cv.panel((24, 24, 976, 210), 24, fill=(0, 0, 0, 0), outline=_a(col, 200), width=2.5, shadow=False)
    nen_hexagon(cv, 270, 425, 135, key)
    cv.panel((520, 235, 970, 620), 22, fill=_a(_darken(col, 0.75), 190), outline=_a(col, 200), width=2.5)
    cv.circle_image(None, 905, 300, 36, col, fallback=NEN_EMOJI[key], ring_w=3)
    cv.text(850, 290, "فئتك", 17, MUTED, "r", "regular", shadow=False)
    cv.text(850, 322, NEN_AR[key], 34, WHITE, "r", "black")
    cv.line((545, 360), (945, 360), _a(col, 120), 1.5)
    cv.text(945, 392, "المهارة", 17, MUTED, "r", "regular", shadow=False)
    cv.text(945, 428, info["skill"], 28, _lighten(col, 0.5), "r", "black")
    y = 470
    for ln in sh.wrap(sh.get_font("regular", 22 * cv.s), info["desc"], 380 * cv.s)[:3]:
        cv.text(945, y, ln, 21, WHITE, "r", "regular", shadow=False)
        y += 30
    chip(cv, 945, 585, "🔷", f"تكلفة {info['cost']} طاقة", BLUE, 17)
    if show_affinity:
        cv.text(270, 642, "كل فئة تتفوق على التي تليها في الدورة (+25%)", 15, MUTED, "m", "regular", shadow=False)
    if rerolled:
        cv.badge(120, 250, "إعادة اختبار", ORANGE, 15)
    return cv.finish()


# ───────────────────────── البرج ─────────────────────────
def tower_card(floor: int, max_floor: int, tier: str, enemy: dict, rewards: tuple[int, int], art: bytes | None, hp_pct: tuple[int, int],
               unlock_floor: int = 50, master_floor: int = 200, is_shadow: bool = False, subtitle: str = "",
               bg: bytes | None = None) -> bytes:
    cv = Canvas(1000, 600, "default")
    cv.backdrop(load_image(bg), 0.6)
    cv.header(f"الطابق {floor}", f"{tier}" + (f" · {subtitle}" if subtitle else ""), emoji="🏰")
    cv.cover(load_image(art), (40, 130, 360, 420), 22, dark=0.25, fallback_color=RED, emoji=enemy.get("emoji", "👹"))
    cv.fade_bottom((40, 320, 360, 420), (10, 10, 30), 230)
    cv.panel((40, 130, 360, 420), 22, fill=(0, 0, 0, 0), outline=_a(RED, 200), width=2.5, shadow=False)
    cv.fit_text(200, 392, enemy["name"], 290, 24, fill=WHITE, align="m", weight="black")
    if enemy.get("nen"):
        cv.icon(NEN_EMOJI[enemy["nen"]], 320, 172, 40)
    if is_shadow:
        cv.badge(100, 160, "ظل لاعب", PURPLE, 14)
    stat_tile(cv, (390, 130, 640, 190), "❤️", "الصحة", str(enemy["hp"]), GREEN)
    stat_tile(cv, (660, 130, 960, 190), "⚔️", "الهجوم", str(enemy["atk"]), RED)
    stat_tile(cv, (390, 205, 640, 265), "🛡️", "الدفاع", str(enemy["defense"]), BLUE)
    stat_tile(cv, (660, 205, 960, 265), "💨", "السرعة", str(enemy["speed"]), CYAN)
    cv.text(955, 305, "المكافأة", 18, MUTED, "r", "regular", shadow=False)
    chip(cv, 955, 345, "💰", f"~{rewards[0]}", GOLD, 21)
    chip(cv, 740, 345, "✨", f"{rewards[1]} XP", PURPLE, 21)
    cv.text(955, 400, "صحتك", 18, MUTED, "r", "regular", shadow=False)
    cv.bar((390, 410, 800, 432), hp_pct[0] / max(1, hp_pct[1]), (80, 220, 120), (40, 150, 90))
    cv.text(595, 421, f"{hp_pct[0]} / {hp_pct[1]}", 14, WHITE, "m", "bold", shadow=False)
    # شريط البرج
    ty = 500
    cv.text(955, ty - 36, "تقدّمك في البرج", 18, MUTED, "r", "regular", shadow=False)
    x0, x1 = 60, 940
    cv.bar((x0, ty - 10, x1, ty + 10), floor / max_floor, (255, 200, 80), (255, 120, 40))
    for mf, em, lab in ((unlock_floor, "🌀", "النين"), (master_floor, "🏯", "الأسياد"), (max_floor, "👑", "القمة")):
        px = x1 - (x1 - x0) * (mf / max_floor)
        cv.icon(em, px, ty - 34, 26)
        cv.text(px, ty + 34, f"{mf} · {lab}", 14, MUTED, "m", "regular", shadow=False)
    px = x1 - (x1 - x0) * (floor / max_floor)
    cv.ellipse(px, ty, 15, fill=WHITE, outline=GOLD, width=4)
    return cv.finish()


# ───────────────────────── الزعيم ─────────────────────────
def boss_card(boss: dict, art: bytes | None, top: list[dict], me: dict | None, time_left: str, attempts_left: int, status_note: str = "") -> bytes:
    cv = Canvas(1000, 720, "boss")
    cv.cover(load_image(art), (24, 24, 976, 280), 26, dark=0.35, fallback_color=RED, emoji=boss.get("emoji", "👹"))
    cv.fade_bottom((24, 150, 976, 280), (20, 6, 20), 235)
    cv.panel((24, 24, 976, 280), 26, fill=(0, 0, 0, 0), outline=_a(RED, 220), width=3, shadow=False)
    cv.badge(880, 62, "زعيم الأسبوع", RED, 17, 150)
    cv.text(956, 190, boss["name"], 50, WHITE, "r", "black")
    cv.text(956, 242, boss["title"], 22, (255, 200, 200), "r", "bold")
    frac = boss["hp"] / max(1, boss["max_hp"])
    cv.bar((44, 300, 956, 340), frac, (255, 80, 80) if frac < 0.3 else (255, 120, 60), (200, 30, 50), radius=14)
    cv.text(500, 320, f"{boss['hp']:,} / {boss['max_hp']:,}", 22, WHITE, "m", "black")
    if frac <= 0:
        cv.icon("💀", 930, 320, 32)
    chip(cv, 956, 385, "⏳", time_left, ORANGE, 19)
    chip(cv, 640, 385, "🎯", f"محاولاتك: {attempts_left}", CYAN, 19)
    if status_note:
        cv.text(44, 385, status_note, 18, GOLD, "l", "bold")
    cv.text(956, 450, "أعلى المصابين", 24, GOLD, "r", "black")
    medals = ["🥇", "🥈", "🥉"]
    for i, t in enumerate(top[:5]):
        y = 495 + i * 42
        cv.panel((300, y - 18, 956, y + 18), 12, fill=(255, 255, 255, 14), outline=None, shadow=False)
        if i < 3:
            cv.icon(medals[i], 928, y, 26)
        else:
            cv.text(928, y, str(i + 1), 18, MUTED, "m", "bold", shadow=False)
        cv.fit_text(895, y, t["name"], 330, 19, fill=WHITE, align="r", weight="bold", shadow=False)
        cv.text(320, y, f"{t['damage']:,}", 19, GOLD, "l", "black", shadow=False)
    if not top:
        cv.text(628, 520, "لم يضرب أحد بعد. كن الأول!", 20, MUTED, "m", "regular", shadow=False)
    # بطاقتي
    cv.panel((24, 520 - 24, 280, 690), 18, fill=_a(_darken(BLUE, 0.7), 190), outline=_a(BLUE, 180))
    cv.text(262, 520, "ضررك", 17, MUTED, "r", "regular", shadow=False)
    cv.text(262, 560, f"{me['damage']:,}" if me else "0", 34, WHITE, "r", "black")
    cv.text(262, 606, f"المركز {me['rank']}" if me and me.get("rank") else "لم تشارك", 19, GOLD, "r", "bold")
    cv.text(262, 645, f"ضربات: {me['hits']}" if me else "اضغط هاجم", 16, MUTED, "r", "regular", shadow=False)
    return cv.finish()


# ───────────────────────── الترتيب والعصابة والحرب ─────────────────────────
def leaderboard_card(title: str, emoji: str, rows: list[dict], unit: str = "") -> bytes:
    n = max(0, len(rows) - 3)
    cv = Canvas(1000, 540 + n * 52, "gold")
    cv.header(title, "", emoji=emoji)
    heights = {0: 200, 1: 150, 2: 120}
    pos = {0: 500, 1: 760, 2: 240}
    cols = {0: GOLD, 1: (200, 210, 225), 2: (205, 130, 70)}
    medals = ["🥇", "🥈", "🥉"]
    base = 410
    for i in range(min(3, len(rows))):
        r = rows[i]
        cx, hh = pos[i], heights[i]
        cv.glow(cx, base - hh - 70, 110, cols[i], 120)
        cv.circle_image(load_image(r.get("avatar")), cx, base - hh - 60, 44 if i == 0 else 36, cols[i], fallback="🧑", ring_w=4)
        cv.panel((cx - 108, base - hh, cx + 108, base), 14, fill=_a(_darken(cols[i], 0.6), 220), outline=_a(cols[i], 230), width=2)
        cv.icon(medals[i], cx, base - hh + 34, 46)
        cv.fit_text(cx, base - hh + 76, r["name"], 200, 21, fill=WHITE, align="m", weight="black")
        cv.text(cx, base - hh + 106, f"{r['value']}{unit}", 19, cols[i], "m", "black")
        if hh >= 150:
            cv.text(cx, base - hh + 134, r.get("extra", ""), 14, MUTED, "m", "regular", shadow=False)
    for j, r in enumerate(rows[3:]):
        y = 452 + j * 52
        cv.panel((60, y - 21, 940, y + 21), 12, fill=(255, 255, 255, 16), outline=(255, 255, 255, 40), shadow=False)
        cv.text(912, y, str(j + 4), 20, MUTED, "m", "black", shadow=False)
        cv.fit_text(880, y, r["name"], 420, 21, fill=WHITE, align="r", weight="bold", shadow=False)
        cv.text(80, y, f"{r['value']}{unit}", 20, GOLD, "l", "black", shadow=False)
        cv.text(300, y, r.get("extra", ""), 15, MUTED, "l", "regular", shadow=False)
    if not rows:
        cv.text(500, 300, "لا يوجد لاعبون بعد", 26, MUTED, "m")
    return cv.finish()


def guild_card(info: dict, my_id: int) -> bytes:
    members = info["members"]
    cv = Canvas(1000, 330 + len(members) * 50, "default")
    cv.header(info["guild_name"], f"نقاط العصابة {info['score']}  ·  {len(members)} / {info['max_members']} عضو", emoji="🏰")
    if info.get("war"):
        cv.badge(160, 62, info["war"], RED, 16)
    cv.text(955, 150, "الأعضاء", 22, GOLD, "r", "black")
    for i, m in enumerate(members):
        y = 200 + i * 50
        me = m["user_id"] == my_id
        cv.panel((50, y - 21, 950, y + 21), 12, fill=_a(BLUE if me else (255, 255, 255), 40 if me else 14), outline=_a(GOLD, 150) if me else None, shadow=False)
        cv.icon("👑" if m["user_id"] == info["leader_id"] else "🧑", 925, y, 26)
        cv.fit_text(890, y, m["username"] or str(m["user_id"]), 340, 20, fill=WHITE, align="r", weight="bold", shadow=False)
        cv.text(520, y, f"المستوى {m['level']}", 18, MUTED, "r", "regular", shadow=False)
        cv.text(300, y, f"الطابق {m['floor']}", 18, WHITE, "r", "bold", shadow=False)
        if m.get("war_points") is not None:
            cv.text(100, y, f"{m['war_points']} ⚔️", 18, GOLD, "l", "black", shadow=False)
    return cv.finish()


def war_card(w: dict) -> bytes:
    cv = Canvas(1000, 520, "boss")
    cv.header("حرب العصابات", w["time_left"], emoji="⚔️")
    total = max(1, w["score_a"] + w["score_b"])
    for side, x, col in (("a", 740, BLUE), ("b", 260, RED)):
        cv.panel((x - 210, 130, x + 210, 330), 22, fill=_a(_darken(col, 0.7), 190), outline=_a(col, 200), width=2.5)
        cv.icon("🏰", x, 190, 64)
        cv.fit_text(x, 252, w[f"name_{side}"], 380, 28, fill=WHITE, align="m", weight="black")
        cv.text(x, 300, str(w[f"score_{side}"]), 36, GOLD, "m", "black")
    cv.glow(500, 230, 80, (255, 220, 120), 100)
    cv.text(500, 235, "VS", 46, GOLD, "m", "black")
    cv.bar((60, 370, 940, 400), w["score_a"] / total, (90, 170, 255), (50, 100, 230), back=_a(RED, 200), radius=14)
    cv.text(500, 385, f"{w['score_a']}  ‹ النقاط ›  {w['score_b']}", 17, WHITE, "m", "bold", shadow=False)
    cv.text(500, 440, w.get("note", ""), 20, WHITE, "m", "bold")
    cv.text(500, 480, "كل انتصار في البرج = 2 نقطة · كل ضربة زعيم = 1 نقطة", 15, MUTED, "m", "regular", shadow=False)
    return cv.finish()


# ───────────────────────── المهام ─────────────────────────
def missions_card(rows: list[dict], bonus_text: str, all_done: bool, reset_in: str) -> bytes:
    cv = Canvas(1000, 250 + len(rows) * 120 + 70, "blue")
    cv.header("مهام الصيّاد", f"تتجدد بعد {reset_in}", emoji="📋")
    for i, m in enumerate(rows):
        y = 170 + i * 120
        done = m["progress"] >= m["target"]
        col = GREEN if m["claimed"] else GOLD if done else BLUE
        cv.panel((40, y, 960, y + 104), 18, fill=_a(_darken(col, 0.72), 190), outline=_a(col, 200), width=2)
        cv.icon(m["emoji"], 918, y + 52, 52)
        cv.text(870, y + 30, m["title"], 24, WHITE, "r", "black")
        cv.bar((380, y + 56, 870, y + 78), m["progress"] / max(1, m["target"]), _lighten(col, 0.2), col)
        cv.text(625, y + 67, f"{min(m['progress'], m['target'])} / {m['target']}", 14, WHITE, "m", "bold", shadow=False)
        chip(cv, 350, y + 52, "💰", str(m["gold"]), GOLD, 16, "r")
        if m["gems"]:
            chip(cv, 200, y + 52, "💎", str(m["gems"]), CYAN, 16, "r")
        if m["claimed"]:
            cv.icon("✅", 70, y + 52, 40)
        elif done:
            cv.icon("🎁", 70, y + 52, 40)
    cv.text(500, cv.h - 32, bonus_text, 19, GOLD if all_done else MUTED, "m", "bold")
    return cv.finish()


# ───────────────────────── العملات (السجل) ─────────────────────────
def ledger_card(title: str, subtitle: str, rows: list[dict], gold: int, gems: int) -> bytes:
    cv = Canvas(1000, 260 + max(1, len(rows)) * 44 + 40, "blue")
    cv.header(title, subtitle, emoji="📊")
    chip(cv, 955, 150, "💰", f"{gold:,}", GOLD, 20)
    chip(cv, 700, 150, "💎", f"{gems:,}", CYAN, 20)
    cv.text(955, 210, "العملية", 16, MUTED, "r", "regular", shadow=False)
    cv.text(440, 210, "المبلغ", 16, MUTED, "r", "regular", shadow=False)
    cv.text(260, 210, "الرصيد بعدها", 16, MUTED, "r", "regular", shadow=False)
    cv.text(60, 210, "الوقت", 16, MUTED, "l", "regular", shadow=False)
    for i, r in enumerate(rows):
        y = 252 + i * 44
        cv.panel((40, y - 18, 960, y + 18), 10, fill=(255, 255, 255, 12 + 6 * (i % 2)), outline=None, shadow=False)
        cv.icon("💰" if r["currency"] == "gold" else "💎", 932, y, 24)
        cv.fit_text(900, y, r["label"], 300, 19, fill=WHITE, align="r", weight="bold", shadow=False)
        amt = r["amount"]
        cv.text(440, y, f"{'+' if amt > 0 else ''}{amt:,}", 20, GREEN if amt > 0 else RED, "r", "black", shadow=False)
        cv.text(260, y, f"{r['balance']:,}", 17, MUTED, "r", "regular", shadow=False)
        cv.text(60, y, r["when"], 14, MUTED, "l", "regular", shadow=False)
    if not rows:
        cv.text(500, 280, "لا توجد عمليات مسجّلة", 22, MUTED, "m")
    return cv.finish()


def economy_card(title: str, period: str, currency: str, circulating: int, sources: list[tuple[str, int]], sinks: list[tuple[str, int]]) -> bytes:
    n = max(len(sources), len(sinks), 1)
    cv = Canvas(1000, 340 + n * 50 + 30, "gold")
    cv.header(title, period, emoji="💰" if currency == "gold" else "💎")
    chip(cv, 955, 150, "🏦", f"في التداول: {circulating:,}", GOLD if currency == "gold" else CYAN, 20)
    top = max([v for _, v in sources + sinks] + [1])
    for side, items, x_right, col, head in (("in", sources, 960, GREEN, "من أين تدخل ➕"), ("out", sinks, 490, RED, "أين تذهب ➖")):
        cv.text(x_right, 215, head, 22, col, "r", "black")
        tot = sum(v for _, v in items)
        cv.text(x_right - 470 + 20, 215, f"{tot:,}", 20, WHITE, "l", "black")
        for i, (lab, val) in enumerate(items):
            y = 262 + i * 50
            cv.fit_text(x_right, y - 12, lab, 200, 17, fill=WHITE, align="r", weight="bold", shadow=False)
            cv.bar((x_right - 440, y + 2, x_right - 20, y + 16), val / top, _lighten(col, 0.2), col)
            cv.text(x_right - 450, y - 12, f"{val:,}", 15, MUTED, "l", "regular", shadow=False)
        if not items:
            cv.text(x_right - 235, 290, "لا شيء", 18, MUTED, "m", "regular", shadow=False)
    return cv.finish()


# ───────────────────────── بطاقة عامة + الشرح ─────────────────────────
def list_card(title: str, subtitle: str, rows: list[tuple[str, str, str]], emoji: str = "✨", theme: str = "default", art: bytes | None = None,
              lines: list[str] | None = None, chips: list[tuple[str, str]] | None = None, footer: str = "", art_emoji: str | None = None) -> bytes:
    h = 170 + (130 if art is not None or art_emoji else 0) + len(rows) * 62 + len(lines or []) * 34 + (70 if chips else 0) + 50
    cv = Canvas(1000, h, theme)
    cv.header(title, subtitle, emoji=emoji)
    y = 130
    if art is not None or art_emoji:
        cv.cover(load_image(art), (40, y, 960, y + 120), 20, dark=0.4, emoji=art_emoji)
        y += 140
    for ln in lines or []:
        cv.text(955, y + 10, ln, 22, WHITE, "r", "bold")
        y += 34
    if lines:
        y += 8
    for e, label, val in rows:
        cv.panel((40, y, 960, y + 52), 14, fill=(255, 255, 255, 18), outline=(255, 255, 255, 45), shadow=False)
        cv.icon(e, 925, y + 26, 30)
        cv.text(885, y + 26, label, 21, MUTED, "r", "bold", shadow=False)
        cv.text(70, y + 26, val, 22, WHITE, "l", "black", shadow=False)
        y += 62
    if chips:
        x = 955
        y += 18
        for e, t in chips:
            x -= chip(cv, x, y + 10, e, t, GOLD if e == "💰" else CYAN if e == "💎" else GREEN, 20) + 14
    if footer:
        cv.footer(footer)
    return cv.finish()


def help_card(title: str, emoji: str, intro: str, entries: list[tuple[str, str]], page: int, pages: int, tips: list[str] | None = None) -> bytes:
    rows = math.ceil(len(entries) / 2)
    intro_lines = sh.wrap(sh.get_font("regular", 22 * 2), intro, 880 * 2)
    h = 190 + len(intro_lines) * 32 + rows * 74 + (len(tips or []) * 32 + 30 if tips else 0) + 56
    cv = Canvas(1000, h, "blue")
    cv.header(title, f"شرح اللعبة · {page} من {pages}", emoji=emoji)
    y = 138
    for ln in intro_lines:
        cv.text(955, y, ln, 22, WHITE, "r", "regular", shadow=False)
        y += 32
    y += 14
    for i, (cmd, desc) in enumerate(entries):
        col, row = i % 2, i // 2
        x1 = 960 - col * 470
        yy = y + row * 74
        cv.panel((x1 - 450, yy, x1, yy + 64), 14, fill=(255, 255, 255, 18), outline=_a(cv.accent, 120), shadow=False)
        cv.text(x1 - 14, yy + 22, cmd, 22, GOLD, "r", "black")
        cv.fit_text(x1 - 14, yy + 48, desc, 420, 16, fill=(215, 222, 240), align="r", weight="regular", shadow=False)
    y += rows * 74 + 8
    for t in tips or []:
        cv.text(955, y + 14, "💡 " + t, 19, (255, 230, 150), "r", "bold", shadow=False)
        y += 32
    return cv.finish()


# ═════════════════════════ بطاقات الشخصيات: الاستدعاء والألبوم والفريق ═════════════════════════
# الصور تأتي جاهزة كبايتات {مفتاح البطاقة: صورة} من anime_images (هذا الملف لا يستخدم الشبكة أبداً).
# إن لم تتوفر صورة تُرسم خلفية متدرجة بحرف الاسم (مؤقتاً حتى تُجلب الصورة).
CARD_STAT_COL = {"atk": (255, 150, 90), "def": (96, 170, 255), "hp": (255, 96, 120), "speed": (255, 220, 90)}
ALBUM_PER_PAGE = 8


def _fmt(n) -> str:
    return f"{int(n):,}"


def _art_images(arts: dict[str, bytes] | None) -> dict[str, Image.Image]:
    return {k: im for k, b in (arts or {}).items() if (im := load_image(b)) is not None}


def _star_pts(cx: float, cy: float, r_out: float, r_in: float) -> list[tuple[float, float]]:
    return [(cx + (r_out if i % 2 == 0 else r_in) * math.cos(-math.pi / 2 + i * math.pi / 5),
             cy + (r_out if i % 2 == 0 else r_in) * math.sin(-math.pi / 2 + i * math.pi / 5)) for i in range(10)]


def _stars_row(cv: Canvas, cx: float, cy: float, n: int, total: int = cd.MAX_STARS, size: float = 11, col: tuple = GOLD) -> None:
    gap = size * 2.35
    x0 = cx - gap * (total - 1) / 2
    for i in range(total):
        pts = _star_pts(x0 + i * gap, cy, size, size * 0.45)
        if i < n:
            cv.polygon(pts, _a(col, 255), _a(_darken(col, 0.45), 220), 1)
        else:
            cv.polygon(pts, (255, 255, 255, 30), (255, 255, 255, 60), 1)


def card_face(cv: Canvas, x: float, y: float, w: float, h: float, card: dict, art: Image.Image | None = None, stars: int = 0,
              owned: bool = True, glow: bool = False, tag: str | None = None) -> None:
    """وجه بطاقة بنسبة ≈3:4. الإطار بلون الندرة، الصورة بالأعلى، لوحة الاسم والنجوم بالأسفل."""
    col = RARITY_COL[card["r"]] if owned else (110, 112, 140)
    small = w < 150
    pad = 5 if small else 7
    plate_h = h * (0.27 if small else 0.25)
    if glow and owned:
        cv.glow(x + w / 2, y + h / 2, max(w, h) * 0.8, col, 110)
    cv.panel((x, y, x + w, y + h), 16, fill=_a(_darken(col, 0.5), 255), outline=_a(_lighten(col, 0.25), 255),
             width=2.5 if (owned and card["r"] > 1) else 1.8)
    box = (x + pad, y + pad, x + w - pad, y + h - plate_h)
    cv.cover(art if owned else None, box, 12, dark=0.0 if owned else 0.45, fallback_color=col)
    if not owned or art is None:       # بديل أنيق إلى أن تتوفر الصورة (أو للبطاقة غير المملوكة)
        letter = sh.clean(card["name"])[:1] if owned else "؟"
        cv.text((box[0] + box[2]) / 2, (box[1] + box[3]) / 2, letter or "؟", (box[3] - box[1]) * 0.42,
                _a(_lighten(col, 0.4), 215), "m", "black")
    if owned:
        fs = 11 if small else 13
        rar = cd.RARITY_AR[card["r"]]
        bw = cv.text_width(rar, fs) + 22
        cv.badge(x + w - pad - 6 - bw / 2, y + pad + (14 if small else 16), rar, col, fs)
        cv.ellipse(x + pad + 18, y + pad + 18, 15 if small else 17, fill=(8, 6, 22, 190), outline=_a(col, 200), width=1.5)
        cv.icon(ROLE_EMOJI[card["role"]], x + pad + 18, y + pad + 18, 20 if small else 24)
    py0 = y + h - plate_h
    cv.panel((x + pad, py0 + 2, x + w - pad, y + h - pad), 10, fill=(8, 6, 22, 215), outline=_a(col, 120), width=1, shadow=False)
    cv.fit_text(x + w / 2, py0 + plate_h * 0.36, sh.clean(card["name"]) if owned else "؟؟؟", w - 2 * pad - 10,
                17 if small else 22, fill=WHITE, align="m", weight="black")
    if owned:
        _stars_row(cv, x + w / 2, py0 + plate_h * 0.74, stars, size=6.5 if small else 9, col=_lighten(col, 0.45))
    if tag:
        cv.badge(x + w / 2, y + h - plate_h - 14, tag, GREEN if tag == "جديدة" else GOLD, 12)


def _status_tag(r: dict) -> str | None:
    if r.get("is_new"):
        return "جديدة"
    if r.get("refund"):
        return f"+{_fmt(r['refund'])} ذهب"
    if r.get("star_up"):
        return "نجمة ↑"
    return None


def summon_result_card(results: list[dict], pity: int, currency: str, cost: int, owner: str,
                       arts: dict[str, bytes] | None = None) -> bytes:
    imgs = _art_images(arts)
    best = max(r["r"] for r in results)
    col = RARITY_COL[best]
    theme = "gold" if best >= 2 else "blue"
    spent = f"{_fmt(cost)} {'ذهب' if currency == 'gold' else 'جوهرة'}"
    if len(results) == 1:
        r = results[0]
        c = cd.CARDS[r["key"]]
        cv = Canvas(1100, 1230, theme)
        cv.header(["استدعاء عادي", "استدعاء جيد", "بطل ملحمي!", "بطل أسطوري!!"][best], f"{owner}  ·  {spent}", emoji="🎴")
        cv.glow(550, 470, 520, col, 130)
        if best >= 2:
            cv.rays(550, 470, 700, col, 22, 45 if best == 3 else 30)
        card_face(cv, 300, 130, 500, 660, c, imgs.get(r["key"]), r["stars"], glow=True)
        cv.fit_text(550, 850, sh.clean(c["name"]), 900, 50, fill=WHITE, align="m", weight="black")
        cv.fit_text(550, 904, c["skill"], 900, 28, fill=_lighten(col, 0.5), align="m", weight="bold")
        role = cd.ROLES[c["role"]]
        tag = _status_tag(r)
        text = f"{role['ar']}  ·  {cd.RARITY_AR[c['r']]}" + (f"  ·  {tag}" if tag else "")
        wchip = cv.text_width(text, 22, "black") + 22 * 2.7
        chip(cv, 550 + wchip / 2, 972, ROLE_EMOJI[c["role"]], text, col, 22)
        cv.text(550, 1030, role["desc"], 21, MUTED, "m", "regular", shadow=False)
    else:
        n = len(results)
        rows = math.ceil(n / 5)
        cw, ch, gap = 270, 360, 18
        cv = Canvas(1500, 170 + rows * (ch + gap + 16) + 110, theme)
        cv.header(f"استدعاء ×{n}", f"{owner}  ·  أفضل نتيجة: {cd.RARITY_AR[best]}  ·  {spent}", emoji="🎴")
        cv.glow(cv.w / 2, 420, 760, col, 70)
        for i, r in enumerate(results):
            row, k = divmod(i, 5)
            in_row = min(5, n - row * 5)
            x0 = cv.w / 2 + (in_row * (cw + gap) - gap) / 2 - (k + 1) * cw - k * gap
            card_face(cv, x0, 170 + row * (ch + gap + 16), cw, ch, cd.CARDS[r["key"]], imgs.get(r["key"]), r["stars"],
                      glow=r["r"] >= 2, tag=_status_tag(r))
        refund = sum(x.get("refund", 0) for x in results)
        if refund:
            chip(cv, cv.w - 60, cv.h - 84, "💰", f"نسخ زائدة تحوّلت إلى {_fmt(refund)} ذهب", GOLD, 15)
    _pity_bar(cv, pity)
    return cv.finish()


def _effect_text(c: dict, stars: int) -> str:
    r, pw, role = c["r"], 1 + 0.10 * stars, c["role"]
    if role == "striker":
        return f"ضربة بقوة {cd.ASSIST_STRIKE[r] * pw:.2f} ضعف من هجومك"
    if role == "tank":
        return f"درع يمتص 70% من الضرر لـ {cd.ASSIST_SHIELD_TURNS[r]} هجمات"
    if role == "healer":
        return f"يعالجك {round(cd.ASSIST_HEAL[r] * pw * 100)}% من صحتك القصوى"
    return f"شلل دور كامل باحتمال {min(100, round(cd.ASSIST_STUN[r] * pw * 100))}% (أو ضربة خفيفة)"


def card_detail_card(card: dict, art: bytes | None, copies: int, owner: str = "") -> bytes:
    owned = copies > 0
    stars = cd.stars_for(copies)
    col = RARITY_COL[card["r"]]
    role = cd.ROLES[card["role"]]
    cv = Canvas(1000, 700, "gold" if card["r"] >= 2 else "blue")
    cv.header(sh.clean(card["name"]), card["en"], emoji=ROLE_EMOJI[card["role"]])
    cv.glow(220, 370, 320, col, 110)
    card_face(cv, 40, 130, 360, 480, card, load_image(art), stars, owned=True, glow=True)
    x0, x1 = 430, 960
    cv.panel((x0, 130, x1, 650), 20, fill=(0, 0, 0, 90), outline=_a(col, 160), width=2)
    x = x1 - 22
    x -= chip(cv, x, 170, ROLE_EMOJI[card["role"]], role["ar"], col, 16) + 8
    x -= chip(cv, x, 170, "⭐", cd.RARITY_AR[card["r"]], col, 16) + 8
    if card["nen"]:
        chip(cv, x, 170, NEN_EMOJI[card["nen"]], NEN_AR[card["nen"]], NEN_COL.get(card["nen"], col), 16)
    st = cd.card_stats(card["key"], stars)
    top = {"atk": 80, "def": 40, "hp": 260, "speed": 25}
    for i, (k, lab) in enumerate([("atk", "الهجوم"), ("def", "الدفاع"), ("hp", "الصحة"), ("speed", "السرعة")]):
        y = 232 + i * 44
        c = CARD_STAT_COL[k]
        cv.text(x1 - 22, y, lab, 21, WHITE, "r", "bold")
        cv.bar((x0 + 100, y - 10, x1 - 130, y + 10), min(1.0, st[k] / top[k]), c, _darken(c, 0.25))
        cv.text(x0 + 84, y, f"+{st[k]}", 21, _lighten(c, 0.4), "r", "black")
    cv.panel((x0 + 20, 422, x1 - 20, 520), 14, fill=(255, 255, 255, 16), outline=_a(col, 120), width=1.2, shadow=False)
    cv.text(x1 - 40, 450, f"نداء الفريق:  {card['skill']}", 22, _lighten(col, 0.5), "r", "black")
    cv.fit_text(x1 - 40, 490, _effect_text(card, stars) + f"  ·  كل {cd.ASSIST_COOLDOWN} جولات", x1 - x0 - 80, 18,
                fill=WHITE, align="r", weight="regular", shadow=False)
    if owned:
        need = "اكتملت النجوم — النسخ الزائدة تتحول لذهب" if stars >= cd.MAX_STARS else "النسخة التالية تمنحك نجمة تزيد إحصائيات البطاقة 12%"
        _stars_row(cv, x1 - 150, 556, stars, size=13, col=_lighten(col, 0.45))
        cv.text(x1 - 290, 556, f"عندك {copies} نسخة", 20, WHITE, "r", "bold")
        cv.fit_text(x1 - 30, 608, need, x1 - x0 - 60, 16, fill=MUTED, align="r", weight="regular", shadow=False)
    else:
        cv.text(x1 - 30, 560, "لا تملك هذه البطاقة بعد", 22, (255, 140, 150), "r", "bold")
        cv.text(x1 - 30, 604, f"احتمال استدعاء بطاقة {cd.RARITY_AR[card['r']]}: {cd.drop_rate(card['r'])}  ·  اكتب «استدعاء»", 16, MUTED, "r", "regular", shadow=False)
    return cv.finish()


def album_pages() -> int:
    return (len(cd.ORDER) + ALBUM_PER_PAGE - 1) // ALBUM_PER_PAGE


def album_card(owned: dict[str, int], page: int, owner: str, arts: dict[str, bytes] | None = None,
               team: list[str] | None = None) -> bytes:
    imgs = _art_images(arts)
    team = team or []
    pages = album_pages()
    page = max(0, min(pages - 1, page))
    keys = cd.ORDER[page * ALBUM_PER_PAGE:(page + 1) * ALBUM_PER_PAGE]
    cv = Canvas(1000, 800, "default")
    cv.header("ألبوم الأبطال", f"{owner}  ·  جمعت {len(owned)} من {len(cd.CARDS)}", emoji="🎴")
    cv.badge(130, 62, f"صفحة {page + 1} من {pages}", cv.accent, 16)
    cw, ch, gap = 218, 290, 18
    for i, key in enumerate(keys):
        row, k = divmod(i, 4)
        c = cd.CARDS[key]
        cp = owned.get(key, 0)
        card_face(cv, 30 + (3 - k) * (cw + gap), 128 + row * (ch + gap + 6), cw, ch, c, imgs.get(key), cd.stars_for(cp),
                  owned=cp > 0, glow=cp > 0 and c["r"] >= 2, tag="في الفريق" if key in team else None)
    cv.footer("اكتب «بطاقة غون» لتفاصيل أي بطاقة  ·  «فريق» لتشكيل فريقك")
    return cv.finish()


def team_card(members: list[dict], bonus: dict, owner: str, arts: dict[str, bytes] | None = None) -> bytes:
    """members: [{key, stars}] حتى 3."""
    imgs = _art_images(arts)
    cv = Canvas(1000, 770, "blue")
    cv.header("فريقك", f"{owner}  ·  يقاتل معك بسلبياته ونداء كل {cd.ASSIST_COOLDOWN} جولات", emoji="🎴")
    cw, ch = 290, 390
    for i in range(cd.TEAM_SIZE):
        x = 30 + (2 - i) * (cw + 25)
        if i < len(members):
            m = members[i]
            card_face(cv, x, 130, cw, ch, cd.CARDS[m["key"]], imgs.get(m["key"]), m["stars"], glow=True)
        else:
            cv.panel((x, 130, x + cw, 130 + ch), 18, fill=(255, 255, 255, 10), outline=(255, 255, 255, 50), width=2, shadow=False)
            cv.text(x + cw / 2, 130 + ch / 2 - 14, "خانة فارغة", 26, MUTED, "m", "bold", shadow=False)
            cv.text(x + cw / 2, 130 + ch / 2 + 22, "فريق غون كيلوا ...", 16, MUTED, "m", "regular", shadow=False)
    cv.panel((30, 546, 970, 736), 18, shadow=False)
    cv.text(950, 576, "مكافآت الفريق السلبية", 20, GOLD, "r", "black")
    x = 950
    for emoji, lab, key in (("⚔️", "هجوم", "atk"), ("🛡️", "دفاع", "def"), ("❤️", "صحة", "hp"), ("💨", "سرعة", "speed")):
        x -= chip(cv, x, 624, emoji, f"{lab} +{bonus.get(key, 0)}", CARD_STAT_COL[key], 17) + 10
    if members:
        parts = [f"{sh.clean(cd.CARDS[m['key']]['name'])}: {cd.ROLES[cd.CARDS[m['key']]['role']]['desc']}" for m in members]
        cv.fit_text(950, 690, "  ·  ".join(parts), 900, 15, fill=MUTED, align="r", weight="regular", shadow=False)
    else:
        cv.text(950, 690, "اختر أبطالك من ألبومك: فريق غون كيلوا ليورو", 17, MUTED, "r", "regular", shadow=False)
    return cv.finish()
