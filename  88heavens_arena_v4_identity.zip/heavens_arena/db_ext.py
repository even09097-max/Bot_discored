"""
دوال قاعدة البيانات الخاصة بالتحديث الكبير (تُدمج في Database عبر الوراثة):
شجرة النين · سحب العتاد والصناديق · سيطرة الطوابق وسجل الانتقام · العصابات · المواسم · السوق الأسود · المهام الأسبوعية · أوامر الإدارة.
"""
from __future__ import annotations

import random
import sqlite3
import time

import game as g
import hatsu as ht
from game import GameError

EXPIRE_STATES = ("open",)


def _now() -> float:
    return time.time()


class DatabaseExt:
    # يتوفر من Database: _run, _money, _bump, _bump_week, _user_with_totals, _take_floor, _week ...

    # ───────────── حضور اللاعب ─────────────
    async def touch(self, user_id: int) -> None:
        await self._run(lambda c: c.execute("UPDATE users SET last_seen = ? WHERE user_id = ?", (_now(), user_id)))

    async def is_online(self, user_id: int) -> bool:
        def fn(conn):
            r = conn.execute("SELECT last_seen FROM users WHERE user_id = ?", (user_id,)).fetchone()
            return bool(r and _now() - (r["last_seen"] or 0) <= g.ONLINE_WINDOW)
        return await self._run(fn)

    # ───────────── شجرة النين ─────────────
    async def tree_info(self, user_id: int) -> dict:
        def fn(conn):
            u = self._user_with_totals(conn, user_id)
            lv = u["tree_levels"]
            return {"levels": lv, "points": u["tree_pts"], "spent": ht.spent_points(lv), "effects": u["tree_effects"],
                    "nen": u["nen_type"], "floor": u["floor"]}
        return await self._run(fn)

    async def tree_upgrade(self, user_id: int, node: str) -> dict:
        def fn(conn):
            u = conn.execute("SELECT tree, tree_pts FROM users WHERE user_id = ?", (user_id,)).fetchone()
            lv = ht.parse_tree(u["tree"])
            ok, msg = ht.can_upgrade(lv, node, u["tree_pts"])
            if not ok:
                raise GameError(msg)
            cost = ht.node_cost(node, lv.get(node, 0))
            lv[node] = lv.get(node, 0) + 1
            conn.execute("UPDATE users SET tree = ?, tree_pts = tree_pts - ? WHERE user_id = ?", (ht.dump_tree(lv), cost, user_id))
            self._bump(conn, user_id, "tree")
            self._bump_week(conn, user_id, "tree", 1)
            return {"node": node, "level": lv[node], "cost": cost, "points": u["tree_pts"] - cost}
        return await self._run(fn)

    async def tree_respec(self, user_id: int) -> dict:
        def fn(conn):
            u = conn.execute("SELECT tree FROM users WHERE user_id = ?", (user_id,)).fetchone()
            lv = ht.parse_tree(u["tree"])
            if not lv:
                raise GameError("شجرتك فارغة أصلاً.")
            self._money(conn, user_id, "gems", -ht.TREE_RESPEC_GEMS, "tree_respec")
            back = ht.spent_points(lv)
            conn.execute("UPDATE users SET tree = '', tree_pts = tree_pts + ? WHERE user_id = ?", (back, user_id))
            return {"refunded": back, "cost": ht.TREE_RESPEC_GEMS}
        return await self._run(fn)

    async def grant_tree_points(self, user_id: int, n: int) -> None:
        await self._run(lambda c: c.execute("UPDATE users SET tree_pts = tree_pts + ? WHERE user_id = ?", (n, user_id)))

    # ───────────── سحب العتاد والصناديق ─────────────
    @staticmethod
    def _insert_gear(conn: sqlite3.Connection, user_id: int, item: dict) -> int:
        cur = conn.execute(
            "INSERT INTO inventory (user_id, item_name, item_type, stat, stat_bonus, rarity, effect, gear_key) VALUES (?,?,?,?,?,?,?,?)",
            (user_id, item["name"], item["type"], item["stat"], item["bonus"], item["rarity"], item.get("effect", ""), item.get("gear_key", "")))
        return cur.lastrowid

    async def gear_pull(self, user_id: int, currency: str, count: int = 1, rng: random.Random | None = None) -> list[dict]:
        rng = rng or random.Random()
        if currency not in ("gold", "gems"):
            raise GameError("عملة غير صالحة.")
        if not 1 <= count <= 10:
            raise GameError("العدد بين 1 و10.")
        cost = (ht.GEAR_GOLD_COST if currency == "gold" else ht.GEAR_GEM_COST) * count

        def fn(conn):
            self._money(conn, user_id, currency, -cost, "gear_gacha", f"×{count}")
            pity = conn.execute("SELECT gear_pity FROM users WHERE user_id = ?", (user_id,)).fetchone()["gear_pity"]
            out = []
            for _ in range(count):
                item, pity = ht.roll_gear(pity, rng)
                item["item_id"] = self._insert_gear(conn, user_id, item)
                out.append(item)
            conn.execute("UPDATE users SET gear_pity = ?, gear_pulls = gear_pulls + ? WHERE user_id = ?", (pity, count, user_id))
            self._bump(conn, user_id, "gear", count)
            for it in out:
                it["pity"], it["cost"] = pity, cost
            return out
        return await self._run(fn)

    async def open_crates(self, user_id: int, count: int = 1, rng: random.Random | None = None) -> list[dict]:
        rng = rng or random.Random()

        def fn(conn):
            have = conn.execute("SELECT crates FROM users WHERE user_id = ?", (user_id,)).fetchone()["crates"]
            if have < 1:
                raise GameError("ما عندك صناديق عتاد. تحصل عليها من مهام العصابة الأسبوعية والسوق الأسود.")
            n = min(count, have)
            conn.execute("UPDATE users SET crates = crates - ? WHERE user_id = ?", (n, user_id))
            out = []
            for _ in range(n):
                item, _p = ht.roll_gear(0, rng, min_rarity=ht.CRATE_MIN_RARITY, legend_chance=ht.CRATE_LEGEND_CHANCE)
                item["item_id"] = self._insert_gear(conn, user_id, item)
                out.append(item)
            return out
        return await self._run(fn)

    async def give_gear(self, user_id: int, gear: dict, count: int = 1) -> list[dict]:
        def fn(conn):
            out = []
            for _ in range(count):
                item = ht.gear_item(gear)
                item["item_id"] = self._insert_gear(conn, user_id, item)
                out.append(item)
            return out
        return await self._run(fn)

    # ───────────── سيطرة الطوابق وسجل الانتقام ─────────────
    async def floor_holder(self, floor: int, exclude_id: int | None = None) -> dict | None:
        """المسيطر الحالي على الطابق (مع إحصائياته الكاملة) أو None إن لم يوجد أو كان هو نفسه."""
        def fn(conn):
            r = conn.execute("SELECT holder_id, since FROM floors WHERE floor = ?", (floor,)).fetchone()
            if not r or not r["holder_id"] or r["holder_id"] == exclude_id:
                return None
            u = self._user_with_totals(conn, r["holder_id"])
            if u is None:
                return None
            u["held_since"] = r["since"]
            u["online"] = _now() - (u["last_seen"] or 0) <= g.ONLINE_WINDOW
            return u
        return await self._run(fn)

    async def floors_held(self, user_id: int) -> list[int]:
        return await self._run(lambda c: [r["floor"] for r in c.execute(
            "SELECT floor FROM floors WHERE holder_id = ? ORDER BY floor DESC", (user_id,))])

    async def revenge_open(self, user_id: int) -> list[dict]:
        def fn(conn):
            conn.execute("UPDATE revenge SET status = 'expired' WHERE status = 'open' AND ts < ?", (_now() - g.REVENGE_HOURS * 3600,))
            rows = conn.execute(
                "SELECT r.*, u.username AS taker_name FROM revenge r LEFT JOIN users u ON u.user_id = r.taker_id "
                "WHERE r.victim_id = ? AND r.status = 'open' ORDER BY r.ts DESC", (user_id,)).fetchall()
            out = []
            for r in rows:
                h = conn.execute("SELECT holder_id FROM floors WHERE floor = ?", (r["floor"],)).fetchone()
                if h and h["holder_id"] == user_id:      # استعدت الطابق بالفعل
                    conn.execute("UPDATE revenge SET status = 'done' WHERE id = ?", (r["id"],))
                    continue
                d = dict(r)
                d["left"] = max(0, r["ts"] + g.REVENGE_HOURS * 3600 - _now())
                out.append(d)
            return out
        return await self._run(fn)

    async def revenge_unnotified(self) -> list[dict]:
        """خسائر الطوابق التي لم يُبلَّغ أصحابها بعد (تُرسل كإشعار تلقائي)."""
        def fn(conn):
            rows = [dict(r) for r in conn.execute(
                "SELECT r.*, v.username AS victim_name, t.username AS taker_name FROM revenge r "
                "LEFT JOIN users v ON v.user_id = r.victim_id LEFT JOIN users t ON t.user_id = r.taker_id "
                "WHERE r.notified = 0 AND r.status = 'open'")]
            for r in rows:
                conn.execute("UPDATE revenge SET notified = 1 WHERE id = ?", (r["id"],))
            return rows
        return await self._run(fn)

    async def revenge_win(self, user_id: int, revenge_id: int, gold: int) -> dict:
        def fn(conn):
            r = conn.execute("SELECT * FROM revenge WHERE id = ? AND victim_id = ?", (revenge_id, user_id)).fetchone()
            if r is None or r["status"] != "open":
                raise GameError("هذا الانتقام لم يعد متاحاً.")
            usurped, new_id = self._take_floor(conn, user_id, r["floor"])
            conn.execute("UPDATE revenge SET status = 'done' WHERE id = ?", (revenge_id,))
            self._money(conn, user_id, "gold", gold, "revenge", f"الطابق {r['floor']}")
            return {"floor": r["floor"], "usurped": usurped, "revenge_id": new_id, "gold": gold}
        return await self._run(fn)

    # ───────────── العصابات ─────────────
    @staticmethod
    def _gang_row(conn, user_id: int) -> tuple[dict, dict]:
        u = conn.execute("SELECT user_id, guild_id, gang_role, username FROM users WHERE user_id = ?", (user_id,)).fetchone()
        if not u or not u["guild_id"]:
            raise GameError("أنت لست في عصابة.")
        gd = conn.execute("SELECT * FROM guilds WHERE guild_id = ?", (u["guild_id"],)).fetchone()
        return dict(u), dict(gd)

    async def create_guild(self, user_id: int, name: str, server_id: int = 0) -> dict:
        name = " ".join(name.split())
        if not ht.GANG_NAME_MIN <= len(name) <= ht.GANG_NAME_MAX:
            raise GameError(f"اسم العصابة بين {ht.GANG_NAME_MIN} و{ht.GANG_NAME_MAX} حرفاً.")

        def fn(conn):
            u = conn.execute("SELECT guild_id, floor, gold, gems FROM users WHERE user_id = ?", (user_id,)).fetchone()
            if u["guild_id"]:
                raise GameError("أنت عضو في عصابة بالفعل. اخرج منها أولاً.")
            if u["floor"] < ht.GANG_MIN_FLOOR:
                raise GameError(f"تأسيس العصابة يتطلب الوصول إلى الطابق {ht.GANG_MIN_FLOOR} (أنت في {u['floor']}).")
            if u["gold"] < ht.GANG_COST_GOLD or u["gems"] < ht.GANG_COST_GEMS:
                raise GameError(f"تأسيس العصابة يكلّف {ht.GANG_COST_GOLD:,} 💰 و{ht.GANG_COST_GEMS} 💎 (رصيدك {u['gold']:,} 💰 / {u['gems']} 💎).")
            try:
                cur = conn.execute("INSERT INTO guilds (guild_name, leader_id, server_id, created_ts) VALUES (?,?,?,?)",
                                   (name, user_id, server_id, _now()))
            except sqlite3.IntegrityError:
                raise GameError("هذا الاسم مستخدم. اختر اسماً آخر.") from None
            self._money(conn, user_id, "gold", -ht.GANG_COST_GOLD, "gang_create", name)
            self._money(conn, user_id, "gems", -ht.GANG_COST_GEMS, "gang_create", name)
            conn.execute("UPDATE users SET guild_id = ?, gang_role = 'leader' WHERE user_id = ?", (cur.lastrowid, user_id))
            conn.execute("DELETE FROM gang_requests WHERE user_id = ?", (user_id,))
            return {"gang_id": cur.lastrowid, "name": name}
        return await self._run(fn)

    async def gang_set_roles(self, gang_id: int, leader_role: int, member_role: int) -> None:
        await self._run(lambda c: c.execute("UPDATE guilds SET leader_role = ?, member_role = ? WHERE guild_id = ?",
                                            (leader_role, member_role, gang_id)))

    async def join_guild(self, user_id: int, name: str) -> dict:
        """طلب انضمام: يقبله الزعيم أو النائب بالأمر «عصابة قبول @لاعب»."""
        def fn(conn):
            if conn.execute("SELECT guild_id FROM users WHERE user_id = ?", (user_id,)).fetchone()["guild_id"]:
                raise GameError("أنت عضو في عصابة بالفعل.")
            gd = conn.execute("SELECT * FROM guilds WHERE guild_name = ?", (" ".join(name.split()),)).fetchone()
            if gd is None:
                raise GameError("ما لقيت عصابة بهذا الاسم.")
            n = conn.execute("SELECT COUNT(*) AS c FROM users WHERE guild_id = ?", (gd["guild_id"],)).fetchone()["c"]
            if n >= ht.GANG_MAX_MEMBERS:
                raise GameError("العصابة ممتلئة.")
            conn.execute("INSERT OR REPLACE INTO gang_requests (user_id, gang_id, ts) VALUES (?,?,?)", (user_id, gd["guild_id"], _now()))
            return {"name": gd["guild_name"], "gang_id": gd["guild_id"], "leader_id": gd["leader_id"]}
        return await self._run(fn)

    async def gang_accept(self, actor_id: int, target_id: int) -> dict:
        def fn(conn):
            me, gd = self._gang_row(conn, actor_id)
            if me["gang_role"] not in ("leader", "deputy"):
                raise GameError("قبول الأعضاء للزعيم والنائب فقط.")
            req = conn.execute("SELECT 1 FROM gang_requests WHERE user_id = ? AND gang_id = ?", (target_id, gd["guild_id"])).fetchone()
            if not req:
                raise GameError("هذا اللاعب لم يطلب الانضمام لعصابتك.")
            t = conn.execute("SELECT guild_id, username FROM users WHERE user_id = ?", (target_id,)).fetchone()
            if t is None:
                raise GameError("اللاعب غير مسجّل في اللعبة.")
            if t["guild_id"]:
                conn.execute("DELETE FROM gang_requests WHERE user_id = ?", (target_id,))
                raise GameError("هذا اللاعب انضم لعصابة أخرى.")
            n = conn.execute("SELECT COUNT(*) AS c FROM users WHERE guild_id = ?", (gd["guild_id"],)).fetchone()["c"]
            if n >= ht.GANG_MAX_MEMBERS:
                raise GameError("العصابة ممتلئة.")
            conn.execute("UPDATE users SET guild_id = ?, gang_role = 'member' WHERE user_id = ?", (gd["guild_id"], target_id))
            conn.execute("DELETE FROM gang_requests WHERE user_id = ?", (target_id,))
            return {"name": gd["guild_name"], "gang_id": gd["guild_id"], "member_role": gd["member_role"], "target_name": t["username"]}
        return await self._run(fn)

    async def gang_kick(self, actor_id: int, target_id: int) -> dict:
        def fn(conn):
            me, gd = self._gang_row(conn, actor_id)
            if me["gang_role"] not in ("leader", "deputy"):
                raise GameError("الطرد للزعيم والنائب فقط.")
            if target_id == actor_id:
                raise GameError("لا تطرد نفسك. استخدم «عصابة مغادرة».")
            t = conn.execute("SELECT guild_id, gang_role, username FROM users WHERE user_id = ?", (target_id,)).fetchone()
            if not t or t["guild_id"] != gd["guild_id"]:
                raise GameError("هذا اللاعب ليس في عصابتك.")
            if t["gang_role"] == "leader" or (t["gang_role"] == "deputy" and me["gang_role"] != "leader"):
                raise GameError("لا تملك صلاحية طرد هذا العضو.")
            conn.execute("UPDATE users SET guild_id = NULL, gang_role = 'member' WHERE user_id = ?", (target_id,))
            return {"name": gd["guild_name"], "gang_id": gd["guild_id"], "leader_role": gd["leader_role"],
                    "member_role": gd["member_role"], "target_name": t["username"]}
        return await self._run(fn)

    async def gang_set_role(self, actor_id: int, target_id: int, role: str) -> dict:
        if role not in ("deputy", "member"):
            raise GameError("الرتبة: نائب أو عضو.")

        def fn(conn):
            me, gd = self._gang_row(conn, actor_id)
            if me["gang_role"] != "leader":
                raise GameError("تعيين الرتب للزعيم فقط.")
            t = conn.execute("SELECT guild_id, gang_role, username FROM users WHERE user_id = ?", (target_id,)).fetchone()
            if not t or t["guild_id"] != gd["guild_id"] or target_id == actor_id:
                raise GameError("اختر عضواً آخر من عصابتك.")
            conn.execute("UPDATE users SET gang_role = ? WHERE user_id = ?", (role, target_id))
            return {"name": gd["guild_name"], "role": role, "target_name": t["username"]}
        return await self._run(fn)

    async def leave_guild(self, user_id: int) -> dict:
        def fn(conn):
            me, gd = self._gang_row(conn, user_id)
            conn.execute("UPDATE users SET guild_id = NULL, gang_role = 'member' WHERE user_id = ?", (user_id,))
            res = {"name": gd["guild_name"], "gang_id": gd["guild_id"], "leader_role": gd["leader_role"], "member_role": gd["member_role"],
                   "was_leader": gd["leader_id"] == user_id, "new_leader": None, "disbanded": False}
            if gd["leader_id"] == user_id:
                heir = conn.execute(
                    "SELECT user_id, username FROM users WHERE guild_id = ? ORDER BY (gang_role = 'deputy') DESC, level DESC LIMIT 1",
                    (gd["guild_id"],)).fetchone()
                if heir:
                    conn.execute("UPDATE guilds SET leader_id = ? WHERE guild_id = ?", (heir["user_id"], gd["guild_id"]))
                    conn.execute("UPDATE users SET gang_role = 'leader' WHERE user_id = ?", (heir["user_id"],))
                    res["new_leader"] = heir["user_id"]
                else:
                    conn.execute("DELETE FROM guilds WHERE guild_id = ?", (gd["guild_id"],))
                    conn.execute("DELETE FROM gang_requests WHERE gang_id = ?", (gd["guild_id"],))
                    res["disbanded"] = True
            return res
        return await self._run(fn)

    async def gang_deposit(self, user_id: int, currency: str, amount: int) -> dict:
        if currency not in ("gold", "gems"):
            raise GameError("العملة: ذهب أو جواهر.")
        if amount < (ht.GANG_DEPOSIT_MIN if currency == "gold" else 1):
            raise GameError(f"أقل مبلغ للإيداع {ht.GANG_DEPOSIT_MIN if currency == 'gold' else 1}.")

        def fn(conn):
            _me, gd = self._gang_row(conn, user_id)
            self._money(conn, user_id, currency, -amount, "gang_deposit", gd["guild_name"])
            col = "gold" if currency == "gold" else "gems"
            conn.execute(f"UPDATE guilds SET {col} = {col} + ? WHERE guild_id = ?", (amount, gd["guild_id"]))
            bal = conn.execute(f"SELECT {col} AS b FROM guilds WHERE guild_id = ?", (gd["guild_id"],)).fetchone()["b"]
            return {"name": gd["guild_name"], "currency": currency, "amount": amount, "treasury": bal}
        return await self._run(fn)

    async def guild_info(self, user_id: int) -> dict | None:
        def fn(conn):
            r = conn.execute("SELECT guild_id, gang_role FROM users WHERE user_id = ?", (user_id,)).fetchone()
            if not r or not r["guild_id"]:
                return None
            gid = r["guild_id"]
            gd = dict(conn.execute("SELECT * FROM guilds WHERE guild_id = ?", (gid,)).fetchone())
            gd["members"] = [dict(x) for x in conn.execute(
                "SELECT user_id, username, level, floor, gang_role FROM users WHERE guild_id = ? "
                "ORDER BY (gang_role = 'leader') DESC, (gang_role = 'deputy') DESC, level DESC", (gid,))]
            gd["max_members"] = ht.GANG_MAX_MEMBERS
            gd["my_role"] = r["gang_role"]
            gd["requests"] = [dict(x) for x in conn.execute(
                "SELECT q.user_id, u.username, u.level, u.floor FROM gang_requests q JOIN users u ON u.user_id = q.user_id "
                "WHERE q.gang_id = ? ORDER BY q.ts", (gid,))]
            gd["missions"] = self._ensure_gang_missions(conn, gid, self._week())
            contrib = {x["user_id"]: x for x in conn.execute(
                "SELECT user_id, points, damage, wins FROM gang_contrib WHERE gang_id = ? AND week = ?", (gid, self._week()))}
            for m in gd["members"]:
                c = contrib.get(m["user_id"])
                m["points"] = (c["points"] if c else 0)
            w = self._active_war(conn, gid)
            if w:
                pts = {x["user_id"]: x["points"] for x in conn.execute("SELECT user_id, points FROM war_points WHERE war_id = ?", (w["war_id"],))}
                for m in gd["members"]:
                    m["war_points"] = pts.get(m["user_id"], 0)
                gd["war"] = "في حرب!"
            return gd
        return await self._run(fn)

    async def top_gangs(self, limit: int = 10) -> list[dict]:
        return await self._run(lambda c: [dict(r) for r in c.execute(
            "SELECT g.guild_id, g.guild_name AS name, g.score, g.gold, "
            "(SELECT COUNT(*) FROM users u WHERE u.guild_id = g.guild_id) AS members FROM guilds g ORDER BY g.score DESC LIMIT ?", (limit,))])

    @staticmethod
    def _steal_treasury(conn, win_gid: int, lose_gid: int, war_id: int) -> dict:
        """الفائزة تسلب 15%-20% من خزينة الخاسرة (الذهب والجواهر) فوراً."""
        pct = random.Random(war_id * 31 + 7).uniform(*ht.STEAL_PCT)
        lose = conn.execute("SELECT gold, gems FROM guilds WHERE guild_id = ?", (lose_gid,)).fetchone()
        if lose is None:
            return {"gold": 0, "gems": 0, "pct": pct}
        gold, gems = int(lose["gold"] * pct), int(lose["gems"] * pct)
        conn.execute("UPDATE guilds SET gold = gold - ?, gems = gems - ? WHERE guild_id = ?", (gold, gems, lose_gid))
        conn.execute("UPDATE guilds SET gold = gold + ?, gems = gems + ? WHERE guild_id = ?", (gold, gems, win_gid))
        return {"gold": gold, "gems": gems, "pct": pct}

    # ───────────── المهام الأسبوعية (فردية) ─────────────
    async def weekly(self, user_id: int) -> list[dict]:
        return await self._run(lambda c: self._ensure_weekly(c, user_id, self._week()))

    async def claim_weekly(self, user_id: int) -> dict:
        def fn(conn):
            week = self._week()
            rows = self._ensure_weekly(conn, user_id, week)
            gold = gems = n = 0
            for m in rows:
                if m["progress"] >= m["target"] and not m["claimed"]:
                    conn.execute("UPDATE weekly_missions SET claimed = 1 WHERE user_id = ? AND week = ? AND slot = ?", (user_id, week, m["slot"]))
                    gold, gems, n = gold + m["gold"], gems + m["gems"], n + 1
            if not n:
                raise GameError("لا توجد مهام أسبوعية مكتملة لاستلامها الآن.")
            rows = self._ensure_weekly(conn, user_id, week)
            bonus = 0
            if all(m["claimed"] for m in rows) and conn.execute(
                    "SELECT 1 FROM ledger WHERE user_id = ? AND reason = 'weekly' AND note = ?", (user_id, f"bonus w{week}")).fetchone() is None:
                bonus = ht.WEEKLY_BONUS_GEMS
                gems += bonus
            if gold:
                self._money(conn, user_id, "gold", gold, "weekly")
            if gems:
                self._money(conn, user_id, "gems", gems, "weekly", f"bonus w{week}" if bonus else "")
            return {"claimed": n, "gold": gold, "gems": gems, "bonus": bonus}
        return await self._run(fn)

    # ───────────── السوق الأسود ─────────────
    async def market_state(self, user_id: int | None = None) -> dict:
        def fn(conn):
            now = _now()
            fu = conn.execute("SELECT v FROM settings WHERE scope = 0 AND k = 'bm_force'").fetchone()
            win = ht.market_window(now, self.tz_offset(), float(fu["v"]) if fu and fu["v"] else 0.0)
            stock = ht.market_stock(win["period"])
            for o in stock:
                sold = conn.execute("SELECT COALESCE(SUM(qty), 0) AS s FROM market_buys WHERE period = ? AND slot = ?",
                                    (win["period"], o["slot"])).fetchone()["s"]
                o["left"] = max(0, o["qty"] - sold)
                mine = 0
                if user_id:
                    r = conn.execute("SELECT qty FROM market_buys WHERE user_id = ? AND period = ? AND slot = ?",
                                     (user_id, win["period"], o["slot"])).fetchone()
                    mine = r["qty"] if r else 0
                o["mine"] = mine
            return {**win, "stock": stock, "now": now}
        return await self._run(fn)

    @staticmethod
    def tz_offset() -> float:
        import database
        return database.TZ_OFFSET_H

    async def market_force(self, hours: float) -> None:
        val = str(_now() + hours * 3600) if hours > 0 else "0"
        await self.set_setting(0, "bm_force", val)

    async def market_buy(self, user_id: int, slot: int) -> dict:
        def fn(conn):
            now = _now()
            fu = conn.execute("SELECT v FROM settings WHERE scope = 0 AND k = 'bm_force'").fetchone()
            win = ht.market_window(now, self.tz_offset(), float(fu["v"]) if fu and fu["v"] else 0.0)
            if not win["open"]:
                raise GameError("السوق الأسود مغلق الآن.")
            stock = ht.market_stock(win["period"])
            if not 0 <= slot < len(stock):
                raise GameError("عرض غير موجود.")
            o = stock[slot]
            sold = conn.execute("SELECT COALESCE(SUM(qty), 0) AS s FROM market_buys WHERE period = ? AND slot = ?", (win["period"], slot)).fetchone()["s"]
            if sold >= o["qty"]:
                raise GameError("نفدت كمية هذا العرض.")
            mine = conn.execute("SELECT qty FROM market_buys WHERE user_id = ? AND period = ? AND slot = ?", (user_id, win["period"], slot)).fetchone()
            if mine and mine["qty"] >= ht.MARKET_MAX_BUY:
                raise GameError("اشتريت هذا العرض من قبل في هذه الفترة.")
            if o["gold"]:
                self._money(conn, user_id, "gold", -o["gold"], "black_market", o["name"])
            if o["gems"]:
                self._money(conn, user_id, "gems", -o["gems"], "black_market", o["name"])
            item = None
            if o["kind"] == "gear":
                item = ht.gear_item(ht.GEAR[o["key"]])
                item["item_id"] = self._insert_gear(conn, user_id, item)
            elif o["kind"] == "stone":
                conn.execute("UPDATE users SET tree_pts = tree_pts + ? WHERE user_id = ?", (o["n"] * ht.STONE_POINTS, user_id))
            else:
                conn.execute("UPDATE users SET crates = crates + 1 WHERE user_id = ?", (user_id,))
            conn.execute("INSERT INTO market_buys (user_id, period, slot, qty) VALUES (?,?,?,1) "
                         "ON CONFLICT(user_id, period, slot) DO UPDATE SET qty = qty + 1", (user_id, win["period"], slot))
            return {"offer": o, "item": item}
        return await self._run(fn)

    # ───────────── المواسم ─────────────
    @staticmethod
    def _active_season(conn) -> dict:
        r = conn.execute("SELECT * FROM seasons WHERE status = 'active' ORDER BY season_id DESC LIMIT 1").fetchone()
        if r is None:
            now = _now()
            cur = conn.execute("INSERT INTO seasons (start_ts, end_ts, status, name) VALUES (?,?, 'active', '')",
                               (now, now + ht.SEASON_DAYS * 86400))
            conn.execute("UPDATE seasons SET name = ? WHERE season_id = ?", (f"الموسم {cur.lastrowid}", cur.lastrowid))
            r = conn.execute("SELECT * FROM seasons WHERE season_id = ?", (cur.lastrowid,)).fetchone()
        return dict(r)

    async def season_current(self) -> dict:
        def fn(conn):
            s = self._active_season(conn)
            s["left"] = max(0, s["end_ts"] - _now())
            return s
        return await self._run(fn)

    async def finish_due_season(self, force: bool = False) -> dict | None:
        """ينهي الموسم عند انتهاء مدته (أو بالإجبار): جوائز وألقاب للأبطال والعصابة الأولى، ثم تصفير الطوابق."""
        def fn(conn):
            s = self._active_season(conn)
            now = _now()
            if not force and s["end_ts"] > now:
                return None
            players = [dict(r) for r in conn.execute(
                "SELECT user_id, username, floor, level FROM users WHERE wins > 0 OR floor > 1 "
                "ORDER BY floor DESC, level DESC, xp DESC LIMIT ?", (ht.SEASON_TOP_N,))]
            conn.execute("UPDATE users SET title = '' WHERE title != ''")
            hall = []
            for rank, p in enumerate(players, 1):
                gold, gems, title = ht.SEASON_PLAYER_REWARDS[rank - 1] if rank <= len(ht.SEASON_PLAYER_REWARDS) else ht.SEASON_TOP_REWARD
                self._money(conn, p["user_id"], "gold", gold, "season", s["name"])
                self._money(conn, p["user_id"], "gems", gems, "season", s["name"])
                if rank <= len(ht.SEASON_PLAYER_REWARDS):
                    conn.execute("UPDATE users SET title = ? WHERE user_id = ?", (title, p["user_id"]))
                p.update({"rank": rank, "gold": gold, "gems": gems, "title": title})
                conn.execute("INSERT INTO season_hall (season_id, kind, rank, ref_id, name, title, floor, level) VALUES (?,?,?,?,?,?,?,?)",
                             (s["season_id"], "player", rank, p["user_id"], p["username"], title, p["floor"], p["level"]))
                hall.append(p)
            gang = None
            top = conn.execute("SELECT * FROM guilds WHERE score > 0 ORDER BY score DESC, guild_id LIMIT 1").fetchone()
            if top:
                gold, gems, title = ht.SEASON_GANG_REWARD
                conn.execute("UPDATE guilds SET gold = gold + ? WHERE guild_id = ?", (gold, top["guild_id"]))
                mem = [r["user_id"] for r in conn.execute("SELECT user_id FROM users WHERE guild_id = ?", (top["guild_id"],))]
                for uid in mem:
                    self._money(conn, uid, "gems", gems, "season", s["name"])
                    conn.execute("UPDATE users SET title = CASE WHEN title = '' OR title IS NULL THEN ? ELSE title END WHERE user_id = ?", (title, uid))
                gang = {"gang_id": top["guild_id"], "name": top["guild_name"], "score": top["score"], "gold": gold, "gems": gems,
                        "title": title, "members": len(mem)}
                conn.execute("INSERT INTO season_hall (season_id, kind, rank, ref_id, name, title, floor, level) VALUES (?,?,?,?,?,?,?,?)",
                             (s["season_id"], "gang", 1, top["guild_id"], top["guild_name"], title, 0, top["score"]))
            # التصفير: الطوابق والسيطرة والانتقامات ونقاط العصابات (تبقى المستويات والعتاد والبطاقات)
            conn.execute("DELETE FROM floors")
            conn.execute("UPDATE revenge SET status = 'expired' WHERE status = 'open'")
            conn.execute("UPDATE users SET floor = 1")
            conn.execute("UPDATE guilds SET score = 0")
            conn.execute("UPDATE seasons SET status = 'done', end_ts = ? WHERE season_id = ?", (now, s["season_id"]))
            new = self._active_season(conn)
            return {"season": s, "players": hall, "gang": gang, "new": new}
        return await self._run(fn)

    async def season_hall(self, season_id: int | None = None) -> dict:
        def fn(conn):
            if season_id is None:
                r = conn.execute("SELECT season_id FROM season_hall ORDER BY season_id DESC LIMIT 1").fetchone()
                sid = r["season_id"] if r else None
            else:
                sid = season_id
            if sid is None:
                return {"season_id": None, "players": [], "gang": None}
            rows = [dict(r) for r in conn.execute("SELECT * FROM season_hall WHERE season_id = ? ORDER BY kind, rank", (sid,))]
            name = conn.execute("SELECT name FROM seasons WHERE season_id = ?", (sid,)).fetchone()
            return {"season_id": sid, "name": name["name"] if name else f"الموسم {sid}",
                    "players": [r for r in rows if r["kind"] == "player"], "gang": next((r for r in rows if r["kind"] == "gang"), None)}
        return await self._run(fn)

    # ───────────── أوامر الإدارة ─────────────
    async def admin_set_floor(self, user_id: int, floor: int) -> dict:
        if not 1 <= floor <= g.MAX_FLOOR:
            raise GameError(f"الطابق بين 1 و{g.MAX_FLOOR}.")

        def fn(conn):
            if conn.execute("SELECT 1 FROM users WHERE user_id = ?", (user_id,)).fetchone() is None:
                raise GameError("هذا اللاعب غير مسجّل في اللعبة.")
            old = conn.execute("SELECT floor FROM users WHERE user_id = ?", (user_id,)).fetchone()["floor"]
            conn.execute("UPDATE users SET floor = ? WHERE user_id = ?", (floor, user_id))
            return {"old": old, "new": floor}
        return await self._run(fn)

    async def admin_reset(self, user_id: int) -> None:
        def fn(conn):
            if conn.execute("SELECT 1 FROM users WHERE user_id = ?", (user_id,)).fetchone() is None:
                raise GameError("هذا اللاعب غير مسجّل في اللعبة.")
            conn.execute("DELETE FROM floors WHERE holder_id = ?", (user_id,))
            conn.execute("UPDATE revenge SET status = 'expired' WHERE victim_id = ? AND status = 'open'", (user_id,))
            conn.execute(
                "UPDATE users SET level = 1, xp = 0, floor = 1, hp = 100, max_hp = 100, atk = 15, def = 5, speed = 10, "
                "nen_type = 'None', vow = '', stat_points = 0, tree = '', tree_pts = 0, wins = 0, losses = 0, hp_updated = ?, "
                "boss_used = 0, hunts = 0, title = '' WHERE user_id = ?", (_now(), user_id))
        await self._run(fn)
