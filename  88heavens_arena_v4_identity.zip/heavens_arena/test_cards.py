"""اختبارات نظام الاستدعاء والبطاقات والفريق (بدون discord ولا شبكة).  شغّلها:  python test_cards.py"""
from __future__ import annotations

import asyncio
import io
import os
import random
import tempfile
from collections import Counter
from pathlib import Path

from PIL import Image

import anime_images as A
import cards as cd
import game as g
import render as R
from database import Database
from game import GameError


def fighter(**kw) -> g.Fighter:
    base = dict(name="x", hp=100, max_hp=100, atk=20, defense=5, speed=10, nen=None, aura=60, max_aura=60)
    base.update(kw)
    return g.Fighter(**base)


def jpeg(color=(120, 60, 200), size=(300, 400)) -> bytes:
    buf = io.BytesIO()
    Image.new("RGB", size, color).save(buf, "JPEG")
    return buf.getvalue()


async def with_db(fn):
    d = tempfile.mkdtemp()
    db = Database(os.path.join(d, "t.db"))
    await db.connect()
    try:
        await fn(db, d)
    finally:
        await db.close()


# ───────────── القائمة والمنطق الصرف ─────────────
def test_roster():
    assert len(cd.CARDS) == 31 and len(set(cd.ORDER)) == 31
    for c in cd.CARDS.values():
        assert c["role"] in cd.ROLES and 0 <= c["r"] <= 3 and c["name"] and c["en"] and c["skill"]
        assert cd.find(c["name"])["key"] == c["key"]                       # الاسم الكامل يجد البطاقة نفسها
    assert cd.find("غون")["key"] == "gon" and cd.find("Gon")["key"] == "gon" and cd.find("zzz") is None
    assert cd.find("إيزاك")["key"] == cd.find("ايزاك")["key"]               # تطبيع الهمزات
    assert all(cd.CARDS[a]["r"] >= cd.CARDS[b]["r"] for a, b in zip(cd.ORDER, cd.ORDER[1:]))   # الأعلى ندرة أولاً
    assert [cd.stars_for(n) for n in (1, 2, 5, 6, 99)] == [0, 1, 4, 5, 5]
    s0, s5 = cd.card_stats("gon", 0), cd.card_stats("gon", cd.MAX_STARS)
    assert all(s5[k] > s0[k] for k in s0)
    assert cd.team_bonus([]) == {"atk": 0, "def": 0, "speed": 0, "hp": 0}


def test_roll_rates_and_pity():
    rng = random.Random(1)
    n = 20000
    cnt, pity = Counter(), 0
    for _ in range(n):
        c, pity = cd.roll_card(pity, rng)
        cnt[c["r"]] += 1
    assert 0.55 < cnt[0] / n < 0.62 and 0.27 < cnt[1] / n < 0.33 and cnt[3] / n < 0.04, cnt
    # الضمان: لا تتجاوز سلسلة بلا ملحمي عتبة الضمان أبداً
    rng, pity, since, worst = random.Random(3), 0, 0, 0
    for _ in range(5000):
        c, pity = cd.roll_card(pity, rng)
        since = 0 if c["r"] >= 2 else since + 1
        worst = max(worst, since)
    assert worst < cd.SUMMON_PITY, worst


# ───────────── قاعدة البيانات ─────────────
async def t_summon_db():
    async def body(db, d):
        await db.ensure_user(1, "a")
        rng = random.Random(4)
        res = await db.summon(1, "gems", 1, rng)                       # يبدأ اللاعب بـ 10 جواهر = استدعاء واحد
        assert len(res["cards"]) == 1 and res["cost"] == cd.SUMMON_GEM_COST and res["cards"][0]["is_new"]
        u = await db.get_user(1)
        assert u["gems"] == 0 and u["summons"] == 1
        try:
            await db.summon(1, "gems", 1, rng); assert False
        except GameError:
            pass
        assert (await db.get_user(1))["summons"] == 1                  # الفشل لا يغيّر شيئاً
        for bad in (("bits", 1), ("gold", 0), ("gold", 11)):
            try:
                await db.summon(1, *bad); assert False, bad
            except GameError:
                pass
        # ذهب: عشرة استدعاءات دفعة واحدة
        await db.add_gold(1, 10000)
        gold0 = (await db.get_user(1))["gold"]
        res = await db.summon(1, "gold", 10, rng)
        assert res["cost"] == 10 * cd.SUMMON_GOLD_COST and len(res["cards"]) == 10
        mine = await db.cards_of(1)
        assert mine and all(m["key"] in cd.CARDS for m in mine)
        assert [cd.CARDS[m["key"]]["r"] for m in mine] == sorted((cd.CARDS[m["key"]]["r"] for m in mine), reverse=True)
        assert sum(m["copies"] for m in mine) <= 11
        assert (await db.get_user(1))["gold"] == gold0 - res["cost"] + res["refund"]
        # التكرار: نجمة لكل نسخة، وبعد اكتمال النجوم تتحول النسخة لذهب
        await db.add_gold(1, 10_000_000)
        refunds, star_ups, cap = 0, 0, cd.MAX_STARS
        for _ in range(60):
            r = await db.summon(1, "gold", 10, rng)
            refunds += r["refund"]
            star_ups += sum(c["star_up"] for c in r["cards"])
            assert all(c["stars"] <= cap for c in r["cards"])
        assert star_ups > 0 and refunds > 0
        assert all(m["stars"] <= cap for m in await db.cards_of(1))
        # الدفتر يطابق الأرصدة (الصرف والاسترداد مسجّلان)
        u = await db.get_user(1)
        for cur in ("gold", "gems"):
            total = (await db._run(lambda c: c.execute("SELECT COALESCE(SUM(amount),0) s FROM ledger WHERE user_id=1 AND currency=?", (cur,)).fetchone()["s"]))
            assert 500 * (cur == "gold") + 10 * (cur == "gems") + total == u[cur], cur
        reasons = {r["reason"] for r in await db._run(lambda c: c.execute("SELECT DISTINCT reason FROM ledger").fetchall())}
        assert {"summon", "card_refund"} <= reasons and all(r in g.REASON_AR for r in reasons if r in ("summon", "card_refund"))
        # الاستدعاء يحتسب في مهمة السحب اليومية
        await db.missions(1)
        await db._run(lambda c: c.execute("UPDATE missions SET mkey = 'gacha', target = 50, progress = 0 WHERE user_id = 1 AND slot = (SELECT MIN(slot) FROM missions WHERE user_id = 1)"))
        await db.summon(1, "gold", 3, rng)
        assert 3 in [m["progress"] for m in await db.missions(1) if m["mkey"] == "gacha"]
    await with_db(body)


async def t_summon_concurrency():
    async def body(db, d):
        await db.ensure_user(1, "a")                                   # 10 جواهر = استدعاء واحد فقط
        rng = random.Random(9)
        res = await asyncio.gather(*(db.summon(1, "gems", 1, rng) for _ in range(5)), return_exceptions=True)
        assert sum(isinstance(r, dict) for r in res) == 1 and sum(isinstance(r, GameError) for r in res) == 4
        assert (await db.get_user(1))["gems"] == 0
    await with_db(body)


async def t_team_and_bonus():
    async def body(db, d):
        await db.ensure_user(1, "a")
        base = await db.get_user(1)
        assert base["team_cards"] == [] and base["team_bonus"]["atk"] == 0
        try:
            await db.set_team(1, ["gon"]); assert False                # لا يملكها بعد
        except GameError:
            pass
        await db._run(lambda c: c.executemany("INSERT INTO cards (user_id, card_key, copies, first_ts) VALUES (1,?,?,0)",
                                              [("gon", 3), ("killua", 1), ("kurapika", 1), ("leorio", 1)]))
        for bad in (["nope"], ["gon", "killua", "kurapika", "leorio"]):
            try:
                await db.set_team(1, bad); assert False, bad
            except GameError:
                pass
        assert await db.set_team(1, ["gon", "gon", "killua"]) == ["gon", "killua"]    # المكرر يُحذف
        u = await db.get_user(1)
        exp = cd.team_bonus([("gon", 3), ("killua", 1)])
        assert [m["key"] for m in u["team_cards"]] == ["gon", "killua"] and u["team_bonus"] == exp and exp["atk"] > 0
        assert u["t_atk"] == base["t_atk"] + exp["atk"] and u["t_def"] == base["t_def"] + exp["def"]
        assert u["t_hp"] == base["t_hp"] + exp["hp"] and u["t_speed"] == base["t_speed"] + exp["speed"]
        assert u["power"] > base["power"]
        f = g.fighter_from_user(u, "a")
        assert [m["key"] for m in f.team] == ["gon", "killua"] and f.assist_cd == 0 and f.atk == u["t_atk"]
        assert g.shadow_fighter(u).team                                  # ظل اللاعب يحمل فريقه أيضاً
        assert [m["key"] for m in g.fighter_view(f)["team"]] == ["gon", "killua"]
        await db.set_team(1, [])                                        # تفريغ الفريق يعيد الإحصائيات
        u = await db.get_user(1)
        assert u["t_atk"] == base["t_atk"] and u["team_cards"] == []
    await with_db(body)


async def t_migration_adds_card_columns():
    d = tempfile.mkdtemp()
    p = os.path.join(d, "old.db")
    import sqlite3
    con = sqlite3.connect(p)
    con.execute("CREATE TABLE users (user_id INTEGER PRIMARY KEY, username TEXT)")
    con.execute("INSERT INTO users VALUES (7, 'old')")
    con.commit(); con.close()
    db = Database(p)
    await db.connect()
    try:
        u = await db.get_user(7)
        assert u["team"] in ("", None) and u["summon_pity"] == 0 and u["summons"] == 0 and u["team_cards"] == []
        assert (await db.summon(7, "gems", 1, random.Random(1)))["cards"]
    finally:
        await db.close()


# ───────────── محرك القتال: نداء الفريق ─────────────
def team_of(*specs):
    return cd.team_fighters(list(specs))


def test_assist_engine():
    # مهاجم: يضرب الخصم، يبدأ التبريد، ويحتسب مرة
    p = fighter(is_player=True, team=team_of(("gon", 1)))
    b = g.Battle(p, fighter(hp=500, max_hp=500, defense=0, speed=1), random.Random(1))
    assert b.assist_usable() and not g.Battle(fighter(is_player=True), fighter(), random.Random(1)).assist_usable()
    b.play_round("assist")
    assert b.e.hp < 500 and b.assist_casts == 1 and not b.assist_usable()
    assert any(e["k"] == "assist" for e in b.ev) or any("🃏" in line for line in b.log)
    # التبريد: ينتهي بعد ASSIST_COOLDOWN جولات بالضبط
    for i in range(cd.ASSIST_COOLDOWN):
        assert not b.assist_usable(), i
        b.play_round("guard")
    assert b.assist_usable()
    b.play_round("assist")
    assert b.assist_casts == 2
    # النداء وهو غير جاهز لا يفعل شيئاً (يتحول إلى هجوم عادي)
    before = b.assist_casts
    b.play_round("assist")
    assert b.assist_casts == before
    # معالج: يرمّم الصحة ولا يتجاوز الحد الأقصى
    p = fighter(is_player=True, hp=40, team=team_of(("leorio", 0)))
    b = g.Battle(p, fighter(hp=500, max_hp=500, atk=1, speed=1), random.Random(2))
    b.play_round("assist")
    assert b.p.hp > 40 and b.p.hp <= b.p.max_hp
    # حامٍ: يرفع درع اللاعب
    tank = [k for k, c in cd.CARDS.items() if c["role"] == "tank"][0]
    b = g.Battle(fighter(is_player=True, team=team_of((tank, 0))), fighter(atk=1, speed=1), random.Random(3))
    b.p.speed = 99
    b._assist(b.p, b.e)
    assert b.p.shield_turns >= cd.ASSIST_SHIELD_TURNS[cd.CARDS[tank]["r"]]
    # مسيطر: احتمال الشلل مضاعف الصعوبة على الأسياد والزعماء
    ctrl = [k for k, c in cd.CARDS.items() if c["role"] == "controller" and c["r"] == 3][0]
    def stuns(sig: str) -> int:
        n = 0
        for s in range(400):
            bb = g.Battle(fighter(is_player=True, team=team_of((ctrl, 0))), fighter(hp=9999, max_hp=9999, sig_name=sig, sig_mult=1.5), random.Random(s))
            bb._assist(bb.p, bb.e)
            n += bb.e.stun_turns > 0
        return n
    normal, boss = stuns(""), stuns("ضربة")
    assert normal > boss * 1.3 > 0, (normal, boss)


def test_auto_battle_uses_team_and_ends():
    wins_team = wins_none = 0
    for s in range(60):
        e1, e2 = fighter(hp=260, max_hp=260, atk=22), fighter(hp=260, max_hp=260, atk=22)
        t = team_of(("gon", 2), ("killua", 1), ("kurapika", 0))
        b1 = g.Battle(fighter(is_player=True, team=t), e1, random.Random(s))
        b2 = g.Battle(fighter(is_player=True), e2, random.Random(s))
        for b in (b1, b2):
            while not b.over:
                b.play_round(b.suggest_action())
        wins_team += b1.winner == "player"
        wins_none += b2.winner == "player"
        assert b1.assist_casts >= 1
    assert wins_team > wins_none, (wins_team, wins_none)


# ───────────── الرسم ─────────────
def is_image(b: bytes) -> bool:
    return b[:8] == b"\x89PNG\r\n\x1a\n" or b[:3] == b"\xff\xd8\xff"


def test_render_cards():
    arts = {"gon": jpeg(), "killua": jpeg((30, 150, 90), (900, 400))}
    one = [{"key": "gon", "r": 3, "is_new": True, "stars": 0, "star_up": False, "refund": 0}]
    ten = [{"key": k, "r": cd.CARDS[k]["r"], "is_new": i % 2 == 0, "stars": i % 5, "star_up": i % 2 == 1, "refund": 400 * (i % 3 == 0)}
           for i, k in enumerate(cd.ORDER[:10])]
    for a in (arts, None):
        assert is_image(R.summon_result_card(one, 5, "gems", 10, "Ahmed", a))
        assert is_image(R.summon_result_card(ten, 29, "gold", 6000, "Ahmed", a))
        assert is_image(R.card_detail_card(cd.CARDS["gon"], (a or {}).get("gon"), 3, "Ahmed"))
        assert is_image(R.card_detail_card(cd.CARDS["gon"], (a or {}).get("gon"), 0, "Ahmed"))
        owned = {k: 1 + i for i, k in enumerate(cd.ORDER[:9])}
        for page in range(R.album_pages()):
            assert is_image(R.album_card(owned, page, "Ahmed", a, ["gon"]))
        assert is_image(R.team_card([{"key": "gon", "stars": 2}], cd.team_bonus([("gon", 3)]), "Ahmed", a))
        assert is_image(R.team_card([], cd.team_bonus([]), "Ahmed", a))
    assert R.album_pages() == 4
    # رقم صفحة خارج المدى لا يكسر الرسم
    assert is_image(R.album_card({}, 99, "x")) and is_image(R.album_card({}, -3, "x"))
    # بطاقة القتال مع شريط الفريق، بصور وبدونها
    p = g.fighter_view(fighter(is_player=True, team=team_of(("gon", 1), ("killua", 0))))
    e = g.fighter_view(fighter())
    assert is_image(R.battle_card("t", 1, p, e, ["a"], team_arts=arts))
    assert is_image(R.battle_card("t", 1, p, e, ["a"]))
    assert is_image(R.gacha_pack_card(3, "جاري الاستدعاء...", "🎴"))
    assert is_image(R.gacha_pack_card(1))


# ───────────── جلب صور البطاقات ─────────────
async def t_card_art_sources():
    d = tempfile.mkdtemp()
    hub = A.ImageHub(cache_dir=d, enabled=True)
    hub.local_dir = Path(tempfile.mkdtemp())
    gon = cd.CARDS["gon"]
    calls: list[str] = []
    A.wiki_lead_image = lambda api, name, width=700: (calls.append("wiki"), [])[1]
    A.jikan_character_exact = lambda name: (calls.append("jikan"), ["http://x/a.jpg"])[1]
    A.wiki_page_images = lambda api, name: (calls.append("pages"), [])[1]
    hub._download = lambda url: jpeg() if url.endswith("a.jpg") else None
    assert hub.card_art_cached("gon") is None
    data = await hub.card_art(gon, 5)
    assert data and is_image(data) and calls[0] == "wiki" and "jikan" in calls and "pages" not in calls
    assert (Path(d) / "cards" / "gon.jpg").exists() and hub.card_art_cached("gon") == data
    n = len(calls)
    assert await hub.card_art(gon, 5) == data and len(calls) == n          # الكاش: لا شبكة ثانية
    # فشل كل المصادر: يعيد None ولا يعيد المحاولة فوراً
    kil = cd.CARDS["killua"]
    A.jikan_character_exact = lambda name: (calls.append("jikan2"), [])[1]
    assert await hub.card_art(kil, 5) is None
    n = len(calls)
    assert await hub.card_art(kil, 5) is None and len(calls) == n
    # صورة يرفعها المالك يدوياً لها الأولوية على الكاش
    (hub.local_dir / "card_gon").mkdir()
    (hub.local_dir / "card_gon" / "mine.jpg").write_bytes(jpeg((1, 2, 3)))
    assert hub.card_art_cached("gon") != data and is_image(hub.card_art_cached("gon"))
    got = await hub.card_arts([gon, kil, gon], 5)
    assert set(got) == {"gon"}
    # معطّل: لا شبكة أبداً
    off = A.ImageHub(cache_dir=tempfile.mkdtemp(), enabled=False)
    assert await off.card_art(gon, 1) is None and await off.warm_cards([gon], 0) == 0


def main():
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("✓", name)
    for name, fn in list(globals().items()):
        if name.startswith("t_"):
            asyncio.run(fn())
            print("✓", name)
    print("\nكل اختبارات البطاقات نجحت")


if __name__ == "__main__":
    main()
